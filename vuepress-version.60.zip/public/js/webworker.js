onmessage = function (e) {
    console.log('e.data', e.data);

    postMessage('闭嘴,我知道了');
}