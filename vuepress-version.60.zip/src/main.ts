import { createApp } from 'vue';
import './theme/style.scss';
import AppClient from './plugins/client';
import App from './App.vue';

createApp(App)
    .use(AppClient, { isVue: true })
    .mount('#app');
