<template>
    <div>
        Hello, Vue Press ~~
    </div>
</template>

<script>
export default {
    name: "VuePress",
    data () {
        return {
            title: "Hello VuePress ~"
        };
    }
}
</script>