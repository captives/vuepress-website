---
home: true
sidebar: false
tagline: null
footer: <b1>captives.github.io</b1>
footerHtml: true
pageClass: 'poetry-home'
---

<!-- 注释： 使用样式 -->
<style lang="scss">
    .poetry-home {
        /* 文字竖排 */
        writing-mode: vertical-rl;
        header {
            margin-top: 20%;
            h1 {
                font-family: "华文行楷";
                font-size: 6rem;
            }
        }
    } 
</style>

<!-- 注释： 使用Vue全局组件 -->
<Poetry></Poetry>
