import { defineAsyncComponent } from 'vue'

export default {
  enhance: ({ app }) => {    
      app.component("Poetry", defineAsyncComponent(() => import("F:/github/vuepress-version.60/src/components/Poetry.vue"))),
      app.component("URLInput", defineAsyncComponent(() => import("F:/github/vuepress-version.60/src/components/URLInput.vue"))),
      app.component("VueSite", defineAsyncComponent(() => import("F:/github/vuepress-version.60/src/components/VueSite.vue"))),
      app.component("WindowBeforePrint", defineAsyncComponent(() => import("F:/github/vuepress-version.60/src/components/guide/WindowBeforePrint.vue"))),
      app.component("WindowEventChange", defineAsyncComponent(() => import("F:/github/vuepress-version.60/src/components/guide/WindowEventChange.vue"))),
      app.component("WindowEventStorage", defineAsyncComponent(() => import("F:/github/vuepress-version.60/src/components/guide/WindowEventStorage.vue"))),
      app.component("WindowVisibilityState", defineAsyncComponent(() => import("F:/github/vuepress-version.60/src/components/guide/WindowVisibilityState.vue")))
  },
}
