import { defineAsyncComponent, ref, readonly, reactive, defineComponent, onMounted, computed, h, inject, Transition, mergeProps, useSSRContext, provide, watch, onUnmounted, resolveComponent, unref, toRefs, withCtx, renderSlot, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, createCommentVNode, withDirectives, Fragment, renderList, vShow, nextTick, onBeforeUnmount, createSSRApp } from "vue";
import { isString, isArray, dedupeHead, resolveLocalePath, isLinkHttp, removeLeadingSlash, isFunction, isPlainObject, isLinkMailto, isLinkTel, removeEndingSlash } from "@vuepress/shared";
import { debounce } from "ts-debounce";
import { useRouter, useRoute, RouterView, createRouter, START_LOCATION, createMemoryHistory } from "vue-router";
import { setupDevtoolsPlugin } from "@vue/devtools-api";
import { ssrRenderAttrs, ssrRenderSlot, ssrInterpolate, ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrRenderSlotInner, ssrRenderAttr, ssrRenderStyle } from "vue/server-renderer";
import { usePreferredDark, useStorage, useToggle } from "@vueuse/core";
import ElementPlus from "element-plus";
const pagesData$1 = {
  // path: /markdown.html
  "v-7fdc6af1": () => import(
    /* webpackChunkName: "v-7fdc6af1" */
    "./assets/markdown.html-dae8d506.mjs"
  ).then(({ data }) => data),
  // path: /
  "v-8daa1a0e": () => import(
    /* webpackChunkName: "v-8daa1a0e" */
    "./assets/index.html-a346a028.mjs"
  ).then(({ data }) => data),
  // path: /user-profile.html
  "v-077d91b9": () => import(
    /* webpackChunkName: "v-077d91b9" */
    "./assets/user-profile.html-a5669e94.mjs"
  ).then(({ data }) => data),
  // path: /guide/favorites.html
  "v-18a03e64": () => import(
    /* webpackChunkName: "v-18a03e64" */
    "./assets/favorites.html-397a50c9.mjs"
  ).then(({ data }) => data),
  // path: /guide/frontend.html
  "v-5efb549b": () => import(
    /* webpackChunkName: "v-5efb549b" */
    "./assets/frontend.html-62d1e7b7.mjs"
  ).then(({ data }) => data),
  // path: /guide/getting-started.html
  "v-fb0f0066": () => import(
    /* webpackChunkName: "v-fb0f0066" */
    "./assets/getting-started.html-ef2b04e8.mjs"
  ).then(({ data }) => data),
  // path: /guide/
  "v-fffb8e28": () => import(
    /* webpackChunkName: "v-fffb8e28" */
    "./assets/index.html-6b5108ef.mjs"
  ).then(({ data }) => data),
  // path: /guide/website-learning.html
  "v-e572ed46": () => import(
    /* webpackChunkName: "v-e572ed46" */
    "./assets/website-learning.html-a698121a.mjs"
  ).then(({ data }) => data),
  // path: /guide/website-resource.html
  "v-2b0c4e6d": () => import(
    /* webpackChunkName: "v-2b0c4e6d" */
    "./assets/website-resource.html-37a21cd1.mjs"
  ).then(({ data }) => data),
  // path: /poetry/
  "v-51ef0801": () => import(
    /* webpackChunkName: "v-51ef0801" */
    "./assets/index.html-e5a2b900.mjs"
  ).then(({ data }) => data),
  // path: /guide/html5/css.html
  "v-ce4ba1b2": () => import(
    /* webpackChunkName: "v-ce4ba1b2" */
    "./assets/css.html-4b237c47.mjs"
  ).then(({ data }) => data),
  // path: /guide/html5/emoji.html
  "v-03666af8": () => import(
    /* webpackChunkName: "v-03666af8" */
    "./assets/emoji.html-8fe6669e.mjs"
  ).then(({ data }) => data),
  // path: /guide/html5/linefeed-br-transform.html
  "v-310216c0": () => import(
    /* webpackChunkName: "v-310216c0" */
    "./assets/linefeed-br-transform.html-07895372.mjs"
  ).then(({ data }) => data),
  // path: /guide/html5/mobile-adapter.html
  "v-1f4e1b24": () => import(
    /* webpackChunkName: "v-1f4e1b24" */
    "./assets/mobile-adapter.html-bc10da63.mjs"
  ).then(({ data }) => data),
  // path: /guide/html5/print.html
  "v-4c3bff06": () => import(
    /* webpackChunkName: "v-4c3bff06" */
    "./assets/print.html-a1d1a058.mjs"
  ).then(({ data }) => data),
  // path: /guide/html5/
  "v-6076b11e": () => import(
    /* webpackChunkName: "v-6076b11e" */
    "./assets/index.html-3e866237.mjs"
  ).then(({ data }) => data),
  // path: /guide/html5/regex.html
  "v-d41799ba": () => import(
    /* webpackChunkName: "v-d41799ba" */
    "./assets/regex.html-711aed04.mjs"
  ).then(({ data }) => data),
  // path: /guide/html5/sass.html
  "v-293597cc": () => import(
    /* webpackChunkName: "v-293597cc" */
    "./assets/sass.html-97c3f7a5.mjs"
  ).then(({ data }) => data),
  // path: /guide/html5/url-decode.html
  "v-665b7688": () => import(
    /* webpackChunkName: "v-665b7688" */
    "./assets/url-decode.html-5a8db080.mjs"
  ).then(({ data }) => data),
  // path: /guide/html5/window-event.html
  "v-5ce3212b": () => import(
    /* webpackChunkName: "v-5ce3212b" */
    "./assets/window-event.html-1497d76a.mjs"
  ).then(({ data }) => data),
  // path: /guide/interview/js-basic.html
  "v-39fd5df5": () => import(
    /* webpackChunkName: "v-39fd5df5" */
    "./assets/js-basic.html-fe07b923.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/async.html
  "v-729a0053": () => import(
    /* webpackChunkName: "v-729a0053" */
    "./assets/async.html-340bf3e5.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/date-by-week.html
  "v-4cbb61f8": () => import(
    /* webpackChunkName: "v-4cbb61f8" */
    "./assets/date-by-week.html-7118d4a0.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/download-cros-file.html
  "v-7b50b952": () => import(
    /* webpackChunkName: "v-7b50b952" */
    "./assets/download-cros-file.html-2cccc3a3.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/es6-basic.html
  "v-01eb0886": () => import(
    /* webpackChunkName: "v-01eb0886" */
    "./assets/es6-basic.html-cfbfb84c.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/javascript-address.html
  "v-aea6c5e2": () => import(
    /* webpackChunkName: "v-aea6c5e2" */
    "./assets/javascript-address.html-aeaf2a6e.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/javascript-array.html
  "v-fd023f6c": () => import(
    /* webpackChunkName: "v-fd023f6c" */
    "./assets/javascript-array.html-696054e0.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/javascript-binary-tree.html
  "v-3b2cbbd9": () => import(
    /* webpackChunkName: "v-3b2cbbd9" */
    "./assets/javascript-binary-tree.html-64a9a165.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/javascript-moment-js.html
  "v-187048e6": () => import(
    /* webpackChunkName: "v-187048e6" */
    "./assets/javascript-moment-js.html-2b929951.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/javascript.html
  "v-b12bee54": () => import(
    /* webpackChunkName: "v-b12bee54" */
    "./assets/javascript.html-bd9878a2.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/lodash-array.html
  "v-793e4222": () => import(
    /* webpackChunkName: "v-793e4222" */
    "./assets/lodash-array.html-3c323169.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/lodash-collection.html
  "v-20db5239": () => import(
    /* webpackChunkName: "v-20db5239" */
    "./assets/lodash-collection.html-ec271560.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/lodash-function.html
  "v-0e480e82": () => import(
    /* webpackChunkName: "v-0e480e82" */
    "./assets/lodash-function.html-2f22eeaf.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/lodash-map.html
  "v-3e3c917f": () => import(
    /* webpackChunkName: "v-3e3c917f" */
    "./assets/lodash-map.html-5b65649b.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/lodash-math.html
  "v-869e1ae2": () => import(
    /* webpackChunkName: "v-869e1ae2" */
    "./assets/lodash-math.html-29f4e08a.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/lodash-number.html
  "v-2736b124": () => import(
    /* webpackChunkName: "v-2736b124" */
    "./assets/lodash-number.html-3466c298.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/lodash-seq.html
  "v-fa5d3748": () => import(
    /* webpackChunkName: "v-fa5d3748" */
    "./assets/lodash-seq.html-45bd5021.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/lodash-string.html
  "v-6663dfa6": () => import(
    /* webpackChunkName: "v-6663dfa6" */
    "./assets/lodash-string.html-30dfef65.mjs"
  ).then(({ data }) => data),
  // path: /guide/javascript/lodash-utils.html
  "v-4c40daca": () => import(
    /* webpackChunkName: "v-4c40daca" */
    "./assets/lodash-utils.html-71bdc025.mjs"
  ).then(({ data }) => data),
  // path: /guide/linux/docker-basic.html
  "v-6afd4071": () => import(
    /* webpackChunkName: "v-6afd4071" */
    "./assets/docker-basic.html-85a93809.mjs"
  ).then(({ data }) => data),
  // path: /guide/linux/go-basic.html
  "v-0b009929": () => import(
    /* webpackChunkName: "v-0b009929" */
    "./assets/go-basic.html-00f6bfa6.mjs"
  ).then(({ data }) => data),
  // path: /guide/linux/ubuntu-config-git.html
  "v-12734c1a": () => import(
    /* webpackChunkName: "v-12734c1a" */
    "./assets/ubuntu-config-git.html-903e8b64.mjs"
  ).then(({ data }) => data),
  // path: /guide/linux/version.html
  "v-775863b0": () => import(
    /* webpackChunkName: "v-775863b0" */
    "./assets/version.html-a56265d7.mjs"
  ).then(({ data }) => data),
  // path: /guide/linux/vscode-guide.html
  "v-190bb819": () => import(
    /* webpackChunkName: "v-190bb819" */
    "./assets/vscode-guide.html-78b091d6.mjs"
  ).then(({ data }) => data),
  // path: /guide/nodejs/ffmpeg.html
  "v-0482165c": () => import(
    /* webpackChunkName: "v-0482165c" */
    "./assets/ffmpeg.html-2b6b5e89.mjs"
  ).then(({ data }) => data),
  // path: /guide/nodejs/inquirer.js.html
  "v-1b64d3b9": () => import(
    /* webpackChunkName: "v-1b64d3b9" */
    "./assets/inquirer.js.html-01dfa331.mjs"
  ).then(({ data }) => data),
  // path: /guide/nodejs/nodejs-install.html
  "v-13af5c88": () => import(
    /* webpackChunkName: "v-13af5c88" */
    "./assets/nodejs-install.html-f2d495bd.mjs"
  ).then(({ data }) => data),
  // path: /guide/nodejs/publish-project-to-npm.html
  "v-2b0cba16": () => import(
    /* webpackChunkName: "v-2b0cba16" */
    "./assets/publish-project-to-npm.html-c5b8c373.mjs"
  ).then(({ data }) => data),
  // path: /guide/nodejs/rsa-symmetric-encryption.html
  "v-5ffcac0a": () => import(
    /* webpackChunkName: "v-5ffcac0a" */
    "./assets/rsa-symmetric-encryption.html-b340cd1f.mjs"
  ).then(({ data }) => data),
  // path: /guide/other/%E4%B8%8B%E8%BD%BDbilibili%E8%A7%86%E9%A2%91.html
  "v-58efd6f6": () => import(
    /* webpackChunkName: "v-58efd6f6" */
    "./assets/下载bilibili视频.html-5aa9c1d0.mjs"
  ).then(({ data }) => data),
  // path: /guide/typescript/get-started.html
  "v-5b5ac426": () => import(
    /* webpackChunkName: "v-5b5ac426" */
    "./assets/get-started.html-fdf48037.mjs"
  ).then(({ data }) => data),
  // path: /guide/vue/nuxt-study-notes.html
  "v-bfca68de": () => import(
    /* webpackChunkName: "v-bfca68de" */
    "./assets/nuxt-study-notes.html-c2e07335.mjs"
  ).then(({ data }) => data),
  // path: /guide/vue/
  "v-5d496b56": () => import(
    /* webpackChunkName: "v-5d496b56" */
    "./assets/index.html-9dba5ac3.mjs"
  ).then(({ data }) => data),
  // path: /guide/vue/reference.html
  "v-b6962bfa": () => import(
    /* webpackChunkName: "v-b6962bfa" */
    "./assets/reference.html-3a74008b.mjs"
  ).then(({ data }) => data),
  // path: /guide/vue/vue-basic.html
  "v-265c7da7": () => import(
    /* webpackChunkName: "v-265c7da7" */
    "./assets/vue-basic.html-d48462c6.mjs"
  ).then(({ data }) => data),
  // path: /guide/vue/vue-event.html
  "v-b7f1fa8a": () => import(
    /* webpackChunkName: "v-b7f1fa8a" */
    "./assets/vue-event.html-597600a9.mjs"
  ).then(({ data }) => data),
  // path: /guide/vue/vue-model.html
  "v-325908e8": () => import(
    /* webpackChunkName: "v-325908e8" */
    "./assets/vue-model.html-052c996c.mjs"
  ).then(({ data }) => data),
  // path: /guide/vue/vue-props.html
  "v-490081a5": () => import(
    /* webpackChunkName: "v-490081a5" */
    "./assets/vue-props.html-070137fe.mjs"
  ).then(({ data }) => data),
  // path: /guide/vue/vue3-composition-api.html
  "v-43e0e56d": () => import(
    /* webpackChunkName: "v-43e0e56d" */
    "./assets/vue3-composition-api.html-08878646.mjs"
  ).then(({ data }) => data),
  // path: /guide/vue/vue3-study-notes.html
  "v-4f9a6732": () => import(
    /* webpackChunkName: "v-4f9a6732" */
    "./assets/vue3-study-notes.html-1e9eeb28.mjs"
  ).then(({ data }) => data),
  // path: /guide/webrtc/
  "v-281db8d6": () => import(
    /* webpackChunkName: "v-281db8d6" */
    "./assets/index.html-56ef2ada.mjs"
  ).then(({ data }) => data),
  // path: /guide/vue/hooks/timer.html
  "v-025b70c8": () => import(
    /* webpackChunkName: "v-025b70c8" */
    "./assets/timer.html-04ab209c.mjs"
  ).then(({ data }) => data),
  // path: /404.html
  "v-3706649a": () => import(
    /* webpackChunkName: "v-3706649a" */
    "./assets/404.html-874778d8.mjs"
  ).then(({ data }) => data)
};
const siteData$1 = JSON.parse('{"base":"/","lang":"/","title":"你好， VuePress ！","description":"这是我的第一个 VuePress 站点","head":[],"locales":{"/guide/":{"lang":"guide","title":"学习指南","description":"captives.github.io"},"/poetry/":{"lang":"poetry","title":"古诗词","description":"captives.github.io"}}}');
const pagesComponents = {
  // path: /markdown.html
  "v-7fdc6af1": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-7fdc6af1" */
    "./assets/markdown.html-3601a863.mjs"
  )),
  // path: /
  "v-8daa1a0e": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-8daa1a0e" */
    "./assets/index.html-8909aa73.mjs"
  )),
  // path: /user-profile.html
  "v-077d91b9": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-077d91b9" */
    "./assets/user-profile.html-3a739d11.mjs"
  )),
  // path: /guide/favorites.html
  "v-18a03e64": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-18a03e64" */
    "./assets/favorites.html-ac460460.mjs"
  )),
  // path: /guide/frontend.html
  "v-5efb549b": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-5efb549b" */
    "./assets/frontend.html-1b2a0c1f.mjs"
  )),
  // path: /guide/getting-started.html
  "v-fb0f0066": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-fb0f0066" */
    "./assets/getting-started.html-72c95c3f.mjs"
  )),
  // path: /guide/
  "v-fffb8e28": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-fffb8e28" */
    "./assets/index.html-dd29ad98.mjs"
  )),
  // path: /guide/website-learning.html
  "v-e572ed46": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-e572ed46" */
    "./assets/website-learning.html-0f3e1854.mjs"
  )),
  // path: /guide/website-resource.html
  "v-2b0c4e6d": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-2b0c4e6d" */
    "./assets/website-resource.html-1cb88b03.mjs"
  )),
  // path: /poetry/
  "v-51ef0801": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-51ef0801" */
    "./assets/index.html-5375a633.mjs"
  )),
  // path: /guide/html5/css.html
  "v-ce4ba1b2": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-ce4ba1b2" */
    "./assets/css.html-0430ea34.mjs"
  )),
  // path: /guide/html5/emoji.html
  "v-03666af8": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-03666af8" */
    "./assets/emoji.html-6fc3b7cb.mjs"
  )),
  // path: /guide/html5/linefeed-br-transform.html
  "v-310216c0": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-310216c0" */
    "./assets/linefeed-br-transform.html-4c57aae6.mjs"
  )),
  // path: /guide/html5/mobile-adapter.html
  "v-1f4e1b24": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-1f4e1b24" */
    "./assets/mobile-adapter.html-284e14d6.mjs"
  )),
  // path: /guide/html5/print.html
  "v-4c3bff06": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-4c3bff06" */
    "./assets/print.html-02a6996f.mjs"
  )),
  // path: /guide/html5/
  "v-6076b11e": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-6076b11e" */
    "./assets/index.html-61baab7f.mjs"
  )),
  // path: /guide/html5/regex.html
  "v-d41799ba": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-d41799ba" */
    "./assets/regex.html-0328fa42.mjs"
  )),
  // path: /guide/html5/sass.html
  "v-293597cc": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-293597cc" */
    "./assets/sass.html-16ccac0f.mjs"
  )),
  // path: /guide/html5/url-decode.html
  "v-665b7688": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-665b7688" */
    "./assets/url-decode.html-2f51a518.mjs"
  )),
  // path: /guide/html5/window-event.html
  "v-5ce3212b": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-5ce3212b" */
    "./assets/window-event.html-ee9fb9d9.mjs"
  )),
  // path: /guide/interview/js-basic.html
  "v-39fd5df5": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-39fd5df5" */
    "./assets/js-basic.html-19139a7a.mjs"
  )),
  // path: /guide/javascript/async.html
  "v-729a0053": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-729a0053" */
    "./assets/async.html-5d88dcd0.mjs"
  )),
  // path: /guide/javascript/date-by-week.html
  "v-4cbb61f8": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-4cbb61f8" */
    "./assets/date-by-week.html-e63d74af.mjs"
  )),
  // path: /guide/javascript/download-cros-file.html
  "v-7b50b952": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-7b50b952" */
    "./assets/download-cros-file.html-c9a151f3.mjs"
  )),
  // path: /guide/javascript/es6-basic.html
  "v-01eb0886": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-01eb0886" */
    "./assets/es6-basic.html-056cd7e1.mjs"
  )),
  // path: /guide/javascript/javascript-address.html
  "v-aea6c5e2": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-aea6c5e2" */
    "./assets/javascript-address.html-8245b5be.mjs"
  )),
  // path: /guide/javascript/javascript-array.html
  "v-fd023f6c": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-fd023f6c" */
    "./assets/javascript-array.html-3010381b.mjs"
  )),
  // path: /guide/javascript/javascript-binary-tree.html
  "v-3b2cbbd9": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-3b2cbbd9" */
    "./assets/javascript-binary-tree.html-048a7918.mjs"
  )),
  // path: /guide/javascript/javascript-moment-js.html
  "v-187048e6": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-187048e6" */
    "./assets/javascript-moment-js.html-65ea0d70.mjs"
  )),
  // path: /guide/javascript/javascript.html
  "v-b12bee54": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-b12bee54" */
    "./assets/javascript.html-4ec750d3.mjs"
  )),
  // path: /guide/javascript/lodash-array.html
  "v-793e4222": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-793e4222" */
    "./assets/lodash-array.html-3d59164e.mjs"
  )),
  // path: /guide/javascript/lodash-collection.html
  "v-20db5239": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-20db5239" */
    "./assets/lodash-collection.html-19964333.mjs"
  )),
  // path: /guide/javascript/lodash-function.html
  "v-0e480e82": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-0e480e82" */
    "./assets/lodash-function.html-7cb45ffc.mjs"
  )),
  // path: /guide/javascript/lodash-map.html
  "v-3e3c917f": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-3e3c917f" */
    "./assets/lodash-map.html-c97528f2.mjs"
  )),
  // path: /guide/javascript/lodash-math.html
  "v-869e1ae2": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-869e1ae2" */
    "./assets/lodash-math.html-a48ad085.mjs"
  )),
  // path: /guide/javascript/lodash-number.html
  "v-2736b124": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-2736b124" */
    "./assets/lodash-number.html-89af3350.mjs"
  )),
  // path: /guide/javascript/lodash-seq.html
  "v-fa5d3748": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-fa5d3748" */
    "./assets/lodash-seq.html-acac1c29.mjs"
  )),
  // path: /guide/javascript/lodash-string.html
  "v-6663dfa6": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-6663dfa6" */
    "./assets/lodash-string.html-6ba9a70f.mjs"
  )),
  // path: /guide/javascript/lodash-utils.html
  "v-4c40daca": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-4c40daca" */
    "./assets/lodash-utils.html-25c5f596.mjs"
  )),
  // path: /guide/linux/docker-basic.html
  "v-6afd4071": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-6afd4071" */
    "./assets/docker-basic.html-1c21aa9c.mjs"
  )),
  // path: /guide/linux/go-basic.html
  "v-0b009929": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-0b009929" */
    "./assets/go-basic.html-286407d8.mjs"
  )),
  // path: /guide/linux/ubuntu-config-git.html
  "v-12734c1a": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-12734c1a" */
    "./assets/ubuntu-config-git.html-c5073c9e.mjs"
  )),
  // path: /guide/linux/version.html
  "v-775863b0": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-775863b0" */
    "./assets/version.html-37e8503a.mjs"
  )),
  // path: /guide/linux/vscode-guide.html
  "v-190bb819": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-190bb819" */
    "./assets/vscode-guide.html-52dbc44a.mjs"
  )),
  // path: /guide/nodejs/ffmpeg.html
  "v-0482165c": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-0482165c" */
    "./assets/ffmpeg.html-53d5146c.mjs"
  )),
  // path: /guide/nodejs/inquirer.js.html
  "v-1b64d3b9": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-1b64d3b9" */
    "./assets/inquirer.js.html-91d28e32.mjs"
  )),
  // path: /guide/nodejs/nodejs-install.html
  "v-13af5c88": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-13af5c88" */
    "./assets/nodejs-install.html-e14ab92d.mjs"
  )),
  // path: /guide/nodejs/publish-project-to-npm.html
  "v-2b0cba16": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-2b0cba16" */
    "./assets/publish-project-to-npm.html-50da5017.mjs"
  )),
  // path: /guide/nodejs/rsa-symmetric-encryption.html
  "v-5ffcac0a": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-5ffcac0a" */
    "./assets/rsa-symmetric-encryption.html-2cb7ae12.mjs"
  )),
  // path: /guide/other/%E4%B8%8B%E8%BD%BDbilibili%E8%A7%86%E9%A2%91.html
  "v-58efd6f6": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-58efd6f6" */
    "./assets/下载bilibili视频.html-9d5a7ed6.mjs"
  )),
  // path: /guide/typescript/get-started.html
  "v-5b5ac426": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-5b5ac426" */
    "./assets/get-started.html-3fb88365.mjs"
  )),
  // path: /guide/vue/nuxt-study-notes.html
  "v-bfca68de": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-bfca68de" */
    "./assets/nuxt-study-notes.html-02895405.mjs"
  )),
  // path: /guide/vue/
  "v-5d496b56": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-5d496b56" */
    "./assets/index.html-c6d634f2.mjs"
  )),
  // path: /guide/vue/reference.html
  "v-b6962bfa": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-b6962bfa" */
    "./assets/reference.html-f0b11677.mjs"
  )),
  // path: /guide/vue/vue-basic.html
  "v-265c7da7": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-265c7da7" */
    "./assets/vue-basic.html-b837a1b7.mjs"
  )),
  // path: /guide/vue/vue-event.html
  "v-b7f1fa8a": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-b7f1fa8a" */
    "./assets/vue-event.html-e3c2fe40.mjs"
  )),
  // path: /guide/vue/vue-model.html
  "v-325908e8": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-325908e8" */
    "./assets/vue-model.html-946049ea.mjs"
  )),
  // path: /guide/vue/vue-props.html
  "v-490081a5": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-490081a5" */
    "./assets/vue-props.html-7aa6471d.mjs"
  )),
  // path: /guide/vue/vue3-composition-api.html
  "v-43e0e56d": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-43e0e56d" */
    "./assets/vue3-composition-api.html-6ed8bc33.mjs"
  )),
  // path: /guide/vue/vue3-study-notes.html
  "v-4f9a6732": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-4f9a6732" */
    "./assets/vue3-study-notes.html-cbcc2f34.mjs"
  )),
  // path: /guide/webrtc/
  "v-281db8d6": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-281db8d6" */
    "./assets/index.html-0fe59f48.mjs"
  )),
  // path: /guide/vue/hooks/timer.html
  "v-025b70c8": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-025b70c8" */
    "./assets/timer.html-7119dc28.mjs"
  )),
  // path: /404.html
  "v-3706649a": defineAsyncComponent(() => import(
    /* webpackChunkName: "v-3706649a" */
    "./assets/404.html-ac391218.mjs"
  ))
};
var layoutsSymbol = Symbol(
  ""
);
var pagesData = ref(pagesData$1);
var pageDataEmpty = readonly({
  key: "",
  path: "",
  title: "",
  lang: "",
  frontmatter: {},
  headers: []
});
var pageData = ref(pageDataEmpty);
var usePageData = () => pageData;
var pageFrontmatterSymbol = Symbol(
  ""
);
var usePageFrontmatter = () => {
  const pageFrontmatter = inject(pageFrontmatterSymbol);
  if (!pageFrontmatter) {
    throw new Error("usePageFrontmatter() is called without provider.");
  }
  return pageFrontmatter;
};
var pageHeadSymbol = Symbol(
  ""
);
var usePageHead = () => {
  const pageHead = inject(pageHeadSymbol);
  if (!pageHead) {
    throw new Error("usePageHead() is called without provider.");
  }
  return pageHead;
};
var pageHeadTitleSymbol = Symbol(
  ""
);
var usePageHeadTitle = () => {
  const pageHeadTitle = inject(pageHeadTitleSymbol);
  if (!pageHeadTitle) {
    throw new Error("usePageHeadTitle() is called without provider.");
  }
  return pageHeadTitle;
};
var pageLangSymbol = Symbol(
  ""
);
var usePageLang = () => {
  const pageLang = inject(pageLangSymbol);
  if (!pageLang) {
    throw new Error("usePageLang() is called without provider.");
  }
  return pageLang;
};
var pageLayoutSymbol = Symbol(
  ""
);
var usePageLayout = () => {
  const pageLayout = inject(pageLayoutSymbol);
  if (!pageLayout) {
    throw new Error("usePageLayout() is called without provider.");
  }
  return pageLayout;
};
var routeLocaleSymbol = Symbol(
  ""
);
var useRouteLocale = () => {
  const routeLocale = inject(routeLocaleSymbol);
  if (!routeLocale) {
    throw new Error("useRouteLocale() is called without provider.");
  }
  return routeLocale;
};
var siteData = ref(siteData$1);
var useSiteData = () => siteData;
var siteLocaleDataSymbol = Symbol(
  ""
);
var useSiteLocaleData = () => {
  const siteLocaleData = inject(siteLocaleDataSymbol);
  if (!siteLocaleData) {
    throw new Error("useSiteLocaleData() is called without provider.");
  }
  return siteLocaleData;
};
var LAYOUT_NAME_DEFAULT = "Layout";
var LAYOUT_NAME_NOT_FOUND = "NotFound";
var resolvers = reactive({
  resolveLayouts: (clientConfigs2) => clientConfigs2.reduce(
    (prev, item) => ({
      ...prev,
      ...item.layouts
    }),
    {}
  ),
  resolvePageData: async (pageKey) => {
    const pageDataResolver = pagesData.value[pageKey];
    const pageData2 = await (pageDataResolver == null ? void 0 : pageDataResolver());
    return pageData2 ?? pageDataEmpty;
  },
  resolvePageFrontmatter: (pageData2) => pageData2.frontmatter,
  resolvePageHead: (headTitle, frontmatter, siteLocale) => {
    const description = isString(frontmatter.description) ? frontmatter.description : siteLocale.description;
    const head = [
      ...isArray(frontmatter.head) ? frontmatter.head : [],
      ...siteLocale.head,
      ["title", {}, headTitle],
      ["meta", { name: "description", content: description }]
    ];
    return dedupeHead(head);
  },
  resolvePageHeadTitle: (page, siteLocale) => [page.title, siteLocale.title].filter((item) => !!item).join(" | "),
  resolvePageLang: (page) => page.lang || "en",
  resolvePageLayout: (page, layouts) => {
    let layoutName;
    if (page.path) {
      const frontmatterLayout = page.frontmatter.layout;
      if (isString(frontmatterLayout)) {
        layoutName = frontmatterLayout;
      } else {
        layoutName = LAYOUT_NAME_DEFAULT;
      }
    } else {
      layoutName = LAYOUT_NAME_NOT_FOUND;
    }
    return layouts[layoutName];
  },
  resolveRouteLocale: (locales2, routePath) => resolveLocalePath(locales2, routePath),
  resolveSiteLocaleData: (site, routeLocale) => ({
    ...site,
    ...site.locales[routeLocale]
  })
});
var ClientOnly = defineComponent({
  name: "ClientOnly",
  setup(_, ctx) {
    const isMounted = ref(false);
    onMounted(() => {
      isMounted.value = true;
    });
    return () => {
      var _a, _b;
      return isMounted.value ? (_b = (_a = ctx.slots).default) == null ? void 0 : _b.call(_a) : null;
    };
  }
});
var Content = defineComponent({
  name: "Content",
  props: {
    pageKey: {
      type: String,
      required: false,
      default: ""
    }
  },
  setup(props) {
    const page = usePageData();
    const pageComponent = computed(
      () => pagesComponents[props.pageKey || page.value.key]
    );
    return () => pageComponent.value ? h(pageComponent.value) : h(
      "div",
      "404 Not Found"
    );
  }
});
var defineClientConfig = (clientConfig = {}) => clientConfig;
var withBase = (url) => {
  if (isLinkHttp(url))
    return url;
  return `${"/"}${removeLeadingSlash(url)}`;
};
const clientConfig0 = defineClientConfig({
  setup() {
    return;
  }
});
const getScrollTop = () => window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
const scrollToTop = () => window.scrollTo({ top: 0, behavior: "smooth" });
const vars$4 = "";
const backToTop = "";
const BackToTop = defineComponent({
  name: "BackToTop",
  setup() {
    const scrollTop = ref(0);
    const show = computed(() => scrollTop.value > 300);
    const onScroll = debounce(() => {
      scrollTop.value = getScrollTop();
    }, 100);
    onMounted(() => {
      scrollTop.value = getScrollTop();
      window.addEventListener("scroll", () => onScroll());
    });
    const backToTopEl = h("div", { class: "back-to-top", onClick: scrollToTop });
    return () => h(Transition, {
      name: "back-to-top"
    }, () => show.value ? backToTopEl : null);
  }
});
const clientConfig1 = defineClientConfig({
  rootComponents: [BackToTop]
});
const vars$3 = "";
const externalLinkIcon = "";
const svg = h("svg", {
  "class": "external-link-icon",
  "xmlns": "http://www.w3.org/2000/svg",
  "aria-hidden": "true",
  "focusable": "false",
  "x": "0px",
  "y": "0px",
  "viewBox": "0 0 100 100",
  "width": "15",
  "height": "15"
}, [
  h("path", {
    fill: "currentColor",
    d: "M18.8,85.1h56l0,0c2.2,0,4-1.8,4-4v-32h-8v28h-48v-48h28v-8h-32l0,0c-2.2,0-4,1.8-4,4v56C14.8,83.3,16.6,85.1,18.8,85.1z"
  }),
  h("polygon", {
    fill: "currentColor",
    points: "45.7,48.7 51.3,54.3 77.2,28.5 77.2,37.2 85.2,37.2 85.2,14.9 62.8,14.9 62.8,22.9 71.5,22.9"
  })
]);
const ExternalLinkIcon = defineComponent({
  name: "ExternalLinkIcon",
  props: {
    locales: {
      type: Object,
      required: false,
      default: () => ({})
    }
  },
  setup(props) {
    const routeLocale = useRouteLocale();
    const locale = computed(() => props.locales[routeLocale.value] ?? {
      openInNewWindow: "open in new window"
    });
    return () => h("span", [
      svg,
      h("span", {
        class: "external-link-icon-sr-only"
      }, locale.value.openInNewWindow)
    ]);
  }
});
const locales$1 = { "/": { "openInNewWindow": "open in new window" }, "/guide/": { "openInNewWindow": "open in new window" }, "/poetry/": { "openInNewWindow": "open in new window" } };
const clientConfig2 = defineClientConfig({
  enhance({ app }) {
    app.component("ExternalLinkIcon", h(ExternalLinkIcon, { locales: locales$1 }));
  }
});
const vars$2 = "";
const mediumZoom = "";
const clientConfig3 = defineClientConfig({
  enhance({ app, router }) {
    return;
  }
});
/**
 * NProgress, (c) 2013, 2014 Rico Sta. Cruz - http://ricostacruz.com/nprogress
 * @license MIT
 */
const nprogress$1 = {
  settings: {
    minimum: 0.08,
    easing: "ease",
    speed: 200,
    trickle: true,
    trickleRate: 0.02,
    trickleSpeed: 800,
    barSelector: '[role="bar"]',
    parent: "body",
    template: '<div class="bar" role="bar"></div>'
  },
  status: null,
  set: (n) => {
    const started = nprogress$1.isStarted();
    n = clamp(n, nprogress$1.settings.minimum, 1);
    nprogress$1.status = n === 1 ? null : n;
    const progress = nprogress$1.render(!started);
    const bar = progress.querySelector(nprogress$1.settings.barSelector);
    const speed = nprogress$1.settings.speed;
    const ease = nprogress$1.settings.easing;
    progress.offsetWidth;
    queue((next) => {
      css(bar, {
        transform: "translate3d(" + toBarPerc(n) + "%,0,0)",
        transition: "all " + speed + "ms " + ease
      });
      if (n === 1) {
        css(progress, {
          transition: "none",
          opacity: "1"
        });
        progress.offsetWidth;
        setTimeout(function() {
          css(progress, {
            transition: "all " + speed + "ms linear",
            opacity: "0"
          });
          setTimeout(function() {
            nprogress$1.remove();
            next();
          }, speed);
        }, speed);
      } else {
        setTimeout(() => next(), speed);
      }
    });
    return nprogress$1;
  },
  isStarted: () => typeof nprogress$1.status === "number",
  start: () => {
    if (!nprogress$1.status)
      nprogress$1.set(0);
    const work = () => {
      setTimeout(() => {
        if (!nprogress$1.status)
          return;
        nprogress$1.trickle();
        work();
      }, nprogress$1.settings.trickleSpeed);
    };
    if (nprogress$1.settings.trickle)
      work();
    return nprogress$1;
  },
  done: (force) => {
    if (!force && !nprogress$1.status)
      return nprogress$1;
    return nprogress$1.inc(0.3 + 0.5 * Math.random()).set(1);
  },
  inc: (amount) => {
    let n = nprogress$1.status;
    if (!n) {
      return nprogress$1.start();
    }
    if (typeof amount !== "number") {
      amount = (1 - n) * clamp(Math.random() * n, 0.1, 0.95);
    }
    n = clamp(n + amount, 0, 0.994);
    return nprogress$1.set(n);
  },
  trickle: () => nprogress$1.inc(Math.random() * nprogress$1.settings.trickleRate),
  render: (fromStart) => {
    if (nprogress$1.isRendered()) {
      return document.getElementById("nprogress");
    }
    addClass(document.documentElement, "nprogress-busy");
    const progress = document.createElement("div");
    progress.id = "nprogress";
    progress.innerHTML = nprogress$1.settings.template;
    const bar = progress.querySelector(nprogress$1.settings.barSelector);
    const perc = fromStart ? "-100" : toBarPerc(nprogress$1.status || 0);
    const parent = document.querySelector(nprogress$1.settings.parent);
    css(bar, {
      transition: "all 0 linear",
      transform: "translate3d(" + perc + "%,0,0)"
    });
    if (parent !== document.body) {
      addClass(parent, "nprogress-custom-parent");
    }
    parent == null ? void 0 : parent.appendChild(progress);
    return progress;
  },
  remove: () => {
    removeClass(document.documentElement, "nprogress-busy");
    removeClass(document.querySelector(nprogress$1.settings.parent), "nprogress-custom-parent");
    const progress = document.getElementById("nprogress");
    progress && removeElement(progress);
  },
  isRendered: () => !!document.getElementById("nprogress")
};
const clamp = (n, min, max) => {
  if (n < min)
    return min;
  if (n > max)
    return max;
  return n;
};
const toBarPerc = (n) => (-1 + n) * 100;
const queue = function() {
  const pending = [];
  function next() {
    const fn = pending.shift();
    if (fn) {
      fn(next);
    }
  }
  return function(fn) {
    pending.push(fn);
    if (pending.length === 1)
      next();
  };
}();
const css = function() {
  const cssPrefixes = ["Webkit", "O", "Moz", "ms"];
  const cssProps = {};
  function camelCase(string) {
    return string.replace(/^-ms-/, "ms-").replace(/-([\da-z])/gi, function(match, letter) {
      return letter.toUpperCase();
    });
  }
  function getVendorProp(name) {
    const style = document.body.style;
    if (name in style)
      return name;
    let i = cssPrefixes.length;
    const capName = name.charAt(0).toUpperCase() + name.slice(1);
    let vendorName;
    while (i--) {
      vendorName = cssPrefixes[i] + capName;
      if (vendorName in style)
        return vendorName;
    }
    return name;
  }
  function getStyleProp(name) {
    name = camelCase(name);
    return cssProps[name] || (cssProps[name] = getVendorProp(name));
  }
  function applyCss(element, prop, value) {
    prop = getStyleProp(prop);
    element.style[prop] = value;
  }
  return function(element, properties) {
    for (const prop in properties) {
      const value = properties[prop];
      if (value !== void 0 && Object.prototype.hasOwnProperty.call(properties, prop))
        applyCss(element, prop, value);
    }
  };
}();
const hasClass = (element, name) => {
  const list = typeof element === "string" ? element : classList(element);
  return list.indexOf(" " + name + " ") >= 0;
};
const addClass = (element, name) => {
  const oldList = classList(element);
  const newList = oldList + name;
  if (hasClass(oldList, name))
    return;
  element.className = newList.substring(1);
};
const removeClass = (element, name) => {
  const oldList = classList(element);
  if (!hasClass(element, name))
    return;
  const newList = oldList.replace(" " + name + " ", " ");
  element.className = newList.substring(1, newList.length - 1);
};
const classList = (element) => {
  return (" " + (element.className || "") + " ").replace(/\s+/gi, " ");
};
const removeElement = (element) => {
  element && element.parentNode && element.parentNode.removeChild(element);
};
const vars$1 = "";
const nprogress = "";
const useNprogress = () => {
  onMounted(() => {
    const router = useRouter();
    const loadedPages = /* @__PURE__ */ new Set();
    loadedPages.add(router.currentRoute.value.path);
    router.beforeEach((to) => {
      if (!loadedPages.has(to.path)) {
        nprogress$1.start();
      }
    });
    router.afterEach((to) => {
      loadedPages.add(to.path);
      nprogress$1.done();
    });
  });
};
const clientConfig4 = defineClientConfig({
  setup() {
    useNprogress();
  }
});
const themeData$1 = JSON.parse(`{"logo":"../assets/images/logo.svg","repo":"captives/captives.github.io","repoLabel":"Captives","docsDir":"docx","smoothScroll":true,"backToHome":"返回Captives","locales":{"/":{"sidebar":false,"editLink":false,"selectLanguageText":"Captives","selectLanguageName":"Captives"},"/guide/":{"navbar":[{"text":"帮助","children":[{"text":"markdown语法","link":"/markdown"},{"text":"markdown语法","link":"/markdown"},{"text":"markdown语法","link":"/markdown"}]}],"editLink":true,"selectLanguageText":"学习指南","selectLanguageName":"学习指南"},"/poetry/":{"navbar":[{"text":"帮助","children":[{"text":"markdown语法","link":"/markdown"},{"text":"markdown语法","link":"/markdown"},{"text":"markdown语法","link":"/markdown"}]}],"selectLanguageText":"中华古诗词","selectLanguageName":"中华古诗词"}},"colorMode":"auto","colorModeSwitch":true,"navbar":[],"selectLanguageText":"Languages","selectLanguageAriaLabel":"Select language","sidebar":"auto","sidebarDepth":2,"editLink":true,"editLinkText":"Edit this page","lastUpdated":true,"lastUpdatedText":"Last Updated","contributors":true,"contributorsText":"Contributors","notFound":["There's nothing here.","How did we get here?","That's a Four-Oh-Four.","Looks like we've got some broken links."],"openInNewWindow":"open in new window","toggleColorMode":"toggle color mode","toggleSidebar":"toggle sidebar"}`);
const themeData = ref(themeData$1);
const useThemeData = () => themeData;
const themeLocaleDataSymbol = Symbol("");
const useThemeLocaleData$1 = () => {
  const themeLocaleData = inject(themeLocaleDataSymbol);
  if (!themeLocaleData) {
    throw new Error("useThemeLocaleData() is called without provider.");
  }
  return themeLocaleData;
};
const resolveThemeLocaleData = (theme, routeLocale) => {
  var _a;
  return {
    ...theme,
    ...(_a = theme.locales) == null ? void 0 : _a[routeLocale]
  };
};
const clientConfig5 = defineClientConfig({
  enhance({ app }) {
    const themeData2 = useThemeData();
    const routeLocale = app._context.provides[routeLocaleSymbol];
    const themeLocaleData = computed(() => resolveThemeLocaleData(themeData2.value, routeLocale.value));
    app.provide(themeLocaleDataSymbol, themeLocaleData);
    Object.defineProperties(app.config.globalProperties, {
      $theme: {
        get() {
          return themeData2.value;
        }
      },
      $themeLocale: {
        get() {
          return themeLocaleData.value;
        }
      }
    });
    {
      setupDevtoolsPlugin({
        // fix recursive reference
        app,
        id: "org.vuejs.vuepress.plugin-theme-data",
        label: "VuePress Theme Data Plugin",
        packageName: "@vuepress/plugin-theme-data",
        homepage: "https://v2.vuepress.vuejs.org",
        logo: "https://v2.vuepress.vuejs.org/images/hero.png",
        componentStateTypes: ["VuePress"]
      }, (api) => {
        api.on.inspectComponent((payload) => {
          payload.instanceData.state.push({
            type: "VuePress",
            key: "themeData",
            editable: false,
            value: themeData2.value
          }, {
            type: "VuePress",
            key: "themeLocaleData",
            editable: false,
            value: themeLocaleData.value
          });
        });
      });
    }
  }
});
const _sfc_main$p = /* @__PURE__ */ defineComponent({
  __name: "Badge",
  __ssrInlineRender: true,
  props: {
    type: {
      type: String,
      required: false,
      default: "tip"
    },
    text: {
      type: String,
      required: false,
      default: ""
    },
    vertical: {
      type: String,
      required: false,
      default: void 0
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<span${ssrRenderAttrs(mergeProps({
        class: ["badge", __props.type],
        style: {
          verticalAlign: __props.vertical
        }
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, () => {
        _push(`${ssrInterpolate(__props.text)}`);
      }, _push, _parent);
      _push(`</span>`);
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const _sfc_setup$p = _sfc_main$p.setup;
_sfc_main$p.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/global/Badge.vue");
  return _sfc_setup$p ? _sfc_setup$p(props, ctx) : void 0;
};
const Badge = /* @__PURE__ */ _export_sfc(_sfc_main$p, [["__file", "Badge.vue"]]);
const CodeGroup = defineComponent({
  name: "CodeGroup",
  setup(_, { slots }) {
    const activeIndex = ref(-1);
    const tabRefs = ref([]);
    const activateNext = (i = activeIndex.value) => {
      if (i < tabRefs.value.length - 1) {
        activeIndex.value = i + 1;
      } else {
        activeIndex.value = 0;
      }
      tabRefs.value[activeIndex.value].focus();
    };
    const activatePrev = (i = activeIndex.value) => {
      if (i > 0) {
        activeIndex.value = i - 1;
      } else {
        activeIndex.value = tabRefs.value.length - 1;
      }
      tabRefs.value[activeIndex.value].focus();
    };
    const keyboardHandler = (event, i) => {
      if (event.key === " " || event.key === "Enter") {
        event.preventDefault();
        activeIndex.value = i;
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        activateNext(i);
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        activatePrev(i);
      }
    };
    return () => {
      var _a;
      const items = (((_a = slots.default) == null ? void 0 : _a.call(slots)) || []).filter((vnode) => vnode.type.name === "CodeGroupItem").map((vnode) => {
        if (vnode.props === null) {
          vnode.props = {};
        }
        return vnode;
      });
      if (items.length === 0) {
        return null;
      }
      if (activeIndex.value < 0 || activeIndex.value > items.length - 1) {
        activeIndex.value = items.findIndex((vnode) => vnode.props.active === "" || vnode.props.active === true);
        if (activeIndex.value === -1) {
          activeIndex.value = 0;
        }
      } else {
        items.forEach((vnode, i) => {
          vnode.props.active = i === activeIndex.value;
        });
      }
      return h("div", { class: "code-group" }, [
        h("div", { class: "code-group__nav" }, h("ul", { class: "code-group__ul" }, items.map((vnode, i) => {
          const isActive = i === activeIndex.value;
          return h("li", { class: "code-group__li" }, h("button", {
            ref: (element) => {
              if (element) {
                tabRefs.value[i] = element;
              }
            },
            class: {
              "code-group__nav-tab": true,
              "code-group__nav-tab-active": isActive
            },
            ariaPressed: isActive,
            ariaExpanded: isActive,
            onClick: () => activeIndex.value = i,
            onKeydown: (e) => keyboardHandler(e, i)
          }, vnode.props.title));
        }))),
        items
      ]);
    };
  }
});
const __default__$1 = defineComponent({
  name: "CodeGroupItem"
});
const _sfc_main$o = /* @__PURE__ */ defineComponent({
  ...__default__$1,
  __ssrInlineRender: true,
  props: {
    title: {
      type: String,
      required: true
    },
    active: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["code-group-item", { "code-group-item__active": __props.active }],
        "aria-selected": __props.active
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$o = _sfc_main$o.setup;
_sfc_main$o.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/global/CodeGroupItem.vue");
  return _sfc_setup$o ? _sfc_setup$o(props, ctx) : void 0;
};
const CodeGroupItem = /* @__PURE__ */ _export_sfc(_sfc_main$o, [["__file", "CodeGroupItem.vue"]]);
const useThemeLocaleData = () => useThemeLocaleData$1();
const darkModeSymbol = Symbol("");
const useDarkMode = () => {
  const isDarkMode = inject(darkModeSymbol);
  if (!isDarkMode) {
    throw new Error("useDarkMode() is called without provider.");
  }
  return isDarkMode;
};
const setupDarkMode = () => {
  const themeLocale = useThemeLocaleData();
  const isDarkPreferred = usePreferredDark();
  const darkStorage = useStorage("vuepress-color-scheme", themeLocale.value.colorMode);
  const isDarkMode = computed({
    get() {
      if (!themeLocale.value.colorModeSwitch) {
        return themeLocale.value.colorMode === "dark";
      }
      if (darkStorage.value === "auto") {
        return isDarkPreferred.value;
      }
      return darkStorage.value === "dark";
    },
    set(val) {
      if (val === isDarkPreferred.value) {
        darkStorage.value = "auto";
      } else {
        darkStorage.value = val ? "dark" : "light";
      }
    }
  });
  provide(darkModeSymbol, isDarkMode);
  updateHtmlDarkClass(isDarkMode);
};
const updateHtmlDarkClass = (isDarkMode) => {
  const update = (value = isDarkMode.value) => {
    const htmlEl = window == null ? void 0 : window.document.querySelector("html");
    htmlEl == null ? void 0 : htmlEl.classList.toggle("dark", value);
  };
  onMounted(() => {
    watch(isDarkMode, update, { immediate: true });
  });
  onUnmounted(() => update());
};
const useResolveRouteWithRedirect = (...args) => {
  const router = useRouter();
  const route = router.resolve(...args);
  const lastMatched = route.matched[route.matched.length - 1];
  if (!(lastMatched == null ? void 0 : lastMatched.redirect)) {
    return route;
  }
  const { redirect } = lastMatched;
  const resolvedRedirect = isFunction(redirect) ? redirect(route) : redirect;
  const resolvedRedirectObj = isString(resolvedRedirect) ? { path: resolvedRedirect } : resolvedRedirect;
  return useResolveRouteWithRedirect({
    hash: route.hash,
    query: route.query,
    params: route.params,
    ...resolvedRedirectObj
  });
};
const useNavLink = (item) => {
  const resolved = useResolveRouteWithRedirect(encodeURI(item));
  return {
    text: resolved.meta.title || item,
    link: resolved.name === "404" ? item : resolved.fullPath
  };
};
let promise = null;
let promiseResolve = null;
const scrollPromise = {
  wait: () => promise,
  pending: () => {
    promise = new Promise((resolve) => promiseResolve = resolve);
  },
  resolve: () => {
    promiseResolve == null ? void 0 : promiseResolve();
    promise = null;
    promiseResolve = null;
  }
};
const useScrollPromise = () => scrollPromise;
const sidebarItemsSymbol = Symbol("sidebarItems");
const useSidebarItems = () => {
  const sidebarItems = inject(sidebarItemsSymbol);
  if (!sidebarItems) {
    throw new Error("useSidebarItems() is called without provider.");
  }
  return sidebarItems;
};
const setupSidebarItems = () => {
  const themeLocale = useThemeLocaleData();
  const frontmatter = usePageFrontmatter();
  const sidebarItems = computed(() => resolveSidebarItems(frontmatter.value, themeLocale.value));
  provide(sidebarItemsSymbol, sidebarItems);
};
const resolveSidebarItems = (frontmatter, themeLocale) => {
  const sidebarConfig = frontmatter.sidebar ?? themeLocale.sidebar ?? "auto";
  const sidebarDepth = frontmatter.sidebarDepth ?? themeLocale.sidebarDepth ?? 2;
  if (frontmatter.home || sidebarConfig === false) {
    return [];
  }
  if (sidebarConfig === "auto") {
    return resolveAutoSidebarItems(sidebarDepth);
  }
  if (isArray(sidebarConfig)) {
    return resolveArraySidebarItems(sidebarConfig, sidebarDepth);
  }
  if (isPlainObject(sidebarConfig)) {
    return resolveMultiSidebarItems(sidebarConfig, sidebarDepth);
  }
  return [];
};
const headerToSidebarItem = (header, sidebarDepth) => ({
  text: header.title,
  link: header.link,
  children: headersToSidebarItemChildren(header.children, sidebarDepth)
});
const headersToSidebarItemChildren = (headers, sidebarDepth) => sidebarDepth > 0 ? headers.map((header) => headerToSidebarItem(header, sidebarDepth - 1)) : [];
const resolveAutoSidebarItems = (sidebarDepth) => {
  const page = usePageData();
  return [
    {
      text: page.value.title,
      children: headersToSidebarItemChildren(page.value.headers, sidebarDepth)
    }
  ];
};
const resolveArraySidebarItems = (sidebarConfig, sidebarDepth) => {
  const route = useRoute();
  const page = usePageData();
  const handleChildItem = (item) => {
    var _a;
    let childItem;
    if (isString(item)) {
      childItem = useNavLink(item);
    } else {
      childItem = item;
    }
    if (childItem.children) {
      return {
        ...childItem,
        children: childItem.children.map((item2) => handleChildItem(item2))
      };
    }
    if (childItem.link === route.path) {
      const headers = ((_a = page.value.headers[0]) == null ? void 0 : _a.level) === 1 ? page.value.headers[0].children : page.value.headers;
      return {
        ...childItem,
        children: headersToSidebarItemChildren(headers, sidebarDepth)
      };
    }
    return childItem;
  };
  return sidebarConfig.map((item) => handleChildItem(item));
};
const resolveMultiSidebarItems = (sidebarConfig, sidebarDepth) => {
  const route = useRoute();
  const sidebarPath = resolveLocalePath(sidebarConfig, route.path);
  const matchedSidebarConfig = sidebarConfig[sidebarPath] ?? [];
  return resolveArraySidebarItems(matchedSidebarConfig, sidebarDepth);
};
const _sfc_main$n = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_Content = resolveComponent("Content");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "theme-default-content" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_Content, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup$n = _sfc_main$n.setup;
_sfc_main$n.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/HomeContent.vue");
  return _sfc_setup$n ? _sfc_setup$n(props, ctx) : void 0;
};
const HomeContent = /* @__PURE__ */ _export_sfc(_sfc_main$n, [["ssrRender", _sfc_ssrRender$1], ["__file", "HomeContent.vue"]]);
const _sfc_main$m = /* @__PURE__ */ defineComponent({
  __name: "HomeFeatures",
  __ssrInlineRender: true,
  setup(__props) {
    const frontmatter = usePageFrontmatter();
    const features = computed(() => {
      if (isArray(frontmatter.value.features)) {
        return frontmatter.value.features;
      }
      return [];
    });
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(features).length) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "features" }, _attrs))}><!--[-->`);
        ssrRenderList(unref(features), (feature) => {
          _push(`<div class="feature"><h2>${ssrInterpolate(feature.title)}</h2><p>${ssrInterpolate(feature.details)}</p></div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup$m = _sfc_main$m.setup;
_sfc_main$m.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/HomeFeatures.vue");
  return _sfc_setup$m ? _sfc_setup$m(props, ctx) : void 0;
};
const HomeFeatures = /* @__PURE__ */ _export_sfc(_sfc_main$m, [["__file", "HomeFeatures.vue"]]);
const _sfc_main$l = /* @__PURE__ */ defineComponent({
  __name: "HomeFooter",
  __ssrInlineRender: true,
  setup(__props) {
    const frontmatter = usePageFrontmatter();
    const footer = computed(() => frontmatter.value.footer);
    const footerHtml = computed(() => frontmatter.value.footerHtml);
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(footer)) {
        _push(`<!--[--><!-- eslint-disable-next-line vue/no-v-html -->`);
        if (unref(footerHtml)) {
          _push(`<div class="footer">${unref(footer)}</div>`);
        } else {
          _push(`<div class="footer">${ssrInterpolate(unref(footer))}</div>`);
        }
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup$l = _sfc_main$l.setup;
_sfc_main$l.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/HomeFooter.vue");
  return _sfc_setup$l ? _sfc_setup$l(props, ctx) : void 0;
};
const HomeFooter = /* @__PURE__ */ _export_sfc(_sfc_main$l, [["__file", "HomeFooter.vue"]]);
const __default__ = defineComponent({
  inheritAttrs: false
});
const _sfc_main$k = /* @__PURE__ */ defineComponent({
  ...__default__,
  __name: "AutoLink",
  __ssrInlineRender: true,
  props: {
    item: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const route = useRoute();
    const site = useSiteData();
    const { item } = toRefs(props);
    const hasHttpProtocol = computed(() => isLinkHttp(item.value.link));
    const hasNonHttpProtocol = computed(
      () => isLinkMailto(item.value.link) || isLinkTel(item.value.link)
    );
    const linkTarget = computed(() => {
      if (hasNonHttpProtocol.value)
        return void 0;
      if (item.value.target)
        return item.value.target;
      if (hasHttpProtocol.value)
        return "_blank";
      return void 0;
    });
    const isBlankTarget = computed(() => linkTarget.value === "_blank");
    const isRouterLink = computed(
      () => !hasHttpProtocol.value && !hasNonHttpProtocol.value && !isBlankTarget.value
    );
    const linkRel = computed(() => {
      if (hasNonHttpProtocol.value)
        return void 0;
      if (item.value.rel)
        return item.value.rel;
      if (isBlankTarget.value)
        return "noopener noreferrer";
      return void 0;
    });
    const linkAriaLabel = computed(() => item.value.ariaLabel || item.value.text);
    const shouldBeActiveInSubpath = computed(() => {
      const localeKeys = Object.keys(site.value.locales);
      if (localeKeys.length) {
        return !localeKeys.some((key) => key === item.value.link);
      }
      return item.value.link !== "/";
    });
    const isActiveInSubpath = computed(() => {
      if (!shouldBeActiveInSubpath.value) {
        return false;
      }
      return route.path.startsWith(item.value.link);
    });
    const isActive = computed(() => {
      if (!isRouterLink.value) {
        return false;
      }
      if (item.value.activeMatch) {
        return new RegExp(item.value.activeMatch).test(route.path);
      }
      return isActiveInSubpath.value;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_RouterLink = resolveComponent("RouterLink");
      const _component_AutoLinkExternalIcon = resolveComponent("AutoLinkExternalIcon");
      if (unref(isRouterLink)) {
        _push(ssrRenderComponent(_component_RouterLink, mergeProps({
          class: { "router-link-active": unref(isActive) },
          to: unref(item).link,
          "aria-label": unref(linkAriaLabel)
        }, _ctx.$attrs, _attrs), {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              ssrRenderSlot(_ctx.$slots, "before", {}, null, _push2, _parent2, _scopeId);
              _push2(` ${ssrInterpolate(unref(item).text)} `);
              ssrRenderSlot(_ctx.$slots, "after", {}, null, _push2, _parent2, _scopeId);
            } else {
              return [
                renderSlot(_ctx.$slots, "before"),
                createTextVNode(
                  " " + toDisplayString(unref(item).text) + " ",
                  1
                  /* TEXT */
                ),
                renderSlot(_ctx.$slots, "after")
              ];
            }
          }),
          _: 3
          /* FORWARDED */
        }, _parent));
      } else {
        _push(`<a${ssrRenderAttrs(mergeProps({
          class: "external-link",
          href: unref(item).link,
          rel: unref(linkRel),
          target: unref(linkTarget),
          "aria-label": unref(linkAriaLabel)
        }, _ctx.$attrs, _attrs))}>`);
        ssrRenderSlot(_ctx.$slots, "before", {}, null, _push, _parent);
        _push(` ${ssrInterpolate(unref(item).text)} `);
        if (unref(isBlankTarget)) {
          _push(ssrRenderComponent(_component_AutoLinkExternalIcon, null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        ssrRenderSlot(_ctx.$slots, "after", {}, null, _push, _parent);
        _push(`</a>`);
      }
    };
  }
});
const _sfc_setup$k = _sfc_main$k.setup;
_sfc_main$k.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/AutoLink.vue");
  return _sfc_setup$k ? _sfc_setup$k(props, ctx) : void 0;
};
const AutoLink = /* @__PURE__ */ _export_sfc(_sfc_main$k, [["__file", "AutoLink.vue"]]);
const _sfc_main$j = /* @__PURE__ */ defineComponent({
  __name: "HomeHero",
  __ssrInlineRender: true,
  setup(__props) {
    const frontmatter = usePageFrontmatter();
    const siteLocale = useSiteLocaleData();
    const isDarkMode = useDarkMode();
    const heroImage = computed(() => {
      if (isDarkMode.value && frontmatter.value.heroImageDark !== void 0) {
        return frontmatter.value.heroImageDark;
      }
      return frontmatter.value.heroImage;
    });
    const heroAlt = computed(
      () => frontmatter.value.heroAlt || heroText.value || "hero"
    );
    const heroHeight = computed(() => frontmatter.value.heroHeight || 280);
    const heroText = computed(() => {
      if (frontmatter.value.heroText === null) {
        return null;
      }
      return frontmatter.value.heroText || siteLocale.value.title || "Hello";
    });
    const tagline = computed(() => {
      if (frontmatter.value.tagline === null) {
        return null;
      }
      return frontmatter.value.tagline || siteLocale.value.description || "Welcome to your VuePress site";
    });
    const actions = computed(() => {
      if (!isArray(frontmatter.value.actions)) {
        return [];
      }
      return frontmatter.value.actions.map(({ text, link, type = "primary" }) => ({
        text,
        link,
        type
      }));
    });
    const HomeHeroImage = () => {
      if (!heroImage.value)
        return null;
      const img = h("img", {
        src: withBase(heroImage.value),
        alt: heroAlt.value,
        height: heroHeight.value
      });
      if (frontmatter.value.heroImageDark === void 0) {
        return img;
      }
      return h(ClientOnly, () => img);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<header${ssrRenderAttrs(mergeProps({ class: "hero" }, _attrs))}>`);
      _push(ssrRenderComponent(HomeHeroImage, null, null, _parent));
      if (unref(heroText)) {
        _push(`<h1 id="main-title">${ssrInterpolate(unref(heroText))}</h1>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(tagline)) {
        _push(`<p class="description">${ssrInterpolate(unref(tagline))}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(actions).length) {
        _push(`<p class="actions"><!--[-->`);
        ssrRenderList(unref(actions), (action) => {
          _push(ssrRenderComponent(AutoLink, {
            key: action.text,
            class: ["action-button", [action.type]],
            item: action
          }, null, _parent));
        });
        _push(`<!--]--></p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</header>`);
    };
  }
});
const _sfc_setup$j = _sfc_main$j.setup;
_sfc_main$j.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/HomeHero.vue");
  return _sfc_setup$j ? _sfc_setup$j(props, ctx) : void 0;
};
const HomeHero = /* @__PURE__ */ _export_sfc(_sfc_main$j, [["__file", "HomeHero.vue"]]);
const _sfc_main$i = /* @__PURE__ */ defineComponent({
  __name: "Home",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<main${ssrRenderAttrs(mergeProps({ class: "home" }, _attrs))}>`);
      _push(ssrRenderComponent(HomeHero, null, null, _parent));
      _push(ssrRenderComponent(HomeFeatures, null, null, _parent));
      _push(ssrRenderComponent(HomeContent, null, null, _parent));
      _push(ssrRenderComponent(HomeFooter, null, null, _parent));
      _push(`</main>`);
    };
  }
});
const _sfc_setup$i = _sfc_main$i.setup;
_sfc_main$i.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/Home.vue");
  return _sfc_setup$i ? _sfc_setup$i(props, ctx) : void 0;
};
const Home = /* @__PURE__ */ _export_sfc(_sfc_main$i, [["__file", "Home.vue"]]);
const _sfc_main$h = /* @__PURE__ */ defineComponent({
  __name: "NavbarBrand",
  __ssrInlineRender: true,
  setup(__props) {
    const routeLocale = useRouteLocale();
    const siteLocale = useSiteLocaleData();
    const themeLocale = useThemeLocaleData();
    const isDarkMode = useDarkMode();
    const navbarBrandLink = computed(
      () => themeLocale.value.home || routeLocale.value
    );
    const navbarBrandTitle = computed(() => siteLocale.value.title);
    const navbarBrandLogo = computed(() => {
      if (isDarkMode.value && themeLocale.value.logoDark !== void 0) {
        return themeLocale.value.logoDark;
      }
      return themeLocale.value.logo;
    });
    const NavbarBrandLogo = () => {
      if (!navbarBrandLogo.value)
        return null;
      const img = h("img", {
        class: "logo",
        src: withBase(navbarBrandLogo.value),
        alt: navbarBrandTitle.value
      });
      if (themeLocale.value.logoDark === void 0) {
        return img;
      }
      return h(ClientOnly, () => img);
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_RouterLink = resolveComponent("RouterLink");
      _push(ssrRenderComponent(_component_RouterLink, mergeProps({ to: unref(navbarBrandLink) }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(NavbarBrandLogo, null, null, _parent2, _scopeId));
            if (unref(navbarBrandTitle)) {
              _push2(`<span class="${ssrRenderClass([{ "can-hide": unref(navbarBrandLogo) }, "site-name"])}"${_scopeId}>${ssrInterpolate(unref(navbarBrandTitle))}</span>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode(NavbarBrandLogo),
              unref(navbarBrandTitle) ? (openBlock(), createBlock(
                "span",
                {
                  key: 0,
                  class: ["site-name", { "can-hide": unref(navbarBrandLogo) }]
                },
                toDisplayString(unref(navbarBrandTitle)),
                3
                /* TEXT, CLASS */
              )) : createCommentVNode("v-if", true)
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
    };
  }
});
const _sfc_setup$h = _sfc_main$h.setup;
_sfc_main$h.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/NavbarBrand.vue");
  return _sfc_setup$h ? _sfc_setup$h(props, ctx) : void 0;
};
const NavbarBrand = /* @__PURE__ */ _export_sfc(_sfc_main$h, [["__file", "NavbarBrand.vue"]]);
const _sfc_main$g = /* @__PURE__ */ defineComponent({
  __name: "DropdownTransition",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      ssrRenderSlotInner(_ctx.$slots, "default", {}, null, _push, _parent, null, true);
    };
  }
});
const _sfc_setup$g = _sfc_main$g.setup;
_sfc_main$g.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/DropdownTransition.vue");
  return _sfc_setup$g ? _sfc_setup$g(props, ctx) : void 0;
};
const DropdownTransition = /* @__PURE__ */ _export_sfc(_sfc_main$g, [["__file", "DropdownTransition.vue"]]);
const _sfc_main$f = /* @__PURE__ */ defineComponent({
  __name: "NavbarDropdown",
  __ssrInlineRender: true,
  props: {
    item: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const { item } = toRefs(props);
    const dropdownAriaLabel = computed(
      () => item.value.ariaLabel || item.value.text
    );
    const open = ref(false);
    const route = useRoute();
    watch(
      () => route.path,
      () => {
        open.value = false;
      }
    );
    const isLastItemOfArray = (item2, arr) => arr[arr.length - 1] === item2;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["navbar-dropdown-wrapper", { open: open.value }]
      }, _attrs))}><button class="navbar-dropdown-title" type="button"${ssrRenderAttr("aria-label", unref(dropdownAriaLabel))}><span class="title">${ssrInterpolate(unref(item).text)}</span><span class="arrow down"></span></button><button class="navbar-dropdown-title-mobile" type="button"${ssrRenderAttr("aria-label", unref(dropdownAriaLabel))}><span class="title">${ssrInterpolate(unref(item).text)}</span><span class="${ssrRenderClass([open.value ? "down" : "right", "arrow"])}"></span></button>`);
      _push(ssrRenderComponent(DropdownTransition, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<ul style="${ssrRenderStyle(open.value ? null : { display: "none" })}" class="navbar-dropdown"${_scopeId}><!--[-->`);
            ssrRenderList(unref(item).children, (child) => {
              _push2(`<li class="navbar-dropdown-item"${_scopeId}>`);
              if (child.children) {
                _push2(`<!--[--><h4 class="navbar-dropdown-subtitle"${_scopeId}>`);
                if (child.link) {
                  _push2(ssrRenderComponent(AutoLink, {
                    item: child,
                    onFocusout: ($event) => isLastItemOfArray(child, unref(item).children) && child.children.length === 0 && (open.value = false)
                  }, null, _parent2, _scopeId));
                } else {
                  _push2(`<span${_scopeId}>${ssrInterpolate(child.text)}</span>`);
                }
                _push2(`</h4><ul class="navbar-dropdown-subitem-wrapper"${_scopeId}><!--[-->`);
                ssrRenderList(child.children, (grandchild) => {
                  _push2(`<li class="navbar-dropdown-subitem"${_scopeId}>`);
                  _push2(ssrRenderComponent(AutoLink, {
                    item: grandchild,
                    onFocusout: ($event) => isLastItemOfArray(grandchild, child.children) && isLastItemOfArray(child, unref(item).children) && (open.value = false)
                  }, null, _parent2, _scopeId));
                  _push2(`</li>`);
                });
                _push2(`<!--]--></ul><!--]-->`);
              } else {
                _push2(ssrRenderComponent(AutoLink, {
                  item: child,
                  onFocusout: ($event) => isLastItemOfArray(child, unref(item).children) && (open.value = false)
                }, null, _parent2, _scopeId));
              }
              _push2(`</li>`);
            });
            _push2(`<!--]--></ul>`);
          } else {
            return [
              withDirectives(createVNode(
                "ul",
                { class: "navbar-dropdown" },
                [
                  (openBlock(true), createBlock(
                    Fragment,
                    null,
                    renderList(unref(item).children, (child) => {
                      return openBlock(), createBlock("li", {
                        key: child.text,
                        class: "navbar-dropdown-item"
                      }, [
                        child.children ? (openBlock(), createBlock(
                          Fragment,
                          { key: 0 },
                          [
                            createVNode("h4", { class: "navbar-dropdown-subtitle" }, [
                              child.link ? (openBlock(), createBlock(AutoLink, {
                                key: 0,
                                item: child,
                                onFocusout: ($event) => isLastItemOfArray(child, unref(item).children) && child.children.length === 0 && (open.value = false)
                              }, null, 8, ["item", "onFocusout"])) : (openBlock(), createBlock(
                                "span",
                                { key: 1 },
                                toDisplayString(child.text),
                                1
                                /* TEXT */
                              ))
                            ]),
                            createVNode("ul", { class: "navbar-dropdown-subitem-wrapper" }, [
                              (openBlock(true), createBlock(
                                Fragment,
                                null,
                                renderList(child.children, (grandchild) => {
                                  return openBlock(), createBlock("li", {
                                    key: grandchild.link,
                                    class: "navbar-dropdown-subitem"
                                  }, [
                                    createVNode(AutoLink, {
                                      item: grandchild,
                                      onFocusout: ($event) => isLastItemOfArray(grandchild, child.children) && isLastItemOfArray(child, unref(item).children) && (open.value = false)
                                    }, null, 8, ["item", "onFocusout"])
                                  ]);
                                }),
                                128
                                /* KEYED_FRAGMENT */
                              ))
                            ])
                          ],
                          64
                          /* STABLE_FRAGMENT */
                        )) : (openBlock(), createBlock(AutoLink, {
                          key: 1,
                          item: child,
                          onFocusout: ($event) => isLastItemOfArray(child, unref(item).children) && (open.value = false)
                        }, null, 8, ["item", "onFocusout"]))
                      ]);
                    }),
                    128
                    /* KEYED_FRAGMENT */
                  ))
                ],
                512
                /* NEED_PATCH */
              ), [
                [vShow, open.value]
              ])
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/NavbarDropdown.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const NavbarDropdown = /* @__PURE__ */ _export_sfc(_sfc_main$f, [["__file", "NavbarDropdown.vue"]]);
const normalizePath = (path) => decodeURI(path).replace(/#.*$/, "").replace(/(index)?\.(md|html)$/, "");
const isActiveLink = (link, route) => {
  if (route.hash === link) {
    return true;
  }
  const currentPath = normalizePath(route.path);
  const targetPath = normalizePath(link);
  return currentPath === targetPath;
};
const isActiveSidebarItem = (item, route) => {
  if (item.link && isActiveLink(item.link, route)) {
    return true;
  }
  if (item.children) {
    return item.children.some((child) => isActiveSidebarItem(child, route));
  }
  return false;
};
const resolveRepoType = (repo) => {
  if (!isLinkHttp(repo) || /github\.com/.test(repo))
    return "GitHub";
  if (/bitbucket\.org/.test(repo))
    return "Bitbucket";
  if (/gitlab\.com/.test(repo))
    return "GitLab";
  if (/gitee\.com/.test(repo))
    return "Gitee";
  return null;
};
const editLinkPatterns = {
  GitHub: ":repo/edit/:branch/:path",
  GitLab: ":repo/-/edit/:branch/:path",
  Gitee: ":repo/edit/:branch/:path",
  Bitbucket: ":repo/src/:branch/:path?mode=edit&spa=0&at=:branch&fileviewer=file-view-default"
};
const resolveEditLinkPatterns = ({ docsRepo, editLinkPattern }) => {
  if (editLinkPattern) {
    return editLinkPattern;
  }
  const repoType = resolveRepoType(docsRepo);
  if (repoType !== null) {
    return editLinkPatterns[repoType];
  }
  return null;
};
const resolveEditLink = ({ docsRepo, docsBranch, docsDir, filePathRelative, editLinkPattern }) => {
  if (!filePathRelative)
    return null;
  const pattern = resolveEditLinkPatterns({ docsRepo, editLinkPattern });
  if (!pattern)
    return null;
  return pattern.replace(/:repo/, isLinkHttp(docsRepo) ? docsRepo : `https://github.com/${docsRepo}`).replace(/:branch/, docsBranch).replace(/:path/, removeLeadingSlash(`${removeEndingSlash(docsDir)}/${filePathRelative}`));
};
const _sfc_main$e = /* @__PURE__ */ defineComponent({
  __name: "NavbarItems",
  __ssrInlineRender: true,
  setup(__props) {
    const useNavbarSelectLanguage = () => {
      const router = useRouter();
      const routeLocale = useRouteLocale();
      const siteLocale = useSiteLocaleData();
      const themeLocale = useThemeLocaleData();
      return computed(() => {
        const localePaths = Object.keys(siteLocale.value.locales);
        if (localePaths.length < 2) {
          return [];
        }
        const currentPath = router.currentRoute.value.path;
        const currentFullPath = router.currentRoute.value.fullPath;
        const languageDropdown = {
          text: themeLocale.value.selectLanguageText ?? "unknown language",
          ariaLabel: themeLocale.value.selectLanguageAriaLabel ?? themeLocale.value.selectLanguageText ?? "unknown language",
          children: localePaths.map((targetLocalePath) => {
            var _a, _b;
            const targetSiteLocale = ((_a = siteLocale.value.locales) == null ? void 0 : _a[targetLocalePath]) ?? {};
            const targetThemeLocale = ((_b = themeLocale.value.locales) == null ? void 0 : _b[targetLocalePath]) ?? {};
            const targetLang = `${targetSiteLocale.lang}`;
            const text = targetThemeLocale.selectLanguageName ?? targetLang;
            let link;
            if (targetLang === siteLocale.value.lang) {
              link = currentFullPath;
            } else {
              const targetLocalePage = currentPath.replace(
                routeLocale.value,
                targetLocalePath
              );
              if (router.getRoutes().some((item) => item.path === targetLocalePage)) {
                link = currentFullPath.replace(currentPath, targetLocalePage);
              } else {
                link = targetThemeLocale.home ?? targetLocalePath;
              }
            }
            return {
              text,
              link
            };
          })
        };
        return [languageDropdown];
      });
    };
    const useNavbarRepo = () => {
      const themeLocale = useThemeLocaleData();
      const repo = computed(() => themeLocale.value.repo);
      const repoType = computed(
        () => repo.value ? resolveRepoType(repo.value) : null
      );
      const repoLink = computed(() => {
        if (repo.value && !isLinkHttp(repo.value)) {
          return `https://github.com/${repo.value}`;
        }
        return repo.value;
      });
      const repoLabel = computed(() => {
        if (!repoLink.value)
          return null;
        if (themeLocale.value.repoLabel)
          return themeLocale.value.repoLabel;
        if (repoType.value === null)
          return "Source";
        return repoType.value;
      });
      return computed(() => {
        if (!repoLink.value || !repoLabel.value) {
          return [];
        }
        return [
          {
            text: repoLabel.value,
            link: repoLink.value
          }
        ];
      });
    };
    const resolveNavbarItem = (item) => {
      if (isString(item)) {
        return useNavLink(item);
      }
      if (item.children) {
        return {
          ...item,
          children: item.children.map(resolveNavbarItem)
        };
      }
      return item;
    };
    const useNavbarConfig = () => {
      const themeLocale = useThemeLocaleData();
      return computed(() => (themeLocale.value.navbar || []).map(resolveNavbarItem));
    };
    const isMobile = ref(false);
    const navbarConfig = useNavbarConfig();
    const navbarSelectLanguage = useNavbarSelectLanguage();
    const navbarRepo = useNavbarRepo();
    const navbarLinks = computed(() => [
      ...navbarConfig.value,
      ...navbarSelectLanguage.value,
      ...navbarRepo.value
    ]);
    onMounted(() => {
      const MOBILE_DESKTOP_BREAKPOINT = 719;
      const handleMobile = () => {
        if (window.innerWidth < MOBILE_DESKTOP_BREAKPOINT) {
          isMobile.value = true;
        } else {
          isMobile.value = false;
        }
      };
      handleMobile();
      window.addEventListener("resize", handleMobile, false);
      window.addEventListener("orientationchange", handleMobile, false);
    });
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(navbarLinks).length) {
        _push(`<nav${ssrRenderAttrs(mergeProps({ class: "navbar-items" }, _attrs))}><!--[-->`);
        ssrRenderList(unref(navbarLinks), (item) => {
          _push(`<div class="navbar-item">`);
          if (item.children) {
            _push(ssrRenderComponent(NavbarDropdown, {
              item,
              class: isMobile.value ? "mobile" : ""
            }, null, _parent));
          } else {
            _push(ssrRenderComponent(AutoLink, { item }, null, _parent));
          }
          _push(`</div>`);
        });
        _push(`<!--]--></nav>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/NavbarItems.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const NavbarItems = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["__file", "NavbarItems.vue"]]);
const _sfc_main$d = /* @__PURE__ */ defineComponent({
  __name: "ToggleColorModeButton",
  __ssrInlineRender: true,
  setup(__props) {
    const themeLocale = useThemeLocaleData();
    const isDarkMode = useDarkMode();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<button${ssrRenderAttrs(mergeProps({
        class: "toggle-color-mode-button",
        title: unref(themeLocale).toggleColorMode
      }, _attrs))}><svg style="${ssrRenderStyle(!unref(isDarkMode) ? null : { display: "none" })}" class="icon" focusable="false" viewBox="0 0 32 32"><path d="M16 12.005a4 4 0 1 1-4 4a4.005 4.005 0 0 1 4-4m0-2a6 6 0 1 0 6 6a6 6 0 0 0-6-6z" fill="currentColor"></path><path d="M5.394 6.813l1.414-1.415l3.506 3.506L8.9 10.318z" fill="currentColor"></path><path d="M2 15.005h5v2H2z" fill="currentColor"></path><path d="M5.394 25.197L8.9 21.691l1.414 1.415l-3.506 3.505z" fill="currentColor"></path><path d="M15 25.005h2v5h-2z" fill="currentColor"></path><path d="M21.687 23.106l1.414-1.415l3.506 3.506l-1.414 1.414z" fill="currentColor"></path><path d="M25 15.005h5v2h-5z" fill="currentColor"></path><path d="M21.687 8.904l3.506-3.506l1.414 1.415l-3.506 3.505z" fill="currentColor"></path><path d="M15 2.005h2v5h-2z" fill="currentColor"></path></svg><svg style="${ssrRenderStyle(unref(isDarkMode) ? null : { display: "none" })}" class="icon" focusable="false" viewBox="0 0 32 32"><path d="M13.502 5.414a15.075 15.075 0 0 0 11.594 18.194a11.113 11.113 0 0 1-7.975 3.39c-.138 0-.278.005-.418 0a11.094 11.094 0 0 1-3.2-21.584M14.98 3a1.002 1.002 0 0 0-.175.016a13.096 13.096 0 0 0 1.825 25.981c.164.006.328 0 .49 0a13.072 13.072 0 0 0 10.703-5.555a1.01 1.01 0 0 0-.783-1.565A13.08 13.08 0 0 1 15.89 4.38A1.015 1.015 0 0 0 14.98 3z" fill="currentColor"></path></svg></button>`);
    };
  }
});
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/ToggleColorModeButton.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const ToggleColorModeButton = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["__file", "ToggleColorModeButton.vue"]]);
const _sfc_main$c = /* @__PURE__ */ defineComponent({
  __name: "ToggleSidebarButton",
  __ssrInlineRender: true,
  emits: ["toggle"],
  setup(__props) {
    const themeLocale = useThemeLocaleData();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "toggle-sidebar-button",
        title: unref(themeLocale).toggleSidebar,
        "aria-expanded": "false",
        role: "button",
        tabindex: "0"
      }, _attrs))}><div class="icon" aria-hidden="true"><span></span><span></span><span></span></div></div>`);
    };
  }
});
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/ToggleSidebarButton.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const ToggleSidebarButton = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["__file", "ToggleSidebarButton.vue"]]);
const _sfc_main$b = /* @__PURE__ */ defineComponent({
  __name: "Navbar",
  __ssrInlineRender: true,
  emits: ["toggle-sidebar"],
  setup(__props) {
    const themeLocale = useThemeLocaleData();
    const navbar = ref(null);
    const navbarBrand = ref(null);
    const linksWrapperMaxWidth = ref(0);
    const linksWrapperStyle = computed(() => {
      if (!linksWrapperMaxWidth.value) {
        return {};
      }
      return {
        maxWidth: linksWrapperMaxWidth.value + "px"
      };
    });
    onMounted(() => {
      const MOBILE_DESKTOP_BREAKPOINT = 719;
      const navbarHorizontalPadding = getCssValue(navbar.value, "paddingLeft") + getCssValue(navbar.value, "paddingRight");
      const handleLinksWrapWidth = () => {
        var _a;
        if (window.innerWidth < MOBILE_DESKTOP_BREAKPOINT) {
          linksWrapperMaxWidth.value = 0;
        } else {
          linksWrapperMaxWidth.value = navbar.value.offsetWidth - navbarHorizontalPadding - (((_a = navbarBrand.value) == null ? void 0 : _a.offsetWidth) || 0);
        }
      };
      handleLinksWrapWidth();
      window.addEventListener("resize", handleLinksWrapWidth, false);
      window.addEventListener("orientationchange", handleLinksWrapWidth, false);
    });
    function getCssValue(el, property) {
      var _a, _b, _c;
      const val = (_c = (_b = (_a = el == null ? void 0 : el.ownerDocument) == null ? void 0 : _a.defaultView) == null ? void 0 : _b.getComputedStyle(el, null)) == null ? void 0 : _c[property];
      const num = Number.parseInt(val, 10);
      return Number.isNaN(num) ? 0 : num;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NavbarSearch = resolveComponent("NavbarSearch");
      _push(`<header${ssrRenderAttrs(mergeProps({
        ref_key: "navbar",
        ref: navbar,
        class: "navbar"
      }, _attrs))}>`);
      _push(ssrRenderComponent(ToggleSidebarButton, {
        onToggle: ($event) => _ctx.$emit("toggle-sidebar")
      }, null, _parent));
      _push(`<span>`);
      _push(ssrRenderComponent(NavbarBrand, null, null, _parent));
      _push(`</span><div class="navbar-items-wrapper" style="${ssrRenderStyle(unref(linksWrapperStyle))}">`);
      ssrRenderSlot(_ctx.$slots, "before", {}, null, _push, _parent);
      _push(ssrRenderComponent(NavbarItems, { class: "can-hide" }, null, _parent));
      ssrRenderSlot(_ctx.$slots, "after", {}, null, _push, _parent);
      if (unref(themeLocale).colorModeSwitch) {
        _push(ssrRenderComponent(ToggleColorModeButton, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_NavbarSearch, null, null, _parent));
      _push(`</div></header>`);
    };
  }
});
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/Navbar.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const Navbar = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["__file", "Navbar.vue"]]);
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  __name: "PageMeta",
  __ssrInlineRender: true,
  setup(__props) {
    const useEditNavLink = () => {
      const themeLocale2 = useThemeLocaleData();
      const page = usePageData();
      const frontmatter = usePageFrontmatter();
      return computed(() => {
        const showEditLink = frontmatter.value.editLink ?? themeLocale2.value.editLink ?? true;
        if (!showEditLink) {
          return null;
        }
        const {
          repo,
          docsRepo = repo,
          docsBranch = "main",
          docsDir = "",
          editLinkText
        } = themeLocale2.value;
        if (!docsRepo)
          return null;
        const editLink = resolveEditLink({
          docsRepo,
          docsBranch,
          docsDir,
          filePathRelative: page.value.filePathRelative,
          editLinkPattern: frontmatter.value.editLinkPattern ?? themeLocale2.value.editLinkPattern
        });
        if (!editLink)
          return null;
        return {
          text: editLinkText ?? "Edit this page",
          link: editLink
        };
      });
    };
    const useLastUpdated = () => {
      const themeLocale2 = useThemeLocaleData();
      const page = usePageData();
      const frontmatter = usePageFrontmatter();
      return computed(() => {
        var _a, _b;
        const showLastUpdated = frontmatter.value.lastUpdated ?? themeLocale2.value.lastUpdated ?? true;
        if (!showLastUpdated)
          return null;
        if (!((_a = page.value.git) == null ? void 0 : _a.updatedTime))
          return null;
        const updatedDate = new Date((_b = page.value.git) == null ? void 0 : _b.updatedTime);
        return updatedDate.toLocaleString();
      });
    };
    const useContributors = () => {
      const themeLocale2 = useThemeLocaleData();
      const page = usePageData();
      const frontmatter = usePageFrontmatter();
      return computed(() => {
        var _a;
        const showContributors = frontmatter.value.contributors ?? themeLocale2.value.contributors ?? true;
        if (!showContributors)
          return null;
        return ((_a = page.value.git) == null ? void 0 : _a.contributors) ?? null;
      });
    };
    const themeLocale = useThemeLocaleData();
    const editNavLink = useEditNavLink();
    const lastUpdated = useLastUpdated();
    const contributors = useContributors();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = resolveComponent("ClientOnly");
      _push(`<footer${ssrRenderAttrs(mergeProps({ class: "page-meta" }, _attrs))}>`);
      if (unref(editNavLink)) {
        _push(`<div class="meta-item edit-link">`);
        _push(ssrRenderComponent(AutoLink, {
          class: "meta-item-label",
          item: unref(editNavLink)
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(lastUpdated)) {
        _push(`<div class="meta-item last-updated"><span class="meta-item-label">${ssrInterpolate(unref(themeLocale).lastUpdatedText)}: </span>`);
        _push(ssrRenderComponent(_component_ClientOnly, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="meta-item-info"${_scopeId}>${ssrInterpolate(unref(lastUpdated))}</span>`);
            } else {
              return [
                createVNode(
                  "span",
                  { class: "meta-item-info" },
                  toDisplayString(unref(lastUpdated)),
                  1
                  /* TEXT */
                )
              ];
            }
          }),
          _: 1
          /* STABLE */
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(contributors) && unref(contributors).length) {
        _push(`<div class="meta-item contributors"><span class="meta-item-label">${ssrInterpolate(unref(themeLocale).contributorsText)}: </span><span class="meta-item-info"><!--[-->`);
        ssrRenderList(unref(contributors), (contributor, index2) => {
          _push(`<!--[--><span class="contributor"${ssrRenderAttr("title", `email: ${contributor.email}`)}>${ssrInterpolate(contributor.name)}</span>`);
          if (index2 !== unref(contributors).length - 1) {
            _push(`<!--[-->, <!--]-->`);
          } else {
            _push(`<!---->`);
          }
          _push(`<!--]-->`);
        });
        _push(`<!--]--></span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</footer>`);
    };
  }
});
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/PageMeta.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const PageMeta = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__file", "PageMeta.vue"]]);
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  __name: "PageNav",
  __ssrInlineRender: true,
  setup(__props) {
    const resolveFromFrontmatterConfig = (conf) => {
      if (conf === false) {
        return null;
      }
      if (isString(conf)) {
        return useNavLink(conf);
      }
      if (isPlainObject(conf)) {
        return conf;
      }
      return false;
    };
    const resolveFromSidebarItems = (sidebarItems2, currentPath, offset) => {
      const index2 = sidebarItems2.findIndex((item) => item.link === currentPath);
      if (index2 !== -1) {
        const targetItem = sidebarItems2[index2 + offset];
        if (!(targetItem == null ? void 0 : targetItem.link)) {
          return null;
        }
        return targetItem;
      }
      for (const item of sidebarItems2) {
        if (item.children) {
          const childResult = resolveFromSidebarItems(
            item.children,
            currentPath,
            offset
          );
          if (childResult) {
            return childResult;
          }
        }
      }
      return null;
    };
    const frontmatter = usePageFrontmatter();
    const sidebarItems = useSidebarItems();
    const route = useRoute();
    const prevNavLink = computed(() => {
      const prevConfig = resolveFromFrontmatterConfig(frontmatter.value.prev);
      if (prevConfig !== false) {
        return prevConfig;
      }
      return resolveFromSidebarItems(sidebarItems.value, route.path, -1);
    });
    const nextNavLink = computed(() => {
      const nextConfig = resolveFromFrontmatterConfig(frontmatter.value.next);
      if (nextConfig !== false) {
        return nextConfig;
      }
      return resolveFromSidebarItems(sidebarItems.value, route.path, 1);
    });
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(prevNavLink) || unref(nextNavLink)) {
        _push(`<nav${ssrRenderAttrs(mergeProps({ class: "page-nav" }, _attrs))}><p class="inner">`);
        if (unref(prevNavLink)) {
          _push(`<span class="prev">`);
          _push(ssrRenderComponent(AutoLink, { item: unref(prevNavLink) }, null, _parent));
          _push(`</span>`);
        } else {
          _push(`<!---->`);
        }
        if (unref(nextNavLink)) {
          _push(`<span class="next">`);
          _push(ssrRenderComponent(AutoLink, { item: unref(nextNavLink) }, null, _parent));
          _push(`</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</p></nav>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/PageNav.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const PageNav = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__file", "PageNav.vue"]]);
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "Page",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Content = resolveComponent("Content");
      _push(`<main${ssrRenderAttrs(mergeProps({ class: "page" }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "top", {}, null, _push, _parent);
      _push(`<div class="theme-default-content">`);
      ssrRenderSlot(_ctx.$slots, "content-top", {}, null, _push, _parent);
      _push(ssrRenderComponent(_component_Content, null, null, _parent));
      ssrRenderSlot(_ctx.$slots, "content-bottom", {}, null, _push, _parent);
      _push(`</div>`);
      _push(ssrRenderComponent(PageMeta, null, null, _parent));
      _push(ssrRenderComponent(PageNav, null, null, _parent));
      ssrRenderSlot(_ctx.$slots, "bottom", {}, null, _push, _parent);
      _push(`</main>`);
    };
  }
});
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/Page.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const Page = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["__file", "Page.vue"]]);
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "SidebarItem",
  __ssrInlineRender: true,
  props: {
    item: {
      type: Object,
      required: true
    },
    depth: {
      type: Number,
      required: false,
      default: 0
    }
  },
  setup(__props) {
    const props = __props;
    const { item, depth } = toRefs(props);
    const route = useRoute();
    const router = useRouter();
    const isActive = computed(() => isActiveSidebarItem(item.value, route));
    const itemClass = computed(() => ({
      "sidebar-item": true,
      "sidebar-heading": depth.value === 0,
      "active": isActive.value,
      "collapsible": item.value.collapsible
    }));
    const isOpenDefault = computed(
      () => item.value.collapsible ? isActive.value : true
    );
    const [isOpen, toggleIsOpen] = useToggle(isOpenDefault.value);
    const unregisterRouterHook = router.afterEach((to) => {
      nextTick(() => {
        isOpen.value = isOpenDefault.value;
      });
    });
    onBeforeUnmount(() => {
      unregisterRouterHook();
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_SidebarItem = resolveComponent("SidebarItem", true);
      _push(`<li${ssrRenderAttrs(_attrs)}>`);
      if (unref(item).link) {
        _push(ssrRenderComponent(AutoLink, {
          class: unref(itemClass),
          item: unref(item)
        }, null, _parent));
      } else {
        _push(`<p tabindex="0" class="${ssrRenderClass(unref(itemClass))}">${ssrInterpolate(unref(item).text)} `);
        if (unref(item).collapsible) {
          _push(`<span class="${ssrRenderClass([unref(isOpen) ? "down" : "right", "arrow"])}"></span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</p>`);
      }
      if ((_a = unref(item).children) == null ? void 0 : _a.length) {
        _push(ssrRenderComponent(DropdownTransition, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<ul style="${ssrRenderStyle(unref(isOpen) ? null : { display: "none" })}" class="sidebar-item-children"${_scopeId}><!--[-->`);
              ssrRenderList(unref(item).children, (child) => {
                _push2(ssrRenderComponent(_component_SidebarItem, {
                  key: `${unref(depth)}${child.text}${child.link}`,
                  item: child,
                  depth: unref(depth) + 1
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></ul>`);
            } else {
              return [
                withDirectives(createVNode(
                  "ul",
                  { class: "sidebar-item-children" },
                  [
                    (openBlock(true), createBlock(
                      Fragment,
                      null,
                      renderList(unref(item).children, (child) => {
                        return openBlock(), createBlock(_component_SidebarItem, {
                          key: `${unref(depth)}${child.text}${child.link}`,
                          item: child,
                          depth: unref(depth) + 1
                        }, null, 8, ["item", "depth"]);
                      }),
                      128
                      /* KEYED_FRAGMENT */
                    ))
                  ],
                  512
                  /* NEED_PATCH */
                ), [
                  [vShow, unref(isOpen)]
                ])
              ];
            }
          }),
          _: 1
          /* STABLE */
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</li>`);
    };
  }
});
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/SidebarItem.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const SidebarItem = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__file", "SidebarItem.vue"]]);
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "SidebarItems",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const sidebarItems = useSidebarItems();
    onMounted(() => {
      watch(
        () => route.hash,
        (hash) => {
          const sidebar = document.querySelector(".sidebar");
          if (!sidebar)
            return;
          const activeSidebarItem = document.querySelector(
            `.sidebar a.sidebar-item[href="${route.path}${hash}"]`
          );
          if (!activeSidebarItem)
            return;
          const { top: sidebarTop, height: sidebarHeight } = sidebar.getBoundingClientRect();
          const { top: activeSidebarItemTop, height: activeSidebarItemHeight } = activeSidebarItem.getBoundingClientRect();
          if (activeSidebarItemTop < sidebarTop) {
            activeSidebarItem.scrollIntoView(true);
          } else if (activeSidebarItemTop + activeSidebarItemHeight > sidebarTop + sidebarHeight) {
            activeSidebarItem.scrollIntoView(false);
          }
        }
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(sidebarItems).length) {
        _push(`<ul${ssrRenderAttrs(mergeProps({ class: "sidebar-items" }, _attrs))}><!--[-->`);
        ssrRenderList(unref(sidebarItems), (item) => {
          _push(ssrRenderComponent(SidebarItem, {
            key: `${item.text}${item.link}`,
            item
          }, null, _parent));
        });
        _push(`<!--]--></ul>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/SidebarItems.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const SidebarItems = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__file", "SidebarItems.vue"]]);
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "Sidebar",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<aside${ssrRenderAttrs(mergeProps({ class: "sidebar" }, _attrs))}>`);
      _push(ssrRenderComponent(NavbarItems, null, null, _parent));
      ssrRenderSlot(_ctx.$slots, "top", {}, null, _push, _parent);
      _push(ssrRenderComponent(SidebarItems, null, null, _parent));
      ssrRenderSlot(_ctx.$slots, "bottom", {}, null, _push, _parent);
      _push(`</aside>`);
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/components/Sidebar.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const Sidebar = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__file", "Sidebar.vue"]]);
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "Layout",
  __ssrInlineRender: true,
  setup(__props) {
    const page = usePageData();
    const frontmatter = usePageFrontmatter();
    const themeLocale = useThemeLocaleData();
    const shouldShowNavbar = computed(
      () => frontmatter.value.navbar !== false && themeLocale.value.navbar !== false
    );
    const sidebarItems = useSidebarItems();
    const isSidebarOpen = ref(false);
    const toggleSidebar = (to) => {
      isSidebarOpen.value = typeof to === "boolean" ? to : !isSidebarOpen.value;
    };
    const containerClass = computed(() => [
      {
        "no-navbar": !shouldShowNavbar.value,
        "no-sidebar": !sidebarItems.value.length,
        "sidebar-open": isSidebarOpen.value
      },
      frontmatter.value.pageClass
    ]);
    let unregisterRouterHook;
    onMounted(() => {
      const router = useRouter();
      unregisterRouterHook = router.afterEach(() => {
        toggleSidebar(false);
      });
    });
    onUnmounted(() => {
      unregisterRouterHook();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["theme-container", unref(containerClass)]
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "navbar", {}, () => {
        if (unref(shouldShowNavbar)) {
          _push(ssrRenderComponent(Navbar, { onToggleSidebar: toggleSidebar }, {
            before: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                ssrRenderSlot(_ctx.$slots, "navbar-before", {}, null, _push2, _parent2, _scopeId);
              } else {
                return [
                  renderSlot(_ctx.$slots, "navbar-before")
                ];
              }
            }),
            after: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                ssrRenderSlot(_ctx.$slots, "navbar-after", {}, null, _push2, _parent2, _scopeId);
              } else {
                return [
                  renderSlot(_ctx.$slots, "navbar-after")
                ];
              }
            }),
            _: 3
            /* FORWARDED */
          }, _parent));
        } else {
          _push(`<!---->`);
        }
      }, _push, _parent);
      _push(`<div class="sidebar-mask"></div>`);
      ssrRenderSlot(_ctx.$slots, "sidebar", {}, () => {
        _push(ssrRenderComponent(Sidebar, null, {
          top: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              ssrRenderSlot(_ctx.$slots, "sidebar-top", {}, null, _push2, _parent2, _scopeId);
            } else {
              return [
                renderSlot(_ctx.$slots, "sidebar-top")
              ];
            }
          }),
          bottom: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              ssrRenderSlot(_ctx.$slots, "sidebar-bottom", {}, null, _push2, _parent2, _scopeId);
            } else {
              return [
                renderSlot(_ctx.$slots, "sidebar-bottom")
              ];
            }
          }),
          _: 3
          /* FORWARDED */
        }, _parent));
      }, _push, _parent);
      ssrRenderSlot(_ctx.$slots, "page", {}, () => {
        if (unref(frontmatter).home) {
          _push(ssrRenderComponent(Home, null, null, _parent));
        } else {
          _push(ssrRenderComponent(Page, {
            key: unref(page).path
          }, {
            top: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                ssrRenderSlot(_ctx.$slots, "page-top", {}, null, _push2, _parent2, _scopeId);
              } else {
                return [
                  renderSlot(_ctx.$slots, "page-top")
                ];
              }
            }),
            "content-top": withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                ssrRenderSlot(_ctx.$slots, "page-content-top", {}, null, _push2, _parent2, _scopeId);
              } else {
                return [
                  renderSlot(_ctx.$slots, "page-content-top")
                ];
              }
            }),
            "content-bottom": withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                ssrRenderSlot(_ctx.$slots, "page-content-bottom", {}, null, _push2, _parent2, _scopeId);
              } else {
                return [
                  renderSlot(_ctx.$slots, "page-content-bottom")
                ];
              }
            }),
            bottom: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                ssrRenderSlot(_ctx.$slots, "page-bottom", {}, null, _push2, _parent2, _scopeId);
              } else {
                return [
                  renderSlot(_ctx.$slots, "page-bottom")
                ];
              }
            }),
            _: 3
            /* FORWARDED */
          }, _parent));
        }
      }, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/layouts/Layout.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const ParentLayout = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__file", "Layout.vue"]]);
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "NotFound",
  __ssrInlineRender: true,
  setup(__props) {
    const routeLocale = useRouteLocale();
    const themeLocale = useThemeLocaleData();
    const messages = themeLocale.value.notFound ?? ["Not Found"];
    const getMsg = () => messages[Math.floor(Math.random() * messages.length)];
    const homeLink = themeLocale.value.home ?? routeLocale.value;
    const homeText = themeLocale.value.backToHome ?? "Back to home";
    return (_ctx, _push, _parent, _attrs) => {
      const _component_RouterLink = resolveComponent("RouterLink");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "theme-container" }, _attrs))}><main class="page"><div class="theme-default-content"><h1>404</h1><blockquote>${ssrInterpolate(getMsg())}</blockquote>`);
      _push(ssrRenderComponent(_component_RouterLink, { to: unref(homeLink) }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(homeText))}`);
          } else {
            return [
              createTextVNode(
                toDisplayString(unref(homeText)),
                1
                /* TEXT */
              )
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</div></main></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/layouts/NotFound.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const NotFound = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__file", "NotFound.vue"]]);
const index$1 = "";
const clientConfig6 = defineClientConfig({
  enhance({ app, router }) {
    app.component("Badge", Badge);
    app.component("CodeGroup", CodeGroup);
    app.component("CodeGroupItem", CodeGroupItem);
    app.component("AutoLinkExternalIcon", () => {
      const ExternalLinkIcon2 = app.component("ExternalLinkIcon");
      if (ExternalLinkIcon2) {
        return h(ExternalLinkIcon2);
      }
      return null;
    });
    app.component("NavbarSearch", () => {
      const SearchComponent = app.component("Docsearch") || app.component("SearchBox");
      if (SearchComponent) {
        return h(SearchComponent);
      }
      return null;
    });
    const scrollBehavior = router.options.scrollBehavior;
    router.options.scrollBehavior = async (...args) => {
      await useScrollPromise().wait();
      return scrollBehavior(...args);
    };
  },
  setup() {
    setupDarkMode();
    setupSidebarItems();
  },
  layouts: {
    Layout: ParentLayout,
    NotFound
  }
});
const isFocusingTextControl = (target) => {
  if (!(target instanceof Element)) {
    return false;
  }
  return document.activeElement === target && (["TEXTAREA", "SELECT", "INPUT"].includes(target.tagName) || target.hasAttribute("contenteditable"));
};
const isKeyMatched = (event, hotKeys2) => hotKeys2.some((item) => {
  if (isString(item)) {
    return item === event.key;
  }
  const { key, ctrl = false, shift = false, alt = false } = item;
  return key === event.key && ctrl === event.ctrlKey && shift === event.shiftKey && alt === event.altKey;
});
const nonASCIIRegExp = /[^\x00-\x7F]/;
const splitWords = (str) => str.split(/\s+/g).map((str2) => str2.trim()).filter((str2) => !!str2);
const escapeRegExp = (str) => str.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
const isQueryMatched = (query, toMatch) => {
  const toMatchStr = toMatch.join(" ");
  const words = splitWords(query);
  if (nonASCIIRegExp.test(query)) {
    return words.some((word) => toMatchStr.toLowerCase().indexOf(word) > -1);
  }
  const hasTrailingSpace = query.endsWith(" ");
  const searchRegex = new RegExp(words.map((word, index2) => {
    if (words.length === index2 + 1 && !hasTrailingSpace) {
      return `(?=.*\\b${escapeRegExp(word)})`;
    }
    return `(?=.*\\b${escapeRegExp(word)}\\b)`;
  }).join("") + ".+", "gi");
  return searchRegex.test(toMatchStr);
};
const useHotKeys = ({ input, hotKeys: hotKeys2 }) => {
  if (hotKeys2.value.length === 0)
    return;
  const onKeydown = (event) => {
    if (!input.value)
      return;
    if (
      // key matches
      isKeyMatched(event, hotKeys2.value) && // event does not come from the search box itself or
      // user isn't focusing (and thus perhaps typing in) a text control
      !isFocusingTextControl(event.target)
    ) {
      event.preventDefault();
      input.value.focus();
    }
  };
  onMounted(() => {
    document.addEventListener("keydown", onKeydown);
  });
  onBeforeUnmount(() => {
    document.removeEventListener("keydown", onKeydown);
  });
};
const searchIndex$1 = [
  {
    "title": "Markdown 样式模板",
    "headers": [
      {
        "level": 1,
        "title": "样式模板",
        "slug": "样式模板",
        "link": "#样式模板",
        "children": [
          {
            "level": 2,
            "title": "目录",
            "slug": "目录",
            "link": "#目录",
            "children": []
          },
          {
            "level": 2,
            "title": "标题",
            "slug": "标题",
            "link": "#标题",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "标题1",
        "slug": "标题1",
        "link": "#标题1",
        "children": []
      },
      {
        "level": 1,
        "title": "标题1",
        "slug": "标题1-1",
        "link": "#标题1-1",
        "children": [
          {
            "level": 2,
            "title": "标题2",
            "slug": "标题2",
            "link": "#标题2",
            "children": []
          },
          {
            "level": 2,
            "title": "标题2",
            "slug": "标题2-1",
            "link": "#标题2-1",
            "children": [
              {
                "level": 3,
                "title": "标题3",
                "slug": "标题3",
                "link": "#标题3",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "粗体",
            "slug": "粗体",
            "link": "#粗体",
            "children": []
          },
          {
            "level": 2,
            "title": "斜体",
            "slug": "斜体",
            "link": "#斜体",
            "children": []
          },
          {
            "level": 2,
            "title": "标记",
            "slug": "标记",
            "link": "#标记",
            "children": []
          },
          {
            "level": 2,
            "title": "上下角标",
            "slug": "上下角标",
            "link": "#上下角标",
            "children": []
          },
          {
            "level": 2,
            "title": "下划线,中划线",
            "slug": "下划线-中划线",
            "link": "#下划线-中划线",
            "children": []
          },
          {
            "level": 2,
            "title": "分割线",
            "slug": "分割线",
            "link": "#分割线",
            "children": []
          },
          {
            "level": 2,
            "title": "链接",
            "slug": "链接",
            "link": "#链接",
            "children": []
          },
          {
            "level": 2,
            "title": "有序列表",
            "slug": "有序列表",
            "link": "#有序列表",
            "children": []
          },
          {
            "level": 2,
            "title": "无序列表",
            "slug": "无序列表",
            "link": "#无序列表",
            "children": []
          },
          {
            "level": 2,
            "title": "任务清单",
            "slug": "任务清单",
            "link": "#任务清单",
            "children": []
          },
          {
            "level": 2,
            "title": "段落引用",
            "slug": "段落引用",
            "link": "#段落引用",
            "children": []
          },
          {
            "level": 2,
            "title": "容器语法",
            "slug": "容器语法",
            "link": "#容器语法",
            "children": []
          },
          {
            "level": 2,
            "title": "折叠块",
            "slug": "折叠块",
            "link": "#折叠块",
            "children": []
          },
          {
            "level": 2,
            "title": "代码",
            "slug": "代码",
            "link": "#代码",
            "children": [
              {
                "level": 3,
                "title": "代码高亮行",
                "slug": "代码高亮行",
                "link": "#代码高亮行",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "导入代码块",
            "slug": "导入代码块",
            "link": "#导入代码块",
            "children": []
          },
          {
            "level": 2,
            "title": "表格",
            "slug": "表格",
            "link": "#表格",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "Vue 语法",
        "slug": "vue-语法",
        "link": "#vue-语法",
        "children": [
          {
            "level": 2,
            "title": "Vue表达式",
            "slug": "vue表达式",
            "link": "#vue表达式",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue模块",
            "slug": "vue模块",
            "link": "#vue模块",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue 模块内Sass语法",
            "slug": "vue-模块内sass语法",
            "link": "#vue-模块内sass语法",
            "children": []
          },
          {
            "level": 2,
            "title": "注释",
            "slug": "注释",
            "link": "#注释",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "分组",
        "slug": "分组",
        "link": "#分组",
        "children": [
          {
            "level": 2,
            "title": "代码组合",
            "slug": "代码组合",
            "link": "#代码组合",
            "children": []
          },
          {
            "level": 2,
            "title": "HTML分组",
            "slug": "html分组",
            "link": "#html分组",
            "children": []
          },
          {
            "level": 2,
            "title": "Frontmatter",
            "slug": "frontmatter",
            "link": "#frontmatter",
            "children": [
              {
                "level": 3,
                "title": "cover",
                "slug": "cover",
                "link": "#cover",
                "children": []
              },
              {
                "level": 3,
                "title": "cover-fit/coverFit",
                "slug": "cover-fit-coverfit",
                "link": "#cover-fit-coverfit",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "高级配置",
            "slug": "高级配置",
            "link": "#高级配置",
            "children": [
              {
                "level": 3,
                "title": "Vue环境变量",
                "slug": "vue环境变量",
                "link": "#vue环境变量",
                "children": []
              },
              {
                "level": 3,
                "title": "路径别名",
                "slug": "路径别名",
                "link": "#路径别名",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/markdown.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/user-profile.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "收藏夹",
    "headers": [
      {
        "level": 1,
        "title": "收藏夹",
        "slug": "收藏夹",
        "link": "#收藏夹",
        "children": []
      },
      {
        "level": 1,
        "title": "工具类",
        "slug": "工具类",
        "link": "#工具类",
        "children": [
          {
            "level": 2,
            "title": "网站图标生成器",
            "slug": "网站图标生成器",
            "link": "#网站图标生成器",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue 2 生态相关",
            "slug": "vue-2-生态相关",
            "link": "#vue-2-生态相关",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue 3 生态相关",
            "slug": "vue-3-生态相关",
            "link": "#vue-3-生态相关",
            "children": []
          },
          {
            "level": 2,
            "title": "PPT模板下载站点",
            "slug": "ppt模板下载站点",
            "link": "#ppt模板下载站点",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/favorites.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "优秀学习资源",
    "headers": [
      {
        "level": 1,
        "title": "优秀学习资源",
        "slug": "优秀学习资源",
        "link": "#优秀学习资源",
        "children": [
          {
            "level": 2,
            "title": "常用前端库",
            "slug": "常用前端库",
            "link": "#常用前端库",
            "children": [
              {
                "level": 3,
                "title": "xtermjs",
                "slug": "xtermjs",
                "link": "#xtermjs",
                "children": []
              },
              {
                "level": 3,
                "title": "webssh",
                "slug": "webssh",
                "link": "#webssh",
                "children": []
              },
              {
                "level": 3,
                "title": "handlebars",
                "slug": "handlebars",
                "link": "#handlebars",
                "children": []
              },
              {
                "level": 3,
                "title": "Metalsmith",
                "slug": "metalsmith",
                "link": "#metalsmith",
                "children": []
              },
              {
                "level": 3,
                "title": "fullcalendar",
                "slug": "fullcalendar",
                "link": "#fullcalendar",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "优秀博文",
            "slug": "优秀博文",
            "link": "#优秀博文",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/frontend.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "vuepress 入门",
    "headers": [
      {
        "level": 1,
        "title": "vuepress 入门",
        "slug": "vuepress-入门",
        "link": "#vuepress-入门",
        "children": []
      }
    ],
    "path": "/guide/getting-started.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Home",
    "headers": [],
    "path": "/guide/",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue 学习资源收藏",
    "headers": [
      {
        "level": 1,
        "title": "Vue 学习资源收藏",
        "slug": "vue-学习资源收藏",
        "link": "#vue-学习资源收藏",
        "children": [
          {
            "level": 2,
            "title": "Vue 2 生态相关",
            "slug": "vue-2-生态相关",
            "link": "#vue-2-生态相关",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue 3 生态相关",
            "slug": "vue-3-生态相关",
            "link": "#vue-3-生态相关",
            "children": []
          },
          {
            "level": 2,
            "title": "PPT模板下载站点",
            "slug": "ppt模板下载站点",
            "link": "#ppt模板下载站点",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/website-learning.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "开发工具收藏",
    "headers": [
      {
        "level": 1,
        "title": "开发工具收藏",
        "slug": "开发工具收藏",
        "link": "#开发工具收藏",
        "children": [
          {
            "level": 2,
            "title": "常用前端库",
            "slug": "常用前端库",
            "link": "#常用前端库",
            "children": [
              {
                "level": 3,
                "title": "xtermjs",
                "slug": "xtermjs",
                "link": "#xtermjs",
                "children": []
              },
              {
                "level": 3,
                "title": "webssh",
                "slug": "webssh",
                "link": "#webssh",
                "children": []
              },
              {
                "level": 3,
                "title": "handlebars",
                "slug": "handlebars",
                "link": "#handlebars",
                "children": []
              },
              {
                "level": 3,
                "title": "Metalsmith",
                "slug": "metalsmith",
                "link": "#metalsmith",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "后端",
            "slug": "后端",
            "link": "#后端",
            "children": []
          },
          {
            "level": 2,
            "title": "前端",
            "slug": "前端",
            "link": "#前端",
            "children": []
          },
          {
            "level": 2,
            "title": "工具",
            "slug": "工具",
            "link": "#工具",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/website-resource.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/poetry/",
    "pathLocale": "/poetry/",
    "extraFields": []
  },
  {
    "title": "CSS 使用笔记",
    "headers": [
      {
        "level": 1,
        "title": "CSS 使用笔记",
        "slug": "css-使用笔记",
        "link": "#css-使用笔记",
        "children": [
          {
            "level": 2,
            "title": "CSS 语法",
            "slug": "css-语法",
            "link": "#css-语法",
            "children": [
              {
                "level": 3,
                "title": "语法",
                "slug": "语法",
                "link": "#语法",
                "children": []
              },
              {
                "level": 3,
                "title": "分组",
                "slug": "分组",
                "link": "#分组",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "CSS 选择器",
            "slug": "css-选择器",
            "link": "#css-选择器",
            "children": [
              {
                "level": 3,
                "title": "全局选择器",
                "slug": "全局选择器",
                "link": "#全局选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "元素选择器",
                "slug": "元素选择器",
                "link": "#元素选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "派生选择器",
                "slug": "派生选择器",
                "link": "#派生选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "id选择器",
                "slug": "id选择器",
                "link": "#id选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "类选择器",
                "slug": "类选择器",
                "link": "#类选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "属性选择器",
                "slug": "属性选择器",
                "link": "#属性选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "后代选择器",
                "slug": "后代选择器",
                "link": "#后代选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "子元素选择器 >",
                "slug": "子元素选择器",
                "link": "#子元素选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "相邻兄弟选择器 +",
                "slug": "相邻兄弟选择器",
                "link": "#相邻兄弟选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "同层全体组合选择器~",
                "slug": "同层全体组合选择器",
                "link": "#同层全体组合选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "伪类选择器",
                "slug": "伪类选择器",
                "link": "#伪类选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "伪元素选择器",
                "slug": "伪元素选择器",
                "link": "#伪元素选择器",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "伪类和伪元素的区别",
            "slug": "伪类和伪元素的区别",
            "link": "#伪类和伪元素的区别",
            "children": []
          },
          {
            "level": 2,
            "title": "文本样式",
            "slug": "文本样式",
            "link": "#文本样式",
            "children": [
              {
                "level": 3,
                "title": "文本颜色",
                "slug": "文本颜色",
                "link": "#文本颜色",
                "children": []
              },
              {
                "level": 3,
                "title": "文本阴影",
                "slug": "文本阴影",
                "link": "#文本阴影",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/html5/css.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [
      {
        "level": 2,
        "title": "Emoji",
        "slug": "emoji",
        "link": "#emoji",
        "children": []
      },
      {
        "level": 2,
        "title": "常用",
        "slug": "常用",
        "link": "#常用",
        "children": []
      },
      {
        "level": 2,
        "title": "表情",
        "slug": "表情",
        "link": "#表情",
        "children": []
      },
      {
        "level": 2,
        "title": "人类和身体",
        "slug": "人类和身体",
        "link": "#人类和身体",
        "children": []
      },
      {
        "level": 2,
        "title": "动物和自然",
        "slug": "动物和自然",
        "link": "#动物和自然",
        "children": []
      },
      {
        "level": 2,
        "title": "食物和饮料",
        "slug": "食物和饮料",
        "link": "#食物和饮料",
        "children": []
      },
      {
        "level": 2,
        "title": "旅行和地点",
        "slug": "旅行和地点",
        "link": "#旅行和地点",
        "children": []
      },
      {
        "level": 2,
        "title": "活动",
        "slug": "活动",
        "link": "#活动",
        "children": []
      },
      {
        "level": 2,
        "title": "物品",
        "slug": "物品",
        "link": "#物品",
        "children": []
      },
      {
        "level": 2,
        "title": "符号",
        "slug": "符号",
        "link": "#符号",
        "children": []
      }
    ],
    "path": "/guide/html5/emoji.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "\\n 和 <br/> 互转",
    "headers": [
      {
        "level": 1,
        "title": "\\n 和 <br/> 互转",
        "slug": "n-和-br-互转",
        "link": "#n-和-br-互转",
        "children": []
      }
    ],
    "path": "/guide/html5/linefeed-br-transform.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "移动端适配处理",
    "headers": [
      {
        "level": 1,
        "title": "移动端适配处理",
        "slug": "移动端适配处理",
        "link": "#移动端适配处理",
        "children": []
      }
    ],
    "path": "/guide/html5/mobile-adapter.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Web打印处理",
    "headers": [
      {
        "level": 1,
        "title": "Web打印处理",
        "slug": "web打印处理",
        "link": "#web打印处理",
        "children": [
          {
            "level": 2,
            "title": "打印",
            "slug": "打印",
            "link": "#打印",
            "children": []
          },
          {
            "level": 2,
            "title": "监听事件",
            "slug": "监听事件",
            "link": "#监听事件",
            "children": []
          },
          {
            "level": 2,
            "title": "样式",
            "slug": "样式",
            "link": "#样式",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/html5/print.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [
      {
        "level": 2,
        "title": "Web API",
        "slug": "web-api",
        "link": "#web-api",
        "children": []
      }
    ],
    "path": "/guide/html5/",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "常用正则表达语句",
    "headers": [
      {
        "level": 1,
        "title": "常用正则表达语句",
        "slug": "常用正则表达语句",
        "link": "#常用正则表达语句",
        "children": [
          {
            "level": 2,
            "title": "高亮段落内关键字",
            "slug": "高亮段落内关键字",
            "link": "#高亮段落内关键字",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/html5/regex.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Sass 使用笔记",
    "headers": [
      {
        "level": 1,
        "title": "Sass 使用笔记",
        "slug": "sass-使用笔记",
        "link": "#sass-使用笔记",
        "children": [
          {
            "level": 2,
            "title": "快速开始",
            "slug": "快速开始",
            "link": "#快速开始",
            "children": [
              {
                "level": 3,
                "title": "安装(Install)",
                "slug": "安装-install",
                "link": "#安装-install",
                "children": []
              },
              {
                "level": 3,
                "title": "预处理(Preprocessing)",
                "slug": "预处理-preprocessing",
                "link": "#预处理-preprocessing",
                "children": []
              },
              {
                "level": 3,
                "title": "注释(Annotation)",
                "slug": "注释-annotation",
                "link": "#注释-annotation",
                "children": []
              },
              {
                "level": 3,
                "title": "调试",
                "slug": "调试",
                "link": "#调试",
                "children": []
              },
              {
                "level": 3,
                "title": "数据类型 (Data Types",
                "slug": "数据类型-data-types",
                "link": "#数据类型-data-types",
                "children": []
              },
              {
                "level": 3,
                "title": "变量(Variables)$",
                "slug": "变量-variables",
                "link": "#变量-variables",
                "children": []
              },
              {
                "level": 3,
                "title": "选择器",
                "slug": "选择器",
                "link": "#选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "嵌套(Nesting)",
                "slug": "嵌套-nesting",
                "link": "#嵌套-nesting",
                "children": []
              },
              {
                "level": 3,
                "title": "片段(Partials)",
                "slug": "片段-partials",
                "link": "#片段-partials",
                "children": []
              },
              {
                "level": 3,
                "title": "模块(Modules)",
                "slug": "模块-modules",
                "link": "#模块-modules",
                "children": []
              },
              {
                "level": 3,
                "title": "混合(Mixins)",
                "slug": "混合-mixins",
                "link": "#混合-mixins",
                "children": []
              },
              {
                "level": 3,
                "title": "扩展(Extend)和继承(Inheritance)",
                "slug": "扩展-extend-和继承-inheritance",
                "link": "#扩展-extend-和继承-inheritance",
                "children": []
              },
              {
                "level": 3,
                "title": "运算(Operators)",
                "slug": "运算-operators",
                "link": "#运算-operators",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "控制指令(Control Directives)",
            "slug": "控制指令-control-directives",
            "link": "#控制指令-control-directives",
            "children": [
              {
                "level": 3,
                "title": "条件语句@if、@else if、@else",
                "slug": "条件语句-if、-else-if、-else",
                "link": "#条件语句-if、-else-if、-else",
                "children": []
              },
              {
                "level": 3,
                "title": "循环语句 for、while、each",
                "slug": "循环语句-for、while、each",
                "link": "#循环语句-for、while、each",
                "children": []
              },
              {
                "level": 3,
                "title": "自定义函数function",
                "slug": "自定义函数function",
                "link": "#自定义函数function",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "内置",
            "slug": "内置",
            "link": "#内置",
            "children": [
              {
                "level": 3,
                "title": "模块(Modules)",
                "slug": "模块-modules-1",
                "link": "#模块-modules-1",
                "children": []
              },
              {
                "level": 3,
                "title": "全局函数(Function)",
                "slug": "全局函数-function",
                "link": "#全局函数-function",
                "children": []
              },
              {
                "level": 3,
                "title": "HSL/HSLA",
                "slug": "hsl-hsla",
                "link": "#hsl-hsla",
                "children": []
              },
              {
                "level": 3,
                "title": "RGB/RGBA",
                "slug": "rgb-rgba",
                "link": "#rgb-rgba",
                "children": []
              },
              {
                "level": 3,
                "title": "内置颜色函数",
                "slug": "内置颜色函数",
                "link": "#内置颜色函数",
                "children": []
              },
              {
                "level": 3,
                "title": "IF",
                "slug": "if",
                "link": "#if",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/html5/sass.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "url 编解码",
    "headers": [
      {
        "level": 1,
        "title": "url 编解码",
        "slug": "url-编解码",
        "link": "#url-编解码",
        "children": []
      }
    ],
    "path": "/guide/html5/url-decode.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "window 浏览器页面事件",
    "headers": [
      {
        "level": 1,
        "title": "window 浏览器页面事件",
        "slug": "window-浏览器页面事件",
        "link": "#window-浏览器页面事件",
        "children": [
          {
            "level": 2,
            "title": "浏览器选项卡获取焦点和失去焦点",
            "slug": "浏览器选项卡获取焦点和失去焦点",
            "link": "#浏览器选项卡获取焦点和失去焦点",
            "children": []
          },
          {
            "level": 2,
            "title": "浏览器选项卡关闭",
            "slug": "浏览器选项卡关闭",
            "link": "#浏览器选项卡关闭",
            "children": []
          },
          {
            "level": 2,
            "title": "页面开始打印/打印结束后事件",
            "slug": "页面开始打印-打印结束后事件",
            "link": "#页面开始打印-打印结束后事件",
            "children": []
          },
          {
            "level": 2,
            "title": "其它页面更改存储触发",
            "slug": "其它页面更改存储触发",
            "link": "#其它页面更改存储触发",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/html5/window-event.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "JavaScript 知识点",
    "headers": [
      {
        "level": 1,
        "title": "JavaScript 知识点",
        "slug": "javascript-知识点",
        "link": "#javascript-知识点",
        "children": [
          {
            "level": 2,
            "title": "基础部分",
            "slug": "基础部分",
            "link": "#基础部分",
            "children": [
              {
                "level": 3,
                "title": "js有哪些内置对象？",
                "slug": "js有哪些内置对象",
                "link": "#js有哪些内置对象",
                "children": []
              },
              {
                "level": 3,
                "title": "js有哪些数据类型",
                "slug": "js有哪些数据类型",
                "link": "#js有哪些数据类型",
                "children": []
              },
              {
                "level": 3,
                "title": "JavaScript有几种类型的值",
                "slug": "javascript有几种类型的值",
                "link": "#javascript有几种类型的值",
                "children": []
              },
              {
                "level": 3,
                "title": "栈和堆的区别",
                "slug": "栈和堆的区别",
                "link": "#栈和堆的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "undefined 和 null 区别",
                "slug": "undefined-和-null-区别",
                "link": "#undefined-和-null-区别",
                "children": []
              },
              {
                "level": 3,
                "title": "对this的理解",
                "slug": "对this的理解",
                "link": "#对this的理解",
                "children": []
              },
              {
                "level": 3,
                "title": "if语句有作用域吗?",
                "slug": "if语句有作用域吗",
                "link": "#if语句有作用域吗",
                "children": []
              },
              {
                "level": 3,
                "title": "原型链和作用域链的区别",
                "slug": "原型链和作用域链的区别",
                "link": "#原型链和作用域链的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "js 判断对象类型(typeof、instanceOf)区别",
                "slug": "js-判断对象类型-typeof、instanceof-区别",
                "link": "#js-判断对象类型-typeof、instanceof-区别",
                "children": []
              },
              {
                "level": 3,
                "title": "普通函数和箭头函数的区别",
                "slug": "普通函数和箭头函数的区别",
                "link": "#普通函数和箭头函数的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "document.write和document.innerHTML的区别",
                "slug": "document-write和document-innerhtml的区别",
                "link": "#document-write和document-innerhtml的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "bind、call、apply的区别",
                "slug": "bind、call、apply的区别",
                "link": "#bind、call、apply的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "eval()计算函数",
                "slug": "eval-计算函数",
                "link": "#eval-计算函数",
                "children": []
              },
              {
                "level": 3,
                "title": "JS哪些操作会造成内存泄露",
                "slug": "js哪些操作会造成内存泄露",
                "link": "#js哪些操作会造成内存泄露",
                "children": []
              },
              {
                "level": 3,
                "title": "什么是闭包，如何使用它，为什么要使用它？",
                "slug": "什么是闭包-如何使用它-为什么要使用它",
                "link": "#什么是闭包-如何使用它-为什么要使用它",
                "children": []
              },
              {
                "level": 3,
                "title": "请解释JSONP的工作原理，以及它为什么不是真正的AJAX",
                "slug": "请解释jsonp的工作原理-以及它为什么不是真正的ajax",
                "link": "#请解释jsonp的工作原理-以及它为什么不是真正的ajax",
                "children": []
              },
              {
                "level": 3,
                "title": "请解释一下JavaScript的同源策略",
                "slug": "请解释一下javascript的同源策略",
                "link": "#请解释一下javascript的同源策略",
                "children": []
              },
              {
                "level": 3,
                "title": "介绍暂时性死区",
                "slug": "介绍暂时性死区",
                "link": "#介绍暂时性死区",
                "children": []
              },
              {
                "level": 3,
                "title": "两个对象如何比较",
                "slug": "两个对象如何比较",
                "link": "#两个对象如何比较",
                "children": []
              },
              {
                "level": 3,
                "title": "Promise和Async处理失败的时候有什么区别",
                "slug": "promise和async处理失败的时候有什么区别",
                "link": "#promise和async处理失败的时候有什么区别",
                "children": []
              },
              {
                "level": 3,
                "title": "setTimeout(0)和setTimeout(2)之间的区别",
                "slug": "settimeout-0-和settimeout-2-之间的区别",
                "link": "#settimeout-0-和settimeout-2-之间的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "for..in和object.keys的区别",
                "slug": "for-in和object-keys的区别",
                "link": "#for-in和object-keys的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "说说你对AMD和Commonjs的理解",
                "slug": "说说你对amd和commonjs的理解",
                "link": "#说说你对amd和commonjs的理解",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "看代码，给结果",
            "slug": "看代码-给结果",
            "link": "#看代码-给结果",
            "children": [
              {
                "level": 3,
                "title": "1. 写出如下代码的打印结果",
                "slug": "_1-写出如下代码的打印结果",
                "link": "#_1-写出如下代码的打印结果",
                "children": []
              },
              {
                "level": 3,
                "title": "2. 输出以下代码运行结果",
                "slug": "_2-输出以下代码运行结果",
                "link": "#_2-输出以下代码运行结果",
                "children": []
              },
              {
                "level": 3,
                "title": '3. ["1", "2", "3"].map(parseInt) 答案是多少？',
                "slug": "_3-1-2-3-map-parseint-答案是多少",
                "link": "#_3-1-2-3-map-parseint-答案是多少",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "扩展",
            "slug": "扩展",
            "link": "#扩展",
            "children": [
              {
                "level": 3,
                "title": "js设计模式",
                "slug": "js设计模式",
                "link": "#js设计模式",
                "children": []
              },
              {
                "level": 3,
                "title": "常见兼容性问题？",
                "slug": "常见兼容性问题",
                "link": "#常见兼容性问题",
                "children": []
              },
              {
                "level": 3,
                "title": "JS为什么要区分微任务和宏任务",
                "slug": "js为什么要区分微任务和宏任务",
                "link": "#js为什么要区分微任务和宏任务",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/interview/js-basic.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "async",
    "headers": [
      {
        "level": 1,
        "title": "async",
        "slug": "async",
        "link": "#async",
        "children": [
          {
            "level": 3,
            "title": "内容",
            "slug": "内容",
            "link": "#内容",
            "children": []
          },
          {
            "level": 3,
            "title": "安装",
            "slug": "安装",
            "link": "#安装",
            "children": []
          },
          {
            "level": 3,
            "title": "流程控制",
            "slug": "流程控制",
            "link": "#流程控制",
            "children": []
          },
          {
            "level": 3,
            "title": "Collections集合",
            "slug": "collections集合",
            "link": "#collections集合",
            "children": []
          },
          {
            "level": 3,
            "title": "mapValues",
            "slug": "mapvalues",
            "link": "#mapvalues",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/async.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "日月周时间段处理",
    "headers": [
      {
        "level": 1,
        "title": "日月周时间段处理",
        "slug": "日月周时间段处理",
        "link": "#日月周时间段处理",
        "children": []
      }
    ],
    "path": "/guide/javascript/date-by-week.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "js跨域资源下载",
    "headers": [
      {
        "level": 1,
        "title": "js跨域资源下载",
        "slug": "js跨域资源下载",
        "link": "#js跨域资源下载",
        "children": []
      }
    ],
    "path": "/guide/javascript/download-cros-file.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "ES6 学习笔记",
    "headers": [
      {
        "level": 1,
        "title": "ES6 学习笔记",
        "slug": "es6-学习笔记",
        "link": "#es6-学习笔记",
        "children": [
          {
            "level": 2,
            "title": "符号",
            "slug": "符号",
            "link": "#符号",
            "children": []
          },
          {
            "level": 2,
            "title": "运算符",
            "slug": "运算符",
            "link": "#运算符",
            "children": [
              {
                "level": 3,
                "title": "按位取反运算符~",
                "slug": "按位取反运算符",
                "link": "#按位取反运算符",
                "children": []
              },
              {
                "level": 3,
                "title": "求幂表达式 **",
                "slug": "求幂表达式",
                "link": "#求幂表达式",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "var/let/const",
            "slug": "var-let-const",
            "link": "#var-let-const",
            "children": []
          },
          {
            "level": 2,
            "title": "对象解构",
            "slug": "对象解构",
            "link": "#对象解构",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/es6-basic.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "省市区联动",
    "headers": [
      {
        "level": 1,
        "title": "省市区联动",
        "slug": "省市区联动",
        "link": "#省市区联动",
        "children": [
          {
            "level": 2,
            "title": "省市区数据添加头[全部]",
            "slug": "省市区数据添加头-全部",
            "link": "#省市区数据添加头-全部",
            "children": []
          },
          {
            "level": 2,
            "title": "省市区移除【全国/全部】项",
            "slug": "省市区移除【全国-全部】项",
            "link": "#省市区移除【全国-全部】项",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/javascript-address.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "数组 Array",
    "headers": [
      {
        "level": 1,
        "title": "数组 Array",
        "slug": "数组-array",
        "link": "#数组-array",
        "children": [
          {
            "level": 2,
            "title": "基础",
            "slug": "基础",
            "link": "#基础",
            "children": [
              {
                "level": 3,
                "title": "求最大/小值",
                "slug": "求最大-小值",
                "link": "#求最大-小值",
                "children": []
              },
              {
                "level": 3,
                "title": "map",
                "slug": "map",
                "link": "#map",
                "children": []
              },
              {
                "level": 3,
                "title": "reduce",
                "slug": "reduce",
                "link": "#reduce",
                "children": []
              },
              {
                "level": 3,
                "title": "filter",
                "slug": "filter",
                "link": "#filter",
                "children": []
              },
              {
                "level": 3,
                "title": "sort",
                "slug": "sort",
                "link": "#sort",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "数据交换",
            "slug": "数据交换",
            "link": "#数据交换",
            "children": [
              {
                "level": 3,
                "title": "普通做法",
                "slug": "普通做法",
                "link": "#普通做法",
                "children": []
              },
              {
                "level": 3,
                "title": "算术运算",
                "slug": "算术运算",
                "link": "#算术运算",
                "children": []
              },
              {
                "level": 3,
                "title": "数组方式",
                "slug": "数组方式",
                "link": "#数组方式",
                "children": []
              },
              {
                "level": 3,
                "title": "对象方式",
                "slug": "对象方式",
                "link": "#对象方式",
                "children": []
              },
              {
                "level": 3,
                "title": "ES6解构",
                "slug": "es6解构",
                "link": "#es6解构",
                "children": []
              },
              {
                "level": 3,
                "title": "异或操作",
                "slug": "异或操作",
                "link": "#异或操作",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "排序",
            "slug": "排序",
            "link": "#排序",
            "children": []
          },
          {
            "level": 2,
            "title": "删除、去重",
            "slug": "删除、去重",
            "link": "#删除、去重",
            "children": [
              {
                "level": 3,
                "title": "正序去重复",
                "slug": "正序去重复",
                "link": "#正序去重复",
                "children": []
              },
              {
                "level": 3,
                "title": "倒序去重复",
                "slug": "倒序去重复",
                "link": "#倒序去重复",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "排序",
            "slug": "排序-1",
            "link": "#排序-1",
            "children": [
              {
                "level": 3,
                "title": "普通排序(Sort)",
                "slug": "普通排序-sort",
                "link": "#普通排序-sort",
                "children": []
              },
              {
                "level": 3,
                "title": "冒泡排序(Bubble Sort)",
                "slug": "冒泡排序-bubble-sort",
                "link": "#冒泡排序-bubble-sort",
                "children": []
              },
              {
                "level": 3,
                "title": "选择排序(Selection Sort)",
                "slug": "选择排序-selection-sort",
                "link": "#选择排序-selection-sort",
                "children": []
              },
              {
                "level": 3,
                "title": "插入排序(Insertion Sort)",
                "slug": "插入排序-insertion-sort",
                "link": "#插入排序-insertion-sort",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/javascript-array.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "JavaScript 二叉树",
    "headers": [
      {
        "level": 1,
        "title": "JavaScript 二叉树",
        "slug": "javascript-二叉树",
        "link": "#javascript-二叉树",
        "children": [
          {
            "level": 2,
            "title": "定义",
            "slug": "定义",
            "link": "#定义",
            "children": []
          },
          {
            "level": 2,
            "title": "遍历",
            "slug": "遍历",
            "link": "#遍历",
            "children": []
          },
          {
            "level": 2,
            "title": "创建二叉树",
            "slug": "创建二叉树",
            "link": "#创建二叉树",
            "children": []
          },
          {
            "level": 2,
            "title": "递归遍历",
            "slug": "递归遍历",
            "link": "#递归遍历",
            "children": []
          },
          {
            "level": 2,
            "title": "深度优先遍历",
            "slug": "深度优先遍历",
            "link": "#深度优先遍历",
            "children": []
          },
          {
            "level": 2,
            "title": "广度优先遍历",
            "slug": "广度优先遍历",
            "link": "#广度优先遍历",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/javascript-binary-tree.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Moment.js",
    "headers": [
      {
        "level": 1,
        "title": "Moment.js",
        "slug": "moment-js",
        "link": "#moment-js",
        "children": [
          {
            "level": 2,
            "title": "日期格式化",
            "slug": "日期格式化",
            "link": "#日期格式化",
            "children": []
          },
          {
            "level": 2,
            "title": "相对时间",
            "slug": "相对时间",
            "link": "#相对时间",
            "children": []
          },
          {
            "level": 2,
            "title": "日历时间",
            "slug": "日历时间",
            "link": "#日历时间",
            "children": []
          },
          {
            "level": 2,
            "title": "多语言支持",
            "slug": "多语言支持",
            "link": "#多语言支持",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/javascript-moment-js.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "JavaScript 基础",
    "headers": [
      {
        "level": 1,
        "title": "JavaScript 基础",
        "slug": "javascript-基础",
        "link": "#javascript-基础",
        "children": [
          {
            "level": 3,
            "title": "全局对象属性（三个值、十三个函数）",
            "slug": "全局对象属性-三个值、十三个函数",
            "link": "#全局对象属性-三个值、十三个函数",
            "children": []
          },
          {
            "level": 3,
            "title": "六种异步方案",
            "slug": "六种异步方案",
            "link": "#六种异步方案",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/javascript.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "lodash 数组 Array",
    "headers": [
      {
        "level": 1,
        "title": "lodash 数组 Array",
        "slug": "lodash-数组-array",
        "link": "#lodash-数组-array",
        "children": [
          {
            "level": 2,
            "title": "检索",
            "slug": "检索",
            "link": "#检索",
            "children": [
              {
                "level": 3,
                "title": "_.indexOf(array, value, [fromIndex = 0])",
                "slug": "indexof-array-value-fromindex-0",
                "link": "#indexof-array-value-fromindex-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.findIndex(array, [predicate = _.identity], [fromIndex=0])",
                "slug": "findindex-array-predicate-identity-fromindex-0",
                "link": "#findindex-array-predicate-identity-fromindex-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.findLastIndex(array, [predicate = _.identity], [fromIndex=array.length-1])",
                "slug": "findlastindex-array-predicate-identity-fromindex-array-length-1",
                "link": "#findlastindex-array-predicate-identity-fromindex-array-length-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.lastIndexOf(array, value, [fromIndex=array.length-1])",
                "slug": "lastindexof-array-value-fromindex-array-length-1",
                "link": "#lastindexof-array-value-fromindex-array-length-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.head(array)",
                "slug": "head-array",
                "link": "#head-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.last(array)",
                "slug": "last-array",
                "link": "#last-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.initial(array)",
                "slug": "initial-array",
                "link": "#initial-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.tail(array)",
                "slug": "tail-array",
                "link": "#tail-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.nth(array, [n=0])",
                "slug": "nth-array-n-0",
                "link": "#nth-array-n-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.take(array, [n=1])",
                "slug": "take-array-n-1",
                "link": "#take-array-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.takeRight(array, [n=1])",
                "slug": "takeright-array-n-1",
                "link": "#takeright-array-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.takeRightWhile(array, [predicate = _.identity])",
                "slug": "takerightwhile-array-predicate-identity",
                "link": "#takerightwhile-array-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.takeWhile(array, [predicate = _.identity])",
                "slug": "takewhile-array-predicate-identity",
                "link": "#takewhile-array-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.slice(array, [start=0], [end=array.length])",
                "slug": "slice-array-start-0-end-array-length",
                "link": "#slice-array-start-0-end-array-length",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "分组",
            "slug": "分组",
            "link": "#分组",
            "children": [
              {
                "level": 3,
                "title": "_.chunk(array, [size=1])",
                "slug": "chunk-array-size-1",
                "link": "#chunk-array-size-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.zip([arrays])",
                "slug": "zip-arrays",
                "link": "#zip-arrays",
                "children": []
              },
              {
                "level": 3,
                "title": "_.unzip(array)",
                "slug": "unzip-array",
                "link": "#unzip-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.zipWith([arrays], [iteratee = _.identity])",
                "slug": "zipwith-arrays-iteratee-identity",
                "link": "#zipwith-arrays-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.unzipWith(array, [iteratee = _.identity])",
                "slug": "unzipwith-array-iteratee-identity",
                "link": "#unzipwith-array-iteratee-identity",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "合并",
            "slug": "合并",
            "link": "#合并",
            "children": [
              {
                "level": 3,
                "title": "_.join(array, [separator=','])",
                "slug": "join-array-separator",
                "link": "#join-array-separator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.concat(array, [values])",
                "slug": "concat-array-values",
                "link": "#concat-array-values",
                "children": []
              },
              {
                "level": 3,
                "title": "_.union([arrays])",
                "slug": "union-arrays",
                "link": "#union-arrays",
                "children": []
              },
              {
                "level": 3,
                "title": "_.unionBy([arrays], [iteratee = _.identity])",
                "slug": "unionby-arrays-iteratee-identity",
                "link": "#unionby-arrays-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.unionWith([arrays], [comparator])",
                "slug": "unionwith-arrays-comparator",
                "link": "#unionwith-arrays-comparator",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "过滤",
            "slug": "过滤",
            "link": "#过滤",
            "children": [
              {
                "level": 3,
                "title": "_.difference(array, [values])",
                "slug": "difference-array-values",
                "link": "#difference-array-values",
                "children": []
              },
              {
                "level": 3,
                "title": "_.differenceBy(array, [values], [iteratee = _.identity])",
                "slug": "differenceby-array-values-iteratee-identity",
                "link": "#differenceby-array-values-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.differenceWith(array, [values], [comparator])",
                "slug": "differencewith-array-values-comparator",
                "link": "#differencewith-array-values-comparator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.compact(array)",
                "slug": "compact-array",
                "link": "#compact-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.intersection([arrays])",
                "slug": "intersection-arrays",
                "link": "#intersection-arrays",
                "children": []
              },
              {
                "level": 3,
                "title": "_.intersectionBy([arrays], [iteratee = _.identity])",
                "slug": "intersectionby-arrays-iteratee-identity",
                "link": "#intersectionby-arrays-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.intersectionWith([arrays], [comparator])",
                "slug": "intersectionwith-arrays-comparator",
                "link": "#intersectionwith-arrays-comparator",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "移除",
            "slug": "移除",
            "link": "#移除",
            "children": [
              {
                "level": 3,
                "title": "_.remove(array, [predicate = _.identity])",
                "slug": "remove-array-predicate-identity",
                "link": "#remove-array-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.drop(array, [n=1])",
                "slug": "drop-array-n-1",
                "link": "#drop-array-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.dropRight(array, [n=1])",
                "slug": "dropright-array-n-1",
                "link": "#dropright-array-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.dropRightWhile(array, [predicate = _.identity])",
                "slug": "droprightwhile-array-predicate-identity",
                "link": "#droprightwhile-array-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.dropWhile(array, [predicate = _.identity])",
                "slug": "dropwhile-array-predicate-identity",
                "link": "#dropwhile-array-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pull(array, [values])",
                "slug": "pull-array-values",
                "link": "#pull-array-values",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pullAll(array, values)",
                "slug": "pullall-array-values",
                "link": "#pullall-array-values",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pullAllBy(array, values, [iteratee = _.identity])",
                "slug": "pullallby-array-values-iteratee-identity",
                "link": "#pullallby-array-values-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pullAllWith(array, values, [comparator])",
                "slug": "pullallwith-array-values-comparator",
                "link": "#pullallwith-array-values-comparator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pullAt(array, [indexes])",
                "slug": "pullat-array-indexes",
                "link": "#pullat-array-indexes",
                "children": []
              },
              {
                "level": 3,
                "title": "_.without(array, [values])",
                "slug": "without-array-values",
                "link": "#without-array-values",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "增加",
            "slug": "增加",
            "link": "#增加",
            "children": [
              {
                "level": 3,
                "title": "_.fill(array, value, [start=0], [end = array.length])",
                "slug": "fill-array-value-start-0-end-array-length",
                "link": "#fill-array-value-start-0-end-array-length",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "排序",
            "slug": "排序",
            "link": "#排序",
            "children": [
              {
                "level": 3,
                "title": "_.sortedIndex(array, value)",
                "slug": "sortedindex-array-value",
                "link": "#sortedindex-array-value",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedIndexBy(array, value, [iteratee = _.identity])",
                "slug": "sortedindexby-array-value-iteratee-identity",
                "link": "#sortedindexby-array-value-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedIndexOf(array, value)",
                "slug": "sortedindexof-array-value",
                "link": "#sortedindexof-array-value",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedLastIndex(array, value)",
                "slug": "sortedlastindex-array-value",
                "link": "#sortedlastindex-array-value",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedLastIndexBy(array, value, [iteratee = _.identity])",
                "slug": "sortedlastindexby-array-value-iteratee-identity",
                "link": "#sortedlastindexby-array-value-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedLastIndexOf(array, value)",
                "slug": "sortedlastindexof-array-value",
                "link": "#sortedlastindexof-array-value",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedUniq(array)",
                "slug": "sorteduniq-array",
                "link": "#sorteduniq-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedUniqBy(array, [iteratee])",
                "slug": "sorteduniqby-array-iteratee",
                "link": "#sorteduniqby-array-iteratee",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "去重",
            "slug": "去重",
            "link": "#去重",
            "children": [
              {
                "level": 3,
                "title": "_.uniq(array)",
                "slug": "uniq-array",
                "link": "#uniq-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.uniqBy(array, [iteratee = _.identity])",
                "slug": "uniqby-array-iteratee-identity",
                "link": "#uniqby-array-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.uniqWith(array, [comparator])",
                "slug": "uniqwith-array-comparator",
                "link": "#uniqwith-array-comparator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.xor([arrays])",
                "slug": "xor-arrays",
                "link": "#xor-arrays",
                "children": []
              },
              {
                "level": 3,
                "title": "_.xorBy([arrays], [iteratee = _.identity])",
                "slug": "xorby-arrays-iteratee-identity",
                "link": "#xorby-arrays-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.xorWith([arrays], [comparator])",
                "slug": "xorwith-arrays-comparator",
                "link": "#xorwith-arrays-comparator",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "转换",
            "slug": "转换",
            "link": "#转换",
            "children": [
              {
                "level": 3,
                "title": "_.reverse(array)",
                "slug": "reverse-array",
                "link": "#reverse-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.flatten(array)",
                "slug": "flatten-array",
                "link": "#flatten-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.flattenDeep(array)",
                "slug": "flattendeep-array",
                "link": "#flattendeep-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.flattenDepth(array, [depth=1])",
                "slug": "flattendepth-array-depth-1",
                "link": "#flattendepth-array-depth-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.fromPairs(pairs)",
                "slug": "frompairs-pairs",
                "link": "#frompairs-pairs",
                "children": []
              },
              {
                "level": 3,
                "title": "_.zipObject([props=[]], [values=[]])",
                "slug": "zipobject-props-values",
                "link": "#zipobject-props-values",
                "children": []
              },
              {
                "level": 3,
                "title": "_.zipObjectDeep([props=[]], [values=[]])",
                "slug": "zipobjectdeep-props-values",
                "link": "#zipobjectdeep-props-values",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-array.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 集合 Collection",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 集合 Collection",
        "slug": "lodash-集合-collection",
        "link": "#lodash-集合-collection",
        "children": [
          {
            "level": 2,
            "title": "创建",
            "slug": "创建",
            "link": "#创建",
            "children": [
              {
                "level": 3,
                "title": "_.sample(collection)",
                "slug": "sample-collection",
                "link": "#sample-collection",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sampleSize(collection, [n = 1])",
                "slug": "samplesize-collection-n-1",
                "link": "#samplesize-collection-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.shuffle(collection)",
                "slug": "shuffle-collection",
                "link": "#shuffle-collection",
                "children": []
              },
              {
                "level": 3,
                "title": "_.countBy(collection, [iteratee = _.identity])",
                "slug": "countby-collection-iteratee-identity",
                "link": "#countby-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortBy(collection, [iteratees = [ _.identity ] ])",
                "slug": "sortby-collection-iteratees-identity",
                "link": "#sortby-collection-iteratees-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.orderBy(collection, [iteratees=[ _.identity ] ], [ orders ])",
                "slug": "orderby-collection-iteratees-identity-orders",
                "link": "#orderby-collection-iteratees-identity-orders",
                "children": []
              },
              {
                "level": 3,
                "title": "_.groupBy(collection, [iteratee = _.identity])",
                "slug": "groupby-collection-iteratee-identity",
                "link": "#groupby-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.keyBy(collection, [iteratee = _.identity])",
                "slug": "keyby-collection-iteratee-identity",
                "link": "#keyby-collection-iteratee-identity",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "遍历",
            "slug": "遍历",
            "link": "#遍历",
            "children": [
              {
                "level": 3,
                "title": "_.forEach(collection, [iteratee = _.identity])",
                "slug": "foreach-collection-iteratee-identity",
                "link": "#foreach-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.forEachRight(collection, [iteratee = _.identity])",
                "slug": "foreachright-collection-iteratee-identity",
                "link": "#foreachright-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.map(collection, [iteratee = _.identity])",
                "slug": "map-collection-iteratee-identity",
                "link": "#map-collection-iteratee-identity",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "检索",
            "slug": "检索",
            "link": "#检索",
            "children": [
              {
                "level": 3,
                "title": "_.includes(collection, value, [fromIndex = 0])",
                "slug": "includes-collection-value-fromindex-0",
                "link": "#includes-collection-value-fromindex-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.every(collection, [predicate = _.identity])",
                "slug": "every-collection-predicate-identity",
                "link": "#every-collection-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.some(collection, [predicate = _.identity])",
                "slug": "some-collection-predicate-identity",
                "link": "#some-collection-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.find(collection, [predicate = _.identity], [fromIndex = 0])",
                "slug": "find-collection-predicate-identity-fromindex-0",
                "link": "#find-collection-predicate-identity-fromindex-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.findLast(collection, [predicate = _.identity], [fromIndex = collection.length - 1])",
                "slug": "findlast-collection-predicate-identity-fromindex-collection-length-1",
                "link": "#findlast-collection-predicate-identity-fromindex-collection-length-1",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "过滤",
            "slug": "过滤",
            "link": "#过滤",
            "children": [
              {
                "level": 3,
                "title": "_.filter(collection, [predicate = _.identity])",
                "slug": "filter-collection-predicate-identity",
                "link": "#filter-collection-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.reject(collection, [predicate = _.identity])",
                "slug": "reject-collection-predicate-identity",
                "link": "#reject-collection-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.partition(collection, [predicate = _.identity])",
                "slug": "partition-collection-predicate-identity",
                "link": "#partition-collection-predicate-identity",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "转换",
            "slug": "转换",
            "link": "#转换",
            "children": [
              {
                "level": 3,
                "title": "_.flatMap(collection, [iteratee = _.identity])",
                "slug": "flatmap-collection-iteratee-identity",
                "link": "#flatmap-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.flatMapDeep(collection, [iteratee = _.identity])",
                "slug": "flatmapdeep-collection-iteratee-identity",
                "link": "#flatmapdeep-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.flatMapDepth(collection, [iteratee = _.identity], [depth = 1])",
                "slug": "flatmapdepth-collection-iteratee-identity-depth-1",
                "link": "#flatmapdepth-collection-iteratee-identity-depth-1",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "其它",
            "slug": "其它",
            "link": "#其它",
            "children": [
              {
                "level": 3,
                "title": "_.invokeMap(collection, path, [args])",
                "slug": "invokemap-collection-path-args",
                "link": "#invokemap-collection-path-args",
                "children": []
              },
              {
                "level": 3,
                "title": "_.reduce(collection, [iteratee = _.identity], [ accumulator ])",
                "slug": "reduce-collection-iteratee-identity-accumulator",
                "link": "#reduce-collection-iteratee-identity-accumulator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.reduceRight(collection, [iteratee = _.identity], [accumulator])",
                "slug": "reduceright-collection-iteratee-identity-accumulator",
                "link": "#reduceright-collection-iteratee-identity-accumulator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.size(collection)",
                "slug": "size-collection",
                "link": "#size-collection",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-collection.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 函数 Function",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 函数 Function",
        "slug": "lodash-函数-function",
        "link": "#lodash-函数-function",
        "children": [
          {
            "level": 3,
            "title": "_.before(n, func)",
            "slug": "before-n-func",
            "link": "#before-n-func",
            "children": []
          },
          {
            "level": 3,
            "title": "_.after(n, func)",
            "slug": "after-n-func",
            "link": "#after-n-func",
            "children": []
          },
          {
            "level": 3,
            "title": "_.ary(func, [n = func.length])",
            "slug": "ary-func-n-func-length",
            "link": "#ary-func-n-func-length",
            "children": []
          },
          {
            "level": 3,
            "title": "_.bind(func, thisArg, [partials])",
            "slug": "bind-func-thisarg-partials",
            "link": "#bind-func-thisarg-partials",
            "children": []
          },
          {
            "level": 3,
            "title": "_.bindKey(object, key, [partials])",
            "slug": "bindkey-object-key-partials",
            "link": "#bindkey-object-key-partials",
            "children": []
          },
          {
            "level": 3,
            "title": "_.partial(func, [partials])",
            "slug": "partial-func-partials",
            "link": "#partial-func-partials",
            "children": []
          },
          {
            "level": 3,
            "title": "_.partialRight(func, [partials])",
            "slug": "partialright-func-partials",
            "link": "#partialright-func-partials",
            "children": []
          },
          {
            "level": 3,
            "title": "_.curry(func, [arity = func.length])",
            "slug": "curry-func-arity-func-length",
            "link": "#curry-func-arity-func-length",
            "children": []
          },
          {
            "level": 3,
            "title": "_.curryRight(func, [arity = func.length])",
            "slug": "curryright-func-arity-func-length",
            "link": "#curryright-func-arity-func-length",
            "children": []
          },
          {
            "level": 3,
            "title": "_.rearg(func, indexes)",
            "slug": "rearg-func-indexes",
            "link": "#rearg-func-indexes",
            "children": []
          },
          {
            "level": 3,
            "title": "_.rest(func, [start=func.length-1])",
            "slug": "rest-func-start-func-length-1",
            "link": "#rest-func-start-func-length-1",
            "children": []
          },
          {
            "level": 3,
            "title": "_.spread(func, [start=0])",
            "slug": "spread-func-start-0",
            "link": "#spread-func-start-0",
            "children": []
          },
          {
            "level": 3,
            "title": "_.throttle(func, [wait = 0], [options = ])",
            "slug": "throttle-func-wait-0-options",
            "link": "#throttle-func-wait-0-options",
            "children": []
          },
          {
            "level": 3,
            "title": "_.unary(func)",
            "slug": "unary-func",
            "link": "#unary-func",
            "children": []
          },
          {
            "level": 3,
            "title": "_.wrap(value, [wrapper=identity])",
            "slug": "wrap-value-wrapper-identity",
            "link": "#wrap-value-wrapper-identity",
            "children": []
          },
          {
            "level": 2,
            "title": "延迟",
            "slug": "延迟",
            "link": "#延迟",
            "children": [
              {
                "level": 3,
                "title": "_.debounce(func, [wait = 0], [options = ])",
                "slug": "debounce-func-wait-0-options",
                "link": "#debounce-func-wait-0-options",
                "children": []
              },
              {
                "level": 3,
                "title": "_.defer(func, [args])",
                "slug": "defer-func-args",
                "link": "#defer-func-args",
                "children": []
              },
              {
                "level": 3,
                "title": "_.delay(func, wait, [args])",
                "slug": "delay-func-wait-args",
                "link": "#delay-func-wait-args",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "转换",
            "slug": "转换",
            "link": "#转换",
            "children": [
              {
                "level": 3,
                "title": "_.flip(func)",
                "slug": "flip-func",
                "link": "#flip-func",
                "children": []
              },
              {
                "level": 3,
                "title": "_.memoize(func, [resolver])",
                "slug": "memoize-func-resolver",
                "link": "#memoize-func-resolver",
                "children": []
              },
              {
                "level": 3,
                "title": "_.negate(predicate:Function)",
                "slug": "negate-predicate-function",
                "link": "#negate-predicate-function",
                "children": []
              },
              {
                "level": 3,
                "title": "_.once(func)",
                "slug": "once-func",
                "link": "#once-func",
                "children": []
              },
              {
                "level": 3,
                "title": "_.overArgs(func, [transforms = [ _.identity ]])",
                "slug": "overargs-func-transforms-identity",
                "link": "#overargs-func-transforms-identity",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-function.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 对象 Map",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 对象 Map",
        "slug": "lodash-对象-map",
        "link": "#lodash-对象-map",
        "children": []
      }
    ],
    "path": "/guide/javascript/lodash-map.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 数学 Math",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 数学 Math",
        "slug": "lodash-数学-math",
        "link": "#lodash-数学-math",
        "children": [
          {
            "level": 2,
            "title": "逻辑运算",
            "slug": "逻辑运算",
            "link": "#逻辑运算",
            "children": [
              {
                "level": 3,
                "title": "_.add(augend, addend)",
                "slug": "add-augend-addend",
                "link": "#add-augend-addend",
                "children": []
              },
              {
                "level": 3,
                "title": "_.subtract(minuend, subtrahend)",
                "slug": "subtract-minuend-subtrahend",
                "link": "#subtract-minuend-subtrahend",
                "children": []
              },
              {
                "level": 3,
                "title": "_.multiply(multiplier, multiplicand)",
                "slug": "multiply-multiplier-multiplicand",
                "link": "#multiply-multiplier-multiplicand",
                "children": []
              },
              {
                "level": 3,
                "title": "_.divide(dividend, divisor)",
                "slug": "divide-dividend-divisor",
                "link": "#divide-dividend-divisor",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sum(array)",
                "slug": "sum-array",
                "link": "#sum-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sumBy(array, [iteratee = _.identity])",
                "slug": "sumby-array-iteratee-identity",
                "link": "#sumby-array-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.mean(array)",
                "slug": "mean-array",
                "link": "#mean-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.meanBy(array, [iteratee = _.identity])",
                "slug": "meanby-array-iteratee-identity",
                "link": "#meanby-array-iteratee-identity",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "格式化",
            "slug": "格式化",
            "link": "#格式化",
            "children": [
              {
                "level": 3,
                "title": "_.round(number, [precision=0])",
                "slug": "round-number-precision-0",
                "link": "#round-number-precision-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.ceil(number, [precision = 0])",
                "slug": "ceil-number-precision-0",
                "link": "#ceil-number-precision-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.floor(number, [precision=0])",
                "slug": "floor-number-precision-0",
                "link": "#floor-number-precision-0",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "比较",
            "slug": "比较",
            "link": "#比较",
            "children": [
              {
                "level": 3,
                "title": "_.min(array)",
                "slug": "min-array",
                "link": "#min-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.minBy(array, [iteratee = _.identity])",
                "slug": "minby-array-iteratee-identity",
                "link": "#minby-array-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.max(array)",
                "slug": "max-array",
                "link": "#max-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.maxBy(array, [iteratee = _.identity])",
                "slug": "maxby-array-iteratee-identity",
                "link": "#maxby-array-iteratee-identity",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-math.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 数字 Number",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 数字 Number",
        "slug": "lodash-数字-number",
        "link": "#lodash-数字-number",
        "children": [
          {
            "level": 2,
            "title": "数字",
            "slug": "数字",
            "link": "#数字",
            "children": [
              {
                "level": 3,
                "title": "_.clamp(number, [lower], upper)",
                "slug": "clamp-number-lower-upper",
                "link": "#clamp-number-lower-upper",
                "children": []
              },
              {
                "level": 3,
                "title": "_.inRange(number, [start = 0], end)",
                "slug": "inrange-number-start-0-end",
                "link": "#inrange-number-start-0-end",
                "children": []
              },
              {
                "level": 3,
                "title": "_.random([lower = 0], [upper = 1], [floating])",
                "slug": "random-lower-0-upper-1-floating",
                "link": "#random-lower-0-upper-1-floating",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-number.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash  Seq",
    "headers": [
      {
        "level": 1,
        "title": "Lodash  Seq",
        "slug": "lodash-seq",
        "link": "#lodash-seq",
        "children": []
      }
    ],
    "path": "/guide/javascript/lodash-seq.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 字符串处理 String",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 字符串处理 String",
        "slug": "lodash-字符串处理-string",
        "link": "#lodash-字符串处理-string",
        "children": [
          {
            "level": 2,
            "title": "转换",
            "slug": "转换",
            "link": "#转换",
            "children": [
              {
                "level": 3,
                "title": "_.toLower([string=''])",
                "slug": "tolower-string",
                "link": "#tolower-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.toUpper([string=''])",
                "slug": "toupper-string",
                "link": "#toupper-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.lowerCase([string=''])",
                "slug": "lowercase-string",
                "link": "#lowercase-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.lowerFirst([string=''])",
                "slug": "lowerfirst-string",
                "link": "#lowerfirst-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.upperCase([string=''])",
                "slug": "uppercase-string",
                "link": "#uppercase-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.upperFirst([string=''])",
                "slug": "upperfirst-string",
                "link": "#upperfirst-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.capitalize([string=''])",
                "slug": "capitalize-string",
                "link": "#capitalize-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.camelCase([string=''])",
                "slug": "camelcase-string",
                "link": "#camelcase-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.kebabCase([string=''])",
                "slug": "kebabcase-string",
                "link": "#kebabcase-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.snakeCase([string=''])",
                "slug": "snakecase-string",
                "link": "#snakecase-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.startCase([string=''])",
                "slug": "startcase-string",
                "link": "#startcase-string",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "转义",
            "slug": "转义",
            "link": "#转义",
            "children": [
              {
                "level": 3,
                "title": "_.escape([string=''])",
                "slug": "escape-string",
                "link": "#escape-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.escapeRegExp([string=''])",
                "slug": "escaperegexp-string",
                "link": "#escaperegexp-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.unescape([string=''])",
                "slug": "unescape-string",
                "link": "#unescape-string",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "分割",
            "slug": "分割",
            "link": "#分割",
            "children": [
              {
                "level": 3,
                "title": "_.split([string=''], separator, [limit])",
                "slug": "split-string-separator-limit",
                "link": "#split-string-separator-limit",
                "children": []
              },
              {
                "level": 3,
                "title": "_.words([string=''], [pattern])",
                "slug": "words-string-pattern",
                "link": "#words-string-pattern",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "检索",
            "slug": "检索",
            "link": "#检索",
            "children": [
              {
                "level": 3,
                "title": "_.startsWith([string=''], [target], [position=0])",
                "slug": "startswith-string-target-position-0",
                "link": "#startswith-string-target-position-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.endsWith([string=''], [target], [position=string.length])",
                "slug": "endswith-string-target-position-string-length",
                "link": "#endswith-string-target-position-string-length",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "替换",
            "slug": "替换",
            "link": "#替换",
            "children": [
              {
                "level": 3,
                "title": "_.replace([string=''], pattern, replacement)",
                "slug": "replace-string-pattern-replacement",
                "link": "#replace-string-pattern-replacement",
                "children": []
              },
              {
                "level": 3,
                "title": "_.trim([string=''], [chars=whitespace])",
                "slug": "trim-string-chars-whitespace",
                "link": "#trim-string-chars-whitespace",
                "children": []
              },
              {
                "level": 3,
                "title": "_.trimStart([string=''], [chars=whitespace])",
                "slug": "trimstart-string-chars-whitespace",
                "link": "#trimstart-string-chars-whitespace",
                "children": []
              },
              {
                "level": 3,
                "title": "_.trimEnd([string=''], [chars=whitespace])",
                "slug": "trimend-string-chars-whitespace",
                "link": "#trimend-string-chars-whitespace",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pad([string=''], [length=0], [chars=' '])",
                "slug": "pad-string-length-0-chars",
                "link": "#pad-string-length-0-chars",
                "children": []
              },
              {
                "level": 3,
                "title": "_.padStart([string=''], [length=0], [chars=' '])",
                "slug": "padstart-string-length-0-chars",
                "link": "#padstart-string-length-0-chars",
                "children": []
              },
              {
                "level": 3,
                "title": "_.padEnd([string=''], [length=0], [chars=' '])",
                "slug": "padend-string-length-0-chars",
                "link": "#padend-string-length-0-chars",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "其它",
            "slug": "其它",
            "link": "#其它",
            "children": [
              {
                "level": 3,
                "title": "_.parseInt(string, [radix=10])",
                "slug": "parseint-string-radix-10",
                "link": "#parseint-string-radix-10",
                "children": []
              },
              {
                "level": 3,
                "title": "_.repeat([string=''], [n=1])",
                "slug": "repeat-string-n-1",
                "link": "#repeat-string-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.truncate([string=''], [options=])",
                "slug": "truncate-string-options",
                "link": "#truncate-string-options",
                "children": []
              },
              {
                "level": 3,
                "title": "_.template([string=''], [options=])",
                "slug": "template-string-options",
                "link": "#template-string-options",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-string.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 实用函数 Utils",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 实用函数 Utils",
        "slug": "lodash-实用函数-utils",
        "link": "#lodash-实用函数-utils",
        "children": []
      }
    ],
    "path": "/guide/javascript/lodash-utils.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Docker 基本入门",
    "headers": [
      {
        "level": 1,
        "title": "Docker 基本入门",
        "slug": "docker-基本入门",
        "link": "#docker-基本入门",
        "children": [
          {
            "level": 2,
            "title": "安装",
            "slug": "安装",
            "link": "#安装",
            "children": []
          },
          {
            "level": 2,
            "title": "名词解释",
            "slug": "名词解释",
            "link": "#名词解释",
            "children": []
          },
          {
            "level": 2,
            "title": "启动",
            "slug": "启动",
            "link": "#启动",
            "children": []
          },
          {
            "level": 2,
            "title": "权限",
            "slug": "权限",
            "link": "#权限",
            "children": [
              {
                "level": 3,
                "title": "查看用户组与用户",
                "slug": "查看用户组与用户",
                "link": "#查看用户组与用户",
                "children": []
              },
              {
                "level": 3,
                "title": "加入用户组",
                "slug": "加入用户组",
                "link": "#加入用户组",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "常用命令",
            "slug": "常用命令",
            "link": "#常用命令",
            "children": []
          },
          {
            "level": 2,
            "title": "Dockerfile 语法",
            "slug": "dockerfile-语法",
            "link": "#dockerfile-语法",
            "children": [
              {
                "level": 3,
                "title": "Dockerfile 示例",
                "slug": "dockerfile-示例",
                "link": "#dockerfile-示例",
                "children": []
              }
            ]
          }
        ]
      },
      {
        "level": 1,
        "title": "Docker Compose",
        "slug": "docker-compose",
        "link": "#docker-compose",
        "children": [
          {
            "level": 2,
            "title": "安装",
            "slug": "安装-1",
            "link": "#安装-1",
            "children": []
          },
          {
            "level": 2,
            "title": "常用命令",
            "slug": "常用命令-1",
            "link": "#常用命令-1",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/linux/docker-basic.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Go 基本入门",
    "headers": [
      {
        "level": 1,
        "title": "Go 基本入门",
        "slug": "go-基本入门",
        "link": "#go-基本入门",
        "children": [
          {
            "level": 2,
            "title": "环境安装",
            "slug": "环境安装",
            "link": "#环境安装",
            "children": [
              {
                "level": 3,
                "title": "下载",
                "slug": "下载",
                "link": "#下载",
                "children": []
              },
              {
                "level": 3,
                "title": "配置Go Proxy",
                "slug": "配置go-proxy",
                "link": "#配置go-proxy",
                "children": []
              },
              {
                "level": 3,
                "title": "VS Code 安装Go插件",
                "slug": "vs-code-安装go插件",
                "link": "#vs-code-安装go插件",
                "children": []
              },
              {
                "level": 3,
                "title": "测试",
                "slug": "测试",
                "link": "#测试",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "语言基础",
            "slug": "语言基础",
            "link": "#语言基础",
            "children": [
              {
                "level": 3,
                "title": "import",
                "slug": "import",
                "link": "#import",
                "children": []
              }
            ]
          }
        ]
      },
      {
        "level": 1,
        "title": "学习资料",
        "slug": "学习资料",
        "link": "#学习资料",
        "children": []
      }
    ],
    "path": "/guide/linux/go-basic.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Ubuntu 配置 git",
    "headers": [
      {
        "level": 1,
        "title": "Ubuntu 配置 git",
        "slug": "ubuntu-配置-git",
        "link": "#ubuntu-配置-git",
        "children": [
          {
            "level": 2,
            "title": "常用命令",
            "slug": "常用命令",
            "link": "#常用命令",
            "children": []
          },
          {
            "level": 2,
            "title": "重命名分支",
            "slug": "重命名分支",
            "link": "#重命名分支",
            "children": []
          },
          {
            "level": 2,
            "title": "配置SSH",
            "slug": "配置ssh",
            "link": "#配置ssh",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/linux/ubuntu-config-git.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "版本发布命名",
    "headers": [
      {
        "level": 1,
        "title": "版本发布命名",
        "slug": "版本发布命名",
        "link": "#版本发布命名",
        "children": [
          {
            "level": 2,
            "title": "常见版本的具体含义",
            "slug": "常见版本的具体含义",
            "link": "#常见版本的具体含义",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/linux/version.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "vscode 前端常用配置",
    "headers": [
      {
        "level": 1,
        "title": "vscode 前端常用配置",
        "slug": "vscode-前端常用配置",
        "link": "#vscode-前端常用配置",
        "children": [
          {
            "level": 2,
            "title": "配置",
            "slug": "配置",
            "link": "#配置",
            "children": []
          },
          {
            "level": 2,
            "title": "常用插件",
            "slug": "常用插件",
            "link": "#常用插件",
            "children": [
              {
                "level": 3,
                "title": "Vue 3 Snippets",
                "slug": "vue-3-snippets",
                "link": "#vue-3-snippets",
                "children": []
              },
              {
                "level": 3,
                "title": "vscode-vue-peek",
                "slug": "vscode-vue-peek",
                "link": "#vscode-vue-peek",
                "children": []
              },
              {
                "level": 3,
                "title": "Vetur",
                "slug": "vetur",
                "link": "#vetur",
                "children": []
              },
              {
                "level": 3,
                "title": "EsLint",
                "slug": "eslint",
                "link": "#eslint",
                "children": []
              },
              {
                "level": 3,
                "title": "Path Intellisense",
                "slug": "path-intellisense",
                "link": "#path-intellisense",
                "children": []
              },
              {
                "level": 3,
                "title": "HTML CSS Support",
                "slug": "html-css-support",
                "link": "#html-css-support",
                "children": []
              },
              {
                "level": 3,
                "title": "Git History",
                "slug": "git-history",
                "link": "#git-history",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/linux/vscode-guide.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "ffmpeg 使用笔记",
    "headers": [
      {
        "level": 1,
        "title": "ffmpeg 使用笔记",
        "slug": "ffmpeg-使用笔记",
        "link": "#ffmpeg-使用笔记",
        "children": [
          {
            "level": 2,
            "title": "录制",
            "slug": "录制",
            "link": "#录制",
            "children": [
              {
                "level": 3,
                "title": "转录网络媒体流",
                "slug": "转录网络媒体流",
                "link": "#转录网络媒体流",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "转码",
            "slug": "转码",
            "link": "#转码",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/nodejs/ffmpeg.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "inquirer.js 命令行询问任务",
    "headers": [
      {
        "level": 1,
        "title": "inquirer.js 命令行询问任务",
        "slug": "inquirer-js-命令行询问任务",
        "link": "#inquirer-js-命令行询问任务",
        "children": [
          {
            "level": 2,
            "title": "文档",
            "slug": "文档",
            "link": "#文档",
            "children": [
              {
                "level": 3,
                "title": "安装",
                "slug": "安装",
                "link": "#安装",
                "children": []
              },
              {
                "level": 3,
                "title": "参数",
                "slug": "参数",
                "link": "#参数",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/nodejs/inquirer.js.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Nodejs 安装",
    "headers": [
      {
        "level": 1,
        "title": "Nodejs 安装",
        "slug": "nodejs-安装",
        "link": "#nodejs-安装",
        "children": [
          {
            "level": 2,
            "title": "安装",
            "slug": "安装",
            "link": "#安装",
            "children": []
          },
          {
            "level": 2,
            "title": "配置",
            "slug": "配置",
            "link": "#配置",
            "children": []
          },
          {
            "level": 2,
            "title": "调试",
            "slug": "调试",
            "link": "#调试",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/nodejs/nodejs-install.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "发布代码到npm库",
    "headers": [
      {
        "level": 1,
        "title": "发布代码到npm库",
        "slug": "发布代码到npm库",
        "link": "#发布代码到npm库",
        "children": [
          {
            "level": 2,
            "title": "账号",
            "slug": "账号",
            "link": "#账号",
            "children": []
          },
          {
            "level": 2,
            "title": "代码库名称",
            "slug": "代码库名称",
            "link": "#代码库名称",
            "children": []
          },
          {
            "level": 2,
            "title": "创建项目",
            "slug": "创建项目",
            "link": "#创建项目",
            "children": []
          },
          {
            "level": 2,
            "title": "新建目录",
            "slug": "新建目录",
            "link": "#新建目录",
            "children": []
          },
          {
            "level": 2,
            "title": "本地测试",
            "slug": "本地测试",
            "link": "#本地测试",
            "children": []
          },
          {
            "level": 2,
            "title": "登陆",
            "slug": "登陆",
            "link": "#登陆",
            "children": []
          },
          {
            "level": 2,
            "title": "提交发布",
            "slug": "提交发布",
            "link": "#提交发布",
            "children": []
          },
          {
            "level": 2,
            "title": "测试提交",
            "slug": "测试提交",
            "link": "#测试提交",
            "children": []
          },
          {
            "level": 2,
            "title": "撤销当前提交",
            "slug": "撤销当前提交",
            "link": "#撤销当前提交",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/nodejs/publish-project-to-npm.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "RSA加密与解密(js-encrypt)",
    "headers": [
      {
        "level": 1,
        "title": "RSA加密与解密(js-encrypt)",
        "slug": "rsa加密与解密-js-encrypt",
        "link": "#rsa加密与解密-js-encrypt",
        "children": [
          {
            "level": 2,
            "title": "第一部分：RSA加密与解密",
            "slug": "第一部分-rsa加密与解密",
            "link": "#第一部分-rsa加密与解密",
            "children": [
              {
                "level": 3,
                "title": "什么是RSA加密",
                "slug": "什么是rsa加密",
                "link": "#什么是rsa加密",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "第二部分：js-encrypt库",
            "slug": "第二部分-js-encrypt库",
            "link": "#第二部分-js-encrypt库",
            "children": [
              {
                "level": 3,
                "title": "例一：转换加密文本",
                "slug": "例一-转换加密文本",
                "link": "#例一-转换加密文本",
                "children": []
              },
              {
                "level": 3,
                "title": "例二：签名和验证",
                "slug": "例二-签名和验证",
                "link": "#例二-签名和验证",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/nodejs/rsa-symmetric-encryption.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "下载哔哩哔哩视频",
    "headers": [
      {
        "level": 1,
        "title": "下载哔哩哔哩视频",
        "slug": "下载哔哩哔哩视频",
        "link": "#下载哔哩哔哩视频",
        "children": [
          {
            "level": 2,
            "title": "获取视频系列地址",
            "slug": "获取视频系列地址",
            "link": "#获取视频系列地址",
            "children": []
          },
          {
            "level": 2,
            "title": "下载视频",
            "slug": "下载视频",
            "link": "#下载视频",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/other/%E4%B8%8B%E8%BD%BDbilibili%E8%A7%86%E9%A2%91.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "快速开始",
    "headers": [
      {
        "level": 1,
        "title": "快速开始",
        "slug": "快速开始",
        "link": "#快速开始",
        "children": [
          {
            "level": 2,
            "title": "环境",
            "slug": "环境",
            "link": "#环境",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/typescript/get-started.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Nuxt",
    "headers": [
      {
        "level": 1,
        "title": "Nuxt",
        "slug": "nuxt",
        "link": "#nuxt",
        "children": [
          {
            "level": 2,
            "title": "配置相关",
            "slug": "配置相关",
            "link": "#配置相关",
            "children": [
              {
                "level": 3,
                "title": "引入第三方库",
                "slug": "引入第三方库",
                "link": "#引入第三方库",
                "children": []
              },
              {
                "level": 3,
                "title": "打包删除console",
                "slug": "打包删除console",
                "link": "#打包删除console",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/vue/nuxt-study-notes.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Home",
    "headers": [],
    "path": "/guide/vue/",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue3",
    "headers": [
      {
        "level": 1,
        "title": "Vue3",
        "slug": "vue3",
        "link": "#vue3",
        "children": [
          {
            "level": 2,
            "title": "缩略语",
            "slug": "缩略语",
            "link": "#缩略语",
            "children": [
              {
                "level": 3,
                "title": "SPA Single-Page application 单页应用程序",
                "slug": "spa-single-page-application-单页应用程序",
                "link": "#spa-single-page-application-单页应用程序",
                "children": []
              },
              {
                "level": 3,
                "title": "SSR Server-Side Rendering 服务端渲染",
                "slug": "ssr-server-side-rendering-服务端渲染",
                "link": "#ssr-server-side-rendering-服务端渲染",
                "children": []
              },
              {
                "level": 3,
                "title": "SSG Static-Site Generation 静态站点生成",
                "slug": "ssg-static-site-generation-静态站点生成",
                "link": "#ssg-static-site-generation-静态站点生成",
                "children": []
              },
              {
                "level": 3,
                "title": "PWA Progressive Web Apps 渐进式Web应用",
                "slug": "pwa-progressive-web-apps-渐进式web应用",
                "link": "#pwa-progressive-web-apps-渐进式web应用",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "框架",
            "slug": "框架",
            "link": "#框架",
            "children": []
          },
          {
            "level": 2,
            "title": "命名",
            "slug": "命名",
            "link": "#命名",
            "children": []
          },
          {
            "level": 2,
            "title": "组件拆分规则",
            "slug": "组件拆分规则",
            "link": "#组件拆分规则",
            "children": []
          },
          {
            "level": 2,
            "title": "书写规则",
            "slug": "书写规则",
            "link": "#书写规则",
            "children": [
              {
                "level": 3,
                "title": "组件内class书写顺序",
                "slug": "组件内class书写顺序",
                "link": "#组件内class书写顺序",
                "children": []
              },
              {
                "level": 3,
                "title": "script setup 语法糖书写",
                "slug": "script-setup-语法糖书写",
                "link": "#script-setup-语法糖书写",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "",
            "slug": "",
            "link": "#",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/vue/reference.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue 知识点总结",
    "headers": [
      {
        "level": 1,
        "title": "Vue 知识点总结",
        "slug": "vue-知识点总结",
        "link": "#vue-知识点总结",
        "children": [
          {
            "level": 2,
            "title": "vue 父子组件通讯",
            "slug": "vue-父子组件通讯",
            "link": "#vue-父子组件通讯",
            "children": [
              {
                "level": 3,
                "title": "方式一：事件类型",
                "slug": "方式一-事件类型",
                "link": "#方式一-事件类型",
                "children": []
              },
              {
                "level": 3,
                "title": "方式二：provide和inject 提供注入（高阶组件库使用）。",
                "slug": "方式二-provide和inject-提供注入-高阶组件库使用-。",
                "link": "#方式二-provide和inject-提供注入-高阶组件库使用-。",
                "children": []
              },
              {
                "level": 3,
                "title": "方式三：原型链",
                "slug": "方式三-原型链",
                "link": "#方式三-原型链",
                "children": []
              },
              {
                "level": 3,
                "title": "方式四：Vuex 状态管理",
                "slug": "方式四-vuex-状态管理",
                "link": "#方式四-vuex-状态管理",
                "children": []
              },
              {
                "level": 3,
                "title": "方式五：attrs和listeners",
                "slug": "方式五-attrs和listeners",
                "link": "#方式五-attrs和listeners",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/vue/vue-basic.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue Event",
    "headers": [
      {
        "level": 1,
        "title": "Vue Event",
        "slug": "vue-event",
        "link": "#vue-event",
        "children": [
          {
            "level": 2,
            "title": "Event",
            "slug": "event",
            "link": "#event",
            "children": [
              {
                "level": 3,
                "title": "JavaScript事件的三阶段",
                "slug": "javascript事件的三阶段",
                "link": "#javascript事件的三阶段",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "事件修饰符",
            "slug": "事件修饰符",
            "link": "#事件修饰符",
            "children": []
          },
          {
            "level": 2,
            "title": "自定义事件",
            "slug": "自定义事件",
            "link": "#自定义事件",
            "children": [
              {
                "level": 3,
                "title": "验证抛出的事件",
                "slug": "验证抛出的事件",
                "link": "#验证抛出的事件",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/vue/vue-event.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue v-model",
    "headers": [
      {
        "level": 1,
        "title": "Vue v-model",
        "slug": "vue-v-model",
        "link": "#vue-v-model",
        "children": [
          {
            "level": 2,
            "title": "表单输入绑定",
            "slug": "表单输入绑定",
            "link": "#表单输入绑定",
            "children": []
          },
          {
            "level": 2,
            "title": "自定义组件上使用v-model",
            "slug": "自定义组件上使用v-model",
            "link": "#自定义组件上使用v-model",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue2在组件上使用v-model",
            "slug": "vue2在组件上使用v-model",
            "link": "#vue2在组件上使用v-model",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue3在组件上使用v-model",
            "slug": "vue3在组件上使用v-model",
            "link": "#vue3在组件上使用v-model",
            "children": []
          },
          {
            "level": 2,
            "title": "v-model参数",
            "slug": "v-model参数",
            "link": "#v-model参数",
            "children": []
          },
          {
            "level": 2,
            "title": "多个v-model绑定",
            "slug": "多个v-model绑定",
            "link": "#多个v-model绑定",
            "children": []
          },
          {
            "level": 2,
            "title": "处理v-model修饰符",
            "slug": "处理v-model修饰符",
            "link": "#处理v-model修饰符",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "Vue .sync",
        "slug": "vue-sync",
        "link": "#vue-sync",
        "children": []
      }
    ],
    "path": "/guide/vue/vue-model.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue props 对象",
    "headers": [
      {
        "level": 1,
        "title": "Vue props 对象",
        "slug": "vue-props-对象",
        "link": "#vue-props-对象",
        "children": []
      }
    ],
    "path": "/guide/vue/vue-props.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue3 组合式API(Composition API)",
    "headers": [
      {
        "level": 1,
        "title": "Vue3 组合式API(Composition API)",
        "slug": "vue3-组合式api-composition-api",
        "link": "#vue3-组合式api-composition-api",
        "children": [
          {
            "level": 2,
            "title": "setup 组件选项",
            "slug": "setup-组件选项",
            "link": "#setup-组件选项",
            "children": []
          },
          {
            "level": 2,
            "title": "带ref的响应式变量",
            "slug": "带ref的响应式变量",
            "link": "#带ref的响应式变量",
            "children": []
          },
          {
            "level": 2,
            "title": "在setup内注册生命周期钩子",
            "slug": "在setup内注册生命周期钩子",
            "link": "#在setup内注册生命周期钩子",
            "children": []
          },
          {
            "level": 2,
            "title": "watch响应式更改",
            "slug": "watch响应式更改",
            "link": "#watch响应式更改",
            "children": []
          },
          {
            "level": 2,
            "title": "独立的 computed 属性",
            "slug": "独立的-computed-属性",
            "link": "#独立的-computed-属性",
            "children": []
          },
          {
            "level": 2,
            "title": "defineProps 和 defineEmits",
            "slug": "defineprops-和-defineemits",
            "link": "#defineprops-和-defineemits",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/vue/vue3-composition-api.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue3 学习笔记",
    "headers": [
      {
        "level": 1,
        "title": "Vue3 学习笔记",
        "slug": "vue3-学习笔记",
        "link": "#vue3-学习笔记",
        "children": [
          {
            "level": 2,
            "title": "全局API",
            "slug": "全局api",
            "link": "#全局api",
            "children": [
              {
                "level": 3,
                "title": "createApp",
                "slug": "createapp",
                "link": "#createapp",
                "children": []
              },
              {
                "level": 3,
                "title": "h",
                "slug": "h",
                "link": "#h",
                "children": []
              },
              {
                "level": 3,
                "title": "createRenderer(HostNode, HostElement)",
                "slug": "createrenderer-hostnode-hostelement",
                "link": "#createrenderer-hostnode-hostelement",
                "children": []
              },
              {
                "level": 3,
                "title": "nextTick",
                "slug": "nexttick",
                "link": "#nexttick",
                "children": []
              },
              {
                "level": 3,
                "title": "mergeProps",
                "slug": "mergeprops",
                "link": "#mergeprops",
                "children": []
              },
              {
                "level": 3,
                "title": "defineComponent",
                "slug": "definecomponent",
                "link": "#definecomponent",
                "children": []
              },
              {
                "level": 3,
                "title": "defineAsyncComponent",
                "slug": "defineasynccomponent",
                "link": "#defineasynccomponent",
                "children": []
              },
              {
                "level": 3,
                "title": "resolveComponent",
                "slug": "resolvecomponent",
                "link": "#resolvecomponent",
                "children": []
              },
              {
                "level": 3,
                "title": "resolveDynamicComponent",
                "slug": "resolvedynamiccomponent",
                "link": "#resolvedynamiccomponent",
                "children": []
              },
              {
                "level": 3,
                "title": "resolveDirective",
                "slug": "resolvedirective",
                "link": "#resolvedirective",
                "children": []
              },
              {
                "level": 3,
                "title": "withDirectives",
                "slug": "withdirectives",
                "link": "#withdirectives",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "应用API",
            "slug": "应用api",
            "link": "#应用api",
            "children": []
          },
          {
            "level": 2,
            "title": "组合式API",
            "slug": "组合式api",
            "link": "#组合式api",
            "children": []
          },
          {
            "level": 2,
            "title": "响应式API",
            "slug": "响应式api",
            "link": "#响应式api",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "深入响应原理",
        "slug": "深入响应原理",
        "link": "#深入响应原理",
        "children": [
          {
            "level": 2,
            "title": "检测变化的注意事项",
            "slug": "检测变化的注意事项",
            "link": "#检测变化的注意事项",
            "children": []
          },
          {
            "level": 2,
            "title": "数组",
            "slug": "数组",
            "link": "#数组",
            "children": []
          },
          {
            "level": 2,
            "title": "对象",
            "slug": "对象",
            "link": "#对象",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "方法",
        "slug": "方法",
        "link": "#方法",
        "children": [
          {
            "level": 2,
            "title": "实例方法",
            "slug": "实例方法",
            "link": "#实例方法",
            "children": [
              {
                "level": 3,
                "title": "$watch",
                "slug": "watch",
                "link": "#watch",
                "children": []
              },
              {
                "level": 3,
                "title": "$emit",
                "slug": "emit",
                "link": "#emit",
                "children": []
              },
              {
                "level": 3,
                "title": "$forceUpdate",
                "slug": "forceupdate",
                "link": "#forceupdate",
                "children": []
              },
              {
                "level": 3,
                "title": "$nextTick",
                "slug": "nexttick-1",
                "link": "#nexttick-1",
                "children": []
              }
            ]
          }
        ]
      },
      {
        "level": 1,
        "title": "指令",
        "slug": "指令",
        "link": "#指令",
        "children": [
          {
            "level": 2,
            "title": "常用指令",
            "slug": "常用指令",
            "link": "#常用指令",
            "children": []
          },
          {
            "level": 2,
            "title": "特殊指令",
            "slug": "特殊指令",
            "link": "#特殊指令",
            "children": [
              {
                "level": 3,
                "title": "key : number | string",
                "slug": "key-number-string",
                "link": "#key-number-string",
                "children": []
              },
              {
                "level": 3,
                "title": "ref : string | Function",
                "slug": "ref-string-function",
                "link": "#ref-string-function",
                "children": []
              },
              {
                "level": 3,
                "title": "is : string | Object (component’s options object)",
                "slug": "is-string-object-component-s-options-object",
                "link": "#is-string-object-component-s-options-object",
                "children": []
              }
            ]
          }
        ]
      },
      {
        "level": 1,
        "title": "组件",
        "slug": "组件",
        "link": "#组件",
        "children": [
          {
            "level": 2,
            "title": "内置组件",
            "slug": "内置组件",
            "link": "#内置组件",
            "children": [
              {
                "level": 3,
                "title": "Teleport",
                "slug": "teleport",
                "link": "#teleport",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "函数式组件",
            "slug": "函数式组件",
            "link": "#函数式组件",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/vue/vue3-study-notes.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "WebRTC 媒体服务",
    "headers": [
      {
        "level": 1,
        "title": "WebRTC 媒体服务",
        "slug": "webrtc-媒体服务",
        "link": "#webrtc-媒体服务",
        "children": []
      },
      {
        "level": 1,
        "title": "获取设备列表",
        "slug": "获取设备列表",
        "link": "#获取设备列表",
        "children": []
      }
    ],
    "path": "/guide/webrtc/",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "常用钩子合集",
    "headers": [
      {
        "level": 1,
        "title": "常用钩子合集",
        "slug": "常用钩子合集",
        "link": "#常用钩子合集",
        "children": [
          {
            "level": 2,
            "title": "定时器useTimer",
            "slug": "定时器usetimer",
            "link": "#定时器usetimer",
            "children": []
          },
          {
            "level": 2,
            "title": "字节格式化",
            "slug": "字节格式化",
            "link": "#字节格式化",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/vue/hooks/timer.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/404.html",
    "pathLocale": "/",
    "extraFields": []
  }
];
const searchIndex = ref(searchIndex$1);
const useSearchIndex = () => searchIndex;
const useSearchSuggestions = ({ searchIndex: searchIndex2, routeLocale, query, maxSuggestions: maxSuggestions2 }) => {
  const localeSearchIndex = computed(() => searchIndex2.value.filter((item) => item.pathLocale === routeLocale.value));
  return computed(() => {
    const searchStr = query.value.trim().toLowerCase();
    if (!searchStr)
      return [];
    const suggestions = [];
    const matchPageHeader = (searchIndexItem, header) => {
      if (isQueryMatched(searchStr, [header.title])) {
        suggestions.push({
          link: `${searchIndexItem.path}#${header.slug}`,
          title: searchIndexItem.title,
          header: header.title
        });
      }
      for (const child of header.children) {
        if (suggestions.length >= maxSuggestions2.value) {
          return;
        }
        matchPageHeader(searchIndexItem, child);
      }
    };
    for (const searchIndexItem of localeSearchIndex.value) {
      if (suggestions.length >= maxSuggestions2.value) {
        break;
      }
      if (isQueryMatched(searchStr, [
        searchIndexItem.title,
        ...searchIndexItem.extraFields
      ])) {
        suggestions.push({
          link: searchIndexItem.path,
          title: searchIndexItem.title
        });
        continue;
      }
      for (const header of searchIndexItem.headers) {
        if (suggestions.length >= maxSuggestions2.value) {
          break;
        }
        matchPageHeader(searchIndexItem, header);
      }
    }
    return suggestions;
  });
};
const useSuggestionsFocus = (suggestions) => {
  const focusIndex = ref(0);
  const focusNext = () => {
    if (focusIndex.value < suggestions.value.length - 1) {
      focusIndex.value += 1;
    } else {
      focusIndex.value = 0;
    }
  };
  const focusPrev = () => {
    if (focusIndex.value > 0) {
      focusIndex.value -= 1;
    } else {
      focusIndex.value = suggestions.value.length - 1;
    }
  };
  return {
    focusIndex,
    focusNext,
    focusPrev
  };
};
const SearchBox = defineComponent({
  name: "SearchBox",
  props: {
    locales: {
      type: Object,
      required: false,
      default: () => ({})
    },
    hotKeys: {
      type: Array,
      required: false,
      default: () => []
    },
    maxSuggestions: {
      type: Number,
      required: false,
      default: 5
    }
  },
  setup(props) {
    const { locales: locales2, hotKeys: hotKeys2, maxSuggestions: maxSuggestions2 } = toRefs(props);
    const router = useRouter();
    const routeLocale = useRouteLocale();
    const searchIndex2 = useSearchIndex();
    const input = ref(null);
    const isActive = ref(false);
    const query = ref("");
    const locale = computed(() => locales2.value[routeLocale.value] ?? {});
    const suggestions = useSearchSuggestions({
      searchIndex: searchIndex2,
      routeLocale,
      query,
      maxSuggestions: maxSuggestions2
    });
    const { focusIndex, focusNext, focusPrev } = useSuggestionsFocus(suggestions);
    useHotKeys({ input, hotKeys: hotKeys2 });
    const showSuggestions = computed(() => isActive.value && !!suggestions.value.length);
    const onArrowUp = () => {
      if (!showSuggestions.value) {
        return;
      }
      focusPrev();
    };
    const onArrowDown = () => {
      if (!showSuggestions.value) {
        return;
      }
      focusNext();
    };
    const goTo = (index2) => {
      if (!showSuggestions.value) {
        return;
      }
      const suggestion = suggestions.value[index2];
      if (!suggestion) {
        return;
      }
      router.push(suggestion.link).then(() => {
        query.value = "";
        focusIndex.value = 0;
      });
    };
    return () => h("form", {
      class: "search-box",
      role: "search"
    }, [
      h("input", {
        ref: input,
        type: "search",
        placeholder: locale.value.placeholder,
        autocomplete: "off",
        spellcheck: false,
        value: query.value,
        onFocus: () => isActive.value = true,
        onBlur: () => isActive.value = false,
        onInput: (event) => query.value = event.target.value,
        onKeydown: (event) => {
          switch (event.key) {
            case "ArrowUp": {
              onArrowUp();
              break;
            }
            case "ArrowDown": {
              onArrowDown();
              break;
            }
            case "Enter": {
              event.preventDefault();
              goTo(focusIndex.value);
              break;
            }
          }
        }
      }),
      showSuggestions.value && h("ul", {
        class: "suggestions",
        onMouseleave: () => focusIndex.value = -1
      }, suggestions.value.map(({ link, title, header }, index2) => h("li", {
        class: [
          "suggestion",
          {
            focus: focusIndex.value === index2
          }
        ],
        onMouseenter: () => focusIndex.value = index2,
        onMousedown: () => goTo(index2)
      }, h("a", {
        href: link,
        onClick: (event) => event.preventDefault()
      }, [
        h("span", {
          class: "page-title"
        }, title),
        header && h("span", { class: "page-header" }, `> ${header}`)
      ]))))
    ]);
  }
});
const vars = "";
const search = "";
const locales = { "/": { "placeholder": "Search" }, "/guide/": { "placeholder": "输入关键字" }, "/poetry/": { "placeholder": "输入古诗词名" } };
const hotKeys = ["s", "/"];
const maxSuggestions = 7;
const clientConfig7 = defineClientConfig({
  enhance({ app }) {
    app.component("SearchBox", (props) => h(SearchBox, {
      locales,
      hotKeys,
      maxSuggestions,
      ...props
    }));
  }
});
const clientConfig8 = {
  enhance: ({ app }) => {
    app.component("Poetry", defineAsyncComponent(() => import("./assets/Poetry-9b91e335.mjs"))), app.component("URLInput", defineAsyncComponent(() => import("./assets/URLInput-4306adcc.mjs"))), app.component("VueSite", defineAsyncComponent(() => import("./assets/VueSite-ecbe7d5a.mjs"))), app.component("WindowBeforePrint", defineAsyncComponent(() => import("./assets/WindowBeforePrint-300867f9.mjs"))), app.component("WindowEventChange", defineAsyncComponent(() => import("./assets/WindowEventChange-a6f67280.mjs"))), app.component("WindowEventStorage", defineAsyncComponent(() => import("./assets/WindowEventStorage-c0f5ad1c.mjs"))), app.component("WindowVisibilityState", defineAsyncComponent(() => import("./assets/WindowVisibilityState-7e337abf.mjs")));
  }
};
const index = "";
function formatBytes(size, fractionDigits = 2) {
  const units = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB", "BB"];
  let suffix = units[0];
  for (let i = 1; size >= 1024 && i < units.length; i += 1) {
    size /= 1024;
    suffix = units[i];
  }
  const value = size.toFixed(fractionDigits);
  return (parseInt(value, 10) === Number(value) ? parseInt(value, 10) : value) + suffix;
}
function loadScript(url) {
  console.log("insert url", url);
  return new Promise((resolve, reject) => {
    var script = document.createElement("script");
    script.type = "text/javascript";
    script.src = url;
    document.body.appendChild(script);
    script.onload = function() {
      resolve(url);
    };
    script.onerror = function(err) {
      reject(err);
    };
  });
}
function fetch(url) {
  let xhr = null;
  if ("ActiveXObject" in window) {
    xhr = new window.ActiveXObject("Microsoft.XMLHTTP");
  } else if ("XMLHttpRequest" in window) {
    xhr = new window.XMLHttpRequest();
  }
  return new Promise((resolve, reject) => {
    xhr.open("get", url, true);
    xhr.onreadystatechange = function() {
      if (xhr.readyState == 4) {
        if (xhr.status >= 200 && xhr.status < 300 || xhr.status == 304) {
          resolve(xhr.responseText);
        }
        reject();
      }
    };
    xhr.onerror = (e) => {
      console.log("Fetch Error", url, e);
      resolve();
    };
    xhr.send();
  });
}
const helper = {
  formatBytes,
  loadScript,
  fetch
};
console.log("helper", helper);
const AppClient = {
  install(app, options) {
    Object.assign(app.config.globalProperties, helper);
    app.config.globalProperties.$videoList = [
      { label: "樱花小镇 1080P MP4", value: "/assets/medias/cherry_town.mp4" },
      { label: "森林 1080P MP4", value: "/assets/medias/forest.mp4" },
      { label: "Piper 720P", value: "/assets/medias/Piper_720P.mp4" },
      { label: "Piper 1080P", value: "/assets/medias/Piper_1080P.mp4" },
      { label: "汽车 绿幕 720P", value: "/assets/medias/green-screen-car.mp4" },
      { label: "锦里 音频 mp3", value: "/assets/medias/jinli.mp3" }
    ];
  }
};
const Layout_vue_vue_type_style_index_0_scoped_0c7f34a8_lang = "";
const _sfc_main$2 = {
  __name: "Layout",
  __ssrInlineRender: true,
  setup(__props) {
    const page = usePageData();
    const frontmatter = usePageFrontmatter();
    const site = useSiteData();
    const head = usePageHead();
    const headTitle = usePageHeadTitle();
    const pageLang = usePageLang();
    const routeLocale = useRouteLocale();
    const siteLocaleData = useSiteLocaleData();
    const cover = computed(() => page.value.frontmatter.cover);
    computed(() => page.value.frontmatter.coverfit || page.value.frontmatter["cover-fit"] || "100% auto");
    onMounted(() => {
      console.log("1.page", page.value);
      console.log("2.site", site.value);
      console.log("3.head", head.value);
      console.log("4.frontmatter", frontmatter.value);
      console.log("5.headTitle", headTitle.value);
      console.log("6.pageLang", pageLang.value);
      console.log("7.routeLocale", routeLocale.value);
      console.log("8.siteLocaleData", siteLocaleData.value);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><!-- <Banner> 压屏通知 </Banner> -->`);
      _push(ssrRenderComponent(ParentLayout, _attrs, {
        "page-top": withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(cover)) {
              _push2(`<div class="cover" style="${ssrRenderStyle({
                height: "320px",
                background: `url(${_ctx.$withBase(unref(cover))}) no-repeat 0/cover`
              })}" data-v-0c7f34a8${_scopeId}><span class="cover-body" data-v-0c7f34a8${_scopeId}><b class="title" data-v-0c7f34a8${_scopeId}>${ssrInterpolate(_ctx.$page.title)}</b>`);
              if (_ctx.$page.frontmatter.description) {
                _push2(`<small class="desc" data-v-0c7f34a8${_scopeId}>${ssrInterpolate(_ctx.$page.frontmatter.description)}</small>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</span></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              unref(cover) ? (openBlock(), createBlock(
                "div",
                {
                  key: 0,
                  class: "cover",
                  style: {
                    height: "320px",
                    background: `url(${_ctx.$withBase(unref(cover))}) no-repeat 0/cover`
                  }
                },
                [
                  createVNode("span", { class: "cover-body" }, [
                    createVNode(
                      "b",
                      { class: "title" },
                      toDisplayString(_ctx.$page.title),
                      1
                      /* TEXT */
                    ),
                    _ctx.$page.frontmatter.description ? (openBlock(), createBlock(
                      "small",
                      {
                        key: 0,
                        class: "desc"
                      },
                      toDisplayString(_ctx.$page.frontmatter.description),
                      1
                      /* TEXT */
                    )) : createCommentVNode("v-if", true)
                  ])
                ],
                4
                /* STYLE */
              )) : createCommentVNode("v-if", true)
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../layouts/Layout.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const Banner_vue_vue_type_style_index_0_scoped_1b29cf88_lang = "";
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "banner" }, _attrs))} data-v-1b29cf88>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, () => {
    _push(`横幅广告`);
  }, _push, _parent);
  _push(`</div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../components/Banner.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Banner = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-1b29cf88"], ["__file", "Banner.vue"]]);
const HomeLayout_vue_vue_type_style_index_0_scoped_c1de9f97_lang = "";
const _sfc_main = {
  __name: "HomeLayout",
  __ssrInlineRender: true,
  setup(__props) {
    const page = usePageData();
    const frontmatter = usePageFrontmatter();
    const site = useSiteData();
    const head = usePageHead();
    const headTitle = usePageHeadTitle();
    const pageLang = usePageLang();
    const routeLocale = useRouteLocale();
    const siteLocaleData = useSiteLocaleData();
    computed(() => page.value.frontmatter.cover);
    computed(() => page.value.frontmatter.coverfit || page.value.frontmatter["cover-fit"] || "100% auto");
    onMounted(() => {
      console.log("1.page", page.value);
      console.log("2.site", site.value);
      console.log("3.head", head.value);
      console.log("4.frontmatter", frontmatter.value);
      console.log("5.headTitle", headTitle.value);
      console.log("6.pageLang", pageLang.value);
      console.log("7.routeLocale", routeLocale.value);
      console.log("8.siteLocaleData", siteLocaleData.value);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(Banner, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` 压屏通知 `);
          } else {
            return [
              createTextVNode(" 压屏通知 ")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(ssrRenderComponent(ParentLayout, null, {
        "page-top": withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h1 data-v-c1de9f97${_scopeId}>这是HomeLayout</h1>`);
          } else {
            return [
              createVNode("h1", null, "这是HomeLayout")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<div class="footer" data-v-c1de9f97>This is my custom page footer</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../layouts/HomeLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const clientConfig9 = defineClientConfig({
  enhance({ app, router, siteData: siteData2 }) {
    console.log(app, router, siteData2);
    app.use(ElementPlus, { zIndex: 3e3 });
    app.use(AppClient);
  },
  setup() {
    const count = ref(0);
    provide("count", count);
  },
  //组件数组，它们将会直接被放置在客户端 Vue 应用的根节点下。
  rootComponents: [],
  layouts: {
    // Layout, 
    // HomeLayout
  }
});
const clientConfigs = [
  clientConfig0,
  clientConfig1,
  clientConfig2,
  clientConfig3,
  clientConfig4,
  clientConfig5,
  clientConfig6,
  clientConfig7,
  clientConfig8,
  clientConfig9
];
const pagesRoutes = [
  ["v-7fdc6af1", "/markdown.html", { "title": "Markdown 样式模板" }, ["/markdown", "/markdown.md"]],
  ["v-8daa1a0e", "/", { "title": "Home" }, ["/index.html", "/README.md"]],
  ["v-077d91b9", "/user-profile.html", { "title": "" }, ["/user-profile", "/user-profile.md"]],
  ["v-18a03e64", "/guide/favorites.html", { "title": "收藏夹" }, ["/guide/favorites", "/guide/favorites.md"]],
  ["v-5efb549b", "/guide/frontend.html", { "title": "优秀学习资源" }, ["/guide/frontend", "/guide/frontend.md"]],
  ["v-fb0f0066", "/guide/getting-started.html", { "title": "vuepress 入门" }, ["/guide/getting-started", "/guide/getting-started.md"]],
  ["v-fffb8e28", "/guide/", { "title": "Home" }, ["/guide/index.html", "/guide/README.md"]],
  ["v-e572ed46", "/guide/website-learning.html", { "title": "Vue 学习资源收藏" }, ["/guide/website-learning", "/guide/website-learning.md"]],
  ["v-2b0c4e6d", "/guide/website-resource.html", { "title": "开发工具收藏" }, ["/guide/website-resource", "/guide/website-resource.md"]],
  ["v-51ef0801", "/poetry/", { "title": "" }, ["/poetry/index.html", "/poetry/README.md"]],
  ["v-ce4ba1b2", "/guide/html5/css.html", { "title": "CSS 使用笔记" }, ["/guide/html5/css", "/guide/html5/css.md"]],
  ["v-03666af8", "/guide/html5/emoji.html", { "title": "" }, ["/guide/html5/emoji", "/guide/html5/emoji.md"]],
  ["v-310216c0", "/guide/html5/linefeed-br-transform.html", { "title": "\\n 和 <br/> 互转" }, ["/guide/html5/linefeed-br-transform", "/guide/html5/linefeed-br-transform.md"]],
  ["v-1f4e1b24", "/guide/html5/mobile-adapter.html", { "title": "移动端适配处理" }, ["/guide/html5/mobile-adapter", "/guide/html5/mobile-adapter.md"]],
  ["v-4c3bff06", "/guide/html5/print.html", { "title": "Web打印处理" }, ["/guide/html5/print", "/guide/html5/print.md"]],
  ["v-6076b11e", "/guide/html5/", { "title": "" }, ["/guide/html5/index.html", "/guide/html5/README.md"]],
  ["v-d41799ba", "/guide/html5/regex.html", { "title": "常用正则表达语句" }, ["/guide/html5/regex", "/guide/html5/regex.md"]],
  ["v-293597cc", "/guide/html5/sass.html", { "title": "Sass 使用笔记" }, ["/guide/html5/sass", "/guide/html5/sass.md"]],
  ["v-665b7688", "/guide/html5/url-decode.html", { "title": "url 编解码" }, ["/guide/html5/url-decode", "/guide/html5/url-decode.md"]],
  ["v-5ce3212b", "/guide/html5/window-event.html", { "title": "window 浏览器页面事件" }, ["/guide/html5/window-event", "/guide/html5/window-event.md"]],
  ["v-39fd5df5", "/guide/interview/js-basic.html", { "title": "JavaScript 知识点" }, ["/guide/interview/js-basic", "/guide/interview/js-basic.md"]],
  ["v-729a0053", "/guide/javascript/async.html", { "title": "async" }, ["/guide/javascript/async", "/guide/javascript/async.md"]],
  ["v-4cbb61f8", "/guide/javascript/date-by-week.html", { "title": "日月周时间段处理" }, ["/guide/javascript/date-by-week", "/guide/javascript/date-by-week.md"]],
  ["v-7b50b952", "/guide/javascript/download-cros-file.html", { "title": "js跨域资源下载" }, ["/guide/javascript/download-cros-file", "/guide/javascript/download-cros-file.md"]],
  ["v-01eb0886", "/guide/javascript/es6-basic.html", { "title": "ES6 学习笔记" }, ["/guide/javascript/es6-basic", "/guide/javascript/es6-basic.md"]],
  ["v-aea6c5e2", "/guide/javascript/javascript-address.html", { "title": "省市区联动" }, ["/guide/javascript/javascript-address", "/guide/javascript/javascript-address.md"]],
  ["v-fd023f6c", "/guide/javascript/javascript-array.html", { "title": "数组 Array" }, ["/guide/javascript/javascript-array", "/guide/javascript/javascript-array.md"]],
  ["v-3b2cbbd9", "/guide/javascript/javascript-binary-tree.html", { "title": "JavaScript 二叉树" }, ["/guide/javascript/javascript-binary-tree", "/guide/javascript/javascript-binary-tree.md"]],
  ["v-187048e6", "/guide/javascript/javascript-moment-js.html", { "title": "Moment.js" }, ["/guide/javascript/javascript-moment-js", "/guide/javascript/javascript-moment-js.md"]],
  ["v-b12bee54", "/guide/javascript/javascript.html", { "title": "JavaScript 基础" }, ["/guide/javascript/javascript", "/guide/javascript/javascript.md"]],
  ["v-793e4222", "/guide/javascript/lodash-array.html", { "title": "lodash 数组 Array" }, ["/guide/javascript/lodash-array", "/guide/javascript/lodash-array.md"]],
  ["v-20db5239", "/guide/javascript/lodash-collection.html", { "title": "Lodash 集合 Collection" }, ["/guide/javascript/lodash-collection", "/guide/javascript/lodash-collection.md"]],
  ["v-0e480e82", "/guide/javascript/lodash-function.html", { "title": "Lodash 函数 Function" }, ["/guide/javascript/lodash-function", "/guide/javascript/lodash-function.md"]],
  ["v-3e3c917f", "/guide/javascript/lodash-map.html", { "title": "Lodash 对象 Map" }, ["/guide/javascript/lodash-map", "/guide/javascript/lodash-map.md"]],
  ["v-869e1ae2", "/guide/javascript/lodash-math.html", { "title": "Lodash 数学 Math" }, ["/guide/javascript/lodash-math", "/guide/javascript/lodash-math.md"]],
  ["v-2736b124", "/guide/javascript/lodash-number.html", { "title": "Lodash 数字 Number" }, ["/guide/javascript/lodash-number", "/guide/javascript/lodash-number.md"]],
  ["v-fa5d3748", "/guide/javascript/lodash-seq.html", { "title": "Lodash  Seq" }, ["/guide/javascript/lodash-seq", "/guide/javascript/lodash-seq.md"]],
  ["v-6663dfa6", "/guide/javascript/lodash-string.html", { "title": "Lodash 字符串处理 String" }, ["/guide/javascript/lodash-string", "/guide/javascript/lodash-string.md"]],
  ["v-4c40daca", "/guide/javascript/lodash-utils.html", { "title": "Lodash 实用函数 Utils" }, ["/guide/javascript/lodash-utils", "/guide/javascript/lodash-utils.md"]],
  ["v-6afd4071", "/guide/linux/docker-basic.html", { "title": "Docker 基本入门" }, ["/guide/linux/docker-basic", "/guide/linux/docker-basic.md"]],
  ["v-0b009929", "/guide/linux/go-basic.html", { "title": "Go 基本入门" }, ["/guide/linux/go-basic", "/guide/linux/go-basic.md"]],
  ["v-12734c1a", "/guide/linux/ubuntu-config-git.html", { "title": "Ubuntu 配置 git" }, ["/guide/linux/ubuntu-config-git", "/guide/linux/ubuntu-config-git.md"]],
  ["v-775863b0", "/guide/linux/version.html", { "title": "版本发布命名" }, ["/guide/linux/version", "/guide/linux/version.md"]],
  ["v-190bb819", "/guide/linux/vscode-guide.html", { "title": "vscode 前端常用配置" }, ["/guide/linux/vscode-guide", "/guide/linux/vscode-guide.md"]],
  ["v-0482165c", "/guide/nodejs/ffmpeg.html", { "title": "ffmpeg 使用笔记" }, ["/guide/nodejs/ffmpeg", "/guide/nodejs/ffmpeg.md"]],
  ["v-1b64d3b9", "/guide/nodejs/inquirer.js.html", { "title": "inquirer.js 命令行询问任务" }, ["/guide/nodejs/inquirer.js", "/guide/nodejs/inquirer.js.md"]],
  ["v-13af5c88", "/guide/nodejs/nodejs-install.html", { "title": "Nodejs 安装" }, ["/guide/nodejs/nodejs-install", "/guide/nodejs/nodejs-install.md"]],
  ["v-2b0cba16", "/guide/nodejs/publish-project-to-npm.html", { "title": "发布代码到npm库" }, ["/guide/nodejs/publish-project-to-npm", "/guide/nodejs/publish-project-to-npm.md"]],
  ["v-5ffcac0a", "/guide/nodejs/rsa-symmetric-encryption.html", { "title": "RSA加密与解密(js-encrypt)" }, ["/guide/nodejs/rsa-symmetric-encryption", "/guide/nodejs/rsa-symmetric-encryption.md"]],
  ["v-58efd6f6", "/guide/other/%E4%B8%8B%E8%BD%BDbilibili%E8%A7%86%E9%A2%91.html", { "title": "下载哔哩哔哩视频" }, ["/guide/other/下载bilibili视频.html", "/guide/other/%E4%B8%8B%E8%BD%BDbilibili%E8%A7%86%E9%A2%91", "/guide/other/下载bilibili视频.md", "/guide/other/%E4%B8%8B%E8%BD%BDbilibili%E8%A7%86%E9%A2%91.md"]],
  ["v-5b5ac426", "/guide/typescript/get-started.html", { "title": "快速开始" }, ["/guide/typescript/get-started", "/guide/typescript/get-started.md"]],
  ["v-bfca68de", "/guide/vue/nuxt-study-notes.html", { "title": "Nuxt" }, ["/guide/vue/nuxt-study-notes", "/guide/vue/nuxt-study-notes.md"]],
  ["v-5d496b56", "/guide/vue/", { "title": "Home" }, ["/guide/vue/index.html", "/guide/vue/README.md"]],
  ["v-b6962bfa", "/guide/vue/reference.html", { "title": "Vue3" }, ["/guide/vue/reference", "/guide/vue/reference.md"]],
  ["v-265c7da7", "/guide/vue/vue-basic.html", { "title": "Vue 知识点总结" }, ["/guide/vue/vue-basic", "/guide/vue/vue-basic.md"]],
  ["v-b7f1fa8a", "/guide/vue/vue-event.html", { "title": "Vue Event" }, ["/guide/vue/vue-event", "/guide/vue/vue-event.md"]],
  ["v-325908e8", "/guide/vue/vue-model.html", { "title": "Vue v-model" }, ["/guide/vue/vue-model", "/guide/vue/vue-model.md"]],
  ["v-490081a5", "/guide/vue/vue-props.html", { "title": "Vue props 对象" }, ["/guide/vue/vue-props", "/guide/vue/vue-props.md"]],
  ["v-43e0e56d", "/guide/vue/vue3-composition-api.html", { "title": "Vue3 组合式API(Composition API)" }, ["/guide/vue/vue3-composition-api", "/guide/vue/vue3-composition-api.md"]],
  ["v-4f9a6732", "/guide/vue/vue3-study-notes.html", { "title": "Vue3 学习笔记" }, ["/guide/vue/vue3-study-notes", "/guide/vue/vue3-study-notes.md"]],
  ["v-281db8d6", "/guide/webrtc/", { "title": "WebRTC 媒体服务" }, ["/guide/webrtc/index.html", "/guide/webrtc/readme.md"]],
  ["v-025b70c8", "/guide/vue/hooks/timer.html", { "title": "常用钩子合集" }, ["/guide/vue/hooks/timer", "/guide/vue/hooks/timer.md"]],
  ["v-3706649a", "/404.html", { "title": "" }, ["/404"]]
];
var Vuepress = defineComponent({
  name: "Vuepress",
  setup() {
    const layout = usePageLayout();
    return () => h(layout.value);
  }
});
var createRoutes = () => pagesRoutes.reduce(
  (result, [name, path, meta, redirects]) => {
    result.push(
      {
        name,
        path,
        component: Vuepress,
        meta
      },
      ...redirects.map((item) => ({
        path: item,
        redirect: path
      }))
    );
    return result;
  },
  [
    {
      name: "404",
      path: "/:catchAll(.*)",
      component: Vuepress
    }
  ]
);
var historyCreator = createMemoryHistory;
var createVueRouter = () => {
  const router = createRouter({
    history: historyCreator(removeEndingSlash("/")),
    routes: createRoutes(),
    scrollBehavior: (to, from, savedPosition) => {
      if (savedPosition)
        return savedPosition;
      if (to.hash)
        return { el: to.hash };
      return { top: 0 };
    }
  });
  router.beforeResolve(async (to, from) => {
    var _a;
    if (to.path !== from.path || from === START_LOCATION) {
      [pageData.value] = await Promise.all([
        resolvers.resolvePageData(to.name),
        (_a = pagesComponents[to.name]) == null ? void 0 : _a.__asyncLoader()
      ]);
    }
  });
  return router;
};
var setupGlobalComponents = (app) => {
  app.component("ClientOnly", ClientOnly);
  app.component("Content", Content);
};
var setupGlobalComputed = (app, router, clientConfigs2) => {
  const layouts = computed(() => resolvers.resolveLayouts(clientConfigs2));
  const routeLocale = computed(
    () => resolvers.resolveRouteLocale(
      siteData.value.locales,
      router.currentRoute.value.path
    )
  );
  const siteLocaleData = computed(
    () => resolvers.resolveSiteLocaleData(siteData.value, routeLocale.value)
  );
  const pageFrontmatter = computed(
    () => resolvers.resolvePageFrontmatter(pageData.value)
  );
  const pageHeadTitle = computed(
    () => resolvers.resolvePageHeadTitle(pageData.value, siteLocaleData.value)
  );
  const pageHead = computed(
    () => resolvers.resolvePageHead(
      pageHeadTitle.value,
      pageFrontmatter.value,
      siteLocaleData.value
    )
  );
  const pageLang = computed(() => resolvers.resolvePageLang(pageData.value));
  const pageLayout = computed(
    () => resolvers.resolvePageLayout(pageData.value, layouts.value)
  );
  app.provide(layoutsSymbol, layouts);
  app.provide(pageFrontmatterSymbol, pageFrontmatter);
  app.provide(pageHeadTitleSymbol, pageHeadTitle);
  app.provide(pageHeadSymbol, pageHead);
  app.provide(pageLangSymbol, pageLang);
  app.provide(pageLayoutSymbol, pageLayout);
  app.provide(routeLocaleSymbol, routeLocale);
  app.provide(siteLocaleDataSymbol, siteLocaleData);
  Object.defineProperties(app.config.globalProperties, {
    $frontmatter: { get: () => pageFrontmatter.value },
    $head: { get: () => pageHead.value },
    $headTitle: { get: () => pageHeadTitle.value },
    $lang: { get: () => pageLang.value },
    $page: { get: () => pageData.value },
    $routeLocale: { get: () => routeLocale.value },
    $site: { get: () => siteData.value },
    $siteLocale: { get: () => siteLocaleData.value },
    $withBase: { get: () => withBase }
  });
  return {
    layouts,
    pageData,
    pageFrontmatter,
    pageHead,
    pageHeadTitle,
    pageLang,
    pageLayout,
    routeLocale,
    siteData,
    siteLocaleData
  };
};
var setupUpdateHead = () => {
  useRoute();
  const head = usePageHead();
  const lang = usePageLang();
  {
    const ssrContext = useSSRContext();
    if (ssrContext) {
      ssrContext.head = head.value;
      ssrContext.lang = lang.value;
    }
    return;
  }
};
var appCreator = createSSRApp;
var createVueApp = async () => {
  var _a;
  const app = appCreator({
    name: "VuepressApp",
    setup() {
      var _a2;
      setupUpdateHead();
      for (const clientConfig of clientConfigs) {
        (_a2 = clientConfig.setup) == null ? void 0 : _a2.call(clientConfig);
      }
      return () => [
        h(RouterView),
        ...clientConfigs.flatMap(
          ({ rootComponents = [] }) => rootComponents.map((component) => h(component))
        )
      ];
    }
  });
  const router = createVueRouter();
  setupGlobalComponents(app);
  const globalComputed = setupGlobalComputed(app, router, clientConfigs);
  {
    const { setupDevtools } = await import("./assets/setupDevtools-EXVHPMXB-dad280e0.mjs");
    setupDevtools(app, globalComputed);
  }
  for (const clientConfig of clientConfigs) {
    await ((_a = clientConfig.enhance) == null ? void 0 : _a.call(clientConfig, { app, router, siteData }));
  }
  app.use(router);
  return {
    app,
    router
  };
};
export {
  _export_sfc as _,
  createVueApp
};
