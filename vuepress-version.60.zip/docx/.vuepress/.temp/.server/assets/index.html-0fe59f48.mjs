import { reactive, ref, defineComponent, resolveComponent, unref, withCtx, createTextVNode, createVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "../app.f81e19e5.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const useDevices = () => {
  const list = reactive([]);
  const audioInput = reactive([]);
  const audioOutput = reactive([]);
  const videoInput = reactive([]);
  const error = ref("");
  const gotDevices = (deviceInfos) => {
    list.splice(0, list.length, ...deviceInfos);
    audioInput.splice(0, audioInput.length, ...deviceInfos.filter((device) => device.kind === "audioinput"));
    audioOutput.splice(0, audioOutput.length, ...deviceInfos.filter((device) => device.kind === "audiooutput"));
    videoInput.splice(0, videoInput.length, ...deviceInfos.filter((device) => device.kind === "videoinput"));
  };
  const handleError = (err) => {
    console.log(err);
    error.value = err;
  };
  const playback = (videoElement, deviceId) => {
    console.log(
      "videoElement",
      deviceId,
      videoElement.sinkId,
      typeof videoElement.sinkId
    );
    if (typeof videoElement.sinkId !== "undefined") {
      videoElement.setSinkId(deviceId).then(() => {
        console.log(`Success, audio output device attached: ${deviceId}`);
      }).catch((error2) => {
        let errorMessage = error2;
        if (error2.name === "SecurityError") {
          errorMessage = `You need to use HTTPS for selecting audio output device: ${error2}`;
        }
        console.error(errorMessage);
      });
    } else {
      console.warn("Browser does not support output device selection.");
    }
  };
  navigator.mediaDevices.enumerateDevices().then(gotDevices).catch(handleError);
  return { list, audioInput, audioOutput, videoInput, playback };
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index.html",
  __ssrInlineRender: true,
  setup(__props) {
    const { list, audioInput, audioOutput, videoInput, playback } = useDevices();
    const url = ref("");
    const videoElement = ref(null);
    const changeDevice = (device) => {
      if (device.kind === "audiooutput") {
        playback(videoElement.value, device.deviceId);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_URLInput = resolveComponent("URLInput");
      const _component_el_table = resolveComponent("el-table");
      const _component_el_table_column = resolveComponent("el-table-column");
      const _component_el_button = resolveComponent("el-button");
      _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="webrtc-媒体服务" tabindex="-1"><a class="header-anchor" href="#webrtc-媒体服务" aria-hidden="true">#</a> WebRTC 媒体服务</h1><h1 id="获取设备列表" tabindex="-1"><a class="header-anchor" href="#获取设备列表" aria-hidden="true">#</a> 获取设备列表</h1><p>使用以下代码获取设备列表</p><p>${ssrInterpolate(url.value)}</p>`);
      _push(ssrRenderComponent(_component_URLInput, {
        modelValue: url.value,
        "onUpdate:modelValue": ($event) => url.value = $event,
        list: _ctx.$videoList
      }, null, _parent));
      _push(`<p><video class="video-item"${ssrRenderAttr("src", url.value)} controls loop autoplay></video></p>`);
      _push(ssrRenderComponent(_component_el_table, {
        data: unref(list),
        width: "100%"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_el_table_column, {
              prop: "label",
              label: "名称"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_table_column, {
              prop: "kind",
              label: "类型"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_table_column, {
              prop: "deviceId",
              label: "设备ID"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_table_column, { label: "操作" }, {
              default: withCtx((scope, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_el_button, {
                    type: "danger",
                    onClick: ($event) => changeDevice(scope.row)
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`选择`);
                      } else {
                        return [
                          createTextVNode("选择")
                        ];
                      }
                    }),
                    _: 2
                    /* DYNAMIC */
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_el_button, {
                      type: "danger",
                      onClick: ($event) => changeDevice(scope.row)
                    }, {
                      default: withCtx(() => [
                        createTextVNode("选择")
                      ]),
                      _: 2
                      /* DYNAMIC */
                    }, 1032, ["onClick"])
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_el_table_column, {
                prop: "label",
                label: "名称"
              }),
              createVNode(_component_el_table_column, {
                prop: "kind",
                label: "类型"
              }),
              createVNode(_component_el_table_column, {
                prop: "deviceId",
                label: "设备ID"
              }),
              createVNode(_component_el_table_column, { label: "操作" }, {
                default: withCtx((scope) => [
                  createVNode(_component_el_button, {
                    type: "danger",
                    onClick: ($event) => changeDevice(scope.row)
                  }, {
                    default: withCtx(() => [
                      createTextVNode("选择")
                    ]),
                    _: 2
                    /* DYNAMIC */
                  }, 1032, ["onClick"])
                ]),
                _: 1
                /* STABLE */
              })
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/webrtc/index.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["__file", "index.html.vue"]]);
export {
  index_html as default
};
