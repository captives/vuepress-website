import { ssrRenderAttrs } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "../app.5d58a35b.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="es6-学习笔记" tabindex="-1"><a class="header-anchor" href="#es6-学习笔记" aria-hidden="true">#</a> ES6 学习笔记</h1><h2 id="符号" tabindex="-1"><a class="header-anchor" href="#符号" aria-hidden="true">#</a> 符号</h2><ul><li><code>@</code> at</li><li><code>|</code> or</li><li><code>&amp;</code> and</li><li><code>.</code> dot</li><li><code>/</code> divide, slash</li><li><code>\\</code> backslash</li><li><code>-</code> dash, minus(减号/负号)</li><li><code>+</code> plus</li><li><code>*</code> multiply,asterisk</li><li><code>=</code> equal</li><li><code>?</code> question mark</li><li><code>!</code> exclamation</li><li><code>:</code> colon</li><li><code>...</code> ellipsis</li><li><code>_</code> underline</li><li><code>,</code> comma</li><li><code>^</code> caret</li><li><code>~</code> tilde</li><li><code>()</code> bracket</li><li><code>[]</code> square bracket</li></ul><h2 id="运算符" tabindex="-1"><a class="header-anchor" href="#运算符" aria-hidden="true">#</a> 运算符</h2><h3 id="按位取反运算符" tabindex="-1"><a class="header-anchor" href="#按位取反运算符" aria-hidden="true">#</a> 按位取反运算符<code>~</code></h3><ul><li><code>~[string | number| null | undefined]</code></li></ul><p>示例：</p><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code><span class="token operator">~</span><span class="token string">&#39;a&#39;</span>			<span class="token comment">//0</span>
<span class="token operator">~</span><span class="token keyword">null</span>			<span class="token comment">//0</span>
<span class="token operator">~</span><span class="token keyword">undefined</span>		<span class="token comment">//0</span>
<span class="token operator">~</span><span class="token number">0</span>				<span class="token comment">//-1</span>
<span class="token operator">~</span><span class="token operator">~</span><span class="token number">0</span>				<span class="token comment">//0</span>
<span class="token operator">~</span><span class="token number">1.555555</span> 		<span class="token comment">// -1</span>
<span class="token operator">~</span><span class="token operator">-</span><span class="token number">1.555555</span> 		<span class="token comment">// 1;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="求幂表达式" tabindex="-1"><a class="header-anchor" href="#求幂表达式" aria-hidden="true">#</a> 求幂表达式 <code>**</code></h3><p>返回基数<code>base</code>的指数<code>exponent</code>次幂,等价于<code>Math.pow(base, exponent)</code>：</p><ul><li><code>base**exponent === Math.pow(base, exponent)</code></li></ul><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code><span class="token number">2</span><span class="token operator">**</span><span class="token number">2</span>		<span class="token comment">//4</span>
<span class="token number">2</span><span class="token operator">**</span><span class="token number">3</span>		<span class="token comment">//8</span>
<span class="token number">2</span><span class="token operator">**</span><span class="token number">10</span>		<span class="token comment">//1024</span>

<span class="token punctuation">(</span><span class="token operator">-</span><span class="token number">3</span><span class="token punctuation">)</span><span class="token operator">**</span><span class="token number">2</span>		<span class="token comment">// 9</span>
<span class="token punctuation">(</span><span class="token operator">-</span><span class="token number">3</span><span class="token punctuation">)</span><span class="token operator">**</span><span class="token number">3</span>		<span class="token comment">// -27</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="var-let-const" tabindex="-1"><a class="header-anchor" href="#var-let-const" aria-hidden="true">#</a> var/let/const</h2><p><code>var</code>命令会发生“变量提升”现象，即变量可以在声明之前使用，值为<code>undefined</code>。</p><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code><span class="token comment">// var 的情况</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>foo<span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// 输出undefined</span>
<span class="token keyword">var</span> foo <span class="token operator">=</span> <span class="token number">2</span><span class="token punctuation">;</span>

<span class="token comment">// let 的情况</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>bar<span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// 报错ReferenceError</span>
<span class="token keyword">let</span> bar <span class="token operator">=</span> <span class="token number">2</span><span class="token punctuation">;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>如果使用<code>let</code>，声明的变量仅在块级作用域<code>{}</code>内有效, 且不允许在相同作用域内，重复声明同一个变量。</p><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code><span class="token keyword">for</span> <span class="token punctuation">(</span><span class="token keyword">var</span> i <span class="token operator">=</span> <span class="token number">0</span><span class="token punctuation">;</span> i <span class="token operator">&lt;</span> <span class="token number">10</span><span class="token punctuation">;</span> i<span class="token operator">++</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
    <span class="token function">setTimeout</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token operator">=&gt;</span><span class="token punctuation">{</span>
        console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">&#39;i = &#39;</span><span class="token punctuation">,</span> i<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token comment">// 9, 9, 9, 9, 9, 9, 9, 9, 9, 9</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code><span class="token keyword">for</span> <span class="token punctuation">(</span><span class="token keyword">let</span> i <span class="token operator">=</span> <span class="token number">0</span><span class="token punctuation">;</span> i <span class="token operator">&lt;</span> <span class="token number">10</span><span class="token punctuation">;</span> i<span class="token operator">++</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
    <span class="token function">setTimeout</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token operator">=&gt;</span><span class="token punctuation">{</span>
        console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">&#39;i = &#39;</span><span class="token punctuation">,</span> i<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
<span class="token comment">// 0, 1, 2, 3, 4, 5, 6, 7, 8, 9</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><code>const</code>是只读常量，一旦赋值，将不能更改；但对象可以更改对象的属性。</p><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code><span class="token keyword">const</span> a <span class="token operator">=</span> <span class="token number">5</span><span class="token punctuation">;</span>
a <span class="token operator">=</span> <span class="token number">6</span><span class="token punctuation">;</span> <span class="token comment">//error</span>

<span class="token keyword">const</span> a <span class="token operator">=</span> <span class="token punctuation">{</span> <span class="token literal-property property">a</span><span class="token operator">:</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token literal-property property">b</span><span class="token operator">:</span><span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">;</span>
a <span class="token operator">=</span> <span class="token punctuation">{</span> <span class="token literal-property property">c</span><span class="token operator">:</span><span class="token number">22</span> <span class="token punctuation">}</span><span class="token punctuation">;</span><span class="token comment">//error</span>
a<span class="token punctuation">.</span>a <span class="token operator">=</span> <span class="token number">3</span> <span class="token comment">//a = 3</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="对象解构" tabindex="-1"><a class="header-anchor" href="#对象解构" aria-hidden="true">#</a> 对象解构</h2></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/javascript/es6-basic.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const es6Basic_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "es6-basic.html.vue"]]);
export {
  es6Basic_html as default
};
