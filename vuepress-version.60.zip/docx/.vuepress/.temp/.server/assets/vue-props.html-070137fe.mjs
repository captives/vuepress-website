const data = JSON.parse('{"key":"v-490081a5","path":"/guide/vue/vue-props.html","title":"Vue props 对象","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"Vue props 对象","slug":"vue-props-对象","link":"#vue-props-对象","children":[]}],"git":{},"filePathRelative":"guide/vue/vue-props.md"}');
export {
  data
};
