import { defineComponent, defineAsyncComponent, ref, reactive, computed, provide, resolveComponent, withCtx, unref, isRef, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, createVNode, mergeProps, createCommentVNode, resolveDynamicComponent, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderVNode } from "vue/server-renderer";
import { _ as _export_sfc } from "../app.f81e19e5.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Component",
  __ssrInlineRender: true,
  setup(__props) {
    let list = [
      { label: "组件A", item: defineAsyncComponent(() => import("./ItemA-4937c682.mjs")) },
      { label: "组件B", item: defineAsyncComponent(() => import("./ItemB-e8d9a43c.mjs")) },
      { label: "组件C", item: defineAsyncComponent(() => import("./ItemC-7b32c682.mjs")) },
      { label: "组件D", item: defineAsyncComponent(() => import("./ItemD-a49ff4a1.mjs")) },
      { label: "组件E", item: defineAsyncComponent(() => import("./ItemE-2a327e91.mjs")) }
    ];
    let seasons = [
      { label: "春天", code: "Spring", value: "1" },
      { label: "夏天", code: "Summer ", value: "2" },
      { label: "秋天", code: "Autumn", value: "3" },
      { label: "冬天", code: "Winter", value: "4" }
    ];
    let selectTabIndex = ref(1);
    let tabIndex = ref(0);
    let selectSeason = ref();
    let selectSeasonValue = ref();
    let selectValue = ref();
    let form = reactive({ likes: [], date: new Date() });
    let solarTerms = [
      "立春",
      "雨水",
      "惊蛰",
      "春分",
      "清明",
      "谷雨",
      "立夏",
      "小满",
      "芒种",
      "夏至",
      "小暑",
      "大暑",
      "立秋",
      "处暑",
      "白露",
      "秋分",
      "寒露",
      "霜降",
      "立冬",
      "小雪",
      "大雪",
      "冬至",
      "小寒",
      "大寒"
    ];
    const currentTabItem = computed(() => list[tabIndex.value]);
    provide("solarTerms", solarTerms);
    provide("season", selectSeason);
    const tabChangeHandler = (value = 0) => {
      if (value != -1) {
        tabIndex.value = value;
      } else {
        tabIndex.value = tabIndex.value == list.length - 1 ? 0 : tabIndex.value + 1;
      }
    };
    const seasonChangeHandler = (label) => {
      selectSeason.value = seasons.find((item) => item.label === label);
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_row = resolveComponent("el-row");
      const _component_el_col = resolveComponent("el-col");
      const _component_el_form = resolveComponent("el-form");
      const _component_el_form_item = resolveComponent("el-form-item");
      const _component_el_radio_group = resolveComponent("el-radio-group");
      const _component_el_radio_button = resolveComponent("el-radio-button");
      const _component_el_date_picker = resolveComponent("el-date-picker");
      const _component_el_checkbox_group = resolveComponent("el-checkbox-group");
      const _component_el_checkbox = resolveComponent("el-checkbox");
      const _component_el_radio = resolveComponent("el-radio");
      _push(ssrRenderComponent(_component_el_row, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_el_col, {
              span: 24,
              md: 10
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_el_form, {
                    model: unref(form),
                    "label-width": "90px"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_el_form_item, { label: "组件" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_el_radio_group, {
                                modelValue: unref(selectTabIndex),
                                "onUpdate:modelValue": [($event) => isRef(selectTabIndex) ? selectTabIndex.value = $event : selectTabIndex = $event, tabChangeHandler]
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<!--[-->`);
                                    ssrRenderList(unref(list), (item, index) => {
                                      _push6(ssrRenderComponent(_component_el_radio_button, {
                                        key: index,
                                        label: index
                                      }, {
                                        default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(`${ssrInterpolate(item.label)}`);
                                          } else {
                                            return [
                                              createTextVNode(
                                                toDisplayString(item.label),
                                                1
                                                /* TEXT */
                                              )
                                            ];
                                          }
                                        }),
                                        _: 2
                                        /* DYNAMIC */
                                      }, _parent6, _scopeId5));
                                    });
                                    _push6(`<!--]-->`);
                                    _push6(ssrRenderComponent(_component_el_radio_button, { label: -1 }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`${ssrInterpolate(unref(selectTabIndex) == unref(list).length - 1 ? "|<<" : ">>")}`);
                                        } else {
                                          return [
                                            createTextVNode(
                                              toDisplayString(unref(selectTabIndex) == unref(list).length - 1 ? "|<<" : ">>"),
                                              1
                                              /* TEXT */
                                            )
                                          ];
                                        }
                                      }),
                                      _: 1
                                      /* STABLE */
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      (openBlock(true), createBlock(
                                        Fragment,
                                        null,
                                        renderList(unref(list), (item, index) => {
                                          return openBlock(), createBlock(_component_el_radio_button, {
                                            key: index,
                                            label: index
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(
                                                toDisplayString(item.label),
                                                1
                                                /* TEXT */
                                              )
                                            ]),
                                            _: 2
                                            /* DYNAMIC */
                                          }, 1032, ["label"]);
                                        }),
                                        128
                                        /* KEYED_FRAGMENT */
                                      )),
                                      createVNode(_component_el_radio_button, { label: -1 }, {
                                        default: withCtx(() => [
                                          createTextVNode(
                                            toDisplayString(unref(selectTabIndex) == unref(list).length - 1 ? "|<<" : ">>"),
                                            1
                                            /* TEXT */
                                          )
                                        ]),
                                        _: 1
                                        /* STABLE */
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                                /* STABLE */
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_el_radio_group, {
                                  modelValue: unref(selectTabIndex),
                                  "onUpdate:modelValue": [($event) => isRef(selectTabIndex) ? selectTabIndex.value = $event : selectTabIndex = $event, tabChangeHandler]
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(
                                      Fragment,
                                      null,
                                      renderList(unref(list), (item, index) => {
                                        return openBlock(), createBlock(_component_el_radio_button, {
                                          key: index,
                                          label: index
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(
                                              toDisplayString(item.label),
                                              1
                                              /* TEXT */
                                            )
                                          ]),
                                          _: 2
                                          /* DYNAMIC */
                                        }, 1032, ["label"]);
                                      }),
                                      128
                                      /* KEYED_FRAGMENT */
                                    )),
                                    createVNode(_component_el_radio_button, { label: -1 }, {
                                      default: withCtx(() => [
                                        createTextVNode(
                                          toDisplayString(unref(selectTabIndex) == unref(list).length - 1 ? "|<<" : ">>"),
                                          1
                                          /* TEXT */
                                        )
                                      ]),
                                      _: 1
                                      /* STABLE */
                                    })
                                  ]),
                                  _: 1
                                  /* STABLE */
                                }, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                          /* STABLE */
                        }, _parent4, _scopeId3));
                        _push4(`<!-- props 传输复杂对象 -->`);
                        _push4(ssrRenderComponent(_component_el_form_item, { label: "日期" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_el_date_picker, {
                                modelValue: unref(form).date,
                                "onUpdate:modelValue": ($event) => unref(form).date = $event,
                                type: "date",
                                placeholder: "请选择"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_el_date_picker, {
                                  modelValue: unref(form).date,
                                  "onUpdate:modelValue": ($event) => unref(form).date = $event,
                                  type: "date",
                                  placeholder: "请选择"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                          /* STABLE */
                        }, _parent4, _scopeId3));
                        _push4(`<!-- props传输数组 -->`);
                        _push4(ssrRenderComponent(_component_el_form_item, { label: "喜欢的节气" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_el_checkbox_group, {
                                modelValue: unref(form).likes,
                                "onUpdate:modelValue": ($event) => unref(form).likes = $event,
                                style: { "width": "300px" }
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<!--[-->`);
                                    ssrRenderList(unref(solarTerms), (item, index) => {
                                      _push6(ssrRenderComponent(_component_el_checkbox, {
                                        key: index,
                                        label: item,
                                        name: "type"
                                      }, null, _parent6, _scopeId5));
                                    });
                                    _push6(`<!--]-->`);
                                  } else {
                                    return [
                                      (openBlock(true), createBlock(
                                        Fragment,
                                        null,
                                        renderList(unref(solarTerms), (item, index) => {
                                          return openBlock(), createBlock(_component_el_checkbox, {
                                            key: index,
                                            label: item,
                                            name: "type"
                                          }, null, 8, ["label"]);
                                        }),
                                        128
                                        /* KEYED_FRAGMENT */
                                      ))
                                    ];
                                  }
                                }),
                                _: 1
                                /* STABLE */
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_el_checkbox_group, {
                                  modelValue: unref(form).likes,
                                  "onUpdate:modelValue": ($event) => unref(form).likes = $event,
                                  style: { "width": "300px" }
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(
                                      Fragment,
                                      null,
                                      renderList(unref(solarTerms), (item, index) => {
                                        return openBlock(), createBlock(_component_el_checkbox, {
                                          key: index,
                                          label: item,
                                          name: "type"
                                        }, null, 8, ["label"]);
                                      }),
                                      128
                                      /* KEYED_FRAGMENT */
                                    ))
                                  ]),
                                  _: 1
                                  /* STABLE */
                                }, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                          /* STABLE */
                        }, _parent4, _scopeId3));
                        _push4(`<!-- provide index/object 响应式数据 -->`);
                        _push4(ssrRenderComponent(_component_el_form_item, { label: "季节" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_el_radio_group, {
                                modelValue: unref(selectSeasonValue),
                                "onUpdate:modelValue": [($event) => isRef(selectSeasonValue) ? selectSeasonValue.value = $event : selectSeasonValue = $event, seasonChangeHandler],
                                placeholder: "请选择"
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<!--[-->`);
                                    ssrRenderList(unref(seasons), (item) => {
                                      _push6(ssrRenderComponent(_component_el_radio, mergeProps({
                                        key: item.code
                                      }, item), null, _parent6, _scopeId5));
                                    });
                                    _push6(`<!--]-->`);
                                  } else {
                                    return [
                                      (openBlock(true), createBlock(
                                        Fragment,
                                        null,
                                        renderList(unref(seasons), (item) => {
                                          return openBlock(), createBlock(
                                            _component_el_radio,
                                            mergeProps({
                                              key: item.code
                                            }, item),
                                            null,
                                            16
                                            /* FULL_PROPS */
                                          );
                                        }),
                                        128
                                        /* KEYED_FRAGMENT */
                                      ))
                                    ];
                                  }
                                }),
                                _: 1
                                /* STABLE */
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_el_radio_group, {
                                  modelValue: unref(selectSeasonValue),
                                  "onUpdate:modelValue": [($event) => isRef(selectSeasonValue) ? selectSeasonValue.value = $event : selectSeasonValue = $event, seasonChangeHandler],
                                  placeholder: "请选择"
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(
                                      Fragment,
                                      null,
                                      renderList(unref(seasons), (item) => {
                                        return openBlock(), createBlock(
                                          _component_el_radio,
                                          mergeProps({
                                            key: item.code
                                          }, item),
                                          null,
                                          16
                                          /* FULL_PROPS */
                                        );
                                      }),
                                      128
                                      /* KEYED_FRAGMENT */
                                    ))
                                  ]),
                                  _: 1
                                  /* STABLE */
                                }, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 1
                          /* STABLE */
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_el_form_item, { label: "选中的季节" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`${ssrInterpolate(unref(selectSeason))}`);
                            } else {
                              return [
                                createTextVNode(
                                  toDisplayString(unref(selectSeason)),
                                  1
                                  /* TEXT */
                                )
                              ];
                            }
                          }),
                          _: 1
                          /* STABLE */
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_el_form_item, { label: "选中的节气" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`${ssrInterpolate(unref(selectValue))}`);
                            } else {
                              return [
                                createTextVNode(
                                  toDisplayString(unref(selectValue)),
                                  1
                                  /* TEXT */
                                )
                              ];
                            }
                          }),
                          _: 1
                          /* STABLE */
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_el_form_item, { label: "组件" }, {
                            default: withCtx(() => [
                              createVNode(_component_el_radio_group, {
                                modelValue: unref(selectTabIndex),
                                "onUpdate:modelValue": [($event) => isRef(selectTabIndex) ? selectTabIndex.value = $event : selectTabIndex = $event, tabChangeHandler]
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(
                                    Fragment,
                                    null,
                                    renderList(unref(list), (item, index) => {
                                      return openBlock(), createBlock(_component_el_radio_button, {
                                        key: index,
                                        label: index
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(
                                            toDisplayString(item.label),
                                            1
                                            /* TEXT */
                                          )
                                        ]),
                                        _: 2
                                        /* DYNAMIC */
                                      }, 1032, ["label"]);
                                    }),
                                    128
                                    /* KEYED_FRAGMENT */
                                  )),
                                  createVNode(_component_el_radio_button, { label: -1 }, {
                                    default: withCtx(() => [
                                      createTextVNode(
                                        toDisplayString(unref(selectTabIndex) == unref(list).length - 1 ? "|<<" : ">>"),
                                        1
                                        /* TEXT */
                                      )
                                    ]),
                                    _: 1
                                    /* STABLE */
                                  })
                                ]),
                                _: 1
                                /* STABLE */
                              }, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                            /* STABLE */
                          }),
                          createCommentVNode(" props 传输复杂对象 "),
                          createVNode(_component_el_form_item, { label: "日期" }, {
                            default: withCtx(() => [
                              createVNode(_component_el_date_picker, {
                                modelValue: unref(form).date,
                                "onUpdate:modelValue": ($event) => unref(form).date = $event,
                                type: "date",
                                placeholder: "请选择"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                            /* STABLE */
                          }),
                          createCommentVNode(" props传输数组 "),
                          createVNode(_component_el_form_item, { label: "喜欢的节气" }, {
                            default: withCtx(() => [
                              createVNode(_component_el_checkbox_group, {
                                modelValue: unref(form).likes,
                                "onUpdate:modelValue": ($event) => unref(form).likes = $event,
                                style: { "width": "300px" }
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(
                                    Fragment,
                                    null,
                                    renderList(unref(solarTerms), (item, index) => {
                                      return openBlock(), createBlock(_component_el_checkbox, {
                                        key: index,
                                        label: item,
                                        name: "type"
                                      }, null, 8, ["label"]);
                                    }),
                                    128
                                    /* KEYED_FRAGMENT */
                                  ))
                                ]),
                                _: 1
                                /* STABLE */
                              }, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                            /* STABLE */
                          }),
                          createCommentVNode(" provide index/object 响应式数据 "),
                          createVNode(_component_el_form_item, { label: "季节" }, {
                            default: withCtx(() => [
                              createVNode(_component_el_radio_group, {
                                modelValue: unref(selectSeasonValue),
                                "onUpdate:modelValue": [($event) => isRef(selectSeasonValue) ? selectSeasonValue.value = $event : selectSeasonValue = $event, seasonChangeHandler],
                                placeholder: "请选择"
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(
                                    Fragment,
                                    null,
                                    renderList(unref(seasons), (item) => {
                                      return openBlock(), createBlock(
                                        _component_el_radio,
                                        mergeProps({
                                          key: item.code
                                        }, item),
                                        null,
                                        16
                                        /* FULL_PROPS */
                                      );
                                    }),
                                    128
                                    /* KEYED_FRAGMENT */
                                  ))
                                ]),
                                _: 1
                                /* STABLE */
                              }, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                            /* STABLE */
                          }),
                          createVNode(_component_el_form_item, { label: "选中的季节" }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(unref(selectSeason)),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }),
                          createVNode(_component_el_form_item, { label: "选中的节气" }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(unref(selectValue)),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          })
                        ];
                      }
                    }),
                    _: 1
                    /* STABLE */
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_el_form, {
                      model: unref(form),
                      "label-width": "90px"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_el_form_item, { label: "组件" }, {
                          default: withCtx(() => [
                            createVNode(_component_el_radio_group, {
                              modelValue: unref(selectTabIndex),
                              "onUpdate:modelValue": [($event) => isRef(selectTabIndex) ? selectTabIndex.value = $event : selectTabIndex = $event, tabChangeHandler]
                            }, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(
                                  Fragment,
                                  null,
                                  renderList(unref(list), (item, index) => {
                                    return openBlock(), createBlock(_component_el_radio_button, {
                                      key: index,
                                      label: index
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(
                                          toDisplayString(item.label),
                                          1
                                          /* TEXT */
                                        )
                                      ]),
                                      _: 2
                                      /* DYNAMIC */
                                    }, 1032, ["label"]);
                                  }),
                                  128
                                  /* KEYED_FRAGMENT */
                                )),
                                createVNode(_component_el_radio_button, { label: -1 }, {
                                  default: withCtx(() => [
                                    createTextVNode(
                                      toDisplayString(unref(selectTabIndex) == unref(list).length - 1 ? "|<<" : ">>"),
                                      1
                                      /* TEXT */
                                    )
                                  ]),
                                  _: 1
                                  /* STABLE */
                                })
                              ]),
                              _: 1
                              /* STABLE */
                            }, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                          /* STABLE */
                        }),
                        createCommentVNode(" props 传输复杂对象 "),
                        createVNode(_component_el_form_item, { label: "日期" }, {
                          default: withCtx(() => [
                            createVNode(_component_el_date_picker, {
                              modelValue: unref(form).date,
                              "onUpdate:modelValue": ($event) => unref(form).date = $event,
                              type: "date",
                              placeholder: "请选择"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                          /* STABLE */
                        }),
                        createCommentVNode(" props传输数组 "),
                        createVNode(_component_el_form_item, { label: "喜欢的节气" }, {
                          default: withCtx(() => [
                            createVNode(_component_el_checkbox_group, {
                              modelValue: unref(form).likes,
                              "onUpdate:modelValue": ($event) => unref(form).likes = $event,
                              style: { "width": "300px" }
                            }, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(
                                  Fragment,
                                  null,
                                  renderList(unref(solarTerms), (item, index) => {
                                    return openBlock(), createBlock(_component_el_checkbox, {
                                      key: index,
                                      label: item,
                                      name: "type"
                                    }, null, 8, ["label"]);
                                  }),
                                  128
                                  /* KEYED_FRAGMENT */
                                ))
                              ]),
                              _: 1
                              /* STABLE */
                            }, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                          /* STABLE */
                        }),
                        createCommentVNode(" provide index/object 响应式数据 "),
                        createVNode(_component_el_form_item, { label: "季节" }, {
                          default: withCtx(() => [
                            createVNode(_component_el_radio_group, {
                              modelValue: unref(selectSeasonValue),
                              "onUpdate:modelValue": [($event) => isRef(selectSeasonValue) ? selectSeasonValue.value = $event : selectSeasonValue = $event, seasonChangeHandler],
                              placeholder: "请选择"
                            }, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(
                                  Fragment,
                                  null,
                                  renderList(unref(seasons), (item) => {
                                    return openBlock(), createBlock(
                                      _component_el_radio,
                                      mergeProps({
                                        key: item.code
                                      }, item),
                                      null,
                                      16
                                      /* FULL_PROPS */
                                    );
                                  }),
                                  128
                                  /* KEYED_FRAGMENT */
                                ))
                              ]),
                              _: 1
                              /* STABLE */
                            }, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                          /* STABLE */
                        }),
                        createVNode(_component_el_form_item, { label: "选中的季节" }, {
                          default: withCtx(() => [
                            createTextVNode(
                              toDisplayString(unref(selectSeason)),
                              1
                              /* TEXT */
                            )
                          ]),
                          _: 1
                          /* STABLE */
                        }),
                        createVNode(_component_el_form_item, { label: "选中的节气" }, {
                          default: withCtx(() => [
                            createTextVNode(
                              toDisplayString(unref(selectValue)),
                              1
                              /* TEXT */
                            )
                          ]),
                          _: 1
                          /* STABLE */
                        })
                      ]),
                      _: 1
                      /* STABLE */
                    }, 8, ["model"])
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_col, {
              span: 24,
              md: 14
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  ssrRenderVNode(_push3, createVNode(resolveDynamicComponent(unref(currentTabItem).item), mergeProps(unref(form), {
                    modelValue: unref(selectValue),
                    "onUpdate:modelValue": ($event) => isRef(selectValue) ? selectValue.value = $event : selectValue = $event,
                    label: unref(currentTabItem).label
                  }), null), _parent3, _scopeId2);
                } else {
                  return [
                    (openBlock(), createBlock(resolveDynamicComponent(unref(currentTabItem).item), mergeProps(unref(form), {
                      modelValue: unref(selectValue),
                      "onUpdate:modelValue": ($event) => isRef(selectValue) ? selectValue.value = $event : selectValue = $event,
                      label: unref(currentTabItem).label
                    }), null, 16, ["modelValue", "onUpdate:modelValue", "label"]))
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_el_col, {
                span: 24,
                md: 10
              }, {
                default: withCtx(() => [
                  createVNode(_component_el_form, {
                    model: unref(form),
                    "label-width": "90px"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_el_form_item, { label: "组件" }, {
                        default: withCtx(() => [
                          createVNode(_component_el_radio_group, {
                            modelValue: unref(selectTabIndex),
                            "onUpdate:modelValue": [($event) => isRef(selectTabIndex) ? selectTabIndex.value = $event : selectTabIndex = $event, tabChangeHandler]
                          }, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(
                                Fragment,
                                null,
                                renderList(unref(list), (item, index) => {
                                  return openBlock(), createBlock(_component_el_radio_button, {
                                    key: index,
                                    label: index
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(
                                        toDisplayString(item.label),
                                        1
                                        /* TEXT */
                                      )
                                    ]),
                                    _: 2
                                    /* DYNAMIC */
                                  }, 1032, ["label"]);
                                }),
                                128
                                /* KEYED_FRAGMENT */
                              )),
                              createVNode(_component_el_radio_button, { label: -1 }, {
                                default: withCtx(() => [
                                  createTextVNode(
                                    toDisplayString(unref(selectTabIndex) == unref(list).length - 1 ? "|<<" : ">>"),
                                    1
                                    /* TEXT */
                                  )
                                ]),
                                _: 1
                                /* STABLE */
                              })
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                        /* STABLE */
                      }),
                      createCommentVNode(" props 传输复杂对象 "),
                      createVNode(_component_el_form_item, { label: "日期" }, {
                        default: withCtx(() => [
                          createVNode(_component_el_date_picker, {
                            modelValue: unref(form).date,
                            "onUpdate:modelValue": ($event) => unref(form).date = $event,
                            type: "date",
                            placeholder: "请选择"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                        /* STABLE */
                      }),
                      createCommentVNode(" props传输数组 "),
                      createVNode(_component_el_form_item, { label: "喜欢的节气" }, {
                        default: withCtx(() => [
                          createVNode(_component_el_checkbox_group, {
                            modelValue: unref(form).likes,
                            "onUpdate:modelValue": ($event) => unref(form).likes = $event,
                            style: { "width": "300px" }
                          }, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(
                                Fragment,
                                null,
                                renderList(unref(solarTerms), (item, index) => {
                                  return openBlock(), createBlock(_component_el_checkbox, {
                                    key: index,
                                    label: item,
                                    name: "type"
                                  }, null, 8, ["label"]);
                                }),
                                128
                                /* KEYED_FRAGMENT */
                              ))
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                        /* STABLE */
                      }),
                      createCommentVNode(" provide index/object 响应式数据 "),
                      createVNode(_component_el_form_item, { label: "季节" }, {
                        default: withCtx(() => [
                          createVNode(_component_el_radio_group, {
                            modelValue: unref(selectSeasonValue),
                            "onUpdate:modelValue": [($event) => isRef(selectSeasonValue) ? selectSeasonValue.value = $event : selectSeasonValue = $event, seasonChangeHandler],
                            placeholder: "请选择"
                          }, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(
                                Fragment,
                                null,
                                renderList(unref(seasons), (item) => {
                                  return openBlock(), createBlock(
                                    _component_el_radio,
                                    mergeProps({
                                      key: item.code
                                    }, item),
                                    null,
                                    16
                                    /* FULL_PROPS */
                                  );
                                }),
                                128
                                /* KEYED_FRAGMENT */
                              ))
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                        /* STABLE */
                      }),
                      createVNode(_component_el_form_item, { label: "选中的季节" }, {
                        default: withCtx(() => [
                          createTextVNode(
                            toDisplayString(unref(selectSeason)),
                            1
                            /* TEXT */
                          )
                        ]),
                        _: 1
                        /* STABLE */
                      }),
                      createVNode(_component_el_form_item, { label: "选中的节气" }, {
                        default: withCtx(() => [
                          createTextVNode(
                            toDisplayString(unref(selectValue)),
                            1
                            /* TEXT */
                          )
                        ]),
                        _: 1
                        /* STABLE */
                      })
                    ]),
                    _: 1
                    /* STABLE */
                  }, 8, ["model"])
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_el_col, {
                span: 24,
                md: 14
              }, {
                default: withCtx(() => [
                  (openBlock(), createBlock(resolveDynamicComponent(unref(currentTabItem).item), mergeProps(unref(form), {
                    modelValue: unref(selectValue),
                    "onUpdate:modelValue": ($event) => isRef(selectValue) ? selectValue.value = $event : selectValue = $event,
                    label: unref(currentTabItem).label
                  }), null, 16, ["modelValue", "onUpdate:modelValue", "label"]))
                ]),
                _: 1
                /* STABLE */
              })
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../src/pages/Component.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Component = /* @__PURE__ */ _export_sfc(_sfc_main, [["__file", "Component.vue"]]);
export {
  Component as default
};
