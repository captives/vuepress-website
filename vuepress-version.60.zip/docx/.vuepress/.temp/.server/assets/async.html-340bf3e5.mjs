const data = JSON.parse('{"key":"v-729a0053","path":"/guide/javascript/async.html","title":"async","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"async","slug":"async","link":"#async","children":[{"level":3,"title":"内容","slug":"内容","link":"#内容","children":[]},{"level":3,"title":"安装","slug":"安装","link":"#安装","children":[]},{"level":3,"title":"流程控制","slug":"流程控制","link":"#流程控制","children":[]},{"level":3,"title":"Collections集合","slug":"collections集合","link":"#collections集合","children":[]},{"level":3,"title":"mapValues","slug":"mapvalues","link":"#mapvalues","children":[]}]}],"git":{},"filePathRelative":"guide/javascript/async.md"}');
export {
  data
};
