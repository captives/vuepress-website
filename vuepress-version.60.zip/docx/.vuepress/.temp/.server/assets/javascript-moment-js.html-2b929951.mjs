const data = JSON.parse('{"key":"v-187048e6","path":"/guide/javascript/javascript-moment-js.html","title":"Moment.js","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"Moment.js","slug":"moment-js","link":"#moment-js","children":[{"level":2,"title":"日期格式化","slug":"日期格式化","link":"#日期格式化","children":[]},{"level":2,"title":"相对时间","slug":"相对时间","link":"#相对时间","children":[]},{"level":2,"title":"日历时间","slug":"日历时间","link":"#日历时间","children":[]},{"level":2,"title":"多语言支持","slug":"多语言支持","link":"#多语言支持","children":[]}]}],"git":{},"filePathRelative":"guide/javascript/javascript-moment-js.md"}');
export {
  data
};
