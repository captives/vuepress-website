const data = JSON.parse('{"key":"v-aea6c5e2","path":"/guide/javascript/javascript-address.html","title":"省市区联动","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"省市区联动","slug":"省市区联动","link":"#省市区联动","children":[{"level":2,"title":"省市区数据添加头[全部]","slug":"省市区数据添加头-全部","link":"#省市区数据添加头-全部","children":[]},{"level":2,"title":"省市区移除【全国/全部】项","slug":"省市区移除【全国-全部】项","link":"#省市区移除【全国-全部】项","children":[]}]}],"git":{},"filePathRelative":"guide/javascript/javascript-address.md"}');
export {
  data
};
