import { ssrRenderAttrs } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "../app.5d58a35b.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><details class="tip-block details"><summary>个人介绍</summary><p>程序员</p></details><div class="tip-block danger"><p class="title">个人介绍</p><p>程序员</p></div><div class="tip-block tip"><p class="title">个人介绍</p><p>程序员</p></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/user-profile.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const userProfile_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "user-profile.html.vue"]]);
export {
  userProfile_html as default
};
