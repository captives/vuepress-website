import { computed, mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderSlot } from "vue/server-renderer";
import { _ as _export_sfc } from "../app.f81e19e5.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const Poetry_vue_vue_type_style_index_0_scoped_fcaa848c_lang = "";
const _sfc_main = {
  __name: "Poetry",
  __ssrInlineRender: true,
  setup(__props) {
    const list = [
      "入门休问荣枯事，观看荣颜便得知",
      "君子安贫，达人知命。",
      "根深不怕风摇动，树正何怕月影斜",
      "他人生气本人不气 气出病来无人理",
      "人生本是一场梦 为了小事莫生气",
      "风起云涌年又年 得得失失要乐天",
      "万物有情心有爱 何惧别人笑本人痴",
      "纵然身处风雷雨 深信朝阳必再遇",
      "且将懊恼化烟云 风吹云散交好运",
      "知足常乐 终生不辱",
      "来如风 去如微尘。知福福常在 怡然自心安",
      "是非整天游 不听自然无",
      "人和自得乐 家和万事兴",
      "不经一番寒彻骨 怎得梅花扑鼻香。",
      "别人生气我不气，气出病来没人理",
      "人生本是一场梦，为了小事莫生气",
      "风起云过年有年，得得失失要乐天",
      "知福福常在，怡然自心安",
      "是非终日有，不听自然无",
      "人和自得乐，家和万事兴",
      "不经一番寒彻骨，怎得梅花扑鼻香",
      "海阔就凭鱼跃，天高就任鸟飞",
      "懒理雷声狂风雨，自求我心一片晴",
      "即是相依同林鸟，风雨同路见真心",
      "笑看世间事，前路我自行",
      "虽无家财万贯，喜有笑面开颜"
    ];
    const desc = computed(() => list[Math.floor(Math.random() * list.length)]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<main${ssrRenderAttrs(mergeProps({ class: "home" }, _attrs))} data-v-fcaa848c><header class="hero" data-v-fcaa848c><!-- <h1 id="main-title">古诗词</h1> --><p class="description" data-v-fcaa848c>${ssrInterpolate(unref(desc))}</p></header>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../src/components/Poetry.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Poetry = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-fcaa848c"], ["__file", "Poetry.vue"]]);
export {
  Poetry as default
};
