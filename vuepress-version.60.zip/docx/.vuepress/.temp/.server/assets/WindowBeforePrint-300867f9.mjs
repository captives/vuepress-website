import { ssrRenderAttrs, ssrIncludeBooleanAttr, ssrLooseContain } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "../app.f81e19e5.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {
  name: "WindowBeforePrint",
  data() {
    return {
      listened: false
    };
  },
  mounted() {
    window.addEventListener("beforeprint", (event) => {
      if (this.listened) {
        document.title = "打印开始，准备点什么";
      }
      console.log("beforeprint", event);
    });
    window.addEventListener("afterprint", (event) => {
      if (this.listened) {
        document.title = "打印完成，做点什么";
      }
      console.log("打印完成", event);
    });
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(_attrs)}> 监听 <input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.listened) ? ssrLooseContain($data.listened, null) : $data.listened) ? " checked" : ""}></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../src/components/guide/guide copy/WindowBeforePrint.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const WindowBeforePrint = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "WindowBeforePrint.vue"]]);
export {
  WindowBeforePrint as default
};
