import { ssrRenderAttrs } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "../app.f81e19e5.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="版本发布命名" tabindex="-1"><a class="header-anchor" href="#版本发布命名" aria-hidden="true">#</a> 版本发布命名</h1><h2 id="常见版本的具体含义" tabindex="-1"><a class="header-anchor" href="#常见版本的具体含义" aria-hidden="true">#</a> 常见版本的具体含义</h2><ul><li><strong>RC</strong> <em>Release Candidate</em> 即将作为正式版发布。用在软件上就是候选版本，系统平台上就是发行候选版本。RC版不会再加入新的功能了，主要着重于除错。</li><li><strong>RTM</strong> <em>Release To Manufacture</em> 是给工厂大量压片的版本，内容跟正式版是一样的，不过RTM版也有出限制、评估版的，但是和正式版本的主要程序代码都是一样的。</li><li><strong>Alpha</strong> 内测,即现在说的CB。指开发团队内部测试的版本或者有限用户体验测试版本。</li><li><strong>Beta</strong> 公测，即针对所有用户公开的测试版本。</li><li><strong>Gamma</strong> 测试版本后做过一些修改，成为正式发布的候选版本，现在叫做<strong>RC</strong> <em>Release Candidate</em>。</li><li><strong>Release</strong> 发行版</li><li><strong>Stable</strong> 稳定版本</li><li><strong>Standard</strong> 标准版</li><li><strong>Ultimate</strong> 旗舰版</li><li><strong>Upgrade</strong> 升级版</li><li><strong>Enhance</strong> 增强版</li><li><strong>Demo</strong> 演示版</li><li><strong>Lts</strong> 长期维护版本</li></ul><div class="tip-block warning"><p class="title">注意</p><ul><li>版本一经发布，不得修改其内容，任何修改必须在新版本发布！</li><li>在接口还没有确定下来的时候，应该先使用开发版本号。</li><li>业务功能 &gt; 功能 &gt; 接口</li></ul></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/linux/version.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const version_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "version.html.vue"]]);
export {
  version_html as default
};
