const data = JSON.parse('{"key":"v-310216c0","path":"/guide/html5/linefeed-br-transform.html","title":"\\\\n 和 <br/> 互转","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"\\\\n 和 <br/> 互转","slug":"n-和-br-互转","link":"#n-和-br-互转","children":[]}],"git":{},"filePathRelative":"guide/html5/linefeed-br-transform.md"}');
export {
  data
};
