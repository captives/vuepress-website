const data = JSON.parse('{"key":"v-665b7688","path":"/guide/html5/url-decode.html","title":"url 编解码","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"url 编解码","slug":"url-编解码","link":"#url-编解码","children":[]}],"git":{},"filePathRelative":"guide/html5/url-decode.md"}');
export {
  data
};
