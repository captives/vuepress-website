const data = JSON.parse('{"key":"v-3706649a","path":"/404.html","title":"","lang":"/","frontmatter":{"layout":"NotFound"},"headers":[],"git":{},"filePathRelative":null}');
export {
  data
};
