const data = JSON.parse('{"key":"v-fa5d3748","path":"/guide/javascript/lodash-seq.html","title":"Lodash  Seq","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"Lodash  Seq","slug":"lodash-seq","link":"#lodash-seq","children":[]}],"git":{},"filePathRelative":"guide/javascript/lodash-seq.md"}');
export {
  data
};
