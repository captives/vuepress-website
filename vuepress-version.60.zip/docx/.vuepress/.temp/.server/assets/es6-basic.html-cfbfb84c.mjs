const data = JSON.parse('{"key":"v-01eb0886","path":"/guide/javascript/es6-basic.html","title":"ES6 学习笔记","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"ES6 学习笔记","slug":"es6-学习笔记","link":"#es6-学习笔记","children":[{"level":2,"title":"符号","slug":"符号","link":"#符号","children":[]},{"level":2,"title":"运算符","slug":"运算符","link":"#运算符","children":[{"level":3,"title":"按位取反运算符~","slug":"按位取反运算符","link":"#按位取反运算符","children":[]},{"level":3,"title":"求幂表达式 **","slug":"求幂表达式","link":"#求幂表达式","children":[]}]},{"level":2,"title":"var/let/const","slug":"var-let-const","link":"#var-let-const","children":[]},{"level":2,"title":"对象解构","slug":"对象解构","link":"#对象解构","children":[]}]}],"git":{},"filePathRelative":"guide/javascript/es6-basic.md"}');
export {
  data
};
