const data = JSON.parse('{"key":"v-51ef0801","path":"/poetry/","title":"","lang":"poetry","frontmatter":{"home":true,"sidebar":false,"tagline":null,"footer":"<b1>captives.github.io</b1>","footerHtml":true,"pageClass":"poetry-home"},"headers":[],"git":{},"filePathRelative":"poetry/README.md"}');
export {
  data
};
