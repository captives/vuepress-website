import { ssrRenderAttrs, ssrRenderStyle, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "../app.5d58a35b.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {
  el: "#example",
  data() {
    return {
      textInput: "",
      textOutput: "",
      list: []
    };
  },
  methods: {
    urlEncodeHandler() {
      this.value = encodeURIComponent(this.textInput);
      this.list = [];
    },
    urlDecodeHandler() {
      this.textOutput = decodeURIComponent(this.textInput);
      this.list = this.textOutput.match(/(\w+):\/\/([^/:]+):(\d*)([^?]*)([^&].*)(#[^#]*)/);
    },
    clean() {
      this.textInput = this.textOutput = null;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="url-编解码" tabindex="-1"><a class="header-anchor" href="#url-编解码" aria-hidden="true">#</a> url 编解码</h1><div id="example"><p>输入 </p><textarea style="${ssrRenderStyle({ "width": "80%", "height": "100px" })}">${ssrInterpolate($data.textInput)}</textarea><br><button>URL编码</button><button>URL解码</button><button>清空</button><br><div><p>输出</p><p>${ssrInterpolate($data.textOutput)}</p></div><div><p>参数解析</p><ol><!--[-->`);
  ssrRenderList($data.list, (item, index) => {
    _push(`<li>${ssrInterpolate(item)}</li>`);
  });
  _push(`<!--]--></ol></div></div><details class="tip-block details"><summary>正则说明</summary><ul><li>实例中的数组包含 7 个元素，索引 0 对应的是整个字符串，索引 1 对应第一个匹配符（括号内），以此类推。</li><li>第一个括号子表达式捕获 Web 地址的协议部分。该子表达式匹配在冒号和两个正斜杠前面的任何单词。</li><li>第二个括号子表达式捕获地址的域地址部分。子表达式匹配非 : 和 / 之后的一个或多个字符。</li><li>第三个括号子表达式捕获端口号（如果指定了的话）。该子表达式匹配冒号后面的零个或多个数字。只能重复一次该子表达式。</li><li>第四个括号子表达式捕获 Web 地址指定的路径和 / 或页信息。该子表达式能匹配不包括 # 或空格字符的任何字符序列。</li><li>第五个括号表达式捕获query参数 第六个括号表达式捕获hash参数</li></ul></details><div class="language-javascript" data-ext="js"><pre class="language-javascript"><code><span class="token function">encodeURIComponent</span><span class="token punctuation">(</span><span class="token keyword">this</span><span class="token punctuation">.</span>textInput<span class="token punctuation">)</span><span class="token punctuation">;</span>

<span class="token function">decodeURIComponent</span><span class="token punctuation">(</span><span class="token keyword">this</span><span class="token punctuation">.</span>textInput<span class="token punctuation">)</span><span class="token punctuation">;</span>
</code></pre></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/html5/url-decode.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const urlDecode_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "url-decode.html.vue"]]);
export {
  urlDecode_html as default
};
