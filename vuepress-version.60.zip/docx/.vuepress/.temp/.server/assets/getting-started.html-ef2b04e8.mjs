const data = JSON.parse('{"key":"v-fb0f0066","path":"/guide/getting-started.html","title":"vuepress 入门","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"vuepress 入门","slug":"vuepress-入门","link":"#vuepress-入门","children":[]}],"git":{},"filePathRelative":"guide/getting-started.md"}');
export {
  data
};
