const data = JSON.parse('{"key":"v-775863b0","path":"/guide/linux/version.html","title":"版本发布命名","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"版本发布命名","slug":"版本发布命名","link":"#版本发布命名","children":[{"level":2,"title":"常见版本的具体含义","slug":"常见版本的具体含义","link":"#常见版本的具体含义","children":[]}]}],"git":{},"filePathRelative":"guide/linux/version.md"}');
export {
  data
};
