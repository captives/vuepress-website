const data = JSON.parse('{"key":"v-13af5c88","path":"/guide/nodejs/nodejs-install.html","title":"Nodejs 安装","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"Nodejs 安装","slug":"nodejs-安装","link":"#nodejs-安装","children":[{"level":2,"title":"安装","slug":"安装","link":"#安装","children":[]},{"level":2,"title":"配置","slug":"配置","link":"#配置","children":[]},{"level":2,"title":"调试","slug":"调试","link":"#调试","children":[]}]}],"git":{},"filePathRelative":"guide/nodejs/nodejs-install.md"}');
export {
  data
};
