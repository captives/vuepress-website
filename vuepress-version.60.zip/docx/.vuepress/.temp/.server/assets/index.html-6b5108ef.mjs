const data = JSON.parse('{"key":"v-fffb8e28","path":"/guide/","title":"Home","lang":"guide","frontmatter":{"home":true,"title":"Home","heroImage":"./assets/images/logo.svg","actions":[{"text":"Get Started","link":"/guide/getting-started.html","type":"primary"},{"text":"GitHub →","link":"https://www.github.com/captives","type":"secondary"}],"features":[{"title":"Guide","details":"代码片段"},{"title":"Poetry","details":"古诗词系列"},{"title":"Tutorial","details":"教程系列"}],"footer":"MIT Licensed | Copyright © 2018-present Evan You"},"headers":[],"git":{},"filePathRelative":"guide/README.md"}');
export {
  data
};
