import { resolveComponent, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { _ as _export_sfc } from "../app.5d58a35b.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_ExternalLinkIcon = resolveComponent("ExternalLinkIcon");
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="快速开始" tabindex="-1"><a class="header-anchor" href="#快速开始" aria-hidden="true">#</a> 快速开始</h1><h2 id="环境" tabindex="-1"><a class="header-anchor" href="#环境" aria-hidden="true">#</a> 环境</h2><ul><li>安装 <a href="https://code.visualstudio.com/" target="_blank" rel="noopener noreferrer">Visual Studio Code`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a></li><li>安装Visual Studio Code的插件<code>TypeScript</code>、<code>Code Runner</code></li><li>安装编译环境</li></ul><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">npm</span> <span class="token function">install</span> <span class="token parameter variable">-g</span> typescript
</code></pre></div><p>编译<code>ts</code>文件</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code>tsc index.ts
</code></pre></div><ul><li>安装运行环境</li></ul><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">npm</span> <span class="token function">install</span> <span class="token parameter variable">-g</span> ts-node tslib @types/node
</code></pre></div><p>运行<code>ts</code>文件</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code>ts-node index.ts
</code></pre></div><p>更多参考<a href="https://www.tslang.cn/docs/handbook/typescript-in-5-minutes.html" target="_blank" rel="noopener noreferrer">5分钟上手TypeScript`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a></p></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/typescript/get-started.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const getStarted_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "get-started.html.vue"]]);
export {
  getStarted_html as default
};
