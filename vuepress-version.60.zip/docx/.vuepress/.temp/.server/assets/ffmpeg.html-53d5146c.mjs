import { ssrRenderAttrs } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "../app.f81e19e5.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="ffmpeg-使用笔记" tabindex="-1"><a class="header-anchor" href="#ffmpeg-使用笔记" aria-hidden="true">#</a> ffmpeg 使用笔记</h1><h2 id="录制" tabindex="-1"><a class="header-anchor" href="#录制" aria-hidden="true">#</a> 录制</h2><h3 id="转录网络媒体流" tabindex="-1"><a class="header-anchor" href="#转录网络媒体流" aria-hidden="true">#</a> 转录网络媒体流</h3><div class="language-bash" data-ext="sh"><pre class="language-bash"><code>ffmpeg <span class="token parameter variable">-i</span> <span class="token punctuation">{</span>input_url<span class="token punctuation">}</span> <span class="token parameter variable">-c</span> copy <span class="token punctuation">{</span>output_file<span class="token punctuation">}</span>
</code></pre></div><p>示例 录制hls,rtmp,http文件流</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code>ffmpeg <span class="token parameter variable">-i</span> https://tencent.avalive.cn/8cf3a1e9vodcq1256803167/1613cd155285890819181394384/playlist_eof.m3u8 <span class="token parameter variable">-c</span> copy record_1.flv
</code></pre></div><h2 id="转码" tabindex="-1"><a class="header-anchor" href="#转码" aria-hidden="true">#</a> 转码</h2><hr></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/nodejs/ffmpeg.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ffmpeg_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "ffmpeg.html.vue"]]);
export {
  ffmpeg_html as default
};
