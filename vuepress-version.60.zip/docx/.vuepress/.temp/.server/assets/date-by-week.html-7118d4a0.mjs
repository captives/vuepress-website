const data = JSON.parse('{"key":"v-4cbb61f8","path":"/guide/javascript/date-by-week.html","title":"日月周时间段处理","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"日月周时间段处理","slug":"日月周时间段处理","link":"#日月周时间段处理","children":[]}],"git":{},"filePathRelative":"guide/javascript/date-by-week.md"}');
export {
  data
};
