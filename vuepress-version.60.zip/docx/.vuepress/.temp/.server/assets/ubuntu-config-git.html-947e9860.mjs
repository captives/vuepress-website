import { ssrRenderAttrs } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "../app.5d58a35b.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="ubuntu-配置-git" tabindex="-1"><a class="header-anchor" href="#ubuntu-配置-git" aria-hidden="true">#</a> Ubuntu 配置 git</h1><h2 id="常用命令" tabindex="-1"><a class="header-anchor" href="#常用命令" aria-hidden="true">#</a> 常用命令</h2><p>更新分支树</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> remote update origin <span class="token parameter variable">--prune</span>
</code></pre></div><p>查看远程分支</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> branch <span class="token parameter variable">-a</span>
</code></pre></div><p>查看本地分支</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> branch
</code></pre></div><p>创建分支</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> branch develop
</code></pre></div><p>推送本地分支到远程</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> push origin develop
</code></pre></div><p>切换分支</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> checkout develop
</code></pre></div><p>删除本地分支</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> branch –D develop
</code></pre></div><p>删除远程分支：</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> branch <span class="token parameter variable">-r</span> <span class="token parameter variable">-d</span> origin/branch-name
<span class="token function">git</span> push origin :branch-name
</code></pre></div><p>或者</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> branch –r –D origin/develop
<span class="token function">git</span> push <span class="token parameter variable">--delete</span> origin develop
</code></pre></div><h2 id="重命名分支" tabindex="-1"><a class="header-anchor" href="#重命名分支" aria-hidden="true">#</a> 重命名分支</h2><p>在git中重命名远程分支，其实就是先删除远程分支，然后重命名本地分支，再重新提交一个远程分支。 例如下面的例子中，我需要把 devel 分支重命名为 develop 分支：</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> branch <span class="token parameter variable">-m</span> devel develop
<span class="token function">git</span> push origin develop
</code></pre></div><h2 id="配置ssh" tabindex="-1"><a class="header-anchor" href="#配置ssh" aria-hidden="true">#</a> 配置SSH</h2><p>1.取消git全局配置</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> config <span class="token parameter variable">--global</span> <span class="token parameter variable">--unset</span> user.name
<span class="token function">git</span> config <span class="token parameter variable">--global</span> <span class="token parameter variable">--unset</span> user.email
</code></pre></div><p>2.查看配置</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">git</span> config <span class="token parameter variable">--list</span>
</code></pre></div><p>3.本地配置私钥</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token builtin class-name">cd</span> ~/.ssh
ssh-keygen <span class="token parameter variable">-t</span> rsa <span class="token parameter variable">-C</span> <span class="token string">&quot;邮箱地址&quot;</span>  	<span class="token comment">#之后会提示输入文件名，默认id_rsa</span>
</code></pre></div><p>4.添加ssh key</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code>ssh-add <span class="token parameter variable">-K</span> ~/.ssh/id_rsa
</code></pre></div><p>::: info 查看配置: <code>ssh-add -l</code> 删除配置：<code>ssh-add -D</code> :::</p><p>5.设置config文件</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token builtin class-name">cd</span> ~/.ssh/
<span class="token function">vim</span> config
</code></pre></div><p>内容格式：</p><div class="language-text line-numbers-mode" data-ext="text"><pre class="language-text"><code># github
Host github
HostName github.com
PreferredAuthentications publickey
User git
IdentityFile ~/.ssh/id_rsa_github

# gitee
Host gitee
HostName gitee.com
PreferredAuthentications publickey
IdentityFile ~/.ssh/id_rsa_gitee
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>::: info <code>Host</code> 别名（方便记忆） <code>HostName</code> IP地址或者域名（可以写假域名，但要在host文件中绑定ip地址） <code>IdentityFile</code> 对应的私钥,也就是不带.pub 后缀的 <code>User</code> 用户名，有的是邮箱,一般默认情况 git 就可以 <code>Port</code> 默认是22可以不写 ::: 6.验证</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">ssh</span> <span class="token parameter variable">-T</span> git@gitee.com
<span class="token function">ssh</span> <span class="token parameter variable">-T</span> git@github.com
</code></pre></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/linux/ubuntu-config-git.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ubuntuConfigGit_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "ubuntu-config-git.html.vue"]]);
export {
  ubuntuConfigGit_html as default
};
