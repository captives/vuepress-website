const data = JSON.parse('{"key":"v-3b2cbbd9","path":"/guide/javascript/javascript-binary-tree.html","title":"JavaScript 二叉树","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"JavaScript 二叉树","slug":"javascript-二叉树","link":"#javascript-二叉树","children":[{"level":2,"title":"定义","slug":"定义","link":"#定义","children":[]},{"level":2,"title":"遍历","slug":"遍历","link":"#遍历","children":[]},{"level":2,"title":"创建二叉树","slug":"创建二叉树","link":"#创建二叉树","children":[]},{"level":2,"title":"递归遍历","slug":"递归遍历","link":"#递归遍历","children":[]},{"level":2,"title":"深度优先遍历","slug":"深度优先遍历","link":"#深度优先遍历","children":[]},{"level":2,"title":"广度优先遍历","slug":"广度优先遍历","link":"#广度优先遍历","children":[]}]}],"git":{},"filePathRelative":"guide/javascript/javascript-binary-tree.md"}');
export {
  data
};
