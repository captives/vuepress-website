import { resolveComponent, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { _ as _export_sfc } from "../app.f81e19e5.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_ExternalLinkIcon = resolveComponent("ExternalLinkIcon");
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="vue-学习资源收藏" tabindex="-1"><a class="header-anchor" href="#vue-学习资源收藏" aria-hidden="true">#</a> Vue 学习资源收藏</h1><h2 id="vue-2-生态相关" tabindex="-1"><a class="header-anchor" href="#vue-2-生态相关" aria-hidden="true">#</a> Vue 2 生态相关</h2><h2 id="vue-3-生态相关" tabindex="-1"><a class="header-anchor" href="#vue-3-生态相关" aria-hidden="true">#</a> Vue 3 生态相关</h2><details class="tip-block details"><summary>Vite介绍</summary><p><a href="https://cn.vitejs.dev/guide/why.html" target="_blank" rel="noopener noreferrer">Vite`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a>（法语意思是 “快”，发音为 /vit/，类似 veet）是一种全新的前端构建工具。你可以把它理解为一个开箱即用的开发服务器 + 打包工具的组合，但是更轻更快。Vite 利用浏览器原生的 ES 模块支持和用编译到原生的语言开发的工具（如 esbuild）来提供一个快速且现代的开发体验。</p><p>Vite 有多快？在 Repl.it 上从零启动一个基于 Vite 的 React 应用，浏览器页面加载完毕的时候，CRA（create-react-app）甚至还没有装完依赖。</p><p>如果你还没听说过 Vite 到底是什么，可以到这里了解一下项目的设计初衷。如果你想要了解 Vite 跟其它一些类似的工具有什么区别，可以参考这里的对比。</p></details><h2 id="ppt模板下载站点" tabindex="-1"><a class="header-anchor" href="#ppt模板下载站点" aria-hidden="true">#</a> PPT模板下载站点</h2><p><a href="http://www.1ppt.com/" target="_blank" rel="noopener noreferrer">www.1ppt.com`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a><a href="http://www.51pptmoban.com/" target="_blank" rel="noopener noreferrer">www.51pptmoban.com`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a></p><hr></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/website-learning.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const websiteLearning_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "website-learning.html.vue"]]);
export {
  websiteLearning_html as default
};
