const data = JSON.parse('{"key":"v-0482165c","path":"/guide/nodejs/ffmpeg.html","title":"ffmpeg 使用笔记","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"ffmpeg 使用笔记","slug":"ffmpeg-使用笔记","link":"#ffmpeg-使用笔记","children":[{"level":2,"title":"录制","slug":"录制","link":"#录制","children":[{"level":3,"title":"转录网络媒体流","slug":"转录网络媒体流","link":"#转录网络媒体流","children":[]}]},{"level":2,"title":"转码","slug":"转码","link":"#转码","children":[]}]}],"git":{},"filePathRelative":"guide/nodejs/ffmpeg.md"}');
export {
  data
};
