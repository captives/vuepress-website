import { defineComponent, toRefs, ref, onMounted, resolveComponent, mergeProps, withCtx, unref, openBlock, createBlock, Fragment, renderList, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList } from "vue/server-renderer";
import { ElMessage } from "element-plus";
import { Position } from "@element-plus/icons-vue";
import { _ as _export_sfc } from "../app.f81e19e5.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "URLInput",
  __ssrInlineRender: true,
  props: {
    modelValue: { default: "" },
    list: { default: () => [] }
  },
  emits: ["update:modelValue", "change"],
  setup(__props, { emit }) {
    const props = __props;
    const { modelValue, list } = toRefs(props);
    const text = ref(modelValue.value);
    const selectValue = ref();
    const changeHandler = (event) => {
      text.value = selectValue.value;
    };
    const requestURL = () => {
      if (text.value) {
        emit("update:modelValue", text.value);
        emit("change", selectValue.value);
      } else {
        ElMessage({ type: "warning", message: "请输入内容" });
      }
    };
    onMounted(() => {
      if (list.value.length) {
        text.value = list.value[0].value;
        selectValue.value = text.value;
        emit("update:modelValue", text.value);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_input = resolveComponent("el-input");
      const _component_el_select = resolveComponent("el-select");
      const _component_el_option = resolveComponent("el-option");
      const _component_el_button = resolveComponent("el-button");
      _push(ssrRenderComponent(_component_el_input, mergeProps({
        modelValue: text.value,
        "onUpdate:modelValue": ($event) => text.value = $event,
        placeholder: "请输入内容",
        clearable: ""
      }, _ctx.$attrs, _attrs), {
        prepend: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(list).length) {
              _push2(ssrRenderComponent(_component_el_select, {
                modelValue: selectValue.value,
                "onUpdate:modelValue": ($event) => selectValue.value = $event,
                placeholder: "请选择",
                onChange: changeHandler
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<!--[-->`);
                    ssrRenderList(unref(list), (item) => {
                      _push3(ssrRenderComponent(_component_el_option, {
                        key: item.value,
                        label: item.label,
                        value: item.value
                      }, null, _parent3, _scopeId2));
                    });
                    _push3(`<!--]-->`);
                  } else {
                    return [
                      (openBlock(true), createBlock(
                        Fragment,
                        null,
                        renderList(unref(list), (item) => {
                          return openBlock(), createBlock(_component_el_option, {
                            key: item.value,
                            label: item.label,
                            value: item.value
                          }, null, 8, ["label", "value"]);
                        }),
                        128
                        /* KEYED_FRAGMENT */
                      ))
                    ];
                  }
                }),
                _: 1
                /* STABLE */
              }, _parent2, _scopeId));
            } else {
              _push2(`<span data-v-e536fece${_scopeId}>URL：</span>`);
            }
          } else {
            return [
              unref(list).length ? (openBlock(), createBlock(_component_el_select, {
                key: 0,
                modelValue: selectValue.value,
                "onUpdate:modelValue": ($event) => selectValue.value = $event,
                placeholder: "请选择",
                onChange: changeHandler
              }, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(
                    Fragment,
                    null,
                    renderList(unref(list), (item) => {
                      return openBlock(), createBlock(_component_el_option, {
                        key: item.value,
                        label: item.label,
                        value: item.value
                      }, null, 8, ["label", "value"]);
                    }),
                    128
                    /* KEYED_FRAGMENT */
                  ))
                ]),
                _: 1
                /* STABLE */
              }, 8, ["modelValue", "onUpdate:modelValue"])) : (openBlock(), createBlock("span", { key: 1 }, "URL："))
            ];
          }
        }),
        append: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_el_button, {
              type: "success",
              icon: unref(Position),
              onClick: requestURL
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_el_button, {
                type: "success",
                icon: unref(Position),
                onClick: requestURL
              }, null, 8, ["icon"])
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
    };
  }
});
const URLInput_vue_vue_type_style_index_0_scoped_e536fece_lang = "";
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../src/components/URLInput.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const URLInput = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-e536fece"], ["__file", "URLInput.vue"]]);
export {
  URLInput as default
};
