const data = JSON.parse('{"key":"v-18a03e64","path":"/guide/favorites.html","title":"收藏夹","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"收藏夹","slug":"收藏夹","link":"#收藏夹","children":[]},{"level":1,"title":"工具类","slug":"工具类","link":"#工具类","children":[{"level":2,"title":"网站图标生成器","slug":"网站图标生成器","link":"#网站图标生成器","children":[]},{"level":2,"title":"Vue 2 生态相关","slug":"vue-2-生态相关","link":"#vue-2-生态相关","children":[]},{"level":2,"title":"Vue 3 生态相关","slug":"vue-3-生态相关","link":"#vue-3-生态相关","children":[]},{"level":2,"title":"PPT模板下载站点","slug":"ppt模板下载站点","link":"#ppt模板下载站点","children":[]}]}],"git":{},"filePathRelative":"guide/favorites.md"}');
export {
  data
};
