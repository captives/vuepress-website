const data = JSON.parse('{"key":"v-58efd6f6","path":"/guide/other/%E4%B8%8B%E8%BD%BDbilibili%E8%A7%86%E9%A2%91.html","title":"下载哔哩哔哩视频","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"下载哔哩哔哩视频","slug":"下载哔哩哔哩视频","link":"#下载哔哩哔哩视频","children":[{"level":2,"title":"获取视频系列地址","slug":"获取视频系列地址","link":"#获取视频系列地址","children":[]},{"level":2,"title":"下载视频","slug":"下载视频","link":"#下载视频","children":[]}]}],"git":{},"filePathRelative":"guide/other/下载bilibili视频.md"}');
export {
  data
};
