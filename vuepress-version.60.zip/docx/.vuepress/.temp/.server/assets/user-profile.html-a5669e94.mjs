const data = JSON.parse('{"key":"v-077d91b9","path":"/user-profile.html","title":"","lang":"/","frontmatter":{"sidebar":false,"layout":"HomeLayout","footer":"MIT Licensed | Copyright © 2018-present Evan You"},"headers":[],"git":{},"filePathRelative":"user-profile.md"}');
export {
  data
};
