import { defineAsyncComponent, computed, resolveComponent, withCtx, createTextVNode, createVNode, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderStyle, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { _ as _export_sfc } from "../app.f81e19e5.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _imports_0 = "/assets/logo.png";
const _imports_1 = "/assets/hero-3c1981fd.png";
const markdown_html_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  __name: "markdown.html",
  __ssrInlineRender: true,
  setup(__props) {
    const DateString = defineAsyncComponent(() => import("./DateString-3063df0c.mjs"));
    const title = computed(() => "API：https://captives.github.io/api");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ExternalLinkIcon = resolveComponent("ExternalLinkIcon");
      const _component_router_link = resolveComponent("router-link");
      const _component_CodeGroup = resolveComponent("CodeGroup");
      const _component_CodeGroupItem = resolveComponent("CodeGroupItem");
      _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="样式模板" tabindex="-1"><a class="header-anchor" href="#样式模板" aria-hidden="true">#</a> 样式模板</h1><h2 id="目录" tabindex="-1"><a class="header-anchor" href="#目录" aria-hidden="true">#</a> 目录</h2><p><a href="https://v2.vuepress.vuejs.org/zh/reference/plugin/toc.html" target="_blank" rel="noopener noreferrer"><code>[toc]</code>组件使用`);
      _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
      _push(`</a></p><div class="language-html line-numbers-mode" data-ext="html"><pre class="language-html"><code>::: details 目录导航
[[toc]] 目录大纲
:::

::: details 目录导航
@[toc] 目录大纲
:::
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><details class="tip-block details"><summary>目录导航</summary><nav class="table-of-contents"><ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#目录" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`目录`);
          } else {
            return [
              createTextVNode("目录")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题`);
          } else {
            return [
              createTextVNode("标题")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题2" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题2`);
          } else {
            return [
              createTextVNode("标题2")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题2-1" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题2`);
          } else {
            return [
              createTextVNode("标题2")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题3" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题3`);
          } else {
            return [
              createTextVNode("标题3")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题4" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题4`);
          } else {
            return [
              createTextVNode("标题4")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题5" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题5`);
          } else {
            return [
              createTextVNode("标题5")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li></ul></li></ul></li></ul></li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#粗体" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`粗体`);
          } else {
            return [
              createTextVNode("粗体")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#斜体" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`斜体`);
          } else {
            return [
              createTextVNode("斜体")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标记" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标记`);
          } else {
            return [
              createTextVNode("标记")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#上下角标" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`上下角标`);
          } else {
            return [
              createTextVNode("上下角标")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#下划线-中划线" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`下划线,中划线`);
          } else {
            return [
              createTextVNode("下划线,中划线")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#分割线" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`分割线`);
          } else {
            return [
              createTextVNode("分割线")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#链接" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`链接`);
          } else {
            return [
              createTextVNode("链接")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#有序列表" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`有序列表`);
          } else {
            return [
              createTextVNode("有序列表")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#无序列表" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`无序列表`);
          } else {
            return [
              createTextVNode("无序列表")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#任务清单" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`任务清单`);
          } else {
            return [
              createTextVNode("任务清单")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#段落引用" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`段落引用`);
          } else {
            return [
              createTextVNode("段落引用")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#容器语法" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`容器语法`);
          } else {
            return [
              createTextVNode("容器语法")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#折叠块" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`折叠块`);
          } else {
            return [
              createTextVNode("折叠块")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#代码" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`代码`);
          } else {
            return [
              createTextVNode("代码")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#代码高亮行" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`代码高亮行`);
          } else {
            return [
              createTextVNode("代码高亮行")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li></ul></li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#导入代码块" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`导入代码块`);
          } else {
            return [
              createTextVNode("导入代码块")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#表格" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`表格`);
          } else {
            return [
              createTextVNode("表格")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#vue表达式" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Vue表达式`);
          } else {
            return [
              createTextVNode("Vue表达式")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#vue模块" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Vue模块`);
          } else {
            return [
              createTextVNode("Vue模块")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#vue-模块内sass语法" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Vue 模块内Sass语法`);
          } else {
            return [
              createTextVNode("Vue 模块内Sass语法")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#注释" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`注释`);
          } else {
            return [
              createTextVNode("注释")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#代码组合" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`代码组合`);
          } else {
            return [
              createTextVNode("代码组合")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#html分组" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`HTML分组`);
          } else {
            return [
              createTextVNode("HTML分组")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#frontmatter" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Frontmatter`);
          } else {
            return [
              createTextVNode("Frontmatter")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#cover" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`cover`);
          } else {
            return [
              createTextVNode("cover")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#cover-fit-coverfit" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`cover-fit/coverFit`);
          } else {
            return [
              createTextVNode("cover-fit/coverFit")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li></ul></li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#高级配置" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`高级配置`);
          } else {
            return [
              createTextVNode("高级配置")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#vue环境变量" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Vue环境变量`);
          } else {
            return [
              createTextVNode("Vue环境变量")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#路径别名" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`路径别名`);
          } else {
            return [
              createTextVNode("路径别名")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li></ul></li></ul></nav></details><details class="tip-block details"><summary>目录导航</summary><nav class="table-of-contents"><ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#目录" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`目录`);
          } else {
            return [
              createTextVNode("目录")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题`);
          } else {
            return [
              createTextVNode("标题")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题2" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题2`);
          } else {
            return [
              createTextVNode("标题2")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题2-1" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题2`);
          } else {
            return [
              createTextVNode("标题2")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题3" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题3`);
          } else {
            return [
              createTextVNode("标题3")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题4" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题4`);
          } else {
            return [
              createTextVNode("标题4")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标题5" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标题5`);
          } else {
            return [
              createTextVNode("标题5")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li></ul></li></ul></li></ul></li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#粗体" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`粗体`);
          } else {
            return [
              createTextVNode("粗体")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#斜体" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`斜体`);
          } else {
            return [
              createTextVNode("斜体")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#标记" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`标记`);
          } else {
            return [
              createTextVNode("标记")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#上下角标" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`上下角标`);
          } else {
            return [
              createTextVNode("上下角标")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#下划线-中划线" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`下划线,中划线`);
          } else {
            return [
              createTextVNode("下划线,中划线")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#分割线" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`分割线`);
          } else {
            return [
              createTextVNode("分割线")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#链接" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`链接`);
          } else {
            return [
              createTextVNode("链接")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#有序列表" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`有序列表`);
          } else {
            return [
              createTextVNode("有序列表")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#无序列表" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`无序列表`);
          } else {
            return [
              createTextVNode("无序列表")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#任务清单" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`任务清单`);
          } else {
            return [
              createTextVNode("任务清单")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#段落引用" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`段落引用`);
          } else {
            return [
              createTextVNode("段落引用")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#容器语法" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`容器语法`);
          } else {
            return [
              createTextVNode("容器语法")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#折叠块" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`折叠块`);
          } else {
            return [
              createTextVNode("折叠块")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#代码" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`代码`);
          } else {
            return [
              createTextVNode("代码")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#代码高亮行" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`代码高亮行`);
          } else {
            return [
              createTextVNode("代码高亮行")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li></ul></li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#导入代码块" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`导入代码块`);
          } else {
            return [
              createTextVNode("导入代码块")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#表格" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`表格`);
          } else {
            return [
              createTextVNode("表格")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#vue表达式" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Vue表达式`);
          } else {
            return [
              createTextVNode("Vue表达式")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#vue模块" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Vue模块`);
          } else {
            return [
              createTextVNode("Vue模块")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#vue-模块内sass语法" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Vue 模块内Sass语法`);
          } else {
            return [
              createTextVNode("Vue 模块内Sass语法")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#注释" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`注释`);
          } else {
            return [
              createTextVNode("注释")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#代码组合" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`代码组合`);
          } else {
            return [
              createTextVNode("代码组合")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#html分组" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`HTML分组`);
          } else {
            return [
              createTextVNode("HTML分组")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#frontmatter" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Frontmatter`);
          } else {
            return [
              createTextVNode("Frontmatter")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#cover" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`cover`);
          } else {
            return [
              createTextVNode("cover")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#cover-fit-coverfit" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`cover-fit/coverFit`);
          } else {
            return [
              createTextVNode("cover-fit/coverFit")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li></ul></li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#高级配置" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`高级配置`);
          } else {
            return [
              createTextVNode("高级配置")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<ul><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#vue环境变量" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Vue环境变量`);
          } else {
            return [
              createTextVNode("Vue环境变量")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_router_link, { to: "#路径别名" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`路径别名`);
          } else {
            return [
              createTextVNode("路径别名")
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`</li></ul></li></ul></nav></details><h2 id="标题" tabindex="-1"><a class="header-anchor" href="#标题" aria-hidden="true">#</a> 标题</h2><div class="language-markdown line-numbers-mode" data-ext="md"><pre class="language-markdown"><code><span class="token title important"><span class="token punctuation">#</span> 标题1</span>
<span class="token title important">标题1
<span class="token punctuation">====</span></span>

<span class="token title important"><span class="token punctuation">##</span> 标题2</span>
<span class="token title important">标题2
<span class="token punctuation">----</span></span>

<span class="token title important"><span class="token punctuation">###</span> 标题3</span>
<span class="token title important"><span class="token punctuation">####</span> 标题4</span>
<span class="token title important"><span class="token punctuation">#####</span> 标题5</span>
<span class="token title important"><span class="token punctuation">######</span> 标题6</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h1 id="标题1" tabindex="-1"><a class="header-anchor" href="#标题1" aria-hidden="true">#</a> 标题1</h1><h1 id="标题1-1" tabindex="-1"><a class="header-anchor" href="#标题1-1" aria-hidden="true">#</a> 标题1</h1><h2 id="标题2" tabindex="-1"><a class="header-anchor" href="#标题2" aria-hidden="true">#</a> 标题2</h2><h2 id="标题2-1" tabindex="-1"><a class="header-anchor" href="#标题2-1" aria-hidden="true">#</a> 标题2</h2><h3 id="标题3" tabindex="-1"><a class="header-anchor" href="#标题3" aria-hidden="true">#</a> 标题3</h3><h4 id="标题4" tabindex="-1"><a class="header-anchor" href="#标题4" aria-hidden="true">#</a> 标题4</h4><h5 id="标题5" tabindex="-1"><a class="header-anchor" href="#标题5" aria-hidden="true">#</a> 标题5</h5><h6 id="标题6" tabindex="-1"><a class="header-anchor" href="#标题6" aria-hidden="true">#</a> 标题6</h6><h2 id="粗体" tabindex="-1"><a class="header-anchor" href="#粗体" aria-hidden="true">#</a> 粗体</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token bold"><span class="token punctuation">**</span><span class="token content">粗体</span><span class="token punctuation">**</span></span>   <span class="token bold"><span class="token punctuation">__</span><span class="token content">粗体</span><span class="token punctuation">__</span></span>
</code></pre></div><p><strong>粗体</strong> <strong>粗体</strong></p><h2 id="斜体" tabindex="-1"><a class="header-anchor" href="#斜体" aria-hidden="true">#</a> 斜体</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token italic"><span class="token punctuation">*</span><span class="token content">斜体</span><span class="token punctuation">*</span></span>   <span class="token italic"><span class="token punctuation">_</span><span class="token content">斜体</span><span class="token punctuation">_</span></span>
</code></pre></div><p><em>斜体</em> <em>斜体</em></p><h2 id="标记" tabindex="-1"><a class="header-anchor" href="#标记" aria-hidden="true">#</a> 标记</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code>==标记==
</code></pre></div><p>==标记==</p><h2 id="上下角标" tabindex="-1"><a class="header-anchor" href="#上下角标" aria-hidden="true">#</a> 上下角标</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code>上角标 x^2^
下角标 H<span class="token strike"><span class="token punctuation">~</span><span class="token content">2</span><span class="token punctuation">~</span></span>0
</code></pre></div><p>上角标 x^2^ 下角标 H~2~0</p><h2 id="下划线-中划线" tabindex="-1"><a class="header-anchor" href="#下划线-中划线" aria-hidden="true">#</a> 下划线,中划线</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code>++下划线++    <span class="token strike"><span class="token punctuation">~~</span><span class="token content">中划线</span><span class="token punctuation">~~</span></span>
</code></pre></div><p>++下划线++ <s>中划线</s></p><h2 id="分割线" tabindex="-1"><a class="header-anchor" href="#分割线" aria-hidden="true">#</a> 分割线</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token title important">***
<span class="token punctuation">---</span></span>
</code></pre></div><hr><hr><h2 id="链接" tabindex="-1"><a class="header-anchor" href="#链接" aria-hidden="true">#</a> 链接</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token url">[<span class="token content">链接文本</span>](<span class="token url">captives.github.com</span>)</span>
<span class="token url">[<span class="token content">链接网站</span>](<span class="token url">https://captives.github.io</span>)</span>
<span class="token url"><span class="token operator">!</span>[<span class="token content">网站logo图</span>](<span class="token url">/assets/logo.png</span>)</span>
</code></pre></div><p><a href="captives.github.com">链接文本</a><a href="https://captives.github.io" target="_blank" rel="noopener noreferrer">链接网站`);
      _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
      _push(`</a><img${ssrRenderAttr("src", _imports_0)} alt="网站logo图"></p><h2 id="有序列表" tabindex="-1"><a class="header-anchor" href="#有序列表" aria-hidden="true">#</a> 有序列表</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token list punctuation">1.</span> 任务准备
<span class="token list punctuation">2.</span> 任务准备
<span class="token list punctuation">3.</span> 任务准备
</code></pre></div><ol><li>任务准备</li><li>任务准备</li><li>任务准备</li></ol><h2 id="无序列表" tabindex="-1"><a class="header-anchor" href="#无序列表" aria-hidden="true">#</a> 无序列表</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token list punctuation">-</span> 任务准备
<span class="token list punctuation">-</span> 任务准备
<span class="token list punctuation">-</span> 任务准备
</code></pre></div><ul><li>任务准备</li><li>任务准备</li><li>任务准备</li></ul><h2 id="任务清单" tabindex="-1"><a class="header-anchor" href="#任务清单" aria-hidden="true">#</a> 任务清单</h2><div class="language-markdown line-numbers-mode" data-ext="md"><pre class="language-markdown"><code><span class="token bold"><span class="token punctuation">**</span><span class="token content">购物清单</span><span class="token punctuation">**</span></span>

<span class="token list punctuation">-</span> [ ] 一次性水杯
<span class="token list punctuation">-</span> [x] 西瓜
<span class="token list punctuation">-</span> [ ] 豆浆
<span class="token list punctuation">-</span> [x] 可口可乐
<span class="token list punctuation">-</span> [ ] 小茗同学
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>购物清单</strong></p><ul><li>[ ] 一次性水杯</li><li>[x] 西瓜</li><li>[ ] 豆浆</li><li>[x] 可口可乐</li><li>[ ] 小茗同学</li></ul><h2 id="段落引用" tabindex="-1"><a class="header-anchor" href="#段落引用" aria-hidden="true">#</a> 段落引用</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token blockquote punctuation">&gt;</span> 一级
<span class="token blockquote punctuation">&gt;&gt;</span> 二级
<span class="token blockquote punctuation">&gt;&gt;&gt;</span> 三级

</code></pre></div><blockquote><p>一级</p><blockquote><p>二级</p><blockquote><p>三级</p></blockquote></blockquote></blockquote><h2 id="容器语法" tabindex="-1"><a class="header-anchor" href="#容器语法" aria-hidden="true">#</a> 容器语法</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code>::: <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>type</span><span class="token punctuation">&gt;</span></span> [info]
[content]
:::
</code></pre></div><p>type 是必须的，支持：提示[<code>tip</code>]、建议[<code>success</code>]、警告[<code>warning</code>]、危险[<code>danger</code>]、折叠块[<code>details</code>]</p><div class="language-markdown line-numbers-mode" data-ext="md"><pre class="language-markdown"><code>::: tip
<span class="token list punctuation">-</span> 阻止事件冒泡： <span class="token code-snippet code keyword">\`event.stopPropagation()\`</span> 或 <span class="token code-snippet code keyword">\`event.cancelBubble = true (IE)\`</span>
<span class="token list punctuation">-</span> 阻止浏览器默认行为：<span class="token code-snippet code keyword">\`event.preventDefault()\`</span>
:::

::: success
<span class="token list punctuation">-</span> 阻止事件冒泡： <span class="token code-snippet code keyword">\`event.stopPropagation()\`</span> 或 <span class="token code-snippet code keyword">\`event.cancelBubble = true (IE)\`</span>
<span class="token list punctuation">-</span> 阻止浏览器默认行为：<span class="token code-snippet code keyword">\`event.preventDefault()\`</span>
:::

::: warning
<span class="token list punctuation">-</span> 阻止事件冒泡： <span class="token code-snippet code keyword">\`event.stopPropagation()\`</span> 或 <span class="token code-snippet code keyword">\`event.cancelBubble = true (IE)\`</span>
<span class="token list punctuation">-</span> 阻止浏览器默认行为：<span class="token code-snippet code keyword">\`event.preventDefault()\`</span>
:::

::: danger
<span class="token list punctuation">-</span> 阻止事件冒泡： <span class="token code-snippet code keyword">\`event.stopPropagation()\`</span> 或 <span class="token code-snippet code keyword">\`event.cancelBubble = true (IE)\`</span>
<span class="token list punctuation">-</span> 阻止浏览器默认行为：<span class="token code-snippet code keyword">\`event.preventDefault()\`</span>
:::
</code></pre><div class="highlight-lines"><div class="highlight-line"> </div><br><br><div class="highlight-line"> </div><br><div class="highlight-line"> </div><br><br><div class="highlight-line"> </div><br><div class="highlight-line"> </div><br><br><div class="highlight-line"> </div><br><div class="highlight-line"> </div><br><br><div class="highlight-line"> </div></div><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><div class="tip-block tip"><p class="title">TIPS</p><ul><li>阻止事件冒泡： <code>event.stopPropagation()</code> 或 <code>event.cancelBubble = true (IE)</code></li><li>阻止浏览器默认行为：<code>event.preventDefault()</code></li></ul></div><div class="tip-block success"><p class="title">SUCCESS</p><ul><li>阻止事件冒泡： <code>event.stopPropagation()</code> 或 <code>event.cancelBubble = true (IE)</code></li><li>阻止浏览器默认行为：<code>event.preventDefault()</code></li></ul></div><div class="tip-block warning"><p class="title">WARNING</p><ul><li>阻止事件冒泡： <code>event.stopPropagation()</code> 或 <code>event.cancelBubble = true (IE)</code></li><li>阻止浏览器默认行为：<code>event.preventDefault()</code></li></ul></div><div class="tip-block danger"><p class="title">ERROR</p><ul><li>阻止事件冒泡： <code>event.stopPropagation()</code> 或 <code>event.cancelBubble = true (IE)</code></li><li>阻止浏览器默认行为：<code>event.preventDefault()</code></li></ul></div><h2 id="折叠块" tabindex="-1"><a class="header-anchor" href="#折叠块" aria-hidden="true">#</a> 折叠块</h2><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code>::: details 查看更多
<span class="token list punctuation">-</span> 阻止事件冒泡： <span class="token code-snippet code keyword">\`event.stopPropagation()\`</span> 或 <span class="token code-snippet code keyword">\`event.cancelBubble = true (IE)\`</span>
<span class="token list punctuation">-</span> 阻止浏览器默认行为：<span class="token code-snippet code keyword">\`event.preventDefault()\`</span>
:::
</code></pre></div><details class="tip-block details"><summary>查看更多</summary><ul><li>阻止事件冒泡： <code>event.stopPropagation()</code> 或 <code>event.cancelBubble = true (IE)</code></li><li>阻止浏览器默认行为：<code>event.preventDefault()</code></li></ul></details><h2 id="代码" tabindex="-1"><a class="header-anchor" href="#代码" aria-hidden="true">#</a> 代码</h2><div class="language-html" data-ext="html"><pre class="language-html"><code>\`\`\`html
  代码段落
\`\`\`
\`代码块\`
</code></pre></div><div class="language-html" data-ext="html"><pre class="language-html"><code>代码段落
</code></pre></div><p><code>代码块</code></p><h3 id="代码高亮行" tabindex="-1"><a class="header-anchor" href="#代码高亮行" aria-hidden="true">#</a> 代码高亮行</h3><p>你可以在代码块添加<code>:line-numbers</code> / <code>:no-line-numbers</code>标记来覆盖配置项中的设置。 除了单行以外，你也可指定多行，行数区间，或是两者都指定。</p><ul><li>行数区间: 例如 {5-8}, {3-10}, {10-17}</li><li>多个单行: 例如 {4,7,9}</li><li>行数区间与多个单行: 例如 {4,7-13,16,23-27,40}</li><li>数字和<code>,</code>前后不可以有空格</li></ul><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code><span class="token comment">//需求：编写方法，实现冒泡</span>
<span class="token keyword">var</span> arr <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">12</span><span class="token punctuation">,</span> <span class="token number">32</span><span class="token punctuation">,</span> <span class="token number">31</span><span class="token punctuation">,</span> <span class="token number">65</span><span class="token punctuation">,</span> <span class="token number">45</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">,</span> <span class="token number">12</span><span class="token punctuation">,</span> <span class="token number">43</span><span class="token punctuation">,</span> <span class="token number">35</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token comment">//外层循环，控制趟数，每一次找到一个最大值</span>
<span class="token keyword">for</span> <span class="token punctuation">(</span><span class="token keyword">var</span> i <span class="token operator">=</span> <span class="token number">0</span><span class="token punctuation">;</span> i <span class="token operator">&lt;</span> arr<span class="token punctuation">.</span>length <span class="token operator">-</span> <span class="token number">1</span><span class="token punctuation">;</span> i<span class="token operator">++</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
    <span class="token comment">// 内层循环,控制比较的次数，并且判断两个数的大小</span>
    <span class="token keyword">for</span> <span class="token punctuation">(</span><span class="token keyword">var</span> j <span class="token operator">=</span> <span class="token number">0</span><span class="token punctuation">;</span> j <span class="token operator">&lt;</span> arr<span class="token punctuation">.</span>length <span class="token operator">-</span> <span class="token number">1</span> <span class="token operator">-</span> i<span class="token punctuation">;</span> j<span class="token operator">++</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
        <span class="token comment">// 如果前面的数大，放到后面(当然是从小到大的冒泡排序)</span>
        <span class="token keyword">if</span> <span class="token punctuation">(</span>arr<span class="token punctuation">[</span>j<span class="token punctuation">]</span> <span class="token operator">&gt;</span> arr<span class="token punctuation">[</span>j <span class="token operator">+</span> <span class="token number">1</span><span class="token punctuation">]</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
            <span class="token keyword">var</span> temp <span class="token operator">=</span> arr<span class="token punctuation">[</span>j<span class="token punctuation">]</span><span class="token punctuation">;</span>
            arr<span class="token punctuation">[</span>j<span class="token punctuation">]</span> <span class="token operator">=</span> arr<span class="token punctuation">[</span>j <span class="token operator">+</span> <span class="token number">1</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
            arr<span class="token punctuation">[</span>j <span class="token operator">+</span> <span class="token number">1</span><span class="token punctuation">]</span> <span class="token operator">=</span> temp<span class="token punctuation">;</span>
        <span class="token punctuation">}</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>arr<span class="token punctuation">)</span><span class="token punctuation">;</span>  
<span class="token comment">// [2, 3, 6, 12, 12, 31, 32, 35, 43, 45, 65]</span>
</code></pre><div class="highlight-lines"><br><div class="highlight-line"> </div><br><br><br><br><br><br><div class="highlight-line"> </div><div class="highlight-line"> </div><div class="highlight-line"> </div><br><br><br><br><br><div class="highlight-line"> </div></div><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="导入代码块" tabindex="-1"><a class="header-anchor" href="#导入代码块" aria-hidden="true">#</a> 导入代码块</h2><p>你可以使用下面的语法，从文件中导入代码块：</p><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token comment">&lt;!-- 最简单的语法 --&gt;</span>
@<span class="token url">[<span class="token content">code</span>](<span class="token url">../foo.js</span>)</span>
</code></pre></div><p>如果你只想导入这个文件的一部分：</p><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token comment">&lt;!-- 仅导入第 1 行至第 10 行 --&gt;</span>
@<span class="token url">[<span class="token content">code{1-10}</span>](<span class="token url">../foo.js</span>)</span>
</code></pre></div><p>代码语言会根据文件扩展名进行推断，但我们建议你显式指定：</p><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token comment">&lt;!-- 指定代码语言 --&gt;</span>
@<span class="token url">[<span class="token content">code js</span>](<span class="token url">../foo.js</span>)</span>
</code></pre></div><p>实际上，[] 内的第二部分会被作为代码块标记来处理，因此在上面 代码块 章节中提到的语法在这里都可以支持：</p><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token comment">&lt;!-- 行高亮 --&gt;</span>
@<span class="token url">[<span class="token content">code js{2,4-5}</span>](<span class="token url">../foo.js</span>)</span>
</code></pre></div><p>在配置文件<code>config.js</code>中添加：</p><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code><span class="token literal-property property">markdown</span><span class="token operator">:</span> <span class="token punctuation">{</span>
    <span class="token literal-property property">importCode</span><span class="token operator">:</span> <span class="token punctuation">{</span>
        <span class="token function-variable function">handleImportPath</span><span class="token operator">:</span> <span class="token punctuation">(</span><span class="token parameter">str</span><span class="token punctuation">)</span> <span class="token operator">=&gt;</span>
            str<span class="token punctuation">.</span><span class="token function">replace</span><span class="token punctuation">(</span><span class="token regex"><span class="token regex-delimiter">/</span><span class="token regex-source language-regex">^@src</span><span class="token regex-delimiter">/</span></span><span class="token punctuation">,</span> path<span class="token punctuation">.</span><span class="token function">resolve</span><span class="token punctuation">(</span>__dirname<span class="token punctuation">,</span> <span class="token string">&#39;./../../&#39;</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">,</span>
    <span class="token punctuation">}</span><span class="token punctuation">,</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>文档中使用：</p><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code>@<span class="token url">[<span class="token content">code</span>](<span class="token url">@src/pages/Vuepress.vue</span>)</span>
</code></pre></div><p>即可加载源码,内容如下</p><div class="language-vue line-numbers-mode" data-ext="vue"><pre class="language-vue"><code><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>template</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span><span class="token punctuation">&gt;</span></span>
        Hello, Vue Press ~~
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>template</span><span class="token punctuation">&gt;</span></span>

<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>script</span><span class="token punctuation">&gt;</span></span><span class="token script"><span class="token language-javascript">
<span class="token keyword">export</span> <span class="token keyword">default</span> <span class="token punctuation">{</span>
    <span class="token literal-property property">name</span><span class="token operator">:</span> <span class="token string">&quot;VuePress&quot;</span><span class="token punctuation">,</span>
    <span class="token function">data</span> <span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span>
            <span class="token literal-property property">title</span><span class="token operator">:</span> <span class="token string">&quot;Hello VuePress ~&quot;</span>
        <span class="token punctuation">}</span><span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</span></span><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>script</span><span class="token punctuation">&gt;</span></span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>更多使用方式参考<a href="https://v2.vuepress.vuejs.org/zh/guide/markdown.html#%E5%AF%BC%E5%85%A5%E4%BB%A3%E7%A0%81%E5%9D%97" target="_blank" rel="noopener noreferrer">VuePress 导入代码块`);
      _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
      _push(`</a></p><h2 id="表格" tabindex="-1"><a class="header-anchor" href="#表格" aria-hidden="true">#</a> 表格</h2><div class="language-html" data-ext="html"><pre class="language-html"><code>| 表格标题1 | 表格标题2 | 表格标题3 |
| :-------- | :-------: | --------: |
| 左对齐    |   居中    |    右对齐 |
| --\\|--       |    --\\|--    |      --\\|-- |
</code></pre></div><table><thead><tr><th style="${ssrRenderStyle({ "text-align": "left" })}">表格标题1</th><th style="${ssrRenderStyle({ "text-align": "center" })}">表格标题2</th><th style="${ssrRenderStyle({ "text-align": "right" })}">表格标题3</th></tr></thead><tbody><tr><td style="${ssrRenderStyle({ "text-align": "left" })}">左对齐</td><td style="${ssrRenderStyle({ "text-align": "center" })}">居中</td><td style="${ssrRenderStyle({ "text-align": "right" })}">右对齐</td></tr><tr><td style="${ssrRenderStyle({ "text-align": "left" })}">--|--</td><td style="${ssrRenderStyle({ "text-align": "center" })}">--|--</td><td style="${ssrRenderStyle({ "text-align": "right" })}">--|--</td></tr></tbody></table><h1 id="vue-语法" tabindex="-1"><a class="header-anchor" href="#vue-语法" aria-hidden="true">#</a> Vue 语法</h1><p>Vuepress可以直接使用Vue语法</p><h2 id="vue表达式" tabindex="-1"><a class="header-anchor" href="#vue表达式" aria-hidden="true">#</a> Vue表达式</h2><div class="language-javascript" data-ext="js"><pre class="language-javascript"><code>一加一等于： <span class="token punctuation">{</span><span class="token punctuation">{</span> <span class="token number">1</span> <span class="token operator">+</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">}</span>
<span class="token operator">&lt;</span>span v<span class="token operator">-</span><span class="token keyword">for</span><span class="token operator">=</span><span class="token string">&quot;i in 3&quot;</span><span class="token operator">&gt;</span> span<span class="token operator">:</span> <span class="token punctuation">{</span><span class="token punctuation">{</span> i <span class="token punctuation">}</span><span class="token punctuation">}</span> <span class="token operator">&lt;</span><span class="token operator">/</span>span<span class="token operator">&gt;</span>
</code></pre></div><p>一加一等于： ${ssrInterpolate(1 + 1)} <!--[-->`);
      ssrRenderList(3, (i) => {
        _push(`<span> span: ${ssrInterpolate(i)}</span>`);
      });
      _push(`<!--]--></p><h2 id="vue模块" tabindex="-1"><a class="header-anchor" href="#vue模块" aria-hidden="true">#</a> Vue模块</h2><p>参考 <a href="#vue%E7%8E%AF%E5%A2%83%E5%8F%98%E9%87%8F">高级配置 &gt; Vue环境变量</a></p><h2 id="vue-模块内sass语法" tabindex="-1"><a class="header-anchor" href="#vue-模块内sass语法" aria-hidden="true">#</a> Vue 模块内Sass语法</h2><p>Vuepress默认使用sass，可以在文档内通过<code>&lt;style&gt;&lt;/style&gt;</code>标签对直接书写sass语法，不支持 <code>scoped</code></p><div class="language-scss line-numbers-mode" data-ext="scss"><pre class="language-scss"><code><span class="token selector">&lt;!-- 注释： 页面内样式 --&gt;
&lt;style lang=&quot;scss&quot;&gt;
    .poetry-home .home &gt; header </span><span class="token punctuation">{</span>
        <span class="token property">margin-top</span><span class="token punctuation">:</span> 20%<span class="token punctuation">;</span>
        <span class="token selector">h1 </span><span class="token punctuation">{</span>
            <span class="token property">font-family</span><span class="token punctuation">:</span> <span class="token string">&quot;华文行楷&quot;</span><span class="token punctuation">;</span>
            <span class="token property">font-size</span><span class="token punctuation">:</span> 6rem<span class="token punctuation">;</span>
        <span class="token punctuation">}</span>
    <span class="token punctuation">}</span>
&lt;/style&gt;
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="注释" tabindex="-1"><a class="header-anchor" href="#注释" aria-hidden="true">#</a> 注释</h2><div class="language-htmD" data-ext="htmD"><pre class="language-htmD"><code>&lt;!-- 注释： 此段区域内容不输出，但显示在DOM结构内 --&gt;
</code></pre></div><!-- 注释： 此段区域内容不输出，但显示在DOM结构内 --><hr><h1 id="分组" tabindex="-1"><a class="header-anchor" href="#分组" aria-hidden="true">#</a> 分组</h1><h2 id="代码组合" tabindex="-1"><a class="header-anchor" href="#代码组合" aria-hidden="true">#</a> 代码组合</h2><div class="language-markdown line-numbers-mode" data-ext="md"><pre class="language-markdown"><code>:::: code-group
::: code-group-item utils/foo.js
<span class="token code"><span class="token punctuation">\`\`\`</span><span class="token code-language">js</span>
<span class="token code-block language-js"><span class="token keyword">const</span> foo <span class="token operator">=</span> <span class="token string">&#39;foo&#39;</span></span>
<span class="token punctuation">\`\`\`</span></span>
:::
::: code-group-item utils/bar.ts
<span class="token code"><span class="token punctuation">\`\`\`</span><span class="token code-language">ts</span>
<span class="token code-block language-ts"><span class="token keyword">const</span> bar<span class="token operator">:</span><span class="token builtin">string</span> <span class="token operator">=</span> <span class="token string">&#39;bar&#39;</span></span>
<span class="token punctuation">\`\`\`</span></span>
:::
::::
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div>`);
      _push(ssrRenderComponent(_component_CodeGroup, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_CodeGroupItem, { title: "utils/foo.js" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="language-javascript" data-ext="js"${_scopeId2}><pre class="language-javascript"${_scopeId2}><code${_scopeId2}><span class="token keyword"${_scopeId2}>const</span> foo <span class="token operator"${_scopeId2}>=</span> <span class="token string"${_scopeId2}>&#39;foo&#39;</span>
</code></pre></div>`);
                } else {
                  return [
                    createVNode("div", {
                      class: "language-javascript",
                      "data-ext": "js"
                    }, [
                      createVNode("pre", { class: "language-javascript" }, [
                        createVNode("code", null, [
                          createVNode("span", { class: "token keyword" }, "const"),
                          createTextVNode(" foo "),
                          createVNode("span", { class: "token operator" }, "="),
                          createTextVNode(),
                          createVNode("span", { class: "token string" }, "'foo'"),
                          createTextVNode("\n")
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_CodeGroupItem, { title: "utils/bar.ts" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="language-typescript" data-ext="ts"${_scopeId2}><pre class="language-typescript"${_scopeId2}><code${_scopeId2}><span class="token keyword"${_scopeId2}>const</span> bar<span class="token operator"${_scopeId2}>:</span><span class="token builtin"${_scopeId2}>string</span> <span class="token operator"${_scopeId2}>=</span> <span class="token string"${_scopeId2}>&#39;bar&#39;</span>
</code></pre></div>`);
                } else {
                  return [
                    createVNode("div", {
                      class: "language-typescript",
                      "data-ext": "ts"
                    }, [
                      createVNode("pre", { class: "language-typescript" }, [
                        createVNode("code", null, [
                          createVNode("span", { class: "token keyword" }, "const"),
                          createTextVNode(" bar"),
                          createVNode("span", { class: "token operator" }, ":"),
                          createVNode("span", { class: "token builtin" }, "string"),
                          createTextVNode(),
                          createVNode("span", { class: "token operator" }, "="),
                          createTextVNode(),
                          createVNode("span", { class: "token string" }, "'bar'"),
                          createTextVNode("\n")
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_CodeGroupItem, { title: "utils/foo.js" }, {
                default: withCtx(() => [
                  createVNode("div", {
                    class: "language-javascript",
                    "data-ext": "js"
                  }, [
                    createVNode("pre", { class: "language-javascript" }, [
                      createVNode("code", null, [
                        createVNode("span", { class: "token keyword" }, "const"),
                        createTextVNode(" foo "),
                        createVNode("span", { class: "token operator" }, "="),
                        createTextVNode(),
                        createVNode("span", { class: "token string" }, "'foo'"),
                        createTextVNode("\n")
                      ])
                    ])
                  ])
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_CodeGroupItem, { title: "utils/bar.ts" }, {
                default: withCtx(() => [
                  createVNode("div", {
                    class: "language-typescript",
                    "data-ext": "ts"
                  }, [
                    createVNode("pre", { class: "language-typescript" }, [
                      createVNode("code", null, [
                        createVNode("span", { class: "token keyword" }, "const"),
                        createTextVNode(" bar"),
                        createVNode("span", { class: "token operator" }, ":"),
                        createVNode("span", { class: "token builtin" }, "string"),
                        createTextVNode(),
                        createVNode("span", { class: "token operator" }, "="),
                        createTextVNode(),
                        createVNode("span", { class: "token string" }, "'bar'"),
                        createTextVNode("\n")
                      ])
                    ])
                  ])
                ]),
                _: 1
                /* STABLE */
              })
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
      _push(`<h2 id="html分组" tabindex="-1"><a class="header-anchor" href="#html分组" aria-hidden="true">#</a> HTML分组</h2><div class="language-html" data-ext="html"><pre class="language-html"><code><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token special-attr"><span class="token attr-name">style</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">&quot;</span><span class="token value css language-css"><span class="token property">columns</span><span class="token punctuation">:</span> 3<span class="token punctuation">;</span></span><span class="token punctuation">&quot;</span></span></span><span class="token punctuation">&gt;</span></span>
严格地说，这个集子很难说是“自选集”。“自选集”应该是从大量的作品里选出自己认为比较满意的。我不能做到这一点。一则是我的作品数量本来就少，挑得严了，就更会所剩无几；二则，我对自己得作品无偏爱。有以为外国的汉学家发给我一张调查表，其中一栏是：“你认为自己最具有代表性的作品是哪几篇”，我实在不知道如何填。我的自选集不是选出了多少篇，而是从我的作品里剔除了一些篇。这不像农民田间选种，倒有点像老太太择（zhai）菜。老太太择菜是很宽容的，往往把择掉的黄叶、桔梗拿起来再看看，觉得凑活着还能吃，于是又搁回到好菜的一堆里。常言说：剪刀篮里的都是菜，我对自选集就有一点是这样。
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>br</span><span class="token punctuation">&gt;</span></span><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>br</span><span class="token punctuation">&gt;</span></span>
汪曾祺先生 一九八六年十二月十四日序于北京蒲黄榆路寓居~
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
</code></pre></div><div style="${ssrRenderStyle({ "columns": "3" })}"> 严格地说，这个集子很难说是“自选集”。“自选集”应该是从大量的作品里选出自己认为比较满意的。我不能做到这一点。一则是我的作品数量本来就少，挑得严了，就更会所剩无几；二则，我对自己得作品无偏爱。有以为外国的汉学家发给我一张调查表，其中一栏是：“你认为自己最具有代表性的作品是哪几篇”，我实在不知道如何填。我的自选集不是选出了多少篇，而是从我的作品里剔除了一些篇。这不像农民田间选种，倒有点像老太太择（zhai）菜。老太太择菜是很宽容的，往往把择掉的黄叶、桔梗拿起来再看看，觉得凑活着还能吃，于是又搁回到好菜的一堆里。常言说：剪刀篮里的都是菜，我对自选集就有一点是这样。 <br><br> 汪曾祺先生 一九八六年十二月十四日序于北京蒲黄榆路寓居~ </div><h2 id="frontmatter" tabindex="-1"><a class="header-anchor" href="#frontmatter" aria-hidden="true">#</a> Frontmatter</h2><p>本章节中的 Frontmatter 会在所有类型的页面中生效。 继承<a href="https://v2.vuepress.vuejs.org/zh/reference/frontmatter.html" target="_blank" rel="noopener noreferrer">Vuepress &gt; 参考 &gt; 默认主题 &gt; Frontmatter`);
      _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
      _push(`</a>下所有功能，以下属性为官方功能的扩展</p><h3 id="cover" tabindex="-1"><a class="header-anchor" href="#cover" aria-hidden="true">#</a> cover</h3><p>页面头图，添加图片地址，可自动在页面顶部显示</p><h3 id="cover-fit-coverfit" tabindex="-1"><a class="header-anchor" href="#cover-fit-coverfit" aria-hidden="true">#</a> cover-fit/coverFit</h3><p>页面头图填充模式，参考css样式<code>background-size</code>属性</p><h2 id="高级配置" tabindex="-1"><a class="header-anchor" href="#高级配置" aria-hidden="true">#</a> 高级配置</h2><h3 id="vue环境变量" tabindex="-1"><a class="header-anchor" href="#vue环境变量" aria-hidden="true">#</a> Vue环境变量</h3><p><b>${ssrInterpolate(unref(title))}</b></p><p>脚本源码：</p><div class="language-vue" data-ext="vue"><pre class="language-vue"><code><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>b</span><span class="token punctuation">&gt;</span></span>{{ title }}<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>b</span><span class="token punctuation">&gt;</span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>script</span>  <span class="token attr-name">setup</span><span class="token punctuation">&gt;</span></span><span class="token script"><span class="token language-javascript">
<span class="token keyword">import</span> <span class="token punctuation">{</span> computed <span class="token punctuation">}</span> <span class="token keyword">from</span> <span class="token string">&#39;vue&#39;</span><span class="token punctuation">;</span>
<span class="token keyword">const</span> title <span class="token operator">=</span> <span class="token function">computed</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token operator">=&gt;</span> <span class="token string">&quot;API：&quot;</span> <span class="token operator">+</span> <span class="token constant">V<wbr>UE_APP_API</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
</span></span><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>script</span><span class="token punctuation">&gt;</span></span>
</code></pre></div><p>在<code>config.js</code>配置中添加<code>define</code>字段：</p><div class="language-javascript" data-ext="js"><pre class="language-javascript"><code>  <span class="token literal-property property">define</span><span class="token operator">:</span> <span class="token punctuation">{</span>
    <span class="token literal-property property">__GLOBAL_BOOLEAN__</span><span class="token operator">:</span> <span class="token boolean">true</span><span class="token punctuation">,</span>
    <span class="token literal-property property">__GLOBAL_STRING__</span><span class="token operator">:</span> <span class="token string">&#39;foobar&#39;</span><span class="token punctuation">,</span>
    <span class="token literal-property property">__GLOBAL_OBJECT__</span><span class="token operator">:</span> <span class="token punctuation">{</span> <span class="token literal-property property">foo</span><span class="token operator">:</span> <span class="token string">&#39;bar&#39;</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">}</span><span class="token punctuation">,</span>
</code></pre></div><p>在文档的<code>&lt;script&gt;</code>中,即可访问：</p><div class="language-javascript" data-ext="js"><pre class="language-javascript"><code>console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>__GLOBAL_BOOLEAN__<span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// true</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>__GLOBAL_STRING__<span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// &#39;foobar&#39;</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>__GLOBAL_OBJECT__<span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// &quot;{ foo: &#39;bar&#39; }&quot;</span>
</code></pre></div><p>文章参考<a href="https://v2.vuepress.vuejs.org/zh/reference/plugin-api.html#define" target="_blank" rel="noopener noreferrer">插件API &gt; 开发Hooks &gt; define`);
      _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
      _push(`</a><a href="https://v2.vuepress.vuejs.org/zh/advanced/cookbook/passing-data-to-client-code.html" target="_blank" rel="noopener noreferrer">向客户端代码传递数据 &gt; 使用<code>define</code>Hook`);
      _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
      _push(`</a></p><h3 id="路径别名" tabindex="-1"><a class="header-anchor" href="#路径别名" aria-hidden="true">#</a> 路径别名</h3><p>在配置文件中设置的路径别名<code>alias</code>：</p><div class="language-javascript" data-ext="js"><pre class="language-javascript"><code><span class="token literal-property property">alias</span><span class="token operator">:</span> <span class="token punctuation">{</span>
    <span class="token string-property property">&#39;~&#39;</span><span class="token operator">:</span> path<span class="token punctuation">.</span><span class="token function">resolve</span><span class="token punctuation">(</span>__dirname<span class="token punctuation">,</span> <span class="token string">&#39;./../../assets/&#39;</span><span class="token punctuation">)</span><span class="token punctuation">,</span>
    <span class="token string-property property">&#39;@&#39;</span><span class="token operator">:</span> path<span class="token punctuation">.</span><span class="token function">resolve</span><span class="token punctuation">(</span>__dirname<span class="token punctuation">,</span> <span class="token string">&#39;./../../&#39;</span><span class="token punctuation">)</span><span class="token punctuation">,</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span>
</code></pre></div><p>这样就很方便的在文档的<code>&lt;script&gt;</code>中导入异步组件：</p>`);
      _push(ssrRenderComponent(unref(DateString), {
        value: Date.now()
      }, null, _parent));
      _push(`<div class="language-vue line-numbers-mode" data-ext="vue"><pre class="language-vue"><code><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>date-string</span> <span class="token attr-name">:value</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">&quot;</span>Date.now()<span class="token punctuation">&quot;</span></span><span class="token punctuation">&gt;</span></span><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>date-string</span><span class="token punctuation">&gt;</span></span>

<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>script</span>  <span class="token attr-name">setup</span><span class="token punctuation">&gt;</span></span><span class="token script"><span class="token language-javascript">
    <span class="token keyword">import</span> <span class="token punctuation">{</span> defineAsyncComponent <span class="token punctuation">}</span> <span class="token keyword">from</span> <span class="token string">&#39;vue&#39;</span><span class="token punctuation">;</span>
    <span class="token keyword">const</span> DateString <span class="token operator">=</span> <span class="token function">defineAsyncComponent</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token operator">=&gt;</span> <span class="token keyword">import</span><span class="token punctuation">(</span><span class="token string">&#39;@/pages/components/DateString.vue&#39;</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
</span></span><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>script</span><span class="token punctuation">&gt;</span></span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>图片资源，可以如下使用：</p><div class="language-markdown" data-ext="md"><pre class="language-markdown"><code><span class="token url"><span class="token operator">!</span>[<span class="token content">vuepress</span>](<span class="token url">@/assets/hero.png</span>)</span>
</code></pre></div><p>即可如下呈现出来</p><p><img${ssrRenderAttr("src", _imports_1)} alt="vuepress"></p><p>文章参考<a href="https://v2.vuepress.vuejs.org/zh/reference/plugin-api.html#alias" target="_blank" rel="noopener noreferrer">插件API &gt; 开发Hooks &gt; alias`);
      _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
      _push(`</a><a href="https://v2.vuepress.vuejs.org/zh/guide/assets.html" target="_blank" rel="noopener noreferrer">静态资源 &gt; 依赖包和路径别名`);
      _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
      _push(`</a></p></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/markdown.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const markdown_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["__file", "markdown.html.vue"]]);
export {
  markdown_html as default
};
