const data = JSON.parse('{"key":"v-1f4e1b24","path":"/guide/html5/mobile-adapter.html","title":"移动端适配处理","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"移动端适配处理","slug":"移动端适配处理","link":"#移动端适配处理","children":[]}],"git":{},"filePathRelative":"guide/html5/mobile-adapter.md"}');
export {
  data
};
