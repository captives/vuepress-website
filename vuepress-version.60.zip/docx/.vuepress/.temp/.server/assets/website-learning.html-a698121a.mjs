const data = JSON.parse('{"key":"v-e572ed46","path":"/guide/website-learning.html","title":"Vue 学习资源收藏","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"Vue 学习资源收藏","slug":"vue-学习资源收藏","link":"#vue-学习资源收藏","children":[{"level":2,"title":"Vue 2 生态相关","slug":"vue-2-生态相关","link":"#vue-2-生态相关","children":[]},{"level":2,"title":"Vue 3 生态相关","slug":"vue-3-生态相关","link":"#vue-3-生态相关","children":[]},{"level":2,"title":"PPT模板下载站点","slug":"ppt模板下载站点","link":"#ppt模板下载站点","children":[]}]}],"git":{},"filePathRelative":"guide/website-learning.md"}');
export {
  data
};
