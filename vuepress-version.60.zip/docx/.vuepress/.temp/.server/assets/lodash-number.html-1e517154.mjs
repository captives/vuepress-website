import { ssrRenderAttrs } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "../app.5d58a35b.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="lodash-数字-number" tabindex="-1"><a class="header-anchor" href="#lodash-数字-number" aria-hidden="true">#</a> Lodash 数字 Number</h1><h2 id="数字" tabindex="-1"><a class="header-anchor" href="#数字" aria-hidden="true">#</a> 数字</h2><h3 id="clamp-number-lower-upper" tabindex="-1"><a class="header-anchor" href="#clamp-number-lower-upper" aria-hidden="true">#</a> _.clamp(number, [lower], upper)</h3><details class="tip-block details"><summary>参数</summary><ul><li>number (number): 被限制的值。</li><li>[lower] (number): 下限。</li><li>upper (number): 上限。</li></ul><p>返回</p><ul><li>(number): 返回被限制的值。</li></ul></details><p>返回限制在<code>lower</code>和<code>upper</code>之间的值</p><div class="language-javascript" data-ext="js"><pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">clamp</span><span class="token punctuation">(</span><span class="token operator">-</span><span class="token number">10</span><span class="token punctuation">,</span> <span class="token operator">-</span><span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; -5</span>
 
_<span class="token punctuation">.</span><span class="token function">clamp</span><span class="token punctuation">(</span><span class="token number">10</span><span class="token punctuation">,</span> <span class="token operator">-</span><span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; 5</span>
</code></pre></div><h3 id="inrange-number-start-0-end" tabindex="-1"><a class="header-anchor" href="#inrange-number-start-0-end" aria-hidden="true">#</a> _.inRange(number, [start = 0], end)</h3><details class="tip-block details"><summary>参数</summary><ul><li>number (number): 要检查的值。</li><li>[start=0] (number): 开始范围。</li><li>end (number): 结束范围。</li></ul><p>返回</p><ul><li>(boolean): 如果number在范围内 ，那么返回true，否则返回 false。</li></ul></details><p>检查<code>n</code>是否在<code>start</code>与<code>end</code>之间，但不包括<code>end</code>。 如果<code>end</code>没有指定，那么<code>start</code>设置为0。 如果<code>start</code>大于 <code>end</code>，那么参数会交换以便支持负范围。</p><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">inRange</span><span class="token punctuation">(</span><span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; true</span>
 
_<span class="token punctuation">.</span><span class="token function">inRange</span><span class="token punctuation">(</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">8</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; true</span>
 
_<span class="token punctuation">.</span><span class="token function">inRange</span><span class="token punctuation">(</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; false</span>
 
_<span class="token punctuation">.</span><span class="token function">inRange</span><span class="token punctuation">(</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; false</span>
 
_<span class="token punctuation">.</span><span class="token function">inRange</span><span class="token punctuation">(</span><span class="token number">1.2</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; true</span>
 
_<span class="token punctuation">.</span><span class="token function">inRange</span><span class="token punctuation">(</span><span class="token number">5.2</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; false</span>
 
_<span class="token punctuation">.</span><span class="token function">inRange</span><span class="token punctuation">(</span><span class="token operator">-</span><span class="token number">3</span><span class="token punctuation">,</span> <span class="token operator">-</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token operator">-</span><span class="token number">6</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; true</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="random-lower-0-upper-1-floating" tabindex="-1"><a class="header-anchor" href="#random-lower-0-upper-1-floating" aria-hidden="true">#</a> _.random([lower = 0], [upper = 1], [floating])</h3><details class="tip-block details"><summary>参数</summary><ul><li>[lower=0] (number): 下限。</li><li>[upper=1] (number): 上限。</li><li>[floating] (boolean): 指定是否返回浮点数。</li></ul><p>返回</p><ul><li>(number): 返回随机数。</li></ul></details><p>产生一个包括<code>lower</code>与<code>upper</code>之间的数。 如果只提供一个参数返回一个0到提供数之间的数。 如果<code>floating</code>设为<code>true</code>，或者<code>lower</code>或<code>upper</code>是浮点数，结果返回浮点数。</p><div class="tip-block warning"><p class="title">注意:</p><p>JavaScript 遵循 IEEE-754 标准处理无法预料的浮点数结果。</p></div><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">random</span><span class="token punctuation">(</span><span class="token number">0</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; an integer between 0 and 5</span>
 
_<span class="token punctuation">.</span><span class="token function">random</span><span class="token punctuation">(</span><span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; also an integer between 0 and 5</span>
 
_<span class="token punctuation">.</span><span class="token function">random</span><span class="token punctuation">(</span><span class="token number">5</span><span class="token punctuation">,</span> <span class="token boolean">true</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; a floating-point number between 0 and 5</span>
 
_<span class="token punctuation">.</span><span class="token function">random</span><span class="token punctuation">(</span><span class="token number">1.2</span><span class="token punctuation">,</span> <span class="token number">5.2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =&gt; a floating-point number between 1.2 and 5.2</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/javascript/lodash-number.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const lodashNumber_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "lodash-number.html.vue"]]);
export {
  lodashNumber_html as default
};
