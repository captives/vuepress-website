const data = JSON.parse('{"key":"v-1b64d3b9","path":"/guide/nodejs/inquirer.js.html","title":"inquirer.js 命令行询问任务","lang":"guide","frontmatter":{},"headers":[{"level":1,"title":"inquirer.js 命令行询问任务","slug":"inquirer-js-命令行询问任务","link":"#inquirer-js-命令行询问任务","children":[{"level":2,"title":"文档","slug":"文档","link":"#文档","children":[{"level":3,"title":"安装","slug":"安装","link":"#安装","children":[]},{"level":3,"title":"参数","slug":"参数","link":"#参数","children":[]}]}]}],"git":{},"filePathRelative":"guide/nodejs/inquirer.js.md"}');
export {
  data
};
