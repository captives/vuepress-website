import { ssrRenderAttrs } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "../app.5d58a35b.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="nodejs-安装" tabindex="-1"><a class="header-anchor" href="#nodejs-安装" aria-hidden="true">#</a> Nodejs 安装</h1><h2 id="安装" tabindex="-1"><a class="header-anchor" href="#安装" aria-hidden="true">#</a> 安装</h2><p>命令行下载</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">wget</span> https://nodejs.org/dist/<span class="token punctuation">..</span>./node-v4.2.1-linux-x64.tar.gz
</code></pre></div><p>解压缩文件</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">tar</span> –zxvf node-v4.2.1-linux-x64.tar.gz
</code></pre></div><p>移动副本目录到 /opt/下</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">sudo</span> <span class="token function">cp</span> <span class="token parameter variable">-r</span> node-v4.2.1-linux-x64/ /opt/
</code></pre></div><p>设置全局软连接</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">sudo</span> <span class="token function">ln</span> <span class="token parameter variable">-s</span> /opt/node-v4.2.1-linux-x64/bin/node /usr/local/bin/node
<span class="token function">sudo</span> <span class="token function">ln</span> <span class="token parameter variable">-s</span> /opt/node-v4.2.1-linux-x64/bin/npm /usr/local/bin/npm
</code></pre></div><p>查看安装版本号</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">node</span> <span class="token parameter variable">-v</span>
<span class="token function">npm</span> <span class="token parameter variable">-v</span>
<span class="token function">npm</span> <span class="token function">install</span> 镜像仓库
</code></pre></div><p>查看镜像仓库</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">npm</span> config get registry  <span class="token comment">#https://registry.npmjs.org/</span>
如果使用npm安装一些包失败，可使用以下三种办法任意一种都能解决问题
</code></pre></div><h2 id="配置" tabindex="-1"><a class="header-anchor" href="#配置" aria-hidden="true">#</a> 配置</h2><p>通过 config命令</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">npm</span> config <span class="token builtin class-name">set</span> registry https://registry.npm.taobao.org
<span class="token function">npm</span> info underscore <span class="token comment">#查看underscore模块信息</span>
</code></pre></div><p>命令行指定</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">npm</span> <span class="token parameter variable">--registry</span> https://registry.npm.taobao.org 
</code></pre></div><p>编辑<code>~/.npmrc</code>加入以下内容 windows路径在 <code>{npm_install_dir}/node_modules/npm/npmrc</code></p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code>registry <span class="token operator">=</span> https://registry.npm.taobao.org
</code></pre></div><h2 id="调试" tabindex="-1"><a class="header-anchor" href="#调试" aria-hidden="true">#</a> 调试</h2><p>启动</p><div class="language-bash" data-ext="sh"><pre class="language-bash"><code><span class="token function">node</span> –inspect index.js
</code></pre></div><p>一共有两种打开调试工具的方法，第一种是在<em>Chrome</em>浏览器的地址栏，键入<code>chrome://inspect</code>或者 <code>about:inspect</code>进入, 在<em>Devices/Target</em>部分，点击<em>inspect</em>链接，就能进入调试工具了。</p><hr></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/nodejs/nodejs-install.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const nodejsInstall_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "nodejs-install.html.vue"]]);
export {
  nodejsInstall_html as default
};
