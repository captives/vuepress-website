import { defineComponent, defineAsyncComponent, ref, inject, toRefs, toRef, computed, watch, onMounted, resolveComponent, mergeProps, unref, withCtx, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { _ as _export_sfc } from "../app.5d58a35b.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ItemC",
  __ssrInlineRender: true,
  props: {
    modelValue: null,
    likes: null,
    date: null
  },
  emits: ["update:modelValue"],
  setup(__props, { expose, emit }) {
    const props = __props;
    expose({
      toLocalString() {
        console.log({ type: "error", message: " - toLocalString 方法触发 ~" });
      }
    });
    const DateString = defineAsyncComponent(() => import("./DateString-ee5b60ba.mjs"));
    let title = ref("Hello ");
    const solarTerms = inject("solarTerms") || [];
    const season = inject("season");
    const { date, likes } = toRefs(props);
    const modelValue = toRef(props, "modelValue");
    let currentSolarTerms = computed(() => {
      let index = season.value ? season.value.value : 0;
      index--;
      return solarTerms.slice(index * 6, index * 6 + 6);
    });
    watch(modelValue, () => {
      requestRemoteData();
    });
    watch([date, likes], (state, prevState) => {
      requestRemoteData();
    });
    const requestRemoteData = () => {
      console.log("远程数据请求已经发送", date, likes, modelValue);
    };
    const selectHandler = (name) => {
      emit("update:modelValue", name);
    };
    console.log("created - 组合式API对应选项式API的created函数是setup ~");
    requestRemoteData();
    onMounted(() => {
      console.log("mounted  - 虚拟DOM挂载完成 ~");
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_descriptions = resolveComponent("el-descriptions");
      const _component_el_descriptions_item = resolveComponent("el-descriptions-item");
      const _component_el_link = resolveComponent("el-link");
      _push(ssrRenderComponent(_component_el_descriptions, mergeProps({
        title: unref(title),
        column: 1
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_el_descriptions_item, { label: "组件名称（$attrs）" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$attrs.label)}`);
                } else {
                  return [
                    createTextVNode(
                      toDisplayString(_ctx.$attrs.label),
                      1
                      /* TEXT */
                    )
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_descriptions_item, { label: "日期（props）: " }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(date))}`);
                } else {
                  return [
                    createTextVNode(
                      toDisplayString(unref(date)),
                      1
                      /* TEXT */
                    )
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_descriptions_item, { label: "喜欢列表（props）: " }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(likes))}`);
                } else {
                  return [
                    createTextVNode(
                      toDisplayString(unref(likes)),
                      1
                      /* TEXT */
                    )
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_descriptions_item, { label: "节气列表（provide）: " }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(solarTerms))}`);
                } else {
                  return [
                    createTextVNode(
                      toDisplayString(unref(solarTerms)),
                      1
                      /* TEXT */
                    )
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_descriptions_item, { label: "选择季节（provide）: " }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(season))}`);
                } else {
                  return [
                    createTextVNode(
                      toDisplayString(unref(season)),
                      1
                      /* TEXT */
                    )
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_descriptions_item, { label: "包含节气（computed）: " }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(currentSolarTerms), (item, index) => {
                    _push3(`<!--[-->    `);
                    _push3(ssrRenderComponent(_component_el_link, {
                      type: unref(modelValue) === item ? "danger" : "primary",
                      onClick: ($event) => selectHandler(item)
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`${ssrInterpolate(item)}`);
                        } else {
                          return [
                            createTextVNode(
                              toDisplayString(item),
                              1
                              /* TEXT */
                            )
                          ];
                        }
                      }),
                      _: 2
                      /* DYNAMIC */
                    }, _parent3, _scopeId2));
                    _push3(`<!--]-->`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(
                      Fragment,
                      null,
                      renderList(unref(currentSolarTerms), (item, index) => {
                        return openBlock(), createBlock(
                          Fragment,
                          { key: index },
                          [
                            createTextVNode("    "),
                            createVNode(_component_el_link, {
                              type: unref(modelValue) === item ? "danger" : "primary",
                              onClick: ($event) => selectHandler(item)
                            }, {
                              default: withCtx(() => [
                                createTextVNode(
                                  toDisplayString(item),
                                  1
                                  /* TEXT */
                                )
                              ]),
                              _: 2
                              /* DYNAMIC */
                            }, 1032, ["type", "onClick"])
                          ],
                          64
                          /* STABLE_FRAGMENT */
                        );
                      }),
                      128
                      /* KEYED_FRAGMENT */
                    ))
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_descriptions_item, { label: "选择节气（v-model）: " }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(modelValue))}`);
                } else {
                  return [
                    createTextVNode(
                      toDisplayString(unref(modelValue)),
                      1
                      /* TEXT */
                    )
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_descriptions_item, { label: "异步组件: " }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(DateString), { value: unref(date) }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(DateString), { value: unref(date) }, null, 8, ["value"])
                  ];
                }
              }),
              _: 1
              /* STABLE */
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_el_descriptions_item, { label: "组件名称（$attrs）" }, {
                default: withCtx(() => [
                  createTextVNode(
                    toDisplayString(_ctx.$attrs.label),
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_el_descriptions_item, { label: "日期（props）: " }, {
                default: withCtx(() => [
                  createTextVNode(
                    toDisplayString(unref(date)),
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_el_descriptions_item, { label: "喜欢列表（props）: " }, {
                default: withCtx(() => [
                  createTextVNode(
                    toDisplayString(unref(likes)),
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_el_descriptions_item, { label: "节气列表（provide）: " }, {
                default: withCtx(() => [
                  createTextVNode(
                    toDisplayString(unref(solarTerms)),
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_el_descriptions_item, { label: "选择季节（provide）: " }, {
                default: withCtx(() => [
                  createTextVNode(
                    toDisplayString(unref(season)),
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_el_descriptions_item, { label: "包含节气（computed）: " }, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(
                    Fragment,
                    null,
                    renderList(unref(currentSolarTerms), (item, index) => {
                      return openBlock(), createBlock(
                        Fragment,
                        { key: index },
                        [
                          createTextVNode("    "),
                          createVNode(_component_el_link, {
                            type: unref(modelValue) === item ? "danger" : "primary",
                            onClick: ($event) => selectHandler(item)
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(item),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 2
                            /* DYNAMIC */
                          }, 1032, ["type", "onClick"])
                        ],
                        64
                        /* STABLE_FRAGMENT */
                      );
                    }),
                    128
                    /* KEYED_FRAGMENT */
                  ))
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_el_descriptions_item, { label: "选择节气（v-model）: " }, {
                default: withCtx(() => [
                  createTextVNode(
                    toDisplayString(unref(modelValue)),
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_el_descriptions_item, { label: "异步组件: " }, {
                default: withCtx(() => [
                  createVNode(unref(DateString), { value: unref(date) }, null, 8, ["value"])
                ]),
                _: 1
                /* STABLE */
              })
            ];
          }
        }),
        _: 1
        /* STABLE */
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../../../../src/pages/components/ItemC.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ItemC = /* @__PURE__ */ _export_sfc(_sfc_main, [["__file", "ItemC.vue"]]);
export {
  ItemC as default
};
