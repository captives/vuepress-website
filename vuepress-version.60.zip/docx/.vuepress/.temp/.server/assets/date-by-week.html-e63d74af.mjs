import { ssrRenderAttrs } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "../app.f81e19e5.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {
  name: "DateByWeek",
  mounted() {
    var cells = document.getElementById("monitor").getElementsByTagName("li");
    var clen = cells.length;
    var currentFirstDate;
    var formatDate = function(date) {
      var year = date.getFullYear() + "年";
      var month = date.getMonth() + 1 + "月";
      var day = date.getDate() + "日";
      var week = "(" + ["星期天", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"][date.getDay()] + ")";
      return year + month + day + " " + week;
    };
    var addDate = function(date, n) {
      var _date = new Date(date);
      _date.setDate(date.getDate() + n);
      return _date;
    };
    var setDate = function(date) {
      var week = date.getDay() - 1;
      date = addDate(date, week * -1);
      currentFirstDate = new Date(date);
      for (var i = 0; i < clen; i++) {
        cells[i].innerHTML = formatDate(i == 0 ? date : addDate(date, 1 * i));
      }
      var weekStart = new Date(new Date(date).setHours(0, 0, 0, 0));
      var weekEnd = new Date(new Date(addDate(date, 1 * 6)).setHours(23, 59, 59, 999));
      console.log("本周", weekStart, weekEnd);
      var upWeekStart = new Date(new Date(addDate(currentFirstDate, -7)).setHours(0, 0, 0, 0));
      var upWeekEnd = new Date(new Date(addDate(currentFirstDate, -1)).setHours(23, 59, 59, 999));
      console.log("本周", upWeekStart, upWeekEnd);
      document.querySelector(".date").innerHTML = `
                  <p>本周的开始${formatDate(date)} --- ${new Date(weekStart).getTime()} --- ${new Date(weekStart).toLocaleTimeString()} </p>
                  <p>本周的结束${formatDate(addDate(date, 1 * 6))} --- ${new Date(weekEnd).getTime()} --- ${new Date(addDate(date, 1 * 6)).toLocaleTimeString()} </p>
                  <p>上一周的开始${formatDate(upWeekStart)} --- ${new Date(upWeekStart).getTime()}---  ${new Date(addDate(currentFirstDate, -7)).toLocaleTimeString()} </p>
                  <p>上一周的结束${formatDate(upWeekEnd)} --- ${new Date(upWeekEnd).getTime()} --- ${new Date(addDate(currentFirstDate, -1)).toLocaleTimeString()} </p>
                  <p>`;
    };
    document.getElementById("last-week").onclick = function() {
      setDate(addDate(currentFirstDate, -7));
    };
    document.getElementById("next-week").onclick = function() {
      setDate(addDate(currentFirstDate, 7));
    };
    setDate(new Date());
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="日月周时间段处理" tabindex="-1"><a class="header-anchor" href="#日月周时间段处理" aria-hidden="true">#</a> 日月周时间段处理</h1><ul id="monitor"><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul><div class="date"></div><button id="last-week">上一周</button><button id="next-week">下一周</button></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/javascript/date-by-week.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const dateByWeek_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "date-by-week.html.vue"]]);
export {
  dateByWeek_html as default
};
