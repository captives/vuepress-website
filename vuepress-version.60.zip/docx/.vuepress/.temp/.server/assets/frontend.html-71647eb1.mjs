import { resolveComponent, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { _ as _export_sfc } from "../app.5d58a35b.mjs";
import "@vuepress/shared";
import "ts-debounce";
import "vue-router";
import "@vue/devtools-api";
import "@vueuse/core";
import "element-plus";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_ExternalLinkIcon = resolveComponent("ExternalLinkIcon");
  _push(`<div${ssrRenderAttrs(_attrs)}><h1 id="优秀学习资源" tabindex="-1"><a class="header-anchor" href="#优秀学习资源" aria-hidden="true">#</a> 优秀学习资源</h1><p><a href="https://www.bookstack.cn/" target="_blank" rel="noopener noreferrer">BookStack`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a> 全科技术网站学习平台</p><p><a href="https://www.30secondsofcode.org" target="_blank" rel="noopener noreferrer">30 秒的代码`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a> 满足您所有开发需求的简短代码片段</p><p><a href="https://muyiy.vip/" target="_blank" rel="noopener noreferrer">木易杨前端进阶`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a> 高级前端进阶之路</p><p><a href="https://xflihaibo.github.io/docs/#/" target="_blank" rel="noopener noreferrer">幸福的拾荒者`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a><a href="https://xflihaibo.github.io/docs/#/standard/" target="_blank" rel="noopener noreferrer">开发规范`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a> | <a href="https://xflihaibo.github.io/docs/#/web/" target="_blank" rel="noopener noreferrer">前端汇总`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a> | <a href="https://xflihaibo.github.io/docs/#/tool/" target="_blank" rel="noopener noreferrer">工具集合`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a> | <a href="https://xflihaibo.github.io/docs/#/advance/" target="_blank" rel="noopener noreferrer">进阶知识`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a></p><h2 id="常用前端库" tabindex="-1"><a class="header-anchor" href="#常用前端库" aria-hidden="true">#</a> 常用前端库</h2><h3 id="xtermjs" tabindex="-1"><a class="header-anchor" href="#xtermjs" aria-hidden="true">#</a> xtermjs</h3><ul><li>Xterm.js是用TypeScript编写的前端组件，它使应用程序可以将功能齐全的终端带给浏览器中的用户。诸如VS Code，Hyper和Theia等热门项目都使用了它。</li></ul><h3 id="webssh" tabindex="-1"><a class="header-anchor" href="#webssh" aria-hidden="true">#</a> webssh</h3><ul><li>基于Web的ssh客户端。<a href="https://github.com/huashengdun/webssh" target="_blank" rel="noopener noreferrer">github`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a></li></ul><h3 id="handlebars" tabindex="-1"><a class="header-anchor" href="#handlebars" aria-hidden="true">#</a> <a href="https://www.npmjs.com/package/handlebars" target="_blank" rel="noopener noreferrer">handlebars`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a></h3><ul><li>模板语法库</li></ul><h3 id="metalsmith" tabindex="-1"><a class="header-anchor" href="#metalsmith" aria-hidden="true">#</a> <a href="https://www.npmjs.com/package/metalsmith" target="_blank" rel="noopener noreferrer">Metalsmith`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a></h3><ul><li>所有逻辑都由插件处理。您只需将它们链接在一起即可</li></ul><div class="language-javascript line-numbers-mode" data-ext="js"><pre class="language-javascript"><code><span class="token function">Metalsmith</span><span class="token punctuation">(</span>__dirname<span class="token punctuation">)</span>
  <span class="token punctuation">.</span><span class="token function">use</span><span class="token punctuation">(</span><span class="token function">markdown</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">)</span>
  <span class="token punctuation">.</span><span class="token function">use</span><span class="token punctuation">(</span><span class="token function">layouts</span><span class="token punctuation">(</span><span class="token string">&#39;handlebars&#39;</span><span class="token punctuation">)</span><span class="token punctuation">)</span>
  <span class="token punctuation">.</span><span class="token function">build</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">err</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
    <span class="token keyword">if</span> <span class="token punctuation">(</span>err<span class="token punctuation">)</span> <span class="token keyword">throw</span> err<span class="token punctuation">;</span>
    console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">&#39;Build finished!&#39;</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
  <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="fullcalendar" tabindex="-1"><a class="header-anchor" href="#fullcalendar" aria-hidden="true">#</a> <a href="https://fullcalendar.io/" target="_blank" rel="noopener noreferrer">fullcalendar`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a></h3><ul><li>一款排班时间日历插件库，支持vue2.x，vue3.x 及react</li></ul><h2 id="优秀博文" tabindex="-1"><a class="header-anchor" href="#优秀博文" aria-hidden="true">#</a> 优秀博文</h2><p><a href="https://juejin.cn/post/6844903789388890119" target="_blank" rel="noopener noreferrer">我是如何让公司后台管理系统焕然一新的(上) -性能优化`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a><a href="https://juejin.cn/post/6844903789388890126" target="_blank" rel="noopener noreferrer">我是如何让公司后台管理系统焕然一新的（下）-封装组件`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a></p><p><a href="https://www.cnblogs.com/onepixel/articles/7674659.html" target="_blank" rel="noopener noreferrer">十大经典排序算法（动图演示）`);
  _push(ssrRenderComponent(_component_ExternalLinkIcon, null, null, _parent));
  _push(`</a></p></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../pages/guide/frontend.html.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const frontend_html = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__file", "frontend.html.vue"]]);
export {
  frontend_html as default
};
