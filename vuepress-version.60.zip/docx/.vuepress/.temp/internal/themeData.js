export const themeData = JSON.parse("{\"logo\":\"../assets/images/logo.svg\",\"repo\":\"captives/captives.github.io\",\"repoLabel\":\"Captives\",\"docsDir\":\"docx\",\"smoothScroll\":true,\"backToHome\":\"返回Captives\",\"locales\":{\"/\":{\"sidebar\":false,\"editLink\":false,\"selectLanguageText\":\"Captives\",\"selectLanguageName\":\"Captives\"},\"/guide/\":{\"navbar\":[{\"text\":\"帮助\",\"children\":[{\"text\":\"markdown语法\",\"link\":\"/markdown\"},{\"text\":\"markdown语法\",\"link\":\"/markdown\"},{\"text\":\"markdown语法\",\"link\":\"/markdown\"}]}],\"editLink\":true,\"selectLanguageText\":\"学习指南\",\"selectLanguageName\":\"学习指南\"},\"/poetry/\":{\"navbar\":[{\"text\":\"帮助\",\"children\":[{\"text\":\"markdown语法\",\"link\":\"/markdown\"},{\"text\":\"markdown语法\",\"link\":\"/markdown\"},{\"text\":\"markdown语法\",\"link\":\"/markdown\"}]}],\"selectLanguageText\":\"中华古诗词\",\"selectLanguageName\":\"中华古诗词\"}},\"colorMode\":\"auto\",\"colorModeSwitch\":true,\"navbar\":[],\"selectLanguageText\":\"Languages\",\"selectLanguageAriaLabel\":\"Select language\",\"sidebar\":\"auto\",\"sidebarDepth\":2,\"editLink\":true,\"editLinkText\":\"Edit this page\",\"lastUpdated\":true,\"lastUpdatedText\":\"Last Updated\",\"contributors\":true,\"contributorsText\":\"Contributors\",\"notFound\":[\"There's nothing here.\",\"How did we get here?\",\"That's a Four-Oh-Four.\",\"Looks like we've got some broken links.\"],\"openInNewWindow\":\"open in new window\",\"toggleColorMode\":\"toggle color mode\",\"toggleSidebar\":\"toggle sidebar\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateThemeData) {
    __VUE_HMR_RUNTIME__.updateThemeData(themeData)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ themeData }) => {
    __VUE_HMR_RUNTIME__.updateThemeData(themeData)
  })
}
