import clientConfig0 from 'F:/github/vuepress-version.60/node_modules/_@vuepress_plugin-active-header-links@2.0.0-beta.60@@vuepress/plugin-active-header-links/lib/client/config.js'
import clientConfig1 from 'F:/github/vuepress-version.60/node_modules/_@vuepress_plugin-back-to-top@2.0.0-beta.60@@vuepress/plugin-back-to-top/lib/client/config.js'
import clientConfig2 from 'F:/github/vuepress-version.60/node_modules/_@vuepress_plugin-external-link-icon@2.0.0-beta.60@@vuepress/plugin-external-link-icon/lib/client/config.js'
import clientConfig3 from 'F:/github/vuepress-version.60/node_modules/_@vuepress_plugin-medium-zoom@2.0.0-beta.60@@vuepress/plugin-medium-zoom/lib/client/config.js'
import clientConfig4 from 'F:/github/vuepress-version.60/node_modules/_@vuepress_plugin-nprogress@2.0.0-beta.60@@vuepress/plugin-nprogress/lib/client/config.js'
import clientConfig5 from 'F:/github/vuepress-version.60/node_modules/_@vuepress_plugin-theme-data@2.0.0-beta.60@@vuepress/plugin-theme-data/lib/client/config.js'
import clientConfig6 from 'F:/github/vuepress-version.60/node_modules/_@vuepress_theme-default@2.0.0-beta.60@@vuepress/theme-default/lib/client/config.js'
import clientConfig7 from 'F:/github/vuepress-version.60/node_modules/_@vuepress_plugin-search@2.0.0-beta.60@@vuepress/plugin-search/lib/client/config.js'
import clientConfig8 from 'F:/github/vuepress-version.60/docx/.vuepress/.temp/register-components/clientConfig.564c5ae0.js'
import clientConfig9 from 'F:/github/vuepress-version.60/docx/.vuepress/client.js'

export const clientConfigs = [
  clientConfig0,
  clientConfig1,
  clientConfig2,
  clientConfig3,
  clientConfig4,
  clientConfig5,
  clientConfig6,
  clientConfig7,
  clientConfig8,
  clientConfig9,
]
