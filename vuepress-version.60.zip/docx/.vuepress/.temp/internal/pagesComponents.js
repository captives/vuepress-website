import { defineAsyncComponent } from 'vue'

export const pagesComponents = {
  // path: /markdown.html
  "v-7fdc6af1": defineAsyncComponent(() => import(/* webpackChunkName: "v-7fdc6af1" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/markdown.html.vue")),
  // path: /
  "v-8daa1a0e": defineAsyncComponent(() => import(/* webpackChunkName: "v-8daa1a0e" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/index.html.vue")),
  // path: /user-profile.html
  "v-077d91b9": defineAsyncComponent(() => import(/* webpackChunkName: "v-077d91b9" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/user-profile.html.vue")),
  // path: /guide/favorites.html
  "v-18a03e64": defineAsyncComponent(() => import(/* webpackChunkName: "v-18a03e64" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/favorites.html.vue")),
  // path: /guide/frontend.html
  "v-5efb549b": defineAsyncComponent(() => import(/* webpackChunkName: "v-5efb549b" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/frontend.html.vue")),
  // path: /guide/getting-started.html
  "v-fb0f0066": defineAsyncComponent(() => import(/* webpackChunkName: "v-fb0f0066" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/getting-started.html.vue")),
  // path: /guide/
  "v-fffb8e28": defineAsyncComponent(() => import(/* webpackChunkName: "v-fffb8e28" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/index.html.vue")),
  // path: /guide/website-learning.html
  "v-e572ed46": defineAsyncComponent(() => import(/* webpackChunkName: "v-e572ed46" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/website-learning.html.vue")),
  // path: /guide/website-resource.html
  "v-2b0c4e6d": defineAsyncComponent(() => import(/* webpackChunkName: "v-2b0c4e6d" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/website-resource.html.vue")),
  // path: /poetry/
  "v-51ef0801": defineAsyncComponent(() => import(/* webpackChunkName: "v-51ef0801" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/poetry/index.html.vue")),
  // path: /guide/interview/js-basic.html
  "v-39fd5df5": defineAsyncComponent(() => import(/* webpackChunkName: "v-39fd5df5" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/interview/js-basic.html.vue")),
  // path: /guide/html5/css.html
  "v-ce4ba1b2": defineAsyncComponent(() => import(/* webpackChunkName: "v-ce4ba1b2" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/html5/css.html.vue")),
  // path: /guide/html5/emoji.html
  "v-03666af8": defineAsyncComponent(() => import(/* webpackChunkName: "v-03666af8" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/html5/emoji.html.vue")),
  // path: /guide/html5/linefeed-br-transform.html
  "v-310216c0": defineAsyncComponent(() => import(/* webpackChunkName: "v-310216c0" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/html5/linefeed-br-transform.html.vue")),
  // path: /guide/html5/mobile-adapter.html
  "v-1f4e1b24": defineAsyncComponent(() => import(/* webpackChunkName: "v-1f4e1b24" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/html5/mobile-adapter.html.vue")),
  // path: /guide/html5/print.html
  "v-4c3bff06": defineAsyncComponent(() => import(/* webpackChunkName: "v-4c3bff06" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/html5/print.html.vue")),
  // path: /guide/html5/
  "v-6076b11e": defineAsyncComponent(() => import(/* webpackChunkName: "v-6076b11e" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/html5/index.html.vue")),
  // path: /guide/html5/regex.html
  "v-d41799ba": defineAsyncComponent(() => import(/* webpackChunkName: "v-d41799ba" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/html5/regex.html.vue")),
  // path: /guide/html5/sass.html
  "v-293597cc": defineAsyncComponent(() => import(/* webpackChunkName: "v-293597cc" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/html5/sass.html.vue")),
  // path: /guide/html5/url-decode.html
  "v-665b7688": defineAsyncComponent(() => import(/* webpackChunkName: "v-665b7688" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/html5/url-decode.html.vue")),
  // path: /guide/html5/window-event.html
  "v-5ce3212b": defineAsyncComponent(() => import(/* webpackChunkName: "v-5ce3212b" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/html5/window-event.html.vue")),
  // path: /guide/javascript/async.html
  "v-729a0053": defineAsyncComponent(() => import(/* webpackChunkName: "v-729a0053" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/async.html.vue")),
  // path: /guide/javascript/date-by-week.html
  "v-4cbb61f8": defineAsyncComponent(() => import(/* webpackChunkName: "v-4cbb61f8" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/date-by-week.html.vue")),
  // path: /guide/javascript/download-cros-file.html
  "v-7b50b952": defineAsyncComponent(() => import(/* webpackChunkName: "v-7b50b952" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/download-cros-file.html.vue")),
  // path: /guide/javascript/es6-basic.html
  "v-01eb0886": defineAsyncComponent(() => import(/* webpackChunkName: "v-01eb0886" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/es6-basic.html.vue")),
  // path: /guide/javascript/javascript-address.html
  "v-aea6c5e2": defineAsyncComponent(() => import(/* webpackChunkName: "v-aea6c5e2" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/javascript-address.html.vue")),
  // path: /guide/javascript/javascript-array.html
  "v-fd023f6c": defineAsyncComponent(() => import(/* webpackChunkName: "v-fd023f6c" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/javascript-array.html.vue")),
  // path: /guide/javascript/javascript-binary-tree.html
  "v-3b2cbbd9": defineAsyncComponent(() => import(/* webpackChunkName: "v-3b2cbbd9" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/javascript-binary-tree.html.vue")),
  // path: /guide/javascript/javascript-moment-js.html
  "v-187048e6": defineAsyncComponent(() => import(/* webpackChunkName: "v-187048e6" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/javascript-moment-js.html.vue")),
  // path: /guide/javascript/javascript.html
  "v-b12bee54": defineAsyncComponent(() => import(/* webpackChunkName: "v-b12bee54" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/javascript.html.vue")),
  // path: /guide/javascript/lodash-array.html
  "v-793e4222": defineAsyncComponent(() => import(/* webpackChunkName: "v-793e4222" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/lodash-array.html.vue")),
  // path: /guide/javascript/lodash-collection.html
  "v-20db5239": defineAsyncComponent(() => import(/* webpackChunkName: "v-20db5239" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/lodash-collection.html.vue")),
  // path: /guide/javascript/lodash-function.html
  "v-0e480e82": defineAsyncComponent(() => import(/* webpackChunkName: "v-0e480e82" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/lodash-function.html.vue")),
  // path: /guide/javascript/lodash-map.html
  "v-3e3c917f": defineAsyncComponent(() => import(/* webpackChunkName: "v-3e3c917f" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/lodash-map.html.vue")),
  // path: /guide/javascript/lodash-math.html
  "v-869e1ae2": defineAsyncComponent(() => import(/* webpackChunkName: "v-869e1ae2" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/lodash-math.html.vue")),
  // path: /guide/javascript/lodash-number.html
  "v-2736b124": defineAsyncComponent(() => import(/* webpackChunkName: "v-2736b124" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/lodash-number.html.vue")),
  // path: /guide/javascript/lodash-seq.html
  "v-fa5d3748": defineAsyncComponent(() => import(/* webpackChunkName: "v-fa5d3748" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/lodash-seq.html.vue")),
  // path: /guide/javascript/lodash-string.html
  "v-6663dfa6": defineAsyncComponent(() => import(/* webpackChunkName: "v-6663dfa6" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/lodash-string.html.vue")),
  // path: /guide/javascript/lodash-utils.html
  "v-4c40daca": defineAsyncComponent(() => import(/* webpackChunkName: "v-4c40daca" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/javascript/lodash-utils.html.vue")),
  // path: /guide/linux/docker-basic.html
  "v-6afd4071": defineAsyncComponent(() => import(/* webpackChunkName: "v-6afd4071" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/linux/docker-basic.html.vue")),
  // path: /guide/linux/go-basic.html
  "v-0b009929": defineAsyncComponent(() => import(/* webpackChunkName: "v-0b009929" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/linux/go-basic.html.vue")),
  // path: /guide/linux/ubuntu-config-git.html
  "v-12734c1a": defineAsyncComponent(() => import(/* webpackChunkName: "v-12734c1a" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/linux/ubuntu-config-git.html.vue")),
  // path: /guide/linux/version.html
  "v-775863b0": defineAsyncComponent(() => import(/* webpackChunkName: "v-775863b0" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/linux/version.html.vue")),
  // path: /guide/linux/vscode-guide.html
  "v-190bb819": defineAsyncComponent(() => import(/* webpackChunkName: "v-190bb819" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/linux/vscode-guide.html.vue")),
  // path: /guide/nodejs/ffmpeg.html
  "v-0482165c": defineAsyncComponent(() => import(/* webpackChunkName: "v-0482165c" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/nodejs/ffmpeg.html.vue")),
  // path: /guide/nodejs/inquirer.js.html
  "v-1b64d3b9": defineAsyncComponent(() => import(/* webpackChunkName: "v-1b64d3b9" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/nodejs/inquirer.js.html.vue")),
  // path: /guide/nodejs/nodejs-install.html
  "v-13af5c88": defineAsyncComponent(() => import(/* webpackChunkName: "v-13af5c88" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/nodejs/nodejs-install.html.vue")),
  // path: /guide/nodejs/publish-project-to-npm.html
  "v-2b0cba16": defineAsyncComponent(() => import(/* webpackChunkName: "v-2b0cba16" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/nodejs/publish-project-to-npm.html.vue")),
  // path: /guide/nodejs/rsa-symmetric-encryption.html
  "v-5ffcac0a": defineAsyncComponent(() => import(/* webpackChunkName: "v-5ffcac0a" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/nodejs/rsa-symmetric-encryption.html.vue")),
  // path: /guide/other/%E4%B8%8B%E8%BD%BDbilibili%E8%A7%86%E9%A2%91.html
  "v-58efd6f6": defineAsyncComponent(() => import(/* webpackChunkName: "v-58efd6f6" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/other/下载bilibili视频.html.vue")),
  // path: /guide/typescript/get-started.html
  "v-5b5ac426": defineAsyncComponent(() => import(/* webpackChunkName: "v-5b5ac426" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/typescript/get-started.html.vue")),
  // path: /guide/vue/nuxt-study-notes.html
  "v-bfca68de": defineAsyncComponent(() => import(/* webpackChunkName: "v-bfca68de" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/vue/nuxt-study-notes.html.vue")),
  // path: /guide/vue/
  "v-5d496b56": defineAsyncComponent(() => import(/* webpackChunkName: "v-5d496b56" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/vue/index.html.vue")),
  // path: /guide/vue/reference.html
  "v-b6962bfa": defineAsyncComponent(() => import(/* webpackChunkName: "v-b6962bfa" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/vue/reference.html.vue")),
  // path: /guide/vue/vue-basic.html
  "v-265c7da7": defineAsyncComponent(() => import(/* webpackChunkName: "v-265c7da7" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/vue/vue-basic.html.vue")),
  // path: /guide/vue/vue-event.html
  "v-b7f1fa8a": defineAsyncComponent(() => import(/* webpackChunkName: "v-b7f1fa8a" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/vue/vue-event.html.vue")),
  // path: /guide/vue/vue-model.html
  "v-325908e8": defineAsyncComponent(() => import(/* webpackChunkName: "v-325908e8" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/vue/vue-model.html.vue")),
  // path: /guide/vue/vue-props.html
  "v-490081a5": defineAsyncComponent(() => import(/* webpackChunkName: "v-490081a5" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/vue/vue-props.html.vue")),
  // path: /guide/vue/vue3-composition-api.html
  "v-43e0e56d": defineAsyncComponent(() => import(/* webpackChunkName: "v-43e0e56d" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/vue/vue3-composition-api.html.vue")),
  // path: /guide/vue/vue3-study-notes.html
  "v-4f9a6732": defineAsyncComponent(() => import(/* webpackChunkName: "v-4f9a6732" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/vue/vue3-study-notes.html.vue")),
  // path: /guide/webrtc/
  "v-281db8d6": defineAsyncComponent(() => import(/* webpackChunkName: "v-281db8d6" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/webrtc/index.html.vue")),
  // path: /guide/vue/hooks/timer.html
  "v-025b70c8": defineAsyncComponent(() => import(/* webpackChunkName: "v-025b70c8" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/guide/vue/hooks/timer.html.vue")),
  // path: /404.html
  "v-3706649a": defineAsyncComponent(() => import(/* webpackChunkName: "v-3706649a" */"F:/github/vuepress-version.60/docx/.vuepress/.temp/pages/404.html.vue")),
}
