export const searchIndex = [
  {
    "title": "Markdown 样式模板",
    "headers": [
      {
        "level": 1,
        "title": "样式模板",
        "slug": "样式模板",
        "link": "#样式模板",
        "children": [
          {
            "level": 2,
            "title": "目录",
            "slug": "目录",
            "link": "#目录",
            "children": []
          },
          {
            "level": 2,
            "title": "标题",
            "slug": "标题",
            "link": "#标题",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "标题1",
        "slug": "标题1",
        "link": "#标题1",
        "children": []
      },
      {
        "level": 1,
        "title": "标题1",
        "slug": "标题1-1",
        "link": "#标题1-1",
        "children": [
          {
            "level": 2,
            "title": "标题2",
            "slug": "标题2",
            "link": "#标题2",
            "children": []
          },
          {
            "level": 2,
            "title": "标题2",
            "slug": "标题2-1",
            "link": "#标题2-1",
            "children": [
              {
                "level": 3,
                "title": "标题3",
                "slug": "标题3",
                "link": "#标题3",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "粗体",
            "slug": "粗体",
            "link": "#粗体",
            "children": []
          },
          {
            "level": 2,
            "title": "斜体",
            "slug": "斜体",
            "link": "#斜体",
            "children": []
          },
          {
            "level": 2,
            "title": "标记",
            "slug": "标记",
            "link": "#标记",
            "children": []
          },
          {
            "level": 2,
            "title": "上下角标",
            "slug": "上下角标",
            "link": "#上下角标",
            "children": []
          },
          {
            "level": 2,
            "title": "下划线,中划线",
            "slug": "下划线-中划线",
            "link": "#下划线-中划线",
            "children": []
          },
          {
            "level": 2,
            "title": "分割线",
            "slug": "分割线",
            "link": "#分割线",
            "children": []
          },
          {
            "level": 2,
            "title": "链接",
            "slug": "链接",
            "link": "#链接",
            "children": []
          },
          {
            "level": 2,
            "title": "有序列表",
            "slug": "有序列表",
            "link": "#有序列表",
            "children": []
          },
          {
            "level": 2,
            "title": "无序列表",
            "slug": "无序列表",
            "link": "#无序列表",
            "children": []
          },
          {
            "level": 2,
            "title": "任务清单",
            "slug": "任务清单",
            "link": "#任务清单",
            "children": []
          },
          {
            "level": 2,
            "title": "段落引用",
            "slug": "段落引用",
            "link": "#段落引用",
            "children": []
          },
          {
            "level": 2,
            "title": "容器语法",
            "slug": "容器语法",
            "link": "#容器语法",
            "children": []
          },
          {
            "level": 2,
            "title": "折叠块",
            "slug": "折叠块",
            "link": "#折叠块",
            "children": []
          },
          {
            "level": 2,
            "title": "代码",
            "slug": "代码",
            "link": "#代码",
            "children": [
              {
                "level": 3,
                "title": "代码高亮行",
                "slug": "代码高亮行",
                "link": "#代码高亮行",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "导入代码块",
            "slug": "导入代码块",
            "link": "#导入代码块",
            "children": []
          },
          {
            "level": 2,
            "title": "表格",
            "slug": "表格",
            "link": "#表格",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "Vue 语法",
        "slug": "vue-语法",
        "link": "#vue-语法",
        "children": [
          {
            "level": 2,
            "title": "Vue表达式",
            "slug": "vue表达式",
            "link": "#vue表达式",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue模块",
            "slug": "vue模块",
            "link": "#vue模块",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue 模块内Sass语法",
            "slug": "vue-模块内sass语法",
            "link": "#vue-模块内sass语法",
            "children": []
          },
          {
            "level": 2,
            "title": "注释",
            "slug": "注释",
            "link": "#注释",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "分组",
        "slug": "分组",
        "link": "#分组",
        "children": [
          {
            "level": 2,
            "title": "代码组合",
            "slug": "代码组合",
            "link": "#代码组合",
            "children": []
          },
          {
            "level": 2,
            "title": "HTML分组",
            "slug": "html分组",
            "link": "#html分组",
            "children": []
          },
          {
            "level": 2,
            "title": "Frontmatter",
            "slug": "frontmatter",
            "link": "#frontmatter",
            "children": [
              {
                "level": 3,
                "title": "cover",
                "slug": "cover",
                "link": "#cover",
                "children": []
              },
              {
                "level": 3,
                "title": "cover-fit/coverFit",
                "slug": "cover-fit-coverfit",
                "link": "#cover-fit-coverfit",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "高级配置",
            "slug": "高级配置",
            "link": "#高级配置",
            "children": [
              {
                "level": 3,
                "title": "Vue环境变量",
                "slug": "vue环境变量",
                "link": "#vue环境变量",
                "children": []
              },
              {
                "level": 3,
                "title": "路径别名",
                "slug": "路径别名",
                "link": "#路径别名",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/markdown.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/user-profile.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "收藏夹",
    "headers": [
      {
        "level": 1,
        "title": "收藏夹",
        "slug": "收藏夹",
        "link": "#收藏夹",
        "children": []
      },
      {
        "level": 1,
        "title": "工具类",
        "slug": "工具类",
        "link": "#工具类",
        "children": [
          {
            "level": 2,
            "title": "网站图标生成器",
            "slug": "网站图标生成器",
            "link": "#网站图标生成器",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue 2 生态相关",
            "slug": "vue-2-生态相关",
            "link": "#vue-2-生态相关",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue 3 生态相关",
            "slug": "vue-3-生态相关",
            "link": "#vue-3-生态相关",
            "children": []
          },
          {
            "level": 2,
            "title": "PPT模板下载站点",
            "slug": "ppt模板下载站点",
            "link": "#ppt模板下载站点",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/favorites.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "优秀学习资源",
    "headers": [
      {
        "level": 1,
        "title": "优秀学习资源",
        "slug": "优秀学习资源",
        "link": "#优秀学习资源",
        "children": [
          {
            "level": 2,
            "title": "常用前端库",
            "slug": "常用前端库",
            "link": "#常用前端库",
            "children": [
              {
                "level": 3,
                "title": "xtermjs",
                "slug": "xtermjs",
                "link": "#xtermjs",
                "children": []
              },
              {
                "level": 3,
                "title": "webssh",
                "slug": "webssh",
                "link": "#webssh",
                "children": []
              },
              {
                "level": 3,
                "title": "handlebars",
                "slug": "handlebars",
                "link": "#handlebars",
                "children": []
              },
              {
                "level": 3,
                "title": "Metalsmith",
                "slug": "metalsmith",
                "link": "#metalsmith",
                "children": []
              },
              {
                "level": 3,
                "title": "fullcalendar",
                "slug": "fullcalendar",
                "link": "#fullcalendar",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "优秀博文",
            "slug": "优秀博文",
            "link": "#优秀博文",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/frontend.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "vuepress 入门",
    "headers": [
      {
        "level": 1,
        "title": "vuepress 入门",
        "slug": "vuepress-入门",
        "link": "#vuepress-入门",
        "children": []
      }
    ],
    "path": "/guide/getting-started.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Home",
    "headers": [],
    "path": "/guide/",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue 学习资源收藏",
    "headers": [
      {
        "level": 1,
        "title": "Vue 学习资源收藏",
        "slug": "vue-学习资源收藏",
        "link": "#vue-学习资源收藏",
        "children": [
          {
            "level": 2,
            "title": "Vue 2 生态相关",
            "slug": "vue-2-生态相关",
            "link": "#vue-2-生态相关",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue 3 生态相关",
            "slug": "vue-3-生态相关",
            "link": "#vue-3-生态相关",
            "children": []
          },
          {
            "level": 2,
            "title": "PPT模板下载站点",
            "slug": "ppt模板下载站点",
            "link": "#ppt模板下载站点",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/website-learning.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "开发工具收藏",
    "headers": [
      {
        "level": 1,
        "title": "开发工具收藏",
        "slug": "开发工具收藏",
        "link": "#开发工具收藏",
        "children": [
          {
            "level": 2,
            "title": "常用前端库",
            "slug": "常用前端库",
            "link": "#常用前端库",
            "children": [
              {
                "level": 3,
                "title": "xtermjs",
                "slug": "xtermjs",
                "link": "#xtermjs",
                "children": []
              },
              {
                "level": 3,
                "title": "webssh",
                "slug": "webssh",
                "link": "#webssh",
                "children": []
              },
              {
                "level": 3,
                "title": "handlebars",
                "slug": "handlebars",
                "link": "#handlebars",
                "children": []
              },
              {
                "level": 3,
                "title": "Metalsmith",
                "slug": "metalsmith",
                "link": "#metalsmith",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "后端",
            "slug": "后端",
            "link": "#后端",
            "children": []
          },
          {
            "level": 2,
            "title": "前端",
            "slug": "前端",
            "link": "#前端",
            "children": []
          },
          {
            "level": 2,
            "title": "工具",
            "slug": "工具",
            "link": "#工具",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/website-resource.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/poetry/",
    "pathLocale": "/poetry/",
    "extraFields": []
  },
  {
    "title": "JavaScript 知识点",
    "headers": [
      {
        "level": 1,
        "title": "JavaScript 知识点",
        "slug": "javascript-知识点",
        "link": "#javascript-知识点",
        "children": [
          {
            "level": 2,
            "title": "基础部分",
            "slug": "基础部分",
            "link": "#基础部分",
            "children": [
              {
                "level": 3,
                "title": "js有哪些内置对象？",
                "slug": "js有哪些内置对象",
                "link": "#js有哪些内置对象",
                "children": []
              },
              {
                "level": 3,
                "title": "js有哪些数据类型",
                "slug": "js有哪些数据类型",
                "link": "#js有哪些数据类型",
                "children": []
              },
              {
                "level": 3,
                "title": "JavaScript有几种类型的值",
                "slug": "javascript有几种类型的值",
                "link": "#javascript有几种类型的值",
                "children": []
              },
              {
                "level": 3,
                "title": "栈和堆的区别",
                "slug": "栈和堆的区别",
                "link": "#栈和堆的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "undefined 和 null 区别",
                "slug": "undefined-和-null-区别",
                "link": "#undefined-和-null-区别",
                "children": []
              },
              {
                "level": 3,
                "title": "对this的理解",
                "slug": "对this的理解",
                "link": "#对this的理解",
                "children": []
              },
              {
                "level": 3,
                "title": "if语句有作用域吗?",
                "slug": "if语句有作用域吗",
                "link": "#if语句有作用域吗",
                "children": []
              },
              {
                "level": 3,
                "title": "原型链和作用域链的区别",
                "slug": "原型链和作用域链的区别",
                "link": "#原型链和作用域链的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "js 判断对象类型(typeof、instanceOf)区别",
                "slug": "js-判断对象类型-typeof、instanceof-区别",
                "link": "#js-判断对象类型-typeof、instanceof-区别",
                "children": []
              },
              {
                "level": 3,
                "title": "普通函数和箭头函数的区别",
                "slug": "普通函数和箭头函数的区别",
                "link": "#普通函数和箭头函数的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "document.write和document.innerHTML的区别",
                "slug": "document-write和document-innerhtml的区别",
                "link": "#document-write和document-innerhtml的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "bind、call、apply的区别",
                "slug": "bind、call、apply的区别",
                "link": "#bind、call、apply的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "eval()计算函数",
                "slug": "eval-计算函数",
                "link": "#eval-计算函数",
                "children": []
              },
              {
                "level": 3,
                "title": "JS哪些操作会造成内存泄露",
                "slug": "js哪些操作会造成内存泄露",
                "link": "#js哪些操作会造成内存泄露",
                "children": []
              },
              {
                "level": 3,
                "title": "什么是闭包，如何使用它，为什么要使用它？",
                "slug": "什么是闭包-如何使用它-为什么要使用它",
                "link": "#什么是闭包-如何使用它-为什么要使用它",
                "children": []
              },
              {
                "level": 3,
                "title": "请解释JSONP的工作原理，以及它为什么不是真正的AJAX",
                "slug": "请解释jsonp的工作原理-以及它为什么不是真正的ajax",
                "link": "#请解释jsonp的工作原理-以及它为什么不是真正的ajax",
                "children": []
              },
              {
                "level": 3,
                "title": "请解释一下JavaScript的同源策略",
                "slug": "请解释一下javascript的同源策略",
                "link": "#请解释一下javascript的同源策略",
                "children": []
              },
              {
                "level": 3,
                "title": "介绍暂时性死区",
                "slug": "介绍暂时性死区",
                "link": "#介绍暂时性死区",
                "children": []
              },
              {
                "level": 3,
                "title": "两个对象如何比较",
                "slug": "两个对象如何比较",
                "link": "#两个对象如何比较",
                "children": []
              },
              {
                "level": 3,
                "title": "Promise和Async处理失败的时候有什么区别",
                "slug": "promise和async处理失败的时候有什么区别",
                "link": "#promise和async处理失败的时候有什么区别",
                "children": []
              },
              {
                "level": 3,
                "title": "setTimeout(0)和setTimeout(2)之间的区别",
                "slug": "settimeout-0-和settimeout-2-之间的区别",
                "link": "#settimeout-0-和settimeout-2-之间的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "for..in和object.keys的区别",
                "slug": "for-in和object-keys的区别",
                "link": "#for-in和object-keys的区别",
                "children": []
              },
              {
                "level": 3,
                "title": "说说你对AMD和Commonjs的理解",
                "slug": "说说你对amd和commonjs的理解",
                "link": "#说说你对amd和commonjs的理解",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "看代码，给结果",
            "slug": "看代码-给结果",
            "link": "#看代码-给结果",
            "children": [
              {
                "level": 3,
                "title": "1. 写出如下代码的打印结果",
                "slug": "_1-写出如下代码的打印结果",
                "link": "#_1-写出如下代码的打印结果",
                "children": []
              },
              {
                "level": 3,
                "title": "2. 输出以下代码运行结果",
                "slug": "_2-输出以下代码运行结果",
                "link": "#_2-输出以下代码运行结果",
                "children": []
              },
              {
                "level": 3,
                "title": "3. [\"1\", \"2\", \"3\"].map(parseInt) 答案是多少？",
                "slug": "_3-1-2-3-map-parseint-答案是多少",
                "link": "#_3-1-2-3-map-parseint-答案是多少",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "扩展",
            "slug": "扩展",
            "link": "#扩展",
            "children": [
              {
                "level": 3,
                "title": "js设计模式",
                "slug": "js设计模式",
                "link": "#js设计模式",
                "children": []
              },
              {
                "level": 3,
                "title": "常见兼容性问题？",
                "slug": "常见兼容性问题",
                "link": "#常见兼容性问题",
                "children": []
              },
              {
                "level": 3,
                "title": "JS为什么要区分微任务和宏任务",
                "slug": "js为什么要区分微任务和宏任务",
                "link": "#js为什么要区分微任务和宏任务",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/interview/js-basic.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "CSS 使用笔记",
    "headers": [
      {
        "level": 1,
        "title": "CSS 使用笔记",
        "slug": "css-使用笔记",
        "link": "#css-使用笔记",
        "children": [
          {
            "level": 2,
            "title": "CSS 语法",
            "slug": "css-语法",
            "link": "#css-语法",
            "children": [
              {
                "level": 3,
                "title": "语法",
                "slug": "语法",
                "link": "#语法",
                "children": []
              },
              {
                "level": 3,
                "title": "分组",
                "slug": "分组",
                "link": "#分组",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "CSS 选择器",
            "slug": "css-选择器",
            "link": "#css-选择器",
            "children": [
              {
                "level": 3,
                "title": "全局选择器",
                "slug": "全局选择器",
                "link": "#全局选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "元素选择器",
                "slug": "元素选择器",
                "link": "#元素选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "派生选择器",
                "slug": "派生选择器",
                "link": "#派生选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "id选择器",
                "slug": "id选择器",
                "link": "#id选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "类选择器",
                "slug": "类选择器",
                "link": "#类选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "属性选择器",
                "slug": "属性选择器",
                "link": "#属性选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "后代选择器",
                "slug": "后代选择器",
                "link": "#后代选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "子元素选择器 >",
                "slug": "子元素选择器",
                "link": "#子元素选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "相邻兄弟选择器 +",
                "slug": "相邻兄弟选择器",
                "link": "#相邻兄弟选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "同层全体组合选择器~",
                "slug": "同层全体组合选择器",
                "link": "#同层全体组合选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "伪类选择器",
                "slug": "伪类选择器",
                "link": "#伪类选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "伪元素选择器",
                "slug": "伪元素选择器",
                "link": "#伪元素选择器",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "伪类和伪元素的区别",
            "slug": "伪类和伪元素的区别",
            "link": "#伪类和伪元素的区别",
            "children": []
          },
          {
            "level": 2,
            "title": "文本样式",
            "slug": "文本样式",
            "link": "#文本样式",
            "children": [
              {
                "level": 3,
                "title": "文本颜色",
                "slug": "文本颜色",
                "link": "#文本颜色",
                "children": []
              },
              {
                "level": 3,
                "title": "文本阴影",
                "slug": "文本阴影",
                "link": "#文本阴影",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/html5/css.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [
      {
        "level": 2,
        "title": "Emoji",
        "slug": "emoji",
        "link": "#emoji",
        "children": []
      },
      {
        "level": 2,
        "title": "常用",
        "slug": "常用",
        "link": "#常用",
        "children": []
      },
      {
        "level": 2,
        "title": "表情",
        "slug": "表情",
        "link": "#表情",
        "children": []
      },
      {
        "level": 2,
        "title": "人类和身体",
        "slug": "人类和身体",
        "link": "#人类和身体",
        "children": []
      },
      {
        "level": 2,
        "title": "动物和自然",
        "slug": "动物和自然",
        "link": "#动物和自然",
        "children": []
      },
      {
        "level": 2,
        "title": "食物和饮料",
        "slug": "食物和饮料",
        "link": "#食物和饮料",
        "children": []
      },
      {
        "level": 2,
        "title": "旅行和地点",
        "slug": "旅行和地点",
        "link": "#旅行和地点",
        "children": []
      },
      {
        "level": 2,
        "title": "活动",
        "slug": "活动",
        "link": "#活动",
        "children": []
      },
      {
        "level": 2,
        "title": "物品",
        "slug": "物品",
        "link": "#物品",
        "children": []
      },
      {
        "level": 2,
        "title": "符号",
        "slug": "符号",
        "link": "#符号",
        "children": []
      }
    ],
    "path": "/guide/html5/emoji.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "\\n 和 <br/> 互转",
    "headers": [
      {
        "level": 1,
        "title": "\\n 和 <br/> 互转",
        "slug": "n-和-br-互转",
        "link": "#n-和-br-互转",
        "children": []
      }
    ],
    "path": "/guide/html5/linefeed-br-transform.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "移动端适配处理",
    "headers": [
      {
        "level": 1,
        "title": "移动端适配处理",
        "slug": "移动端适配处理",
        "link": "#移动端适配处理",
        "children": []
      }
    ],
    "path": "/guide/html5/mobile-adapter.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Web打印处理",
    "headers": [
      {
        "level": 1,
        "title": "Web打印处理",
        "slug": "web打印处理",
        "link": "#web打印处理",
        "children": [
          {
            "level": 2,
            "title": "打印",
            "slug": "打印",
            "link": "#打印",
            "children": []
          },
          {
            "level": 2,
            "title": "监听事件",
            "slug": "监听事件",
            "link": "#监听事件",
            "children": []
          },
          {
            "level": 2,
            "title": "样式",
            "slug": "样式",
            "link": "#样式",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/html5/print.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [
      {
        "level": 2,
        "title": "Web API",
        "slug": "web-api",
        "link": "#web-api",
        "children": []
      }
    ],
    "path": "/guide/html5/",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "常用正则表达语句",
    "headers": [
      {
        "level": 1,
        "title": "常用正则表达语句",
        "slug": "常用正则表达语句",
        "link": "#常用正则表达语句",
        "children": [
          {
            "level": 2,
            "title": "高亮段落内关键字",
            "slug": "高亮段落内关键字",
            "link": "#高亮段落内关键字",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/html5/regex.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Sass 使用笔记",
    "headers": [
      {
        "level": 1,
        "title": "Sass 使用笔记",
        "slug": "sass-使用笔记",
        "link": "#sass-使用笔记",
        "children": [
          {
            "level": 2,
            "title": "快速开始",
            "slug": "快速开始",
            "link": "#快速开始",
            "children": [
              {
                "level": 3,
                "title": "安装(Install)",
                "slug": "安装-install",
                "link": "#安装-install",
                "children": []
              },
              {
                "level": 3,
                "title": "预处理(Preprocessing)",
                "slug": "预处理-preprocessing",
                "link": "#预处理-preprocessing",
                "children": []
              },
              {
                "level": 3,
                "title": "注释(Annotation)",
                "slug": "注释-annotation",
                "link": "#注释-annotation",
                "children": []
              },
              {
                "level": 3,
                "title": "调试",
                "slug": "调试",
                "link": "#调试",
                "children": []
              },
              {
                "level": 3,
                "title": "数据类型 (Data Types",
                "slug": "数据类型-data-types",
                "link": "#数据类型-data-types",
                "children": []
              },
              {
                "level": 3,
                "title": "变量(Variables)$",
                "slug": "变量-variables",
                "link": "#变量-variables",
                "children": []
              },
              {
                "level": 3,
                "title": "选择器",
                "slug": "选择器",
                "link": "#选择器",
                "children": []
              },
              {
                "level": 3,
                "title": "嵌套(Nesting)",
                "slug": "嵌套-nesting",
                "link": "#嵌套-nesting",
                "children": []
              },
              {
                "level": 3,
                "title": "片段(Partials)",
                "slug": "片段-partials",
                "link": "#片段-partials",
                "children": []
              },
              {
                "level": 3,
                "title": "模块(Modules)",
                "slug": "模块-modules",
                "link": "#模块-modules",
                "children": []
              },
              {
                "level": 3,
                "title": "混合(Mixins)",
                "slug": "混合-mixins",
                "link": "#混合-mixins",
                "children": []
              },
              {
                "level": 3,
                "title": "扩展(Extend)和继承(Inheritance)",
                "slug": "扩展-extend-和继承-inheritance",
                "link": "#扩展-extend-和继承-inheritance",
                "children": []
              },
              {
                "level": 3,
                "title": "运算(Operators)",
                "slug": "运算-operators",
                "link": "#运算-operators",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "控制指令(Control Directives)",
            "slug": "控制指令-control-directives",
            "link": "#控制指令-control-directives",
            "children": [
              {
                "level": 3,
                "title": "条件语句@if、@else if、@else",
                "slug": "条件语句-if、-else-if、-else",
                "link": "#条件语句-if、-else-if、-else",
                "children": []
              },
              {
                "level": 3,
                "title": "循环语句 for、while、each",
                "slug": "循环语句-for、while、each",
                "link": "#循环语句-for、while、each",
                "children": []
              },
              {
                "level": 3,
                "title": "自定义函数function",
                "slug": "自定义函数function",
                "link": "#自定义函数function",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "内置",
            "slug": "内置",
            "link": "#内置",
            "children": [
              {
                "level": 3,
                "title": "模块(Modules)",
                "slug": "模块-modules-1",
                "link": "#模块-modules-1",
                "children": []
              },
              {
                "level": 3,
                "title": "全局函数(Function)",
                "slug": "全局函数-function",
                "link": "#全局函数-function",
                "children": []
              },
              {
                "level": 3,
                "title": "HSL/HSLA",
                "slug": "hsl-hsla",
                "link": "#hsl-hsla",
                "children": []
              },
              {
                "level": 3,
                "title": "RGB/RGBA",
                "slug": "rgb-rgba",
                "link": "#rgb-rgba",
                "children": []
              },
              {
                "level": 3,
                "title": "内置颜色函数",
                "slug": "内置颜色函数",
                "link": "#内置颜色函数",
                "children": []
              },
              {
                "level": 3,
                "title": "IF",
                "slug": "if",
                "link": "#if",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/html5/sass.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "url 编解码",
    "headers": [
      {
        "level": 1,
        "title": "url 编解码",
        "slug": "url-编解码",
        "link": "#url-编解码",
        "children": []
      }
    ],
    "path": "/guide/html5/url-decode.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "window 浏览器页面事件",
    "headers": [
      {
        "level": 1,
        "title": "window 浏览器页面事件",
        "slug": "window-浏览器页面事件",
        "link": "#window-浏览器页面事件",
        "children": [
          {
            "level": 2,
            "title": "浏览器选项卡获取焦点和失去焦点",
            "slug": "浏览器选项卡获取焦点和失去焦点",
            "link": "#浏览器选项卡获取焦点和失去焦点",
            "children": []
          },
          {
            "level": 2,
            "title": "浏览器选项卡关闭",
            "slug": "浏览器选项卡关闭",
            "link": "#浏览器选项卡关闭",
            "children": []
          },
          {
            "level": 2,
            "title": "页面开始打印/打印结束后事件",
            "slug": "页面开始打印-打印结束后事件",
            "link": "#页面开始打印-打印结束后事件",
            "children": []
          },
          {
            "level": 2,
            "title": "其它页面更改存储触发",
            "slug": "其它页面更改存储触发",
            "link": "#其它页面更改存储触发",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/html5/window-event.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "async",
    "headers": [
      {
        "level": 1,
        "title": "async",
        "slug": "async",
        "link": "#async",
        "children": [
          {
            "level": 3,
            "title": "内容",
            "slug": "内容",
            "link": "#内容",
            "children": []
          },
          {
            "level": 3,
            "title": "安装",
            "slug": "安装",
            "link": "#安装",
            "children": []
          },
          {
            "level": 3,
            "title": "流程控制",
            "slug": "流程控制",
            "link": "#流程控制",
            "children": []
          },
          {
            "level": 3,
            "title": "Collections集合",
            "slug": "collections集合",
            "link": "#collections集合",
            "children": []
          },
          {
            "level": 3,
            "title": "mapValues",
            "slug": "mapvalues",
            "link": "#mapvalues",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/async.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "日月周时间段处理",
    "headers": [
      {
        "level": 1,
        "title": "日月周时间段处理",
        "slug": "日月周时间段处理",
        "link": "#日月周时间段处理",
        "children": []
      }
    ],
    "path": "/guide/javascript/date-by-week.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "js跨域资源下载",
    "headers": [
      {
        "level": 1,
        "title": "js跨域资源下载",
        "slug": "js跨域资源下载",
        "link": "#js跨域资源下载",
        "children": []
      }
    ],
    "path": "/guide/javascript/download-cros-file.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "ES6 学习笔记",
    "headers": [
      {
        "level": 1,
        "title": "ES6 学习笔记",
        "slug": "es6-学习笔记",
        "link": "#es6-学习笔记",
        "children": [
          {
            "level": 2,
            "title": "符号",
            "slug": "符号",
            "link": "#符号",
            "children": []
          },
          {
            "level": 2,
            "title": "运算符",
            "slug": "运算符",
            "link": "#运算符",
            "children": [
              {
                "level": 3,
                "title": "按位取反运算符~",
                "slug": "按位取反运算符",
                "link": "#按位取反运算符",
                "children": []
              },
              {
                "level": 3,
                "title": "求幂表达式 **",
                "slug": "求幂表达式",
                "link": "#求幂表达式",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "var/let/const",
            "slug": "var-let-const",
            "link": "#var-let-const",
            "children": []
          },
          {
            "level": 2,
            "title": "对象解构",
            "slug": "对象解构",
            "link": "#对象解构",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/es6-basic.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "省市区联动",
    "headers": [
      {
        "level": 1,
        "title": "省市区联动",
        "slug": "省市区联动",
        "link": "#省市区联动",
        "children": [
          {
            "level": 2,
            "title": "省市区数据添加头[全部]",
            "slug": "省市区数据添加头-全部",
            "link": "#省市区数据添加头-全部",
            "children": []
          },
          {
            "level": 2,
            "title": "省市区移除【全国/全部】项",
            "slug": "省市区移除【全国-全部】项",
            "link": "#省市区移除【全国-全部】项",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/javascript-address.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "数组 Array",
    "headers": [
      {
        "level": 1,
        "title": "数组 Array",
        "slug": "数组-array",
        "link": "#数组-array",
        "children": [
          {
            "level": 2,
            "title": "基础",
            "slug": "基础",
            "link": "#基础",
            "children": [
              {
                "level": 3,
                "title": "求最大/小值",
                "slug": "求最大-小值",
                "link": "#求最大-小值",
                "children": []
              },
              {
                "level": 3,
                "title": "map",
                "slug": "map",
                "link": "#map",
                "children": []
              },
              {
                "level": 3,
                "title": "reduce",
                "slug": "reduce",
                "link": "#reduce",
                "children": []
              },
              {
                "level": 3,
                "title": "filter",
                "slug": "filter",
                "link": "#filter",
                "children": []
              },
              {
                "level": 3,
                "title": "sort",
                "slug": "sort",
                "link": "#sort",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "数据交换",
            "slug": "数据交换",
            "link": "#数据交换",
            "children": [
              {
                "level": 3,
                "title": "普通做法",
                "slug": "普通做法",
                "link": "#普通做法",
                "children": []
              },
              {
                "level": 3,
                "title": "算术运算",
                "slug": "算术运算",
                "link": "#算术运算",
                "children": []
              },
              {
                "level": 3,
                "title": "数组方式",
                "slug": "数组方式",
                "link": "#数组方式",
                "children": []
              },
              {
                "level": 3,
                "title": "对象方式",
                "slug": "对象方式",
                "link": "#对象方式",
                "children": []
              },
              {
                "level": 3,
                "title": "ES6解构",
                "slug": "es6解构",
                "link": "#es6解构",
                "children": []
              },
              {
                "level": 3,
                "title": "异或操作",
                "slug": "异或操作",
                "link": "#异或操作",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "排序",
            "slug": "排序",
            "link": "#排序",
            "children": []
          },
          {
            "level": 2,
            "title": "删除、去重",
            "slug": "删除、去重",
            "link": "#删除、去重",
            "children": [
              {
                "level": 3,
                "title": "正序去重复",
                "slug": "正序去重复",
                "link": "#正序去重复",
                "children": []
              },
              {
                "level": 3,
                "title": "倒序去重复",
                "slug": "倒序去重复",
                "link": "#倒序去重复",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "排序",
            "slug": "排序-1",
            "link": "#排序-1",
            "children": [
              {
                "level": 3,
                "title": "普通排序(Sort)",
                "slug": "普通排序-sort",
                "link": "#普通排序-sort",
                "children": []
              },
              {
                "level": 3,
                "title": "冒泡排序(Bubble Sort)",
                "slug": "冒泡排序-bubble-sort",
                "link": "#冒泡排序-bubble-sort",
                "children": []
              },
              {
                "level": 3,
                "title": "选择排序(Selection Sort)",
                "slug": "选择排序-selection-sort",
                "link": "#选择排序-selection-sort",
                "children": []
              },
              {
                "level": 3,
                "title": "插入排序(Insertion Sort)",
                "slug": "插入排序-insertion-sort",
                "link": "#插入排序-insertion-sort",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/javascript-array.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "JavaScript 二叉树",
    "headers": [
      {
        "level": 1,
        "title": "JavaScript 二叉树",
        "slug": "javascript-二叉树",
        "link": "#javascript-二叉树",
        "children": [
          {
            "level": 2,
            "title": "定义",
            "slug": "定义",
            "link": "#定义",
            "children": []
          },
          {
            "level": 2,
            "title": "遍历",
            "slug": "遍历",
            "link": "#遍历",
            "children": []
          },
          {
            "level": 2,
            "title": "创建二叉树",
            "slug": "创建二叉树",
            "link": "#创建二叉树",
            "children": []
          },
          {
            "level": 2,
            "title": "递归遍历",
            "slug": "递归遍历",
            "link": "#递归遍历",
            "children": []
          },
          {
            "level": 2,
            "title": "深度优先遍历",
            "slug": "深度优先遍历",
            "link": "#深度优先遍历",
            "children": []
          },
          {
            "level": 2,
            "title": "广度优先遍历",
            "slug": "广度优先遍历",
            "link": "#广度优先遍历",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/javascript-binary-tree.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Moment.js",
    "headers": [
      {
        "level": 1,
        "title": "Moment.js",
        "slug": "moment-js",
        "link": "#moment-js",
        "children": [
          {
            "level": 2,
            "title": "日期格式化",
            "slug": "日期格式化",
            "link": "#日期格式化",
            "children": []
          },
          {
            "level": 2,
            "title": "相对时间",
            "slug": "相对时间",
            "link": "#相对时间",
            "children": []
          },
          {
            "level": 2,
            "title": "日历时间",
            "slug": "日历时间",
            "link": "#日历时间",
            "children": []
          },
          {
            "level": 2,
            "title": "多语言支持",
            "slug": "多语言支持",
            "link": "#多语言支持",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/javascript-moment-js.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "JavaScript 基础",
    "headers": [
      {
        "level": 1,
        "title": "JavaScript 基础",
        "slug": "javascript-基础",
        "link": "#javascript-基础",
        "children": [
          {
            "level": 3,
            "title": "全局对象属性（三个值、十三个函数）",
            "slug": "全局对象属性-三个值、十三个函数",
            "link": "#全局对象属性-三个值、十三个函数",
            "children": []
          },
          {
            "level": 3,
            "title": "六种异步方案",
            "slug": "六种异步方案",
            "link": "#六种异步方案",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/javascript/javascript.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "lodash 数组 Array",
    "headers": [
      {
        "level": 1,
        "title": "lodash 数组 Array",
        "slug": "lodash-数组-array",
        "link": "#lodash-数组-array",
        "children": [
          {
            "level": 2,
            "title": "检索",
            "slug": "检索",
            "link": "#检索",
            "children": [
              {
                "level": 3,
                "title": "_.indexOf(array, value, [fromIndex = 0])",
                "slug": "indexof-array-value-fromindex-0",
                "link": "#indexof-array-value-fromindex-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.findIndex(array, [predicate = _.identity], [fromIndex=0])",
                "slug": "findindex-array-predicate-identity-fromindex-0",
                "link": "#findindex-array-predicate-identity-fromindex-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.findLastIndex(array, [predicate = _.identity], [fromIndex=array.length-1])",
                "slug": "findlastindex-array-predicate-identity-fromindex-array-length-1",
                "link": "#findlastindex-array-predicate-identity-fromindex-array-length-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.lastIndexOf(array, value, [fromIndex=array.length-1])",
                "slug": "lastindexof-array-value-fromindex-array-length-1",
                "link": "#lastindexof-array-value-fromindex-array-length-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.head(array)",
                "slug": "head-array",
                "link": "#head-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.last(array)",
                "slug": "last-array",
                "link": "#last-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.initial(array)",
                "slug": "initial-array",
                "link": "#initial-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.tail(array)",
                "slug": "tail-array",
                "link": "#tail-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.nth(array, [n=0])",
                "slug": "nth-array-n-0",
                "link": "#nth-array-n-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.take(array, [n=1])",
                "slug": "take-array-n-1",
                "link": "#take-array-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.takeRight(array, [n=1])",
                "slug": "takeright-array-n-1",
                "link": "#takeright-array-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.takeRightWhile(array, [predicate = _.identity])",
                "slug": "takerightwhile-array-predicate-identity",
                "link": "#takerightwhile-array-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.takeWhile(array, [predicate = _.identity])",
                "slug": "takewhile-array-predicate-identity",
                "link": "#takewhile-array-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.slice(array, [start=0], [end=array.length])",
                "slug": "slice-array-start-0-end-array-length",
                "link": "#slice-array-start-0-end-array-length",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "分组",
            "slug": "分组",
            "link": "#分组",
            "children": [
              {
                "level": 3,
                "title": "_.chunk(array, [size=1])",
                "slug": "chunk-array-size-1",
                "link": "#chunk-array-size-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.zip([arrays])",
                "slug": "zip-arrays",
                "link": "#zip-arrays",
                "children": []
              },
              {
                "level": 3,
                "title": "_.unzip(array)",
                "slug": "unzip-array",
                "link": "#unzip-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.zipWith([arrays], [iteratee = _.identity])",
                "slug": "zipwith-arrays-iteratee-identity",
                "link": "#zipwith-arrays-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.unzipWith(array, [iteratee = _.identity])",
                "slug": "unzipwith-array-iteratee-identity",
                "link": "#unzipwith-array-iteratee-identity",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "合并",
            "slug": "合并",
            "link": "#合并",
            "children": [
              {
                "level": 3,
                "title": "_.join(array, [separator=','])",
                "slug": "join-array-separator",
                "link": "#join-array-separator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.concat(array, [values])",
                "slug": "concat-array-values",
                "link": "#concat-array-values",
                "children": []
              },
              {
                "level": 3,
                "title": "_.union([arrays])",
                "slug": "union-arrays",
                "link": "#union-arrays",
                "children": []
              },
              {
                "level": 3,
                "title": "_.unionBy([arrays], [iteratee = _.identity])",
                "slug": "unionby-arrays-iteratee-identity",
                "link": "#unionby-arrays-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.unionWith([arrays], [comparator])",
                "slug": "unionwith-arrays-comparator",
                "link": "#unionwith-arrays-comparator",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "过滤",
            "slug": "过滤",
            "link": "#过滤",
            "children": [
              {
                "level": 3,
                "title": "_.difference(array, [values])",
                "slug": "difference-array-values",
                "link": "#difference-array-values",
                "children": []
              },
              {
                "level": 3,
                "title": "_.differenceBy(array, [values], [iteratee = _.identity])",
                "slug": "differenceby-array-values-iteratee-identity",
                "link": "#differenceby-array-values-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.differenceWith(array, [values], [comparator])",
                "slug": "differencewith-array-values-comparator",
                "link": "#differencewith-array-values-comparator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.compact(array)",
                "slug": "compact-array",
                "link": "#compact-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.intersection([arrays])",
                "slug": "intersection-arrays",
                "link": "#intersection-arrays",
                "children": []
              },
              {
                "level": 3,
                "title": "_.intersectionBy([arrays], [iteratee = _.identity])",
                "slug": "intersectionby-arrays-iteratee-identity",
                "link": "#intersectionby-arrays-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.intersectionWith([arrays], [comparator])",
                "slug": "intersectionwith-arrays-comparator",
                "link": "#intersectionwith-arrays-comparator",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "移除",
            "slug": "移除",
            "link": "#移除",
            "children": [
              {
                "level": 3,
                "title": "_.remove(array, [predicate = _.identity])",
                "slug": "remove-array-predicate-identity",
                "link": "#remove-array-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.drop(array, [n=1])",
                "slug": "drop-array-n-1",
                "link": "#drop-array-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.dropRight(array, [n=1])",
                "slug": "dropright-array-n-1",
                "link": "#dropright-array-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.dropRightWhile(array, [predicate = _.identity])",
                "slug": "droprightwhile-array-predicate-identity",
                "link": "#droprightwhile-array-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.dropWhile(array, [predicate = _.identity])",
                "slug": "dropwhile-array-predicate-identity",
                "link": "#dropwhile-array-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pull(array, [values])",
                "slug": "pull-array-values",
                "link": "#pull-array-values",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pullAll(array, values)",
                "slug": "pullall-array-values",
                "link": "#pullall-array-values",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pullAllBy(array, values, [iteratee = _.identity])",
                "slug": "pullallby-array-values-iteratee-identity",
                "link": "#pullallby-array-values-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pullAllWith(array, values, [comparator])",
                "slug": "pullallwith-array-values-comparator",
                "link": "#pullallwith-array-values-comparator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pullAt(array, [indexes])",
                "slug": "pullat-array-indexes",
                "link": "#pullat-array-indexes",
                "children": []
              },
              {
                "level": 3,
                "title": "_.without(array, [values])",
                "slug": "without-array-values",
                "link": "#without-array-values",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "增加",
            "slug": "增加",
            "link": "#增加",
            "children": [
              {
                "level": 3,
                "title": "_.fill(array, value, [start=0], [end = array.length])",
                "slug": "fill-array-value-start-0-end-array-length",
                "link": "#fill-array-value-start-0-end-array-length",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "排序",
            "slug": "排序",
            "link": "#排序",
            "children": [
              {
                "level": 3,
                "title": "_.sortedIndex(array, value)",
                "slug": "sortedindex-array-value",
                "link": "#sortedindex-array-value",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedIndexBy(array, value, [iteratee = _.identity])",
                "slug": "sortedindexby-array-value-iteratee-identity",
                "link": "#sortedindexby-array-value-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedIndexOf(array, value)",
                "slug": "sortedindexof-array-value",
                "link": "#sortedindexof-array-value",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedLastIndex(array, value)",
                "slug": "sortedlastindex-array-value",
                "link": "#sortedlastindex-array-value",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedLastIndexBy(array, value, [iteratee = _.identity])",
                "slug": "sortedlastindexby-array-value-iteratee-identity",
                "link": "#sortedlastindexby-array-value-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedLastIndexOf(array, value)",
                "slug": "sortedlastindexof-array-value",
                "link": "#sortedlastindexof-array-value",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedUniq(array)",
                "slug": "sorteduniq-array",
                "link": "#sorteduniq-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortedUniqBy(array, [iteratee])",
                "slug": "sorteduniqby-array-iteratee",
                "link": "#sorteduniqby-array-iteratee",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "去重",
            "slug": "去重",
            "link": "#去重",
            "children": [
              {
                "level": 3,
                "title": "_.uniq(array)",
                "slug": "uniq-array",
                "link": "#uniq-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.uniqBy(array, [iteratee = _.identity])",
                "slug": "uniqby-array-iteratee-identity",
                "link": "#uniqby-array-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.uniqWith(array, [comparator])",
                "slug": "uniqwith-array-comparator",
                "link": "#uniqwith-array-comparator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.xor([arrays])",
                "slug": "xor-arrays",
                "link": "#xor-arrays",
                "children": []
              },
              {
                "level": 3,
                "title": "_.xorBy([arrays], [iteratee = _.identity])",
                "slug": "xorby-arrays-iteratee-identity",
                "link": "#xorby-arrays-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.xorWith([arrays], [comparator])",
                "slug": "xorwith-arrays-comparator",
                "link": "#xorwith-arrays-comparator",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "转换",
            "slug": "转换",
            "link": "#转换",
            "children": [
              {
                "level": 3,
                "title": "_.reverse(array)",
                "slug": "reverse-array",
                "link": "#reverse-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.flatten(array)",
                "slug": "flatten-array",
                "link": "#flatten-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.flattenDeep(array)",
                "slug": "flattendeep-array",
                "link": "#flattendeep-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.flattenDepth(array, [depth=1])",
                "slug": "flattendepth-array-depth-1",
                "link": "#flattendepth-array-depth-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.fromPairs(pairs)",
                "slug": "frompairs-pairs",
                "link": "#frompairs-pairs",
                "children": []
              },
              {
                "level": 3,
                "title": "_.zipObject([props=[]], [values=[]])",
                "slug": "zipobject-props-values",
                "link": "#zipobject-props-values",
                "children": []
              },
              {
                "level": 3,
                "title": "_.zipObjectDeep([props=[]], [values=[]])",
                "slug": "zipobjectdeep-props-values",
                "link": "#zipobjectdeep-props-values",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-array.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 集合 Collection",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 集合 Collection",
        "slug": "lodash-集合-collection",
        "link": "#lodash-集合-collection",
        "children": [
          {
            "level": 2,
            "title": "创建",
            "slug": "创建",
            "link": "#创建",
            "children": [
              {
                "level": 3,
                "title": "_.sample(collection)",
                "slug": "sample-collection",
                "link": "#sample-collection",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sampleSize(collection, [n = 1])",
                "slug": "samplesize-collection-n-1",
                "link": "#samplesize-collection-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.shuffle(collection)",
                "slug": "shuffle-collection",
                "link": "#shuffle-collection",
                "children": []
              },
              {
                "level": 3,
                "title": "_.countBy(collection, [iteratee = _.identity])",
                "slug": "countby-collection-iteratee-identity",
                "link": "#countby-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sortBy(collection, [iteratees = [ _.identity ] ])",
                "slug": "sortby-collection-iteratees-identity",
                "link": "#sortby-collection-iteratees-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.orderBy(collection, [iteratees=[ _.identity ] ], [ orders ])",
                "slug": "orderby-collection-iteratees-identity-orders",
                "link": "#orderby-collection-iteratees-identity-orders",
                "children": []
              },
              {
                "level": 3,
                "title": "_.groupBy(collection, [iteratee = _.identity])",
                "slug": "groupby-collection-iteratee-identity",
                "link": "#groupby-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.keyBy(collection, [iteratee = _.identity])",
                "slug": "keyby-collection-iteratee-identity",
                "link": "#keyby-collection-iteratee-identity",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "遍历",
            "slug": "遍历",
            "link": "#遍历",
            "children": [
              {
                "level": 3,
                "title": "_.forEach(collection, [iteratee = _.identity])",
                "slug": "foreach-collection-iteratee-identity",
                "link": "#foreach-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.forEachRight(collection, [iteratee = _.identity])",
                "slug": "foreachright-collection-iteratee-identity",
                "link": "#foreachright-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.map(collection, [iteratee = _.identity])",
                "slug": "map-collection-iteratee-identity",
                "link": "#map-collection-iteratee-identity",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "检索",
            "slug": "检索",
            "link": "#检索",
            "children": [
              {
                "level": 3,
                "title": "_.includes(collection, value, [fromIndex = 0])",
                "slug": "includes-collection-value-fromindex-0",
                "link": "#includes-collection-value-fromindex-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.every(collection, [predicate = _.identity])",
                "slug": "every-collection-predicate-identity",
                "link": "#every-collection-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.some(collection, [predicate = _.identity])",
                "slug": "some-collection-predicate-identity",
                "link": "#some-collection-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.find(collection, [predicate = _.identity], [fromIndex = 0])",
                "slug": "find-collection-predicate-identity-fromindex-0",
                "link": "#find-collection-predicate-identity-fromindex-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.findLast(collection, [predicate = _.identity], [fromIndex = collection.length - 1])",
                "slug": "findlast-collection-predicate-identity-fromindex-collection-length-1",
                "link": "#findlast-collection-predicate-identity-fromindex-collection-length-1",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "过滤",
            "slug": "过滤",
            "link": "#过滤",
            "children": [
              {
                "level": 3,
                "title": "_.filter(collection, [predicate = _.identity])",
                "slug": "filter-collection-predicate-identity",
                "link": "#filter-collection-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.reject(collection, [predicate = _.identity])",
                "slug": "reject-collection-predicate-identity",
                "link": "#reject-collection-predicate-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.partition(collection, [predicate = _.identity])",
                "slug": "partition-collection-predicate-identity",
                "link": "#partition-collection-predicate-identity",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "转换",
            "slug": "转换",
            "link": "#转换",
            "children": [
              {
                "level": 3,
                "title": "_.flatMap(collection, [iteratee = _.identity])",
                "slug": "flatmap-collection-iteratee-identity",
                "link": "#flatmap-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.flatMapDeep(collection, [iteratee = _.identity])",
                "slug": "flatmapdeep-collection-iteratee-identity",
                "link": "#flatmapdeep-collection-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.flatMapDepth(collection, [iteratee = _.identity], [depth = 1])",
                "slug": "flatmapdepth-collection-iteratee-identity-depth-1",
                "link": "#flatmapdepth-collection-iteratee-identity-depth-1",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "其它",
            "slug": "其它",
            "link": "#其它",
            "children": [
              {
                "level": 3,
                "title": "_.invokeMap(collection, path, [args])",
                "slug": "invokemap-collection-path-args",
                "link": "#invokemap-collection-path-args",
                "children": []
              },
              {
                "level": 3,
                "title": "_.reduce(collection, [iteratee = _.identity], [ accumulator ])",
                "slug": "reduce-collection-iteratee-identity-accumulator",
                "link": "#reduce-collection-iteratee-identity-accumulator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.reduceRight(collection, [iteratee = _.identity], [accumulator])",
                "slug": "reduceright-collection-iteratee-identity-accumulator",
                "link": "#reduceright-collection-iteratee-identity-accumulator",
                "children": []
              },
              {
                "level": 3,
                "title": "_.size(collection)",
                "slug": "size-collection",
                "link": "#size-collection",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-collection.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 函数 Function",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 函数 Function",
        "slug": "lodash-函数-function",
        "link": "#lodash-函数-function",
        "children": [
          {
            "level": 3,
            "title": "_.before(n, func)",
            "slug": "before-n-func",
            "link": "#before-n-func",
            "children": []
          },
          {
            "level": 3,
            "title": "_.after(n, func)",
            "slug": "after-n-func",
            "link": "#after-n-func",
            "children": []
          },
          {
            "level": 3,
            "title": "_.ary(func, [n = func.length])",
            "slug": "ary-func-n-func-length",
            "link": "#ary-func-n-func-length",
            "children": []
          },
          {
            "level": 3,
            "title": "_.bind(func, thisArg, [partials])",
            "slug": "bind-func-thisarg-partials",
            "link": "#bind-func-thisarg-partials",
            "children": []
          },
          {
            "level": 3,
            "title": "_.bindKey(object, key, [partials])",
            "slug": "bindkey-object-key-partials",
            "link": "#bindkey-object-key-partials",
            "children": []
          },
          {
            "level": 3,
            "title": "_.partial(func, [partials])",
            "slug": "partial-func-partials",
            "link": "#partial-func-partials",
            "children": []
          },
          {
            "level": 3,
            "title": "_.partialRight(func, [partials])",
            "slug": "partialright-func-partials",
            "link": "#partialright-func-partials",
            "children": []
          },
          {
            "level": 3,
            "title": "_.curry(func, [arity = func.length])",
            "slug": "curry-func-arity-func-length",
            "link": "#curry-func-arity-func-length",
            "children": []
          },
          {
            "level": 3,
            "title": "_.curryRight(func, [arity = func.length])",
            "slug": "curryright-func-arity-func-length",
            "link": "#curryright-func-arity-func-length",
            "children": []
          },
          {
            "level": 3,
            "title": "_.rearg(func, indexes)",
            "slug": "rearg-func-indexes",
            "link": "#rearg-func-indexes",
            "children": []
          },
          {
            "level": 3,
            "title": "_.rest(func, [start=func.length-1])",
            "slug": "rest-func-start-func-length-1",
            "link": "#rest-func-start-func-length-1",
            "children": []
          },
          {
            "level": 3,
            "title": "_.spread(func, [start=0])",
            "slug": "spread-func-start-0",
            "link": "#spread-func-start-0",
            "children": []
          },
          {
            "level": 3,
            "title": "_.throttle(func, [wait = 0], [options = ])",
            "slug": "throttle-func-wait-0-options",
            "link": "#throttle-func-wait-0-options",
            "children": []
          },
          {
            "level": 3,
            "title": "_.unary(func)",
            "slug": "unary-func",
            "link": "#unary-func",
            "children": []
          },
          {
            "level": 3,
            "title": "_.wrap(value, [wrapper=identity])",
            "slug": "wrap-value-wrapper-identity",
            "link": "#wrap-value-wrapper-identity",
            "children": []
          },
          {
            "level": 2,
            "title": "延迟",
            "slug": "延迟",
            "link": "#延迟",
            "children": [
              {
                "level": 3,
                "title": "_.debounce(func, [wait = 0], [options = ])",
                "slug": "debounce-func-wait-0-options",
                "link": "#debounce-func-wait-0-options",
                "children": []
              },
              {
                "level": 3,
                "title": "_.defer(func, [args])",
                "slug": "defer-func-args",
                "link": "#defer-func-args",
                "children": []
              },
              {
                "level": 3,
                "title": "_.delay(func, wait, [args])",
                "slug": "delay-func-wait-args",
                "link": "#delay-func-wait-args",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "转换",
            "slug": "转换",
            "link": "#转换",
            "children": [
              {
                "level": 3,
                "title": "_.flip(func)",
                "slug": "flip-func",
                "link": "#flip-func",
                "children": []
              },
              {
                "level": 3,
                "title": "_.memoize(func, [resolver])",
                "slug": "memoize-func-resolver",
                "link": "#memoize-func-resolver",
                "children": []
              },
              {
                "level": 3,
                "title": "_.negate(predicate:Function)",
                "slug": "negate-predicate-function",
                "link": "#negate-predicate-function",
                "children": []
              },
              {
                "level": 3,
                "title": "_.once(func)",
                "slug": "once-func",
                "link": "#once-func",
                "children": []
              },
              {
                "level": 3,
                "title": "_.overArgs(func, [transforms = [ _.identity ]])",
                "slug": "overargs-func-transforms-identity",
                "link": "#overargs-func-transforms-identity",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-function.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 对象 Map",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 对象 Map",
        "slug": "lodash-对象-map",
        "link": "#lodash-对象-map",
        "children": []
      }
    ],
    "path": "/guide/javascript/lodash-map.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 数学 Math",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 数学 Math",
        "slug": "lodash-数学-math",
        "link": "#lodash-数学-math",
        "children": [
          {
            "level": 2,
            "title": "逻辑运算",
            "slug": "逻辑运算",
            "link": "#逻辑运算",
            "children": [
              {
                "level": 3,
                "title": "_.add(augend, addend)",
                "slug": "add-augend-addend",
                "link": "#add-augend-addend",
                "children": []
              },
              {
                "level": 3,
                "title": "_.subtract(minuend, subtrahend)",
                "slug": "subtract-minuend-subtrahend",
                "link": "#subtract-minuend-subtrahend",
                "children": []
              },
              {
                "level": 3,
                "title": "_.multiply(multiplier, multiplicand)",
                "slug": "multiply-multiplier-multiplicand",
                "link": "#multiply-multiplier-multiplicand",
                "children": []
              },
              {
                "level": 3,
                "title": "_.divide(dividend, divisor)",
                "slug": "divide-dividend-divisor",
                "link": "#divide-dividend-divisor",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sum(array)",
                "slug": "sum-array",
                "link": "#sum-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.sumBy(array, [iteratee = _.identity])",
                "slug": "sumby-array-iteratee-identity",
                "link": "#sumby-array-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.mean(array)",
                "slug": "mean-array",
                "link": "#mean-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.meanBy(array, [iteratee = _.identity])",
                "slug": "meanby-array-iteratee-identity",
                "link": "#meanby-array-iteratee-identity",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "格式化",
            "slug": "格式化",
            "link": "#格式化",
            "children": [
              {
                "level": 3,
                "title": "_.round(number, [precision=0])",
                "slug": "round-number-precision-0",
                "link": "#round-number-precision-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.ceil(number, [precision = 0])",
                "slug": "ceil-number-precision-0",
                "link": "#ceil-number-precision-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.floor(number, [precision=0])",
                "slug": "floor-number-precision-0",
                "link": "#floor-number-precision-0",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "比较",
            "slug": "比较",
            "link": "#比较",
            "children": [
              {
                "level": 3,
                "title": "_.min(array)",
                "slug": "min-array",
                "link": "#min-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.minBy(array, [iteratee = _.identity])",
                "slug": "minby-array-iteratee-identity",
                "link": "#minby-array-iteratee-identity",
                "children": []
              },
              {
                "level": 3,
                "title": "_.max(array)",
                "slug": "max-array",
                "link": "#max-array",
                "children": []
              },
              {
                "level": 3,
                "title": "_.maxBy(array, [iteratee = _.identity])",
                "slug": "maxby-array-iteratee-identity",
                "link": "#maxby-array-iteratee-identity",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-math.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 数字 Number",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 数字 Number",
        "slug": "lodash-数字-number",
        "link": "#lodash-数字-number",
        "children": [
          {
            "level": 2,
            "title": "数字",
            "slug": "数字",
            "link": "#数字",
            "children": [
              {
                "level": 3,
                "title": "_.clamp(number, [lower], upper)",
                "slug": "clamp-number-lower-upper",
                "link": "#clamp-number-lower-upper",
                "children": []
              },
              {
                "level": 3,
                "title": "_.inRange(number, [start = 0], end)",
                "slug": "inrange-number-start-0-end",
                "link": "#inrange-number-start-0-end",
                "children": []
              },
              {
                "level": 3,
                "title": "_.random([lower = 0], [upper = 1], [floating])",
                "slug": "random-lower-0-upper-1-floating",
                "link": "#random-lower-0-upper-1-floating",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-number.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash  Seq",
    "headers": [
      {
        "level": 1,
        "title": "Lodash  Seq",
        "slug": "lodash-seq",
        "link": "#lodash-seq",
        "children": []
      }
    ],
    "path": "/guide/javascript/lodash-seq.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 字符串处理 String",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 字符串处理 String",
        "slug": "lodash-字符串处理-string",
        "link": "#lodash-字符串处理-string",
        "children": [
          {
            "level": 2,
            "title": "转换",
            "slug": "转换",
            "link": "#转换",
            "children": [
              {
                "level": 3,
                "title": "_.toLower([string=''])",
                "slug": "tolower-string",
                "link": "#tolower-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.toUpper([string=''])",
                "slug": "toupper-string",
                "link": "#toupper-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.lowerCase([string=''])",
                "slug": "lowercase-string",
                "link": "#lowercase-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.lowerFirst([string=''])",
                "slug": "lowerfirst-string",
                "link": "#lowerfirst-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.upperCase([string=''])",
                "slug": "uppercase-string",
                "link": "#uppercase-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.upperFirst([string=''])",
                "slug": "upperfirst-string",
                "link": "#upperfirst-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.capitalize([string=''])",
                "slug": "capitalize-string",
                "link": "#capitalize-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.camelCase([string=''])",
                "slug": "camelcase-string",
                "link": "#camelcase-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.kebabCase([string=''])",
                "slug": "kebabcase-string",
                "link": "#kebabcase-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.snakeCase([string=''])",
                "slug": "snakecase-string",
                "link": "#snakecase-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.startCase([string=''])",
                "slug": "startcase-string",
                "link": "#startcase-string",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "转义",
            "slug": "转义",
            "link": "#转义",
            "children": [
              {
                "level": 3,
                "title": "_.escape([string=''])",
                "slug": "escape-string",
                "link": "#escape-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.escapeRegExp([string=''])",
                "slug": "escaperegexp-string",
                "link": "#escaperegexp-string",
                "children": []
              },
              {
                "level": 3,
                "title": "_.unescape([string=''])",
                "slug": "unescape-string",
                "link": "#unescape-string",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "分割",
            "slug": "分割",
            "link": "#分割",
            "children": [
              {
                "level": 3,
                "title": "_.split([string=''], separator, [limit])",
                "slug": "split-string-separator-limit",
                "link": "#split-string-separator-limit",
                "children": []
              },
              {
                "level": 3,
                "title": "_.words([string=''], [pattern])",
                "slug": "words-string-pattern",
                "link": "#words-string-pattern",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "检索",
            "slug": "检索",
            "link": "#检索",
            "children": [
              {
                "level": 3,
                "title": "_.startsWith([string=''], [target], [position=0])",
                "slug": "startswith-string-target-position-0",
                "link": "#startswith-string-target-position-0",
                "children": []
              },
              {
                "level": 3,
                "title": "_.endsWith([string=''], [target], [position=string.length])",
                "slug": "endswith-string-target-position-string-length",
                "link": "#endswith-string-target-position-string-length",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "替换",
            "slug": "替换",
            "link": "#替换",
            "children": [
              {
                "level": 3,
                "title": "_.replace([string=''], pattern, replacement)",
                "slug": "replace-string-pattern-replacement",
                "link": "#replace-string-pattern-replacement",
                "children": []
              },
              {
                "level": 3,
                "title": "_.trim([string=''], [chars=whitespace])",
                "slug": "trim-string-chars-whitespace",
                "link": "#trim-string-chars-whitespace",
                "children": []
              },
              {
                "level": 3,
                "title": "_.trimStart([string=''], [chars=whitespace])",
                "slug": "trimstart-string-chars-whitespace",
                "link": "#trimstart-string-chars-whitespace",
                "children": []
              },
              {
                "level": 3,
                "title": "_.trimEnd([string=''], [chars=whitespace])",
                "slug": "trimend-string-chars-whitespace",
                "link": "#trimend-string-chars-whitespace",
                "children": []
              },
              {
                "level": 3,
                "title": "_.pad([string=''], [length=0], [chars=' '])",
                "slug": "pad-string-length-0-chars",
                "link": "#pad-string-length-0-chars",
                "children": []
              },
              {
                "level": 3,
                "title": "_.padStart([string=''], [length=0], [chars=' '])",
                "slug": "padstart-string-length-0-chars",
                "link": "#padstart-string-length-0-chars",
                "children": []
              },
              {
                "level": 3,
                "title": "_.padEnd([string=''], [length=0], [chars=' '])",
                "slug": "padend-string-length-0-chars",
                "link": "#padend-string-length-0-chars",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "其它",
            "slug": "其它",
            "link": "#其它",
            "children": [
              {
                "level": 3,
                "title": "_.parseInt(string, [radix=10])",
                "slug": "parseint-string-radix-10",
                "link": "#parseint-string-radix-10",
                "children": []
              },
              {
                "level": 3,
                "title": "_.repeat([string=''], [n=1])",
                "slug": "repeat-string-n-1",
                "link": "#repeat-string-n-1",
                "children": []
              },
              {
                "level": 3,
                "title": "_.truncate([string=''], [options=])",
                "slug": "truncate-string-options",
                "link": "#truncate-string-options",
                "children": []
              },
              {
                "level": 3,
                "title": "_.template([string=''], [options=])",
                "slug": "template-string-options",
                "link": "#template-string-options",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/javascript/lodash-string.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Lodash 实用函数 Utils",
    "headers": [
      {
        "level": 1,
        "title": "Lodash 实用函数 Utils",
        "slug": "lodash-实用函数-utils",
        "link": "#lodash-实用函数-utils",
        "children": []
      }
    ],
    "path": "/guide/javascript/lodash-utils.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Docker 基本入门",
    "headers": [
      {
        "level": 1,
        "title": "Docker 基本入门",
        "slug": "docker-基本入门",
        "link": "#docker-基本入门",
        "children": [
          {
            "level": 2,
            "title": "安装",
            "slug": "安装",
            "link": "#安装",
            "children": []
          },
          {
            "level": 2,
            "title": "名词解释",
            "slug": "名词解释",
            "link": "#名词解释",
            "children": []
          },
          {
            "level": 2,
            "title": "启动",
            "slug": "启动",
            "link": "#启动",
            "children": []
          },
          {
            "level": 2,
            "title": "权限",
            "slug": "权限",
            "link": "#权限",
            "children": [
              {
                "level": 3,
                "title": "查看用户组与用户",
                "slug": "查看用户组与用户",
                "link": "#查看用户组与用户",
                "children": []
              },
              {
                "level": 3,
                "title": "加入用户组",
                "slug": "加入用户组",
                "link": "#加入用户组",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "常用命令",
            "slug": "常用命令",
            "link": "#常用命令",
            "children": []
          },
          {
            "level": 2,
            "title": "Dockerfile 语法",
            "slug": "dockerfile-语法",
            "link": "#dockerfile-语法",
            "children": [
              {
                "level": 3,
                "title": "Dockerfile 示例",
                "slug": "dockerfile-示例",
                "link": "#dockerfile-示例",
                "children": []
              }
            ]
          }
        ]
      },
      {
        "level": 1,
        "title": "Docker Compose",
        "slug": "docker-compose",
        "link": "#docker-compose",
        "children": [
          {
            "level": 2,
            "title": "安装",
            "slug": "安装-1",
            "link": "#安装-1",
            "children": []
          },
          {
            "level": 2,
            "title": "常用命令",
            "slug": "常用命令-1",
            "link": "#常用命令-1",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/linux/docker-basic.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Go 基本入门",
    "headers": [
      {
        "level": 1,
        "title": "Go 基本入门",
        "slug": "go-基本入门",
        "link": "#go-基本入门",
        "children": [
          {
            "level": 2,
            "title": "环境安装",
            "slug": "环境安装",
            "link": "#环境安装",
            "children": [
              {
                "level": 3,
                "title": "下载",
                "slug": "下载",
                "link": "#下载",
                "children": []
              },
              {
                "level": 3,
                "title": "配置Go Proxy",
                "slug": "配置go-proxy",
                "link": "#配置go-proxy",
                "children": []
              },
              {
                "level": 3,
                "title": "VS Code 安装Go插件",
                "slug": "vs-code-安装go插件",
                "link": "#vs-code-安装go插件",
                "children": []
              },
              {
                "level": 3,
                "title": "测试",
                "slug": "测试",
                "link": "#测试",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "语言基础",
            "slug": "语言基础",
            "link": "#语言基础",
            "children": [
              {
                "level": 3,
                "title": "import",
                "slug": "import",
                "link": "#import",
                "children": []
              }
            ]
          }
        ]
      },
      {
        "level": 1,
        "title": "学习资料",
        "slug": "学习资料",
        "link": "#学习资料",
        "children": []
      }
    ],
    "path": "/guide/linux/go-basic.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Ubuntu 配置 git",
    "headers": [
      {
        "level": 1,
        "title": "Ubuntu 配置 git",
        "slug": "ubuntu-配置-git",
        "link": "#ubuntu-配置-git",
        "children": [
          {
            "level": 2,
            "title": "常用命令",
            "slug": "常用命令",
            "link": "#常用命令",
            "children": []
          },
          {
            "level": 2,
            "title": "重命名分支",
            "slug": "重命名分支",
            "link": "#重命名分支",
            "children": []
          },
          {
            "level": 2,
            "title": "配置SSH",
            "slug": "配置ssh",
            "link": "#配置ssh",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/linux/ubuntu-config-git.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "版本发布命名",
    "headers": [
      {
        "level": 1,
        "title": "版本发布命名",
        "slug": "版本发布命名",
        "link": "#版本发布命名",
        "children": [
          {
            "level": 2,
            "title": "常见版本的具体含义",
            "slug": "常见版本的具体含义",
            "link": "#常见版本的具体含义",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/linux/version.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "vscode 前端常用配置",
    "headers": [
      {
        "level": 1,
        "title": "vscode 前端常用配置",
        "slug": "vscode-前端常用配置",
        "link": "#vscode-前端常用配置",
        "children": [
          {
            "level": 2,
            "title": "配置",
            "slug": "配置",
            "link": "#配置",
            "children": []
          },
          {
            "level": 2,
            "title": "常用插件",
            "slug": "常用插件",
            "link": "#常用插件",
            "children": [
              {
                "level": 3,
                "title": "Vue 3 Snippets",
                "slug": "vue-3-snippets",
                "link": "#vue-3-snippets",
                "children": []
              },
              {
                "level": 3,
                "title": "vscode-vue-peek",
                "slug": "vscode-vue-peek",
                "link": "#vscode-vue-peek",
                "children": []
              },
              {
                "level": 3,
                "title": "Vetur",
                "slug": "vetur",
                "link": "#vetur",
                "children": []
              },
              {
                "level": 3,
                "title": "EsLint",
                "slug": "eslint",
                "link": "#eslint",
                "children": []
              },
              {
                "level": 3,
                "title": "Path Intellisense",
                "slug": "path-intellisense",
                "link": "#path-intellisense",
                "children": []
              },
              {
                "level": 3,
                "title": "HTML CSS Support",
                "slug": "html-css-support",
                "link": "#html-css-support",
                "children": []
              },
              {
                "level": 3,
                "title": "Git History",
                "slug": "git-history",
                "link": "#git-history",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/linux/vscode-guide.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "ffmpeg 使用笔记",
    "headers": [
      {
        "level": 1,
        "title": "ffmpeg 使用笔记",
        "slug": "ffmpeg-使用笔记",
        "link": "#ffmpeg-使用笔记",
        "children": [
          {
            "level": 2,
            "title": "录制",
            "slug": "录制",
            "link": "#录制",
            "children": [
              {
                "level": 3,
                "title": "转录网络媒体流",
                "slug": "转录网络媒体流",
                "link": "#转录网络媒体流",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "转码",
            "slug": "转码",
            "link": "#转码",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/nodejs/ffmpeg.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "inquirer.js 命令行询问任务",
    "headers": [
      {
        "level": 1,
        "title": "inquirer.js 命令行询问任务",
        "slug": "inquirer-js-命令行询问任务",
        "link": "#inquirer-js-命令行询问任务",
        "children": [
          {
            "level": 2,
            "title": "文档",
            "slug": "文档",
            "link": "#文档",
            "children": [
              {
                "level": 3,
                "title": "安装",
                "slug": "安装",
                "link": "#安装",
                "children": []
              },
              {
                "level": 3,
                "title": "参数",
                "slug": "参数",
                "link": "#参数",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/nodejs/inquirer.js.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Nodejs 安装",
    "headers": [
      {
        "level": 1,
        "title": "Nodejs 安装",
        "slug": "nodejs-安装",
        "link": "#nodejs-安装",
        "children": [
          {
            "level": 2,
            "title": "安装",
            "slug": "安装",
            "link": "#安装",
            "children": []
          },
          {
            "level": 2,
            "title": "配置",
            "slug": "配置",
            "link": "#配置",
            "children": []
          },
          {
            "level": 2,
            "title": "调试",
            "slug": "调试",
            "link": "#调试",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/nodejs/nodejs-install.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "发布代码到npm库",
    "headers": [
      {
        "level": 1,
        "title": "发布代码到npm库",
        "slug": "发布代码到npm库",
        "link": "#发布代码到npm库",
        "children": [
          {
            "level": 2,
            "title": "账号",
            "slug": "账号",
            "link": "#账号",
            "children": []
          },
          {
            "level": 2,
            "title": "代码库名称",
            "slug": "代码库名称",
            "link": "#代码库名称",
            "children": []
          },
          {
            "level": 2,
            "title": "创建项目",
            "slug": "创建项目",
            "link": "#创建项目",
            "children": []
          },
          {
            "level": 2,
            "title": "新建目录",
            "slug": "新建目录",
            "link": "#新建目录",
            "children": []
          },
          {
            "level": 2,
            "title": "本地测试",
            "slug": "本地测试",
            "link": "#本地测试",
            "children": []
          },
          {
            "level": 2,
            "title": "登陆",
            "slug": "登陆",
            "link": "#登陆",
            "children": []
          },
          {
            "level": 2,
            "title": "提交发布",
            "slug": "提交发布",
            "link": "#提交发布",
            "children": []
          },
          {
            "level": 2,
            "title": "测试提交",
            "slug": "测试提交",
            "link": "#测试提交",
            "children": []
          },
          {
            "level": 2,
            "title": "撤销当前提交",
            "slug": "撤销当前提交",
            "link": "#撤销当前提交",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/nodejs/publish-project-to-npm.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "RSA加密与解密(js-encrypt)",
    "headers": [
      {
        "level": 1,
        "title": "RSA加密与解密(js-encrypt)",
        "slug": "rsa加密与解密-js-encrypt",
        "link": "#rsa加密与解密-js-encrypt",
        "children": [
          {
            "level": 2,
            "title": "第一部分：RSA加密与解密",
            "slug": "第一部分-rsa加密与解密",
            "link": "#第一部分-rsa加密与解密",
            "children": [
              {
                "level": 3,
                "title": "什么是RSA加密",
                "slug": "什么是rsa加密",
                "link": "#什么是rsa加密",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "第二部分：js-encrypt库",
            "slug": "第二部分-js-encrypt库",
            "link": "#第二部分-js-encrypt库",
            "children": [
              {
                "level": 3,
                "title": "例一：转换加密文本",
                "slug": "例一-转换加密文本",
                "link": "#例一-转换加密文本",
                "children": []
              },
              {
                "level": 3,
                "title": "例二：签名和验证",
                "slug": "例二-签名和验证",
                "link": "#例二-签名和验证",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/nodejs/rsa-symmetric-encryption.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "下载哔哩哔哩视频",
    "headers": [
      {
        "level": 1,
        "title": "下载哔哩哔哩视频",
        "slug": "下载哔哩哔哩视频",
        "link": "#下载哔哩哔哩视频",
        "children": [
          {
            "level": 2,
            "title": "获取视频系列地址",
            "slug": "获取视频系列地址",
            "link": "#获取视频系列地址",
            "children": []
          },
          {
            "level": 2,
            "title": "下载视频",
            "slug": "下载视频",
            "link": "#下载视频",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/other/%E4%B8%8B%E8%BD%BDbilibili%E8%A7%86%E9%A2%91.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "快速开始",
    "headers": [
      {
        "level": 1,
        "title": "快速开始",
        "slug": "快速开始",
        "link": "#快速开始",
        "children": [
          {
            "level": 2,
            "title": "环境",
            "slug": "环境",
            "link": "#环境",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/typescript/get-started.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Nuxt",
    "headers": [
      {
        "level": 1,
        "title": "Nuxt",
        "slug": "nuxt",
        "link": "#nuxt",
        "children": [
          {
            "level": 2,
            "title": "配置相关",
            "slug": "配置相关",
            "link": "#配置相关",
            "children": [
              {
                "level": 3,
                "title": "引入第三方库",
                "slug": "引入第三方库",
                "link": "#引入第三方库",
                "children": []
              },
              {
                "level": 3,
                "title": "打包删除console",
                "slug": "打包删除console",
                "link": "#打包删除console",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/vue/nuxt-study-notes.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Home",
    "headers": [],
    "path": "/guide/vue/",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue3",
    "headers": [
      {
        "level": 1,
        "title": "Vue3",
        "slug": "vue3",
        "link": "#vue3",
        "children": [
          {
            "level": 2,
            "title": "缩略语",
            "slug": "缩略语",
            "link": "#缩略语",
            "children": [
              {
                "level": 3,
                "title": "SPA Single-Page application 单页应用程序",
                "slug": "spa-single-page-application-单页应用程序",
                "link": "#spa-single-page-application-单页应用程序",
                "children": []
              },
              {
                "level": 3,
                "title": "SSR Server-Side Rendering 服务端渲染",
                "slug": "ssr-server-side-rendering-服务端渲染",
                "link": "#ssr-server-side-rendering-服务端渲染",
                "children": []
              },
              {
                "level": 3,
                "title": "SSG Static-Site Generation 静态站点生成",
                "slug": "ssg-static-site-generation-静态站点生成",
                "link": "#ssg-static-site-generation-静态站点生成",
                "children": []
              },
              {
                "level": 3,
                "title": "PWA Progressive Web Apps 渐进式Web应用",
                "slug": "pwa-progressive-web-apps-渐进式web应用",
                "link": "#pwa-progressive-web-apps-渐进式web应用",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "框架",
            "slug": "框架",
            "link": "#框架",
            "children": []
          },
          {
            "level": 2,
            "title": "命名",
            "slug": "命名",
            "link": "#命名",
            "children": []
          },
          {
            "level": 2,
            "title": "组件拆分规则",
            "slug": "组件拆分规则",
            "link": "#组件拆分规则",
            "children": []
          },
          {
            "level": 2,
            "title": "书写规则",
            "slug": "书写规则",
            "link": "#书写规则",
            "children": [
              {
                "level": 3,
                "title": "组件内class书写顺序",
                "slug": "组件内class书写顺序",
                "link": "#组件内class书写顺序",
                "children": []
              },
              {
                "level": 3,
                "title": "script setup 语法糖书写",
                "slug": "script-setup-语法糖书写",
                "link": "#script-setup-语法糖书写",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "",
            "slug": "",
            "link": "#",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/vue/reference.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue 知识点总结",
    "headers": [
      {
        "level": 1,
        "title": "Vue 知识点总结",
        "slug": "vue-知识点总结",
        "link": "#vue-知识点总结",
        "children": [
          {
            "level": 2,
            "title": "vue 父子组件通讯",
            "slug": "vue-父子组件通讯",
            "link": "#vue-父子组件通讯",
            "children": [
              {
                "level": 3,
                "title": "方式一：事件类型",
                "slug": "方式一-事件类型",
                "link": "#方式一-事件类型",
                "children": []
              },
              {
                "level": 3,
                "title": "方式二：provide和inject 提供注入（高阶组件库使用）。",
                "slug": "方式二-provide和inject-提供注入-高阶组件库使用-。",
                "link": "#方式二-provide和inject-提供注入-高阶组件库使用-。",
                "children": []
              },
              {
                "level": 3,
                "title": "方式三：原型链",
                "slug": "方式三-原型链",
                "link": "#方式三-原型链",
                "children": []
              },
              {
                "level": 3,
                "title": "方式四：Vuex 状态管理",
                "slug": "方式四-vuex-状态管理",
                "link": "#方式四-vuex-状态管理",
                "children": []
              },
              {
                "level": 3,
                "title": "方式五：attrs和listeners",
                "slug": "方式五-attrs和listeners",
                "link": "#方式五-attrs和listeners",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/vue/vue-basic.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue Event",
    "headers": [
      {
        "level": 1,
        "title": "Vue Event",
        "slug": "vue-event",
        "link": "#vue-event",
        "children": [
          {
            "level": 2,
            "title": "Event",
            "slug": "event",
            "link": "#event",
            "children": [
              {
                "level": 3,
                "title": "JavaScript事件的三阶段",
                "slug": "javascript事件的三阶段",
                "link": "#javascript事件的三阶段",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "事件修饰符",
            "slug": "事件修饰符",
            "link": "#事件修饰符",
            "children": []
          },
          {
            "level": 2,
            "title": "自定义事件",
            "slug": "自定义事件",
            "link": "#自定义事件",
            "children": [
              {
                "level": 3,
                "title": "验证抛出的事件",
                "slug": "验证抛出的事件",
                "link": "#验证抛出的事件",
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "path": "/guide/vue/vue-event.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue v-model",
    "headers": [
      {
        "level": 1,
        "title": "Vue v-model",
        "slug": "vue-v-model",
        "link": "#vue-v-model",
        "children": [
          {
            "level": 2,
            "title": "表单输入绑定",
            "slug": "表单输入绑定",
            "link": "#表单输入绑定",
            "children": []
          },
          {
            "level": 2,
            "title": "自定义组件上使用v-model",
            "slug": "自定义组件上使用v-model",
            "link": "#自定义组件上使用v-model",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue2在组件上使用v-model",
            "slug": "vue2在组件上使用v-model",
            "link": "#vue2在组件上使用v-model",
            "children": []
          },
          {
            "level": 2,
            "title": "Vue3在组件上使用v-model",
            "slug": "vue3在组件上使用v-model",
            "link": "#vue3在组件上使用v-model",
            "children": []
          },
          {
            "level": 2,
            "title": "v-model参数",
            "slug": "v-model参数",
            "link": "#v-model参数",
            "children": []
          },
          {
            "level": 2,
            "title": "多个v-model绑定",
            "slug": "多个v-model绑定",
            "link": "#多个v-model绑定",
            "children": []
          },
          {
            "level": 2,
            "title": "处理v-model修饰符",
            "slug": "处理v-model修饰符",
            "link": "#处理v-model修饰符",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "Vue .sync",
        "slug": "vue-sync",
        "link": "#vue-sync",
        "children": []
      }
    ],
    "path": "/guide/vue/vue-model.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue props 对象",
    "headers": [
      {
        "level": 1,
        "title": "Vue props 对象",
        "slug": "vue-props-对象",
        "link": "#vue-props-对象",
        "children": []
      }
    ],
    "path": "/guide/vue/vue-props.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue3 组合式API(Composition API)",
    "headers": [
      {
        "level": 1,
        "title": "Vue3 组合式API(Composition API)",
        "slug": "vue3-组合式api-composition-api",
        "link": "#vue3-组合式api-composition-api",
        "children": [
          {
            "level": 2,
            "title": "setup 组件选项",
            "slug": "setup-组件选项",
            "link": "#setup-组件选项",
            "children": []
          },
          {
            "level": 2,
            "title": "带ref的响应式变量",
            "slug": "带ref的响应式变量",
            "link": "#带ref的响应式变量",
            "children": []
          },
          {
            "level": 2,
            "title": "在setup内注册生命周期钩子",
            "slug": "在setup内注册生命周期钩子",
            "link": "#在setup内注册生命周期钩子",
            "children": []
          },
          {
            "level": 2,
            "title": "watch响应式更改",
            "slug": "watch响应式更改",
            "link": "#watch响应式更改",
            "children": []
          },
          {
            "level": 2,
            "title": "独立的 computed 属性",
            "slug": "独立的-computed-属性",
            "link": "#独立的-computed-属性",
            "children": []
          },
          {
            "level": 2,
            "title": "defineProps 和 defineEmits",
            "slug": "defineprops-和-defineemits",
            "link": "#defineprops-和-defineemits",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/vue/vue3-composition-api.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "Vue3 学习笔记",
    "headers": [
      {
        "level": 1,
        "title": "Vue3 学习笔记",
        "slug": "vue3-学习笔记",
        "link": "#vue3-学习笔记",
        "children": [
          {
            "level": 2,
            "title": "全局API",
            "slug": "全局api",
            "link": "#全局api",
            "children": [
              {
                "level": 3,
                "title": "createApp",
                "slug": "createapp",
                "link": "#createapp",
                "children": []
              },
              {
                "level": 3,
                "title": "h",
                "slug": "h",
                "link": "#h",
                "children": []
              },
              {
                "level": 3,
                "title": "createRenderer(HostNode, HostElement)",
                "slug": "createrenderer-hostnode-hostelement",
                "link": "#createrenderer-hostnode-hostelement",
                "children": []
              },
              {
                "level": 3,
                "title": "nextTick",
                "slug": "nexttick",
                "link": "#nexttick",
                "children": []
              },
              {
                "level": 3,
                "title": "mergeProps",
                "slug": "mergeprops",
                "link": "#mergeprops",
                "children": []
              },
              {
                "level": 3,
                "title": "defineComponent",
                "slug": "definecomponent",
                "link": "#definecomponent",
                "children": []
              },
              {
                "level": 3,
                "title": "defineAsyncComponent",
                "slug": "defineasynccomponent",
                "link": "#defineasynccomponent",
                "children": []
              },
              {
                "level": 3,
                "title": "resolveComponent",
                "slug": "resolvecomponent",
                "link": "#resolvecomponent",
                "children": []
              },
              {
                "level": 3,
                "title": "resolveDynamicComponent",
                "slug": "resolvedynamiccomponent",
                "link": "#resolvedynamiccomponent",
                "children": []
              },
              {
                "level": 3,
                "title": "resolveDirective",
                "slug": "resolvedirective",
                "link": "#resolvedirective",
                "children": []
              },
              {
                "level": 3,
                "title": "withDirectives",
                "slug": "withdirectives",
                "link": "#withdirectives",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "应用API",
            "slug": "应用api",
            "link": "#应用api",
            "children": []
          },
          {
            "level": 2,
            "title": "组合式API",
            "slug": "组合式api",
            "link": "#组合式api",
            "children": []
          },
          {
            "level": 2,
            "title": "响应式API",
            "slug": "响应式api",
            "link": "#响应式api",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "深入响应原理",
        "slug": "深入响应原理",
        "link": "#深入响应原理",
        "children": [
          {
            "level": 2,
            "title": "检测变化的注意事项",
            "slug": "检测变化的注意事项",
            "link": "#检测变化的注意事项",
            "children": []
          },
          {
            "level": 2,
            "title": "数组",
            "slug": "数组",
            "link": "#数组",
            "children": []
          },
          {
            "level": 2,
            "title": "对象",
            "slug": "对象",
            "link": "#对象",
            "children": []
          }
        ]
      },
      {
        "level": 1,
        "title": "方法",
        "slug": "方法",
        "link": "#方法",
        "children": [
          {
            "level": 2,
            "title": "实例方法",
            "slug": "实例方法",
            "link": "#实例方法",
            "children": [
              {
                "level": 3,
                "title": "$watch",
                "slug": "watch",
                "link": "#watch",
                "children": []
              },
              {
                "level": 3,
                "title": "$emit",
                "slug": "emit",
                "link": "#emit",
                "children": []
              },
              {
                "level": 3,
                "title": "$forceUpdate",
                "slug": "forceupdate",
                "link": "#forceupdate",
                "children": []
              },
              {
                "level": 3,
                "title": "$nextTick",
                "slug": "nexttick-1",
                "link": "#nexttick-1",
                "children": []
              }
            ]
          }
        ]
      },
      {
        "level": 1,
        "title": "指令",
        "slug": "指令",
        "link": "#指令",
        "children": [
          {
            "level": 2,
            "title": "常用指令",
            "slug": "常用指令",
            "link": "#常用指令",
            "children": []
          },
          {
            "level": 2,
            "title": "特殊指令",
            "slug": "特殊指令",
            "link": "#特殊指令",
            "children": [
              {
                "level": 3,
                "title": "key : number | string",
                "slug": "key-number-string",
                "link": "#key-number-string",
                "children": []
              },
              {
                "level": 3,
                "title": "ref : string | Function",
                "slug": "ref-string-function",
                "link": "#ref-string-function",
                "children": []
              },
              {
                "level": 3,
                "title": "is : string | Object (component’s options object)",
                "slug": "is-string-object-component-s-options-object",
                "link": "#is-string-object-component-s-options-object",
                "children": []
              }
            ]
          }
        ]
      },
      {
        "level": 1,
        "title": "组件",
        "slug": "组件",
        "link": "#组件",
        "children": [
          {
            "level": 2,
            "title": "内置组件",
            "slug": "内置组件",
            "link": "#内置组件",
            "children": [
              {
                "level": 3,
                "title": "Teleport",
                "slug": "teleport",
                "link": "#teleport",
                "children": []
              }
            ]
          },
          {
            "level": 2,
            "title": "函数式组件",
            "slug": "函数式组件",
            "link": "#函数式组件",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/vue/vue3-study-notes.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "WebRTC 媒体服务",
    "headers": [
      {
        "level": 1,
        "title": "WebRTC 媒体服务",
        "slug": "webrtc-媒体服务",
        "link": "#webrtc-媒体服务",
        "children": []
      },
      {
        "level": 1,
        "title": "获取设备列表",
        "slug": "获取设备列表",
        "link": "#获取设备列表",
        "children": []
      }
    ],
    "path": "/guide/webrtc/",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "常用钩子合集",
    "headers": [
      {
        "level": 1,
        "title": "常用钩子合集",
        "slug": "常用钩子合集",
        "link": "#常用钩子合集",
        "children": [
          {
            "level": 2,
            "title": "定时器useTimer",
            "slug": "定时器usetimer",
            "link": "#定时器usetimer",
            "children": []
          },
          {
            "level": 2,
            "title": "字节格式化",
            "slug": "字节格式化",
            "link": "#字节格式化",
            "children": []
          }
        ]
      }
    ],
    "path": "/guide/vue/hooks/timer.html",
    "pathLocale": "/guide/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/404.html",
    "pathLocale": "/",
    "extraFields": []
  }
]

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateSearchIndex) {
    __VUE_HMR_RUNTIME__.updateSearchIndex(searchIndex)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ searchIndex }) => {
    __VUE_HMR_RUNTIME__.updateSearchIndex(searchIndex)
  })
}
