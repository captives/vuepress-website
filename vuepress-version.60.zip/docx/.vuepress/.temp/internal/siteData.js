export const siteData = JSON.parse("{\"base\":\"/\",\"lang\":\"/\",\"title\":\"你好， VuePress ！\",\"description\":\"这是我的第一个 VuePress 站点\",\"head\":[],\"locales\":{\"/guide/\":{\"lang\":\"guide\",\"title\":\"学习指南\",\"description\":\"captives.github.io\"},\"/poetry/\":{\"lang\":\"poetry\",\"title\":\"古诗词\",\"description\":\"captives.github.io\"}}}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateSiteData) {
    __VUE_HMR_RUNTIME__.updateSiteData(siteData)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ siteData }) => {
    __VUE_HMR_RUNTIME__.updateSiteData(siteData)
  })
}
