export const data = JSON.parse("{\"key\":\"v-51ef0801\",\"path\":\"/poetry/\",\"title\":\"\",\"lang\":\"poetry\",\"frontmatter\":{\"home\":true,\"sidebar\":false,\"tagline\":null,\"footer\":\"<b1>captives.github.io</b1>\",\"footerHtml\":true,\"pageClass\":\"poetry-home\"},\"headers\":[],\"git\":{},\"filePathRelative\":\"poetry/README.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
