<template><div><!-- 注释： 使用样式 -->
<!-- 注释： 使用Vue全局组件 -->
<Poetry></Poetry></div></template>



<style lang="scss">
    .poetry-home {
        /* 文字竖排 */
        writing-mode: vertical-rl;
        header {
            margin-top: 20%;
            h1 {
                font-family: "华文行楷";
                font-size: 6rem;
            }
        }
    } 
</style>