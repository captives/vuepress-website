export const data = JSON.parse("{\"key\":\"v-077d91b9\",\"path\":\"/user-profile.html\",\"title\":\"\",\"lang\":\"/\",\"frontmatter\":{\"sidebar\":false,\"layout\":\"HomeLayout\",\"footer\":\"MIT Licensed | Copyright © 2018-present Evan You\"},\"headers\":[],\"git\":{},\"filePathRelative\":\"user-profile.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
