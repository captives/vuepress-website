<template><div><details class="tip-block details"><summary>个人介绍</summary><p>程序员</p>
</details>
<div class="tip-block danger"><p class="title">个人介绍</p><p>程序员</p>
</div>
<div class="tip-block tip"><p class="title">个人介绍</p><p>程序员</p>
</div>
</div></template>


