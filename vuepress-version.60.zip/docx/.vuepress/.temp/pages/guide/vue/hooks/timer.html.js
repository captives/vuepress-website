export const data = JSON.parse("{\"key\":\"v-025b70c8\",\"path\":\"/guide/vue/hooks/timer.html\",\"title\":\"常用钩子合集\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"常用钩子合集\",\"slug\":\"常用钩子合集\",\"link\":\"#常用钩子合集\",\"children\":[{\"level\":2,\"title\":\"定时器useTimer\",\"slug\":\"定时器usetimer\",\"link\":\"#定时器usetimer\",\"children\":[]},{\"level\":2,\"title\":\"字节格式化\",\"slug\":\"字节格式化\",\"link\":\"#字节格式化\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/vue/hooks/timer.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
