export const data = JSON.parse("{\"key\":\"v-5d496b56\",\"path\":\"/guide/vue/\",\"title\":\"Home\",\"lang\":\"guide\",\"frontmatter\":{\"home\":true,\"title\":\"Home\",\"heroText\":\"Vue 3.x\",\"heroImage\":\"./assets/images/logo.svg\",\"tagline\":\"Vue 3.x 入门demo\",\"footer\":\"<b1>captives.github.io</b1>\",\"footerHtml\":true},\"headers\":[],\"git\":{},\"filePathRelative\":\"guide/vue/README.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
