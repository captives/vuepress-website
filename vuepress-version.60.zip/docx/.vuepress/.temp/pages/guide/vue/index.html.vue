<template><div><h2>{{title}}</h2>
<Component/><CodeGroup>
<CodeGroupItem title="Page.vue">
<div class="language-vue" data-ext="vue"><pre v-pre class="language-vue"><code>File not found</code></pre></div></CodeGroupItem>
<CodeGroupItem title="ItemA.vue">
<div class="language-vue" data-ext="vue"><pre v-pre class="language-vue"><code>File not found</code></pre></div></CodeGroupItem>
<CodeGroupItem title="ItemB.vue">
<div class="language-vue" data-ext="vue"><pre v-pre class="language-vue"><code>File not found</code></pre></div></CodeGroupItem>
<CodeGroupItem title="ItemC.vue">
<div class="language-vue" data-ext="vue"><pre v-pre class="language-vue"><code>File not found</code></pre></div></CodeGroupItem>
<CodeGroupItem title="ItemD.vue">
<div class="language-vue" data-ext="vue"><pre v-pre class="language-vue"><code>File not found</code></pre></div></CodeGroupItem>
<CodeGroupItem title="ItemE.vue">
<div class="language-vue" data-ext="vue"><pre v-pre class="language-vue"><code>File not found</code></pre></div></CodeGroupItem>
</CodeGroup>
</div></template>


<script  setup>
import {computed, defineAsyncComponent, onMounted} from 'vue';
//使用全局常量
const title = computed(()=> "API：" + VUE_APP_API);
// 异步组件
const Component = defineAsyncComponent(() => import('@/views/Component.vue'));
console.log("created - 组合式API对应选项式API的created函数是setup ~");
onMounted(()=>{
  console.log('mounted  - 虚拟DOM挂载完成 ~');
})
</script>