export const data = JSON.parse("{\"key\":\"v-490081a5\",\"path\":\"/guide/vue/vue-props.html\",\"title\":\"Vue props 对象\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"Vue props 对象\",\"slug\":\"vue-props-对象\",\"link\":\"#vue-props-对象\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/vue/vue-props.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
