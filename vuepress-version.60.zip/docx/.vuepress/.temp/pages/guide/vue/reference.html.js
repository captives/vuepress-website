export const data = JSON.parse("{\"key\":\"v-b6962bfa\",\"path\":\"/guide/vue/reference.html\",\"title\":\"Vue3\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"Vue3\",\"slug\":\"vue3\",\"link\":\"#vue3\",\"children\":[{\"level\":2,\"title\":\"缩略语\",\"slug\":\"缩略语\",\"link\":\"#缩略语\",\"children\":[{\"level\":3,\"title\":\"SPA Single-Page application 单页应用程序\",\"slug\":\"spa-single-page-application-单页应用程序\",\"link\":\"#spa-single-page-application-单页应用程序\",\"children\":[]},{\"level\":3,\"title\":\"SSR Server-Side Rendering 服务端渲染\",\"slug\":\"ssr-server-side-rendering-服务端渲染\",\"link\":\"#ssr-server-side-rendering-服务端渲染\",\"children\":[]},{\"level\":3,\"title\":\"SSG Static-Site Generation 静态站点生成\",\"slug\":\"ssg-static-site-generation-静态站点生成\",\"link\":\"#ssg-static-site-generation-静态站点生成\",\"children\":[]},{\"level\":3,\"title\":\"PWA Progressive Web Apps 渐进式Web应用\",\"slug\":\"pwa-progressive-web-apps-渐进式web应用\",\"link\":\"#pwa-progressive-web-apps-渐进式web应用\",\"children\":[]}]},{\"level\":2,\"title\":\"框架\",\"slug\":\"框架\",\"link\":\"#框架\",\"children\":[]},{\"level\":2,\"title\":\"命名\",\"slug\":\"命名\",\"link\":\"#命名\",\"children\":[]},{\"level\":2,\"title\":\"组件拆分规则\",\"slug\":\"组件拆分规则\",\"link\":\"#组件拆分规则\",\"children\":[]},{\"level\":2,\"title\":\"书写规则\",\"slug\":\"书写规则\",\"link\":\"#书写规则\",\"children\":[{\"level\":3,\"title\":\"组件内class书写顺序\",\"slug\":\"组件内class书写顺序\",\"link\":\"#组件内class书写顺序\",\"children\":[]},{\"level\":3,\"title\":\"script setup 语法糖书写\",\"slug\":\"script-setup-语法糖书写\",\"link\":\"#script-setup-语法糖书写\",\"children\":[]}]},{\"level\":2,\"title\":\"\",\"slug\":\"\",\"link\":\"#\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/vue/reference.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
