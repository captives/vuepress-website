export const data = JSON.parse("{\"key\":\"v-325908e8\",\"path\":\"/guide/vue/vue-model.html\",\"title\":\"Vue v-model\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"Vue v-model\",\"slug\":\"vue-v-model\",\"link\":\"#vue-v-model\",\"children\":[{\"level\":2,\"title\":\"表单输入绑定\",\"slug\":\"表单输入绑定\",\"link\":\"#表单输入绑定\",\"children\":[]},{\"level\":2,\"title\":\"自定义组件上使用v-model\",\"slug\":\"自定义组件上使用v-model\",\"link\":\"#自定义组件上使用v-model\",\"children\":[]},{\"level\":2,\"title\":\"Vue2在组件上使用v-model\",\"slug\":\"vue2在组件上使用v-model\",\"link\":\"#vue2在组件上使用v-model\",\"children\":[]},{\"level\":2,\"title\":\"Vue3在组件上使用v-model\",\"slug\":\"vue3在组件上使用v-model\",\"link\":\"#vue3在组件上使用v-model\",\"children\":[]},{\"level\":2,\"title\":\"v-model参数\",\"slug\":\"v-model参数\",\"link\":\"#v-model参数\",\"children\":[]},{\"level\":2,\"title\":\"多个v-model绑定\",\"slug\":\"多个v-model绑定\",\"link\":\"#多个v-model绑定\",\"children\":[]},{\"level\":2,\"title\":\"处理v-model修饰符\",\"slug\":\"处理v-model修饰符\",\"link\":\"#处理v-model修饰符\",\"children\":[]}]},{\"level\":1,\"title\":\"Vue .sync\",\"slug\":\"vue-sync\",\"link\":\"#vue-sync\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/vue/vue-model.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
