export const data = JSON.parse("{\"key\":\"v-bfca68de\",\"path\":\"/guide/vue/nuxt-study-notes.html\",\"title\":\"Nuxt\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"Nuxt\",\"slug\":\"nuxt\",\"link\":\"#nuxt\",\"children\":[{\"level\":2,\"title\":\"配置相关\",\"slug\":\"配置相关\",\"link\":\"#配置相关\",\"children\":[{\"level\":3,\"title\":\"引入第三方库\",\"slug\":\"引入第三方库\",\"link\":\"#引入第三方库\",\"children\":[]},{\"level\":3,\"title\":\"打包删除console\",\"slug\":\"打包删除console\",\"link\":\"#打包删除console\",\"children\":[]}]}]}],\"git\":{},\"filePathRelative\":\"guide/vue/nuxt-study-notes.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
