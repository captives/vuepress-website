<template><div><h1 id="发布代码到npm库" tabindex="-1"><a class="header-anchor" href="#发布代码到npm库" aria-hidden="true">#</a> 发布代码到npm库</h1>
<h2 id="账号" tabindex="-1"><a class="header-anchor" href="#账号" aria-hidden="true">#</a> 账号</h2>
<p>登陆<a href="http://npmjs.org/" target="_blank" rel="noopener noreferrer">npm<ExternalLinkIcon/></a>注册账号，结束后<strong>务必</strong>进入邮箱进行验证账号；</p>
<h2 id="代码库名称" tabindex="-1"><a class="header-anchor" href="#代码库名称" aria-hidden="true">#</a> 代码库名称</h2>
<p>命名之前，一定要在npm库搜索，是否被使用</p>
<h2 id="创建项目" tabindex="-1"><a class="header-anchor" href="#创建项目" aria-hidden="true">#</a> 创建项目</h2>
<h2 id="新建目录" tabindex="-1"><a class="header-anchor" href="#新建目录" aria-hidden="true">#</a> 新建目录</h2>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">mkdir</span> captive-admin-ui
<span class="token builtin class-name">cd</span> captive-admin-ui
</code></pre></div><p>配置package.json，不仅仅用来标明依赖和npm script脚本，也是npm包被外界识别的配置文件。</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> init
</code></pre></div><p>根据提示进行操作，即可</p>
<div class="language-json line-numbers-mode" data-ext="json"><pre v-pre class="language-json"><code><span class="token punctuation">{</span>
    <span class="token property">"name"</span><span class="token operator">:</span> <span class="token string">"captive-admin-ui"</span><span class="token punctuation">,</span>
    <span class="token property">"version"</span><span class="token operator">:</span> <span class="token string">"1.0.1"</span><span class="token punctuation">,</span>
    <span class="token property">"description"</span><span class="token operator">:</span> <span class="token string">"基于element-ui库开发对后台UI库"</span><span class="token punctuation">,</span>
    <span class="token property">"main"</span><span class="token operator">:</span> <span class="token string">"index.js"</span><span class="token punctuation">,</span>
    <span class="token property">"scripts"</span><span class="token operator">:</span> <span class="token punctuation">{</span>
        <span class="token property">"test"</span><span class="token operator">:</span> <span class="token string">"echo \"Error: no test specified\" &amp;&amp; exit 1"</span>
    <span class="token punctuation">}</span><span class="token punctuation">,</span>
    <span class="token property">"keywords"</span><span class="token operator">:</span> <span class="token punctuation">[</span>
        <span class="token string">"element-ui"</span><span class="token punctuation">,</span>
        <span class="token string">"admin"</span>
    <span class="token punctuation">]</span><span class="token punctuation">,</span>
    <span class="token property">"author"</span><span class="token operator">:</span> <span class="token string">"captives"</span><span class="token punctuation">,</span>
    <span class="token property">"license"</span><span class="token operator">:</span> <span class="token string">"ISC"</span><span class="token punctuation">,</span>
    <span class="token property">"dependencies"</span><span class="token operator">:</span> <span class="token punctuation">{</span>
        <span class="token property">"element-ui"</span><span class="token operator">:</span> <span class="token string">"^2.15.1"</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="本地测试" tabindex="-1"><a class="header-anchor" href="#本地测试" aria-hidden="true">#</a> 本地测试</h2>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> pack
</code></pre></div><p>会生成一个 tgz版本文件
打开一个新的项目，路径为刚刚生成的路径,即可安装使用</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> <span class="token function">install</span> <span class="token variable">${path}</span>/captive-admin-ui-1.0.0.tgz
</code></pre></div><h2 id="登陆" tabindex="-1"><a class="header-anchor" href="#登陆" aria-hidden="true">#</a> 登陆</h2>
<p>在本地命令行下，登陆账号</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code> <span class="token function">npm</span> adduser 
</code></pre></div><p>按照提示，输入账户名，密码，以及账户的email邮箱地址；这时候看一下package.json中author尽量与npm账户一致。</p>
<p>检查是否登录成功</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> <span class="token function">who</span> am i
</code></pre></div><p>如果不成功则重新登录一下</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> login
</code></pre></div><h2 id="提交发布" tabindex="-1"><a class="header-anchor" href="#提交发布" aria-hidden="true">#</a> 提交发布</h2>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> publish
</code></pre></div><h2 id="测试提交" tabindex="-1"><a class="header-anchor" href="#测试提交" aria-hidden="true">#</a> 测试提交</h2>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> i captive-admin-ui <span class="token parameter variable">--save</span>
</code></pre></div><h2 id="撤销当前提交" tabindex="-1"><a class="header-anchor" href="#撤销当前提交" aria-hidden="true">#</a> 撤销当前提交</h2>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> unpublish  <span class="token parameter variable">--force</span> //删除包
</code></pre></div><hr/>
</div></template>


