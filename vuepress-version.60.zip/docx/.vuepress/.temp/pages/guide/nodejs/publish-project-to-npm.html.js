export const data = JSON.parse("{\"key\":\"v-2b0cba16\",\"path\":\"/guide/nodejs/publish-project-to-npm.html\",\"title\":\"发布代码到npm库\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"发布代码到npm库\",\"slug\":\"发布代码到npm库\",\"link\":\"#发布代码到npm库\",\"children\":[{\"level\":2,\"title\":\"账号\",\"slug\":\"账号\",\"link\":\"#账号\",\"children\":[]},{\"level\":2,\"title\":\"代码库名称\",\"slug\":\"代码库名称\",\"link\":\"#代码库名称\",\"children\":[]},{\"level\":2,\"title\":\"创建项目\",\"slug\":\"创建项目\",\"link\":\"#创建项目\",\"children\":[]},{\"level\":2,\"title\":\"新建目录\",\"slug\":\"新建目录\",\"link\":\"#新建目录\",\"children\":[]},{\"level\":2,\"title\":\"本地测试\",\"slug\":\"本地测试\",\"link\":\"#本地测试\",\"children\":[]},{\"level\":2,\"title\":\"登陆\",\"slug\":\"登陆\",\"link\":\"#登陆\",\"children\":[]},{\"level\":2,\"title\":\"提交发布\",\"slug\":\"提交发布\",\"link\":\"#提交发布\",\"children\":[]},{\"level\":2,\"title\":\"测试提交\",\"slug\":\"测试提交\",\"link\":\"#测试提交\",\"children\":[]},{\"level\":2,\"title\":\"撤销当前提交\",\"slug\":\"撤销当前提交\",\"link\":\"#撤销当前提交\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/nodejs/publish-project-to-npm.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
