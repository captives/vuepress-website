export const data = JSON.parse("{\"key\":\"v-2b0c4e6d\",\"path\":\"/guide/website-resource.html\",\"title\":\"开发工具收藏\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"开发工具收藏\",\"slug\":\"开发工具收藏\",\"link\":\"#开发工具收藏\",\"children\":[{\"level\":2,\"title\":\"常用前端库\",\"slug\":\"常用前端库\",\"link\":\"#常用前端库\",\"children\":[{\"level\":3,\"title\":\"xtermjs\",\"slug\":\"xtermjs\",\"link\":\"#xtermjs\",\"children\":[]},{\"level\":3,\"title\":\"webssh\",\"slug\":\"webssh\",\"link\":\"#webssh\",\"children\":[]},{\"level\":3,\"title\":\"handlebars\",\"slug\":\"handlebars\",\"link\":\"#handlebars\",\"children\":[]},{\"level\":3,\"title\":\"Metalsmith\",\"slug\":\"metalsmith\",\"link\":\"#metalsmith\",\"children\":[]}]},{\"level\":2,\"title\":\"后端\",\"slug\":\"后端\",\"link\":\"#后端\",\"children\":[]},{\"level\":2,\"title\":\"前端\",\"slug\":\"前端\",\"link\":\"#前端\",\"children\":[]},{\"level\":2,\"title\":\"工具\",\"slug\":\"工具\",\"link\":\"#工具\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/website-resource.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
