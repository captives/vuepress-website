export const data = JSON.parse("{\"key\":\"v-5efb549b\",\"path\":\"/guide/frontend.html\",\"title\":\"优秀学习资源\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"优秀学习资源\",\"slug\":\"优秀学习资源\",\"link\":\"#优秀学习资源\",\"children\":[{\"level\":2,\"title\":\"常用前端库\",\"slug\":\"常用前端库\",\"link\":\"#常用前端库\",\"children\":[{\"level\":3,\"title\":\"xtermjs\",\"slug\":\"xtermjs\",\"link\":\"#xtermjs\",\"children\":[]},{\"level\":3,\"title\":\"webssh\",\"slug\":\"webssh\",\"link\":\"#webssh\",\"children\":[]},{\"level\":3,\"title\":\"handlebars\",\"slug\":\"handlebars\",\"link\":\"#handlebars\",\"children\":[]},{\"level\":3,\"title\":\"Metalsmith\",\"slug\":\"metalsmith\",\"link\":\"#metalsmith\",\"children\":[]},{\"level\":3,\"title\":\"fullcalendar\",\"slug\":\"fullcalendar\",\"link\":\"#fullcalendar\",\"children\":[]}]},{\"level\":2,\"title\":\"优秀博文\",\"slug\":\"优秀博文\",\"link\":\"#优秀博文\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/frontend.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
