<template><div><h1 id="优秀学习资源" tabindex="-1"><a class="header-anchor" href="#优秀学习资源" aria-hidden="true">#</a> 优秀学习资源</h1>
<p><a href="https://www.bookstack.cn/" target="_blank" rel="noopener noreferrer">BookStack<ExternalLinkIcon/></a>
全科技术网站学习平台</p>
<p><a href="https://www.30secondsofcode.org" target="_blank" rel="noopener noreferrer">30 秒的代码<ExternalLinkIcon/></a>
满足您所有开发需求的简短代码片段</p>
<p><a href="https://muyiy.vip/" target="_blank" rel="noopener noreferrer">木易杨前端进阶<ExternalLinkIcon/></a>
高级前端进阶之路</p>
<p><a href="https://xflihaibo.github.io/docs/#/" target="_blank" rel="noopener noreferrer">幸福的拾荒者<ExternalLinkIcon/></a>
<a href="https://xflihaibo.github.io/docs/#/standard/" target="_blank" rel="noopener noreferrer">开发规范<ExternalLinkIcon/></a> | <a href="https://xflihaibo.github.io/docs/#/web/" target="_blank" rel="noopener noreferrer">前端汇总<ExternalLinkIcon/></a> | <a href="https://xflihaibo.github.io/docs/#/tool/" target="_blank" rel="noopener noreferrer">工具集合<ExternalLinkIcon/></a> | <a href="https://xflihaibo.github.io/docs/#/advance/" target="_blank" rel="noopener noreferrer">进阶知识<ExternalLinkIcon/></a></p>
<h2 id="常用前端库" tabindex="-1"><a class="header-anchor" href="#常用前端库" aria-hidden="true">#</a> 常用前端库</h2>
<h3 id="xtermjs" tabindex="-1"><a class="header-anchor" href="#xtermjs" aria-hidden="true">#</a> xtermjs</h3>
<ul>
<li>Xterm.js是用TypeScript编写的前端组件，它使应用程序可以将功能齐全的终端带给浏览器中的用户。诸如VS Code，Hyper和Theia等热门项目都使用了它。</li>
</ul>
<h3 id="webssh" tabindex="-1"><a class="header-anchor" href="#webssh" aria-hidden="true">#</a> webssh</h3>
<ul>
<li>基于Web的ssh客户端。<a href="https://github.com/huashengdun/webssh" target="_blank" rel="noopener noreferrer">github<ExternalLinkIcon/></a></li>
</ul>
<h3 id="handlebars" tabindex="-1"><a class="header-anchor" href="#handlebars" aria-hidden="true">#</a> <a href="https://www.npmjs.com/package/handlebars" target="_blank" rel="noopener noreferrer">handlebars<ExternalLinkIcon/></a></h3>
<ul>
<li>模板语法库</li>
</ul>
<h3 id="metalsmith" tabindex="-1"><a class="header-anchor" href="#metalsmith" aria-hidden="true">#</a> <a href="https://www.npmjs.com/package/metalsmith" target="_blank" rel="noopener noreferrer">Metalsmith<ExternalLinkIcon/></a></h3>
<ul>
<li>所有逻辑都由插件处理。您只需将它们链接在一起即可</li>
</ul>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token function">Metalsmith</span><span class="token punctuation">(</span>__dirname<span class="token punctuation">)</span>
  <span class="token punctuation">.</span><span class="token function">use</span><span class="token punctuation">(</span><span class="token function">markdown</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">)</span>
  <span class="token punctuation">.</span><span class="token function">use</span><span class="token punctuation">(</span><span class="token function">layouts</span><span class="token punctuation">(</span><span class="token string">'handlebars'</span><span class="token punctuation">)</span><span class="token punctuation">)</span>
  <span class="token punctuation">.</span><span class="token function">build</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">err</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
    <span class="token keyword">if</span> <span class="token punctuation">(</span>err<span class="token punctuation">)</span> <span class="token keyword">throw</span> err<span class="token punctuation">;</span>
    console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'Build finished!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
  <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="fullcalendar" tabindex="-1"><a class="header-anchor" href="#fullcalendar" aria-hidden="true">#</a> <a href="https://fullcalendar.io/" target="_blank" rel="noopener noreferrer">fullcalendar<ExternalLinkIcon/></a></h3>
<ul>
<li>一款排班时间日历插件库，支持vue2.x，vue3.x 及react</li>
</ul>
<h2 id="优秀博文" tabindex="-1"><a class="header-anchor" href="#优秀博文" aria-hidden="true">#</a> 优秀博文</h2>
<p><a href="https://juejin.cn/post/6844903789388890119" target="_blank" rel="noopener noreferrer">我是如何让公司后台管理系统焕然一新的(上) -性能优化<ExternalLinkIcon/></a>
<a href="https://juejin.cn/post/6844903789388890126" target="_blank" rel="noopener noreferrer">我是如何让公司后台管理系统焕然一新的（下）-封装组件<ExternalLinkIcon/></a></p>
<p><a href="https://www.cnblogs.com/onepixel/articles/7674659.html" target="_blank" rel="noopener noreferrer">十大经典排序算法（动图演示）<ExternalLinkIcon/></a></p>
</div></template>


