export const data = JSON.parse("{\"key\":\"v-5b5ac426\",\"path\":\"/guide/typescript/get-started.html\",\"title\":\"快速开始\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"快速开始\",\"slug\":\"快速开始\",\"link\":\"#快速开始\",\"children\":[{\"level\":2,\"title\":\"环境\",\"slug\":\"环境\",\"link\":\"#环境\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/typescript/get-started.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
