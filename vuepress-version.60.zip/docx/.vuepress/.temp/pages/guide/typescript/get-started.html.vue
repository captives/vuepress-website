<template><div><h1 id="快速开始" tabindex="-1"><a class="header-anchor" href="#快速开始" aria-hidden="true">#</a> 快速开始</h1>
<h2 id="环境" tabindex="-1"><a class="header-anchor" href="#环境" aria-hidden="true">#</a> 环境</h2>
<ul>
<li>安装 <a href="https://code.visualstudio.com/" target="_blank" rel="noopener noreferrer">Visual Studio Code<ExternalLinkIcon/></a></li>
<li>安装Visual Studio Code的插件<code v-pre>TypeScript</code>、<code v-pre>Code Runner</code></li>
<li>安装编译环境</li>
</ul>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> <span class="token function">install</span> <span class="token parameter variable">-g</span> typescript
</code></pre></div><p>编译<code v-pre>ts</code>文件</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code>tsc index.ts
</code></pre></div><ul>
<li>安装运行环境</li>
</ul>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> <span class="token function">install</span> <span class="token parameter variable">-g</span> ts-node tslib @types/node
</code></pre></div><p>运行<code v-pre>ts</code>文件</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code>ts-node index.ts
</code></pre></div><p>更多参考<a href="https://www.tslang.cn/docs/handbook/typescript-in-5-minutes.html" target="_blank" rel="noopener noreferrer">5分钟上手TypeScript<ExternalLinkIcon/></a></p>
</div></template>


