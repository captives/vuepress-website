export const data = JSON.parse("{\"key\":\"v-b12bee54\",\"path\":\"/guide/javascript/javascript.html\",\"title\":\"JavaScript 基础\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"JavaScript 基础\",\"slug\":\"javascript-基础\",\"link\":\"#javascript-基础\",\"children\":[{\"level\":3,\"title\":\"全局对象属性（三个值、十三个函数）\",\"slug\":\"全局对象属性-三个值、十三个函数\",\"link\":\"#全局对象属性-三个值、十三个函数\",\"children\":[]},{\"level\":3,\"title\":\"六种异步方案\",\"slug\":\"六种异步方案\",\"link\":\"#六种异步方案\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/javascript/javascript.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
