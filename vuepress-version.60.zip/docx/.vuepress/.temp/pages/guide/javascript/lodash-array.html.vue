<template><div><h1 id="lodash-数组-array" tabindex="-1"><a class="header-anchor" href="#lodash-数组-array" aria-hidden="true">#</a> lodash 数组 Array</h1>
<h2 id="检索" tabindex="-1"><a class="header-anchor" href="#检索" aria-hidden="true">#</a> 检索</h2>
<h3 id="indexof-array-value-fromindex-0" tabindex="-1"><a class="header-anchor" href="#indexof-array-value-fromindex-0" aria-hidden="true">#</a> _.indexOf(array, value, [fromIndex = 0])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 需要查找的数组。</li>
<li>value (*): 需要查找的值。</li>
<li>[fromIndex=0] (number): 开始查询的位置。
返回值</li>
<li>(number): 返回 值value在数组中的索引位置, 没有找到为返回-1。</li>
</ul>
</details>
<p>使用<a href="http://ecma-international.org/ecma-262/6.0/#sec-samevaluezero" target="_blank" rel="noopener noreferrer">SameValueZero<ExternalLinkIcon/></a> 等值比较，返回首次<code v-pre>value</code>在数组<code v-pre>array</code>中被找到的索引值， 如果<code v-pre>fromIndex</code>为负值，将从数组<code v-pre>array</code>尾端索引进行匹配。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">indexOf</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 1</span>
 
<span class="token comment">// Search from the `fromIndex`.</span>
_<span class="token punctuation">.</span><span class="token function">indexOf</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 3</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="findindex-array-predicate-identity-fromindex-0" tabindex="-1"><a class="header-anchor" href="#findindex-array-predicate-identity-fromindex-0" aria-hidden="true">#</a> _.findIndex(array, [predicate = _.identity], [fromIndex=0])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要搜索的数组。</li>
<li>[predicate=_.identity] (Array|Function|Object|string): 这个函数会在每一次迭代调用。</li>
<li>[fromIndex=0] (number): The index to search from.</li>
</ul>
<p>返回值</p>
<ul>
<li>(number): 返回找到元素的 索引值（index），否则返回 -1</li>
</ul>
</details>
<p>该方法类似<code v-pre>_.find</code>，区别是该方法返回第一个通过<code v-pre>predicate</code>判断为真值的元素的索引值（index），而不是元素本身。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span>  <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>    <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">findIndex</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token parameter">item</span> <span class="token operator">=></span> item<span class="token punctuation">.</span>user <span class="token operator">==</span> <span class="token string">'barney'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 0</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">findIndex</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 1</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">findIndex</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 0</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">findIndex</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 2</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="findlastindex-array-predicate-identity-fromindex-array-length-1" tabindex="-1"><a class="header-anchor" href="#findlastindex-array-predicate-identity-fromindex-array-length-1" aria-hidden="true">#</a> _.findLastIndex(array, [predicate = _.identity], [fromIndex=array.length-1])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要搜索的数组。</li>
<li>[predicate=_.identity] (Array|Function|Object|string): 这个函数会在每一次迭代调用。</li>
<li>[fromIndex=array.length-1] (number): The index to search from.</li>
</ul>
<p>返回值</p>
<ul>
<li>(number): 返回找到元素的 索引值（index），否则返回 -1</li>
</ul>
</details>
<p>这个方式类似<code v-pre>_.findIndex</code>，区别是它是从右到左的迭代集合array中的元素。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span>  <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>    <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">findLastIndex</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">o</span><span class="token punctuation">)</span> <span class="token punctuation">{</span> <span class="token keyword">return</span> o<span class="token punctuation">.</span>user <span class="token operator">==</span> <span class="token string">'pebbles'</span><span class="token punctuation">;</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 2</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">findLastIndex</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 0</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">findLastIndex</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 2</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">findLastIndex</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 0</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="lastindexof-array-value-fromindex-array-length-1" tabindex="-1"><a class="header-anchor" href="#lastindexof-array-value-fromindex-array-length-1" aria-hidden="true">#</a> _.lastIndexOf(array, value, [fromIndex=array.length-1])</h3>
<p>这个方法类似<code v-pre>_.indexOf</code>，区别是它是从右到左遍历<code v-pre>array</code>的元素。</p>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要搜索的数组。</li>
<li>value (*): 要搜索的值。</li>
<li>[fromIndex=array.length-1] (number): 开始搜索的索引值。</li>
</ul>
<p>返回值</p>
<ul>
<li>(number): 返回匹配值的索引值，否则返回 -1。</li>
</ul>
</details>
<div class="language-text line-numbers-mode" data-ext="text"><pre v-pre class="language-text"><code>_.lastIndexOf([1, 2, 1, 2], 2);
// => 3
 
// Search from the `fromIndex`.
_.lastIndexOf([1, 2, 1, 2], 2, 2);
// => 1
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="head-array" tabindex="-1"><a class="header-anchor" href="#head-array" aria-hidden="true">#</a> _.head(array)</h3>
<p>获取数组 array 的第一个元素。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">head</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 1</span>
 
_<span class="token punctuation">.</span><span class="token function">head</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => undefined</span>
</code></pre></div><h3 id="last-array" tabindex="-1"><a class="header-anchor" href="#last-array" aria-hidden="true">#</a> _.last(array)</h3>
<p>获取array中的最后一个元素。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">last</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 3</span>
</code></pre></div><h3 id="initial-array" tabindex="-1"><a class="header-anchor" href="#initial-array" aria-hidden="true">#</a> _.initial(array)</h3>
<p>获取数组<code v-pre>array</code>中除了最后一个元素之外的所有元素（去除数组array中的最后一个元素）。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">initial</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2]</span>
</code></pre></div><h3 id="tail-array" tabindex="-1"><a class="header-anchor" href="#tail-array" aria-hidden="true">#</a> _.tail(array)</h3>
<p>返回 array 数组的切片，除了array数组第一个元素以外的全部元素。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">tail</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2, 3]</span>
</code></pre></div><h3 id="nth-array-n-0" tabindex="-1"><a class="header-anchor" href="#nth-array-n-0" aria-hidden="true">#</a> _.nth(array, [n=0])</h3>
<p>获取array数组的第n个元素。如果n为负数，则返回从数组结尾开始的第n个元素。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token string">'a'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">,</span> <span class="token string">'c'</span><span class="token punctuation">,</span> <span class="token string">'d'</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">nth</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'b'</span>
 
_<span class="token punctuation">.</span><span class="token function">nth</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token operator">-</span><span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'c';</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="take-array-n-1" tabindex="-1"><a class="header-anchor" href="#take-array-n-1" aria-hidden="true">#</a> _.take(array, [n=1])</h3>
<p>创建一个数组切片，从array数组的起始元素开始提取n个元素。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">take</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1]</span>
 
_<span class="token punctuation">.</span><span class="token function">take</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2]</span>
 
_<span class="token punctuation">.</span><span class="token function">take</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
 
_<span class="token punctuation">.</span><span class="token function">take</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">0</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => []</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="takeright-array-n-1" tabindex="-1"><a class="header-anchor" href="#takeright-array-n-1" aria-hidden="true">#</a> _.takeRight(array, [n=1])</h3>
<p>创建一个数组切片，从array数组的最后一个元素开始提取n个元素。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">takeRight</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [3]</span>
 
_<span class="token punctuation">.</span><span class="token function">takeRight</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2, 3]</span>
 
_<span class="token punctuation">.</span><span class="token function">takeRight</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
 
_<span class="token punctuation">.</span><span class="token function">takeRight</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">0</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => []</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="takerightwhile-array-predicate-identity" tabindex="-1"><a class="header-anchor" href="#takerightwhile-array-predicate-identity" aria-hidden="true">#</a> _.takeRightWhile(array, [predicate = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要检索的数组。</li>
<li>[predicate = _.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回
-(Array): 返回 array 数组的切片。</p>
</details>
<p>从array数组的最后一个元素开始提取元素，直到<code v-pre>predicate</code>返回假值。<code v-pre>predicate</code>会传入三个参数： <code v-pre>(value, index, array)</code>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span>  <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>    <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">takeRightWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token parameter">item</span> <span class="token operator">=></span> <span class="token operator">!</span>item<span class="token punctuation">.</span>active<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['fred', 'pebbles']</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">takeRightWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['pebbles']</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">takeRightWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['fred', 'pebbles']</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">takeRightWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => []</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="takewhile-array-predicate-identity" tabindex="-1"><a class="header-anchor" href="#takewhile-array-predicate-identity" aria-hidden="true">#</a> _.takeWhile(array, [predicate = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要检索的数组。</li>
<li>[predicate = _.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回
-(Array): 返回 array 数组的切片。</p>
</details>
<p>从<code v-pre>array</code>数组的起始元素开始提取元素，直到<code v-pre>predicate</code>返回假值。<code v-pre>predicate</code>会传入三个参数：<code v-pre>(value, index, array)</code>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span>  <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>    <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span><span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">takeWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token parameter">item</span> <span class="token operator">=></span> <span class="token operator">!</span>item<span class="token punctuation">.</span>active<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney', 'fred']</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">takeWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney']</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">takeWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney', 'fred']</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">takeWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => []</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="slice-array-start-0-end-array-length" tabindex="-1"><a class="header-anchor" href="#slice-array-start-0-end-array-length" aria-hidden="true">#</a> _.slice(array, [start=0], [end=array.length])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要裁剪数组。</li>
<li>[start=0] (number): 开始位置。</li>
<li>[end=array.length] (number): 结束位置。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回 数组array 裁剪部分的新数组。</li>
</ul>
</details>
<p>裁剪数组<code v-pre>array</code>，从<code v-pre>start</code>位置开始到<code v-pre>end</code>结束，但不包括<code v-pre>end</code>本身的位置。</p>
<p>:::info
这个方法用于代替<a href="https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Array/slice" target="_blank" rel="noopener noreferrer">Array#slice<ExternalLinkIcon/></a>来确保数组正确返回。
:::</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token keyword">var</span> evens <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">slice</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// =>  [1, 2, 3, 4]</span>

console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>evens<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2, 3]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="分组" tabindex="-1"><a class="header-anchor" href="#分组" aria-hidden="true">#</a> 分组</h2>
<h3 id="chunk-array-size-1" tabindex="-1"><a class="header-anchor" href="#chunk-array-size-1" aria-hidden="true">#</a> _.chunk(array, [size=1])</h3>
<p>将数组<code v-pre>array</code>拆分成多个<code v-pre>size</code>长度的区块，并将这些区块组成一个新数组。 如果<code v-pre>array</code>无法被分割成全部等长的区块，那么最后剩余的元素将组成一个区块。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">chunk</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'a'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">,</span> <span class="token string">'c'</span><span class="token punctuation">,</span> <span class="token string">'d'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [['a', 'b'], ['c', 'd']]</span>
 
_<span class="token punctuation">.</span><span class="token function">chunk</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'a'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">,</span> <span class="token string">'c'</span><span class="token punctuation">,</span> <span class="token string">'d'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [['a', 'b', 'c'], ['d']]</span>
</code></pre></div><h3 id="zip-arrays" tabindex="-1"><a class="header-anchor" href="#zip-arrays" aria-hidden="true">#</a> _.zip([arrays])</h3>
<p>创建一个分组元素的数组，数组的第一个元素包含所有给定数组的第一个元素，数组的第二个元素包含所有给定数组的第二个元素，以此类推。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">zip</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'fred'</span><span class="token punctuation">,</span> <span class="token string">'barney'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">30</span><span class="token punctuation">,</span> <span class="token number">40</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token boolean">true</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [['fred', 30, true], ['barney', 40, false]]</span>
</code></pre></div><h3 id="unzip-array" tabindex="-1"><a class="header-anchor" href="#unzip-array" aria-hidden="true">#</a> _.unzip(array)</h3>
<p>这个方法类似于<code v-pre>_.zip</code>，除了它接收分组元素的数组，并且创建一个数组，分组元素到打包前的结构。（返回数组的第一个元素包含所有的输入数组的第一元素，第一个元素包含了所有的输入数组的第二元素，依此类推。）</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> zipped <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">zip</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'fred'</span><span class="token punctuation">,</span> <span class="token string">'barney'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">30</span><span class="token punctuation">,</span> <span class="token number">40</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token boolean">true</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [['fred', 30, true], ['barney', 40, false]]</span>
 
_<span class="token punctuation">.</span><span class="token function">unzip</span><span class="token punctuation">(</span>zipped<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [['fred', 'barney'], [30, 40], [true, false]]</span>
</code></pre></div><h3 id="zipwith-arrays-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#zipwith-arrays-iteratee-identity" aria-hidden="true">#</a> _.zipWith([arrays], [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>[arrays] (...Array): 要处理的数组。</li>
<li>[iteratee=_.identity] (Function): 函数用来组合分组的值。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回分组元素的新数组。</li>
</ul>
</details>
<p>这个方法类似于<code v-pre>_.zip</code>，不同之处在于它接受一个 iteratee（迭代函数），来 指定分组的值应该如何被组合。 该iteratee调用每个组的元素： (...group).</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">zipWith</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">10</span><span class="token punctuation">,</span> <span class="token number">20</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">100</span><span class="token punctuation">,</span> <span class="token number">200</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">(</span><span class="token parameter">a<span class="token punctuation">,</span> b<span class="token punctuation">,</span> c</span><span class="token punctuation">)</span> <span class="token operator">=></span> a <span class="token operator">+</span> b <span class="token operator">+</span> c<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [111, 222]</span>
</code></pre></div><h3 id="unzipwith-array-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#unzipwith-array-iteratee-identity" aria-hidden="true">#</a> _.unzipWith(array, [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>[arrays] (...Array): 要处理的数组。</li>
<li>[iteratee=_.identity] (Function): 函数用来组合分组的值。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回分组元素的新数组。</li>
</ul>
</details>
<p>此方法类似于<code v-pre>_.unzip</code>，除了它接受一个iteratee指定重组值应该如何被组合。iteratee 调用时会传入每个分组的值： (...group)。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> zipped <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">zip</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">10</span><span class="token punctuation">,</span> <span class="token number">20</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">100</span><span class="token punctuation">,</span> <span class="token number">200</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [[1, 10, 100], [2, 20, 200]]</span>
 
_<span class="token punctuation">.</span><span class="token function">unzipWith</span><span class="token punctuation">(</span>zipped<span class="token punctuation">,</span> _<span class="token punctuation">.</span>add<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [3, 30, 300]</span>
</code></pre></div><h2 id="合并" tabindex="-1"><a class="header-anchor" href="#合并" aria-hidden="true">#</a> 合并</h2>
<h3 id="join-array-separator" tabindex="-1"><a class="header-anchor" href="#join-array-separator" aria-hidden="true">#</a> _.join(array, [separator=','])</h3>
<p>将 array 中的所有元素转换为由 separator 分隔的字符串</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">join</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'a'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">,</span> <span class="token string">'c'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'~'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'a~b~c'</span>
</code></pre></div><h3 id="concat-array-values" tabindex="-1"><a class="header-anchor" href="#concat-array-values" aria-hidden="true">#</a> _.concat(array, [values])</h3>
<p>创建一个新数组，将<code v-pre>array</code>与任何数组 或 值连接在一起。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token keyword">var</span> other <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">concat</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>other<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3, [4]]</span>
 
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="union-arrays" tabindex="-1"><a class="header-anchor" href="#union-arrays" aria-hidden="true">#</a> _.union([arrays])</h3>
<p>创建一个按顺序返回一个新的联合数组,并且数组的元素是唯一的。所有给定数组的元素值使用<a href="http://ecma-international.org/ecma-262/6.0/#sec-samevaluezero" target="_blank" rel="noopener noreferrer">SameValueZero<ExternalLinkIcon/></a>做等值比较。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">union</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span>
<span class="token comment">// => [2, 1, 3]</span>
</code></pre></div><h3 id="unionby-arrays-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#unionby-arrays-iteratee-identity" aria-hidden="true">#</a> _.unionBy([arrays], [iteratee = _.identity])</h3>
<p>这个方法类似<a href="https://www.lodashjs.com/docs/lodash.union" target="_blank" rel="noopener noreferrer">_.union<ExternalLinkIcon/></a>，除了它接受一个<code v-pre>iteratee</code>（迭代函数），调用每一个数组（array）的每个元素以产生唯一性计算的标准。iteratee 会传入一个参数：(value)。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">unionBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">2.1</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">1.2</span><span class="token punctuation">,</span> <span class="token number">2.3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> Math<span class="token punctuation">.</span>floor<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2.1, 1.2]</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">unionBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'x'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 1 }, { 'x': 2 }]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="unionwith-arrays-comparator" tabindex="-1"><a class="header-anchor" href="#unionwith-arrays-comparator" aria-hidden="true">#</a> _.unionWith([arrays], [comparator])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>[arrays] (...Array): 要检查的数组。</li>
<li>[comparator] (Function): 比较函数，调用每个元素。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回一个新的联合数组。</li>
</ul>
</details>
<p>这个方法类似<a href="https://www.lodashjs.com/docs/lodash.union" target="_blank" rel="noopener noreferrer">_.union<ExternalLinkIcon/></a>，除了它接受一个<code v-pre>comparator</code>调用比较<code v-pre>arrays</code>数组的每一个元素。<code v-pre>comparator</code>调用时会传入2个参数：<code v-pre>(arrVal, othVal)</code>。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> objects <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token keyword">var</span> others <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">unionWith</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> others<span class="token punctuation">,</span> _<span class="token punctuation">.</span>isEqual<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 1, 'y': 2 }, { 'x': 2, 'y': 1 }, { 'x': 1, 'y': 1 }]</span>
</code></pre></div><h2 id="过滤" tabindex="-1"><a class="header-anchor" href="#过滤" aria-hidden="true">#</a> 过滤</h2>
<h3 id="difference-array-values" tabindex="-1"><a class="header-anchor" href="#difference-array-values" aria-hidden="true">#</a> _.difference(array, [values])</h3>
<p>创建一个具有唯一<code v-pre>array</code>值的数组，每个值不包含在其他给定的数组中。该方法使用SameValueZero做相等比较。结果值是从第一数组中选择, 顺序是由第一个数组中的顺序确定。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>创建一个新数组，这个数组中的值，为第一个参数（array）排除了给定数组中的值。</p>
</div>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">difference</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [3, 1]</span>
</code></pre></div><h3 id="differenceby-array-values-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#differenceby-array-values-iteratee-identity" aria-hidden="true">#</a> _.differenceBy(array, [values], [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要检查的数组。</li>
<li>[values] (...Array): 排除的值。</li>
<li>[iteratee=_.identity] (Array|Function|Object|string): iteratee 调用每个元素。</li>
</ul>
<p>返回：
(Array): 返回一个过滤值后的新数组。</p>
</details>
<p>这个方法类似<code v-pre>_.difference</code> ，增加一个 <code v-pre>iteratee</code>（注：迭代器）， 调用<code v-pre>array</code>和<code v-pre>values</code>中的每个元素以产生比较的标准。 结果值是从第一数组中选择。<code v-pre>iteratee</code>会调用一个参数：(value)。</p>
<blockquote>
<p>首先使用迭代器分别迭代array 和 values中的每个元素，返回的值作为比较值</p>
</blockquote>
<div class="tip-block warning"><p class="title">注意：</p><p>不像<a href="https://www.lodashjs.com/docs/lodash.differenceBy#pullAllBy" target="_blank" rel="noopener noreferrer">_.pullAllBy<ExternalLinkIcon/></a>，这个方法会返回一个新数组。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token comment">//迭代器把值Math.floor后进行比较，返回的原值</span>
_<span class="token punctuation">.</span><span class="token function">differenceBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">3.1</span><span class="token punctuation">,</span> <span class="token number">2.2</span><span class="token punctuation">,</span> <span class="token number">1.3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">4.4</span><span class="token punctuation">,</span> <span class="token number">2.5</span><span class="token punctuation">]</span><span class="token punctuation">,</span> Math<span class="token punctuation">.</span>floor<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [3.1, 1.3]</span>
 
<span class="token comment">// 指定对象属性排除</span>
_<span class="token punctuation">.</span><span class="token function">differenceBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">3</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">3</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'x'</span><span class="token punctuation">)</span>
<span class="token comment">// => [{x: 2, y: 3}]</span>

_<span class="token punctuation">.</span><span class="token function">differenceBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">3</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">3</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'x'</span><span class="token punctuation">)</span>
<span class="token comment">// => [{x: 2, y: 3}, { 'x': 1, 'y': 3 }]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="differencewith-array-values-comparator" tabindex="-1"><a class="header-anchor" href="#differencewith-array-values-comparator" aria-hidden="true">#</a> _.differenceWith(array, [values], [comparator])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要检查的数组。</li>
<li>[values] (...Array): 排除的值。</li>
<li>[comparator] (Function): comparator 调用每个元素。</li>
</ul>
<p>返回值</p>
<ul>
<li>返回一个过滤值后的新数组。</li>
</ul>
</details>
<p>这个方法类似<code v-pre>_.difference</code>，除了它接受一个<code v-pre>comparator</code>（比较器），它调用比较<code v-pre>array</code>，<code v-pre>values</code>中的元素。 结果值是从第一数组中选择。<code v-pre>comparator</code>调用参数有两个：<code v-pre>(arrVal, othVal)</code>。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>不像<a href="https://www.lodashjs.com/docs/lodash.differenceWith#pullAllWith" target="_blank" rel="noopener noreferrer">_.pullAllWith<ExternalLinkIcon/></a>，这个方法会返回一个新数组。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>
_<span class="token punctuation">.</span><span class="token function">differenceWith</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span>isEqual<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 2, 'y': 1 }]</span>

_<span class="token punctuation">.</span><span class="token function">differenceWith</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string-property property">'z'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span>isEqual<span class="token punctuation">)</span>
<span class="token comment">// => [{ 'x': 1, 'y': 2, 'z': 4 }, { 'x': 2, 'y': 1}]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="compact-array" tabindex="-1"><a class="header-anchor" href="#compact-array" aria-hidden="true">#</a> _.compact(array)</h3>
<p>创建一个新数组，包含原数组中所有的非假值元素。例如<code v-pre>false</code>, <code v-pre>null</code>, <code v-pre>0</code>, <code v-pre>&quot;&quot;</code>, <code v-pre>undefined</code>, <code v-pre>NaN</code> 等都是被认为是“假值”</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">compact</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">0</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string">''</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
</code></pre></div><h3 id="intersection-arrays" tabindex="-1"><a class="header-anchor" href="#intersection-arrays" aria-hidden="true">#</a> _.intersection([arrays])</h3>
<p>创建唯一值的数组，这个数组包含所有给定数组都包含的元素，使用<a href="http://ecma-international.org/ecma-262/6.0/#sec-samevaluezero" target="_blank" rel="noopener noreferrer">SameValueZero<ExternalLinkIcon/></a>进行相等性比较。（可以理解为给定数组的交集）</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">intersection</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2]</span>
</code></pre></div><h3 id="intersectionby-arrays-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#intersectionby-arrays-iteratee-identity" aria-hidden="true">#</a> _.intersectionBy([arrays], [iteratee = _.identity])</h3>
<p>这个方法类似<code v-pre>_.intersection</code>，区别是它接受一个<code v-pre>iteratee</code>调用每一个<code v-pre>arrays</code>的每个值以产生一个值，通过产生的值进行了比较。结果值是从第一数组中选择。<code v-pre>iteratee</code>会传入一个参数：<code v-pre>(value)</code>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token comment">//迭代器把值Math.floor后进行比较，返回的原值</span>
_<span class="token punctuation">.</span><span class="token function">intersectionBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">2.1</span><span class="token punctuation">,</span> <span class="token number">1.2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">4.3</span><span class="token punctuation">,</span> <span class="token number">2.4</span><span class="token punctuation">]</span><span class="token punctuation">,</span> Math<span class="token punctuation">.</span>floor<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2.1]</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">intersectionBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'x'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 1 }]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="intersectionwith-arrays-comparator" tabindex="-1"><a class="header-anchor" href="#intersectionwith-arrays-comparator" aria-hidden="true">#</a> _.intersectionWith([arrays], [comparator])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>[arrays] (...Array): 待检查的数组。</li>
<li>[comparator] (Function): comparator（比较器）调用每个元素。</li>
</ul>
<p>返回值</p>
<ul>
<li>(Array): 返回一个包含所有传入数组交集元素的新数组。</li>
</ul>
</details>
<p>这个方法类似<code v-pre>_.intersection</code>，区别是它接受一个<code v-pre>comparator</code>调用比较<code v-pre>arrays</code>中的元素。结果值是从第一数组中选择。<code v-pre>comparator</code>会传入两个参数:<code v-pre>(arrVal, othVal)</code>。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> objects <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token keyword">var</span> others <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">intersectionWith</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> others<span class="token punctuation">,</span> _<span class="token punctuation">.</span>isEqual<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 1, 'y': 2 }]</span>
</code></pre></div><h2 id="移除" tabindex="-1"><a class="header-anchor" href="#移除" aria-hidden="true">#</a> 移除</h2>
<h3 id="remove-array-predicate-identity" tabindex="-1"><a class="header-anchor" href="#remove-array-predicate-identity" aria-hidden="true">#</a> _.remove(array, [predicate = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要修改的数组。</li>
<li>[predicate=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回移除元素组成的新数组。</li>
</ul>
</details>
<p>移除数组中<code v-pre>predicate</code>（断言）返回为真值的所有元素，并返回移除元素组成的数组。<code v-pre>predicate</code>（断言）会传入3个参数：<code v-pre>(value, index, array)</code>。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>和<a href="https://www.lodashjs.com/docs/lodash.filter" target="_blank" rel="noopener noreferrer">_.filter<ExternalLinkIcon/></a>不同, 这个方法会改变数组<code v-pre>array</code>。使用<a href="https://www.lodashjs.com/docs/lodash.pull" target="_blank" rel="noopener noreferrer">_.pull<ExternalLinkIcon/></a>来根据提供的<code v-pre>value</code>值从数组中移除元素。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token keyword">var</span> evens <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">remove</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token parameter">n</span> <span class="token operator">=></span> n <span class="token operator">%</span> <span class="token number">2</span> <span class="token operator">==</span> <span class="token number">0</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 3]</span>
 
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>evens<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2, 4]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="drop-array-n-1" tabindex="-1"><a class="header-anchor" href="#drop-array-n-1" aria-hidden="true">#</a> _.drop(array, [n=1])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要查询的数组。</li>
<li>[n=1] (number): 要去除的元素个数。</li>
</ul>
<p>返回值</p>
<ul>
<li>(Array): 返回array剩余切片。</li>
</ul>
</details>
<p>创建一个切片数组，去除array前面的n个元素；n默认值为1。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">drop</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2, 3]</span>
 
_<span class="token punctuation">.</span><span class="token function">drop</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [3]</span>
 
_<span class="token punctuation">.</span><span class="token function">drop</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => []</span>
 
_<span class="token punctuation">.</span><span class="token function">drop</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">0</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="dropright-array-n-1" tabindex="-1"><a class="header-anchor" href="#dropright-array-n-1" aria-hidden="true">#</a> _.dropRight(array, [n=1])</h3>
<p>创建一个切片数组，去除array尾部的n个元素；n默认值为1。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">dropRight</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2]</span>
 
_<span class="token punctuation">.</span><span class="token function">dropRight</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1]</span>
 
_<span class="token punctuation">.</span><span class="token function">dropRight</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => []</span>
 
_<span class="token punctuation">.</span><span class="token function">dropRight</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">0</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="droprightwhile-array-predicate-identity" tabindex="-1"><a class="header-anchor" href="#droprightwhile-array-predicate-identity" aria-hidden="true">#</a> _.dropRightWhile(array, [predicate = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要查询的数组。</li>
<li>[predicate=_.identity] (Function): 这个函数会在每一次迭代调用。</li>
</ul>
<p>返回值</p>
<ul>
<li>(Array): 返回array剩余切片。</li>
</ul>
</details>
<p>创建一个切片数组，去除array中从<code v-pre>predicate</code>返回值开始到尾部的部分。<code v-pre>predicate</code>会传入3个参数： <code v-pre>(value, index, array)</code>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span>  <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>    <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">dropRightWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">o</span><span class="token punctuation">)</span> <span class="token punctuation">{</span> <span class="token keyword">return</span> <span class="token operator">!</span>o<span class="token punctuation">.</span>active<span class="token punctuation">;</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney']</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">dropRightWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney', 'fred']</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">dropRightWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney']</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">dropRightWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span>
<span class="token operator">=></span>  objects <span class="token keyword">for</span> <span class="token punctuation">[</span><span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string">'fred'</span><span class="token punctuation">,</span> <span class="token string">'pebbles'</span><span class="token punctuation">]</span>

_<span class="token punctuation">.</span><span class="token function">isEqual</span><span class="token punctuation">(</span>_<span class="token punctuation">.</span><span class="token function">dropRightWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">,</span> users<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="dropwhile-array-predicate-identity" tabindex="-1"><a class="header-anchor" href="#dropwhile-array-predicate-identity" aria-hidden="true">#</a> _.dropWhile(array, [predicate = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要查询的数组。</li>
<li>[predicate=_.identity] (Function): 这个函数会在每一次迭代调用。</li>
</ul>
<p>返回值</p>
<ul>
<li>(Array): 返回array剩余切片。</li>
</ul>
</details>
<p>创建一个切片数组，去除array中从起点开始到<code v-pre>predicate</code>返回值结束部分。<code v-pre>predicate</code>会传入3个参数：<code v-pre>(value, index, array)</code>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span>  <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>    <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">dropWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">o</span><span class="token punctuation">)</span> <span class="token punctuation">{</span> <span class="token keyword">return</span> <span class="token operator">!</span>o<span class="token punctuation">.</span>active<span class="token punctuation">;</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['pebbles']</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">dropWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['fred', 'pebbles']</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">dropWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['pebbles']</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">dropWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney', 'fred', 'pebbles']</span>

_<span class="token punctuation">.</span><span class="token function">isEqual</span><span class="token punctuation">(</span>_<span class="token punctuation">.</span><span class="token function">dropWhile</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">,</span> users<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="pull-array-values" tabindex="-1"><a class="header-anchor" href="#pull-array-values" aria-hidden="true">#</a> _.pull(array, [values])</h3>
<p>移除数组<code v-pre>array</code>中所有和给定值相等的元素，使用<a href="http://ecma-international.org/ecma-262/6.0/#sec-samevaluezero" target="_blank" rel="noopener noreferrer">SameValueZero<ExternalLinkIcon/></a>进行全等比较。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>和<a href="https://www.lodashjs.com/docs/lodash.without" target="_blank" rel="noopener noreferrer">_.without<ExternalLinkIcon/></a> 方法不同，这个方法会改变数组。使用<a href="https://www.lodashjs.com/docs/lodash.remove" target="_blank" rel="noopener noreferrer">_.remove<ExternalLinkIcon/></a> 从一个数组中移除元素。</p>
</div>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">pull</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 1]</span>
</code></pre></div><h3 id="pullall-array-values" tabindex="-1"><a class="header-anchor" href="#pullall-array-values" aria-hidden="true">#</a> _.pullAll(array, values)</h3>
<p>这个方法类似<a href="https://www.lodashjs.com/docs/lodash.pull" target="_blank" rel="noopener noreferrer">_.pull<ExternalLinkIcon/></a>，区别是这个方法接收一个要移除值的数组。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>不同于<a href="https://www.lodashjs.com/docs/lodash.difference" target="_blank" rel="noopener noreferrer">_.difference<ExternalLinkIcon/></a>, 这个方法会改变数组<code v-pre>array</code></p>
</div>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">pullAll</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 1]</span>
</code></pre></div><h3 id="pullallby-array-values-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#pullallby-array-values-iteratee-identity" aria-hidden="true">#</a> _.pullAllBy(array, values, [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要修改的数组。</li>
<li>values (Array): 要移除值的数组。</li>
<li>[iteratee=_.identity] (Array|Function|Object|string): iteratee（迭代器）调用每个元素。</li>
</ul>
<p>返回值</p>
<ul>
<li>(Array): 返回 array.</li>
</ul>
</details>
<p>这个方法类似于<a href="https://www.lodashjs.com/docs/lodash.pullAll" target="_blank" rel="noopener noreferrer">_.pullAll<ExternalLinkIcon/></a> ，区别是这个方法接受一个 <code v-pre>iteratee</code>（迭代函数） 调用<code v-pre>array</code>和<code v-pre>values</code>的每个值以产生一个值，通过产生的值进行了比较。<code v-pre>iteratee</code>会传入一个参数：<code v-pre>(value)</code>。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>不同于<a href="https://www.lodashjs.com/docs/lodash.differenceBy" target="_blank" rel="noopener noreferrer">_.differenceBy<ExternalLinkIcon/></a>, 这个方法会改变数组 <code v-pre>array</code></p>
</div>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">3</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">pullAllBy</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">3</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'x'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 2 }]</span>
</code></pre></div><h3 id="pullallwith-array-values-comparator" tabindex="-1"><a class="header-anchor" href="#pullallwith-array-values-comparator" aria-hidden="true">#</a> _.pullAllWith(array, values, [comparator])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要修改的数组。</li>
<li>values (Array): 要移除值的数组。</li>
<li>[comparator] (Function): comparator（比较器）调用每个元素。</li>
</ul>
<p>返回值</p>
<ul>
<li>(Array): 返回 array。</li>
</ul>
</details>
<p>这个方法类似于<a href="https://www.lodashjs.com/docs/lodash.pullAll" target="_blank" rel="noopener noreferrer">_.pullAll<ExternalLinkIcon/></a>，区别是这个方法接受 <code v-pre>comparator</code>调用<code v-pre>array</code>中的元素和<code v-pre>values</code>比较。<code v-pre>comparator</code>会传入两个参数：<code v-pre>(arrVal, othVal)</code>。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>不同于<a href="https://www.lodashjs.com/docs/lodash.differenceWith" target="_blank" rel="noopener noreferrer">_.differenceWith<ExternalLinkIcon/></a>, 这个方法会改变数组 <code v-pre>array</code></p>
</div>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">6</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">pullAllWith</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span>isEqual<span class="token punctuation">)</span><span class="token punctuation">;</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 1, 'y': 2 }, { 'x': 5, 'y': 6 }]</span>
</code></pre></div><h3 id="pullat-array-indexes" tabindex="-1"><a class="header-anchor" href="#pullat-array-indexes" aria-hidden="true">#</a> _.pullAt(array, [indexes])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要修改的数组。</li>
<li>[indexes] (...(number|number[])): 要移除元素的索引。</li>
</ul>
<p>返回值</p>
<ul>
<li>(Array): 返回移除元素组成的新数组。</li>
</ul>
</details>
<p>根据索引<code v-pre>indexes</code>，移除<code v-pre>array</code>中对应的元素，并返回被移除元素的数组。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>和 <a href="https://www.lodashjs.com/docs/lodash.at" target="_blank" rel="noopener noreferrer">_.at<ExternalLinkIcon/></a>不同, 这个方法会改变数组 array。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">10</span><span class="token punctuation">,</span> <span class="token number">15</span><span class="token punctuation">,</span> <span class="token number">20</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token keyword">var</span> evens <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">pullAt</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [5, 15]</span>
 
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>evens<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [10, 20]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="without-array-values" tabindex="-1"><a class="header-anchor" href="#without-array-values" aria-hidden="true">#</a> _.without(array, [values])</h3>
<p>创建一个剔除所有给定值的新数组，剔除值的时候，使用SameValueZero<RouterLink to="/guide/javascript/%5BSameValueZero%5D(http:/ecma-international.org/ecma-262/6.0/#sec-samevaluezero)">^1</RouterLink>做相等比较。</p>
<div class="tip-block warning"><p class="title">注意:</p><p>不像<a href="https://www.lodashjs.com/docs/lodash.pull" target="_blank" rel="noopener noreferrer">_.pull<ExternalLinkIcon/></a>, 这个方法会返回一个新数组。</p>
</div>
<h2 id="增加" tabindex="-1"><a class="header-anchor" href="#增加" aria-hidden="true">#</a> 增加</h2>
<h3 id="fill-array-value-start-0-end-array-length" tabindex="-1"><a class="header-anchor" href="#fill-array-value-start-0-end-array-length" aria-hidden="true">#</a> _.fill(array, value, [start=0], [end = array.length])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要填充改变的数组。</li>
<li>value (*): 填充给 array 的值。</li>
<li>[start=0] (number): 开始位置（默认0）。</li>
<li>[end=array.length] (number):结束位置（默认array.length）。</li>
</ul>
<p>返回值</p>
<ul>
<li>(Array): 返回 array。</li>
</ul>
</details>
<p>使用<code v-pre>value</code>值来填充（替换）<code v-pre>array</code>，从<code v-pre>start</code>位置开始, 到<code v-pre>end</code>位置结束（但不包含end位置）</p>
<div class="tip-block warning"><p class="title">警告</p><p>这个方法会改变<code v-pre>array</code>(不是创建新数组）</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">fill</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token string">'a'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => ['a', 'a', 'a']</span>
 
_<span class="token punctuation">.</span><span class="token function">fill</span><span class="token punctuation">(</span><span class="token function">Array</span><span class="token punctuation">(</span><span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2, 2, 2]</span>
 
_<span class="token punctuation">.</span><span class="token function">fill</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">,</span> <span class="token number">8</span><span class="token punctuation">,</span> <span class="token number">10</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'*'</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [4, '*', '*', 10]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="排序" tabindex="-1"><a class="header-anchor" href="#排序" aria-hidden="true">#</a> 排序</h2>
<h3 id="sortedindex-array-value" tabindex="-1"><a class="header-anchor" href="#sortedindex-array-value" aria-hidden="true">#</a> _.sortedIndex(array, value)</h3>
<p>使用二进制的方式检索，来决定<code v-pre>value</code>值应该插入到数组中尽可能小的索引位置，以保证array的排序。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">sortedIndex</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 2</span>
</code></pre></div><h3 id="sortedindexby-array-value-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#sortedindexby-array-value-iteratee-identity" aria-hidden="true">#</a> _.sortedIndexBy(array, value, [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要检查的排序数组。</li>
<li>value (*): 要评估的值。</li>
<li>[iteratee=_.identity] (Array|Function|Object|string): 迭代函数，调用每个元素。</li>
</ul>
<p>返回</p>
<ul>
<li>(number): 返回 value值 应该在数组array中插入的索引位置 index。</li>
</ul>
</details>
<p>这个方法类似<a href="https://www.lodashjs.com/docs/lodash.sortedIndex" target="_blank" rel="noopener noreferrer">_.sortedIndex<ExternalLinkIcon/></a>，除了它接受一个<code v-pre>iteratee</code>（迭代函数），调用每一个数组（array）元素，返回结果和value 值比较来计算排序。iteratee 会传入一个参数：(value)。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">3</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">5</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">6</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>

_<span class="token punctuation">.</span><span class="token function">sortedIndexBy</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token parameter">item</span> <span class="token operator">=></span> item<span class="token punctuation">.</span>x<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 1</span>

<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">sortedIndexBy</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token string">'x'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 1</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="sortedindexof-array-value" tabindex="-1"><a class="header-anchor" href="#sortedindexof-array-value" aria-hidden="true">#</a> _.sortedIndexOf(array, value)</h3>
<p>这个方法类似<a href="https://www.lodashjs.com/docs/lodash.indexOf" target="_blank" rel="noopener noreferrer">_.indexOf<ExternalLinkIcon/></a>，除了它是在已经排序的数组	<code v-pre>array</code>上执行二进制检索。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">sortedIndexOf</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 1</span>
</code></pre></div><h3 id="sortedlastindex-array-value" tabindex="-1"><a class="header-anchor" href="#sortedlastindex-array-value" aria-hidden="true">#</a> _.sortedLastIndex(array, value)</h3>
<p>此方法类似于<a href="https://www.lodashjs.com/docs/lodash.sortedIndex" target="_blank" rel="noopener noreferrer">_.sortedIndex<ExternalLinkIcon/></a>，除了它返回<code v-pre>value</code>值在<code v-pre>array</code>中尽可能大的索引位置（index）。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">sortedLastIndex</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 4</span>
</code></pre></div><h3 id="sortedlastindexby-array-value-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#sortedlastindexby-array-value-iteratee-identity" aria-hidden="true">#</a> _.sortedLastIndexBy(array, value, [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>array (Array): 要检查的排序数组。</li>
<li>value (*): 要评估的值。</li>
<li>[iteratee = _.identity] (Array|Function|Object|string): 迭代函数，调用每个元素。</li>
</ul>
<p>返回</p>
<ul>
<li>(number): 返回 value值 应该在数组array中插入的索引位置 index。</li>
</ul>
</details>
<p>这个方法类似<a href="https://www.lodashjs.com/docs/lodash.sortedLastIndex" target="_blank" rel="noopener noreferrer">_.sortedLastIndex<ExternalLinkIcon/></a> ，除了它接受一个<code v-pre>iteratee</code>（迭代函数），调用每一个数组<code v-pre>array</code>元素，返回结果和<code v-pre>value</code>值比较来计算排序。<code v-pre>iteratee </code>会传入一个参数：<code v-pre>value</code>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">3</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">5</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">6</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>

_<span class="token punctuation">.</span><span class="token function">sortedLastIndexBy</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token parameter">item</span> <span class="token operator">=></span> item<span class="token punctuation">.</span>x<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 2</span>

<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">sortedLastIndexBy</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token string">'x'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 2</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="sortedlastindexof-array-value" tabindex="-1"><a class="header-anchor" href="#sortedlastindexof-array-value" aria-hidden="true">#</a> _.sortedLastIndexOf(array, value)</h3>
<p>这个方法类似<a href="https://www.lodashjs.com/docs/lodash.lastIndexOf" target="_blank" rel="noopener noreferrer">_.lastIndexOf<ExternalLinkIcon/></a>，除了它是在已经排序的数组array上执行二进制检索。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">sortedLastIndexOf</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 3</span>
</code></pre></div><h3 id="sorteduniq-array" tabindex="-1"><a class="header-anchor" href="#sorteduniq-array" aria-hidden="true">#</a> _.sortedUniq(array)</h3>
<p>这个方法类似<a href="https://www.lodashjs.com/docs/lodash.uniq" target="_blank" rel="noopener noreferrer">_.uniq<ExternalLinkIcon/></a>；它会优化排序数组，返回一个新的不重复的数组。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">sortedUniq</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2]</span>
</code></pre></div><h3 id="sorteduniqby-array-iteratee" tabindex="-1"><a class="header-anchor" href="#sorteduniqby-array-iteratee" aria-hidden="true">#</a> _.sortedUniqBy(array, [iteratee])</h3>
<p>这个方法类似<a href="https://www.lodashjs.com/docs/lodash.uniqBy" target="_blank" rel="noopener noreferrer">_.uniqBy<ExternalLinkIcon/></a>；它会优化排序数组，返回一个新的不重复的数组。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">sortedUniqBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1.1</span><span class="token punctuation">,</span> <span class="token number">1.2</span><span class="token punctuation">,</span> <span class="token number">2.3</span><span class="token punctuation">,</span> <span class="token number">2.4</span><span class="token punctuation">]</span><span class="token punctuation">,</span> Math<span class="token punctuation">.</span>floor<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1.1, 2.3]</span>
</code></pre></div><h2 id="去重" tabindex="-1"><a class="header-anchor" href="#去重" aria-hidden="true">#</a> 去重</h2>
<h3 id="uniq-array" tabindex="-1"><a class="header-anchor" href="#uniq-array" aria-hidden="true">#</a> _.uniq(array)</h3>
<p>返回一个去重后的array数组副本。使用了SameValueZero<RouterLink to="/guide/javascript/%5BSameValueZero%5D(http:/ecma-international.org/ecma-262/6.0/#sec-samevaluezero)">^1</RouterLink> 做等值比较。只有第一次出现的元素才会被保留。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">uniq</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2, 1]</span>
</code></pre></div><h3 id="uniqby-array-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#uniqby-array-iteratee-identity" aria-hidden="true">#</a> _.uniqBy(array, [iteratee = _.identity])</h3>
<p>这个方法类似_.uniq ，除了它接受一个 iteratee（迭代函数），调用每一个数组（array）的每个元素以产生唯一性计算的标准。iteratee 调用时会传入一个参数：(value)。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">uniqBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">2.1</span><span class="token punctuation">,</span> <span class="token number">1.2</span><span class="token punctuation">,</span> <span class="token number">2.3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> Math<span class="token punctuation">.</span>floor<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2.1, 1.2]</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">uniqBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'x'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 1 }, { 'x': 2 }]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="uniqwith-array-comparator" tabindex="-1"><a class="header-anchor" href="#uniqwith-array-comparator" aria-hidden="true">#</a> _.uniqWith(array, [comparator])</h3>
<p>这个方法类似_.uniq， 除了它接受一个 comparator 调用比较arrays数组的每一个元素。 comparator 调用时会传入2个参数： (arrVal, othVal)。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> objects <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">uniqWith</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> _<span class="token punctuation">.</span>isEqual<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 1, 'y': 2 }, { 'x': 2, 'y': 1 }]</span>
</code></pre></div><h3 id="xor-arrays" tabindex="-1"><a class="header-anchor" href="#xor-arrays" aria-hidden="true">#</a> _.xor([arrays])</h3>
<p>创建一个给定数组唯一值的数组，使用symmetric difference[^2]做等值比较。
返回一个值的顺序取决于他们数组的出现顺序。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">xor</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 3]</span>
</code></pre></div><h3 id="xorby-arrays-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#xorby-arrays-iteratee-identity" aria-hidden="true">#</a> _.xorBy([arrays], [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>[arrays] (...Array): 要检查的数组。</li>
<li>[iteratee=_.identity] (Array|Function|Object|string): 调用每一个元素的迭代函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回过滤值后的新数组。</li>
</ul>
</details>
<p>这个方法类似<code v-pre>_.xor</code>，除了它接受 iteratee（迭代器），这个迭代器 调用每一个 arrays（数组）的每一个值，以生成比较的新值。iteratee 调用一个参数：(value).</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">xorBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">2.1</span><span class="token punctuation">,</span> <span class="token number">1.2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">2.3</span><span class="token punctuation">,</span> <span class="token number">3.4</span><span class="token punctuation">]</span><span class="token punctuation">,</span> Math<span class="token punctuation">.</span>floor<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1.2, 3.4]</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">xorBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'x'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 2 }]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="xorwith-arrays-comparator" tabindex="-1"><a class="header-anchor" href="#xorwith-arrays-comparator" aria-hidden="true">#</a> _.xorWith([arrays], [comparator])</h3>
<p>该方法是像<code v-pre>_.xor</code>，除了它接受一个<code v-pre>comparator</code>，以调用比较数组的元素。
<code v-pre>comparator</code>调用2个参数：<code v-pre>(arrVal, othVal)</code>.</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> objects <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token keyword">var</span> others <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'x'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'y'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">xorWith</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> others<span class="token punctuation">,</span> _<span class="token punctuation">.</span>isEqual<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{ 'x': 2, 'y': 1 }, { 'x': 1, 'y': 1 }]</span>
</code></pre></div><h2 id="转换" tabindex="-1"><a class="header-anchor" href="#转换" aria-hidden="true">#</a> 转换</h2>
<h3 id="reverse-array" tabindex="-1"><a class="header-anchor" href="#reverse-array" aria-hidden="true">#</a> _.reverse(array)</h3>
<p>反转<code v-pre>array</code>，使得第一个元素变为最后一个元素，第二个元素变为倒数第二个元素，依次类推。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>这个方法会改变原数组<code v-pre>array</code>，基于<a href="https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Array/reverse" target="_blank" rel="noopener noreferrer">Array#reverse<ExternalLinkIcon/></a>.</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">reverse</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [3, 2, 1]</span>
 
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>array<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [3, 2, 1]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="flatten-array" tabindex="-1"><a class="header-anchor" href="#flatten-array" aria-hidden="true">#</a> _.flatten(array)</h3>
<p>减少一级array嵌套深度。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">flatten</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">3</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, [3, [4]], 5]</span>
</code></pre></div><h3 id="flattendeep-array" tabindex="-1"><a class="header-anchor" href="#flattendeep-array" aria-hidden="true">#</a> _.flattenDeep(array)</h3>
<p>将array递归为一维数组。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">flattenDeep</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">3</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3, 4, 5]</span>
</code></pre></div><h3 id="flattendepth-array-depth-1" tabindex="-1"><a class="header-anchor" href="#flattendepth-array-depth-1" aria-hidden="true">#</a> _.flattenDepth(array, [depth=1])</h3>
<p>根据 depth 递归减少<code v-pre>array</code>的嵌套层级。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">3</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">flattenDepth</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, [3, [4]], 5]</span>
 
_<span class="token punctuation">.</span><span class="token function">flattenDepth</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3, [4], 5]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="frompairs-pairs" tabindex="-1"><a class="header-anchor" href="#frompairs-pairs" aria-hidden="true">#</a> _.fromPairs(pairs)</h3>
<p>与<a href="https://www.lodashjs.com/docs/lodash.toPairs" target="_blank" rel="noopener noreferrer">_.toPairs<ExternalLinkIcon/></a>正好相反；这个方法返回一个由键值对pairs构成的对象。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">fromPairs</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">[</span><span class="token string">'fred'</span><span class="token punctuation">,</span> <span class="token number">30</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token number">40</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { 'fred': 30, 'barney': 40 }</span>
</code></pre></div><h3 id="zipobject-props-values" tabindex="-1"><a class="header-anchor" href="#zipobject-props-values" aria-hidden="true">#</a> _.zipObject([props=[]], [values=[]])</h3>
<p>这个方法类似<code v-pre>_.fromPairs</code>，除了它接受2个数组，第一个数组中的值作为属性标识符（属性名），第二个数组中的值作为相应的属性值。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">zipObject</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'a'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { 'a': 1, 'b': 2 }</span>
</code></pre></div><h3 id="zipobjectdeep-props-values" tabindex="-1"><a class="header-anchor" href="#zipobjectdeep-props-values" aria-hidden="true">#</a> _.zipObjectDeep([props=[]], [values=[]])</h3>
<p>这个方法类似<code v-pre>_.zipObject</code>，除了它支持属性路径。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">zipObjectDeep</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'a.b[0].c'</span><span class="token punctuation">,</span> <span class="token string">'a.b[1].d'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { 'a': { 'b': [{ 'c': 1 }, { 'd': 2 }] } }</span>
</code></pre></div><p>[^2]:<a href="https://en.wikipedia.org/wiki/Symmetric_difference" target="_blank" rel="noopener noreferrer">symmetric difference<ExternalLinkIcon/></a></p>
<hr/>
</div></template>


