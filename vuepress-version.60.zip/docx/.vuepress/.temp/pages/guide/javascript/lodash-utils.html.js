export const data = JSON.parse("{\"key\":\"v-4c40daca\",\"path\":\"/guide/javascript/lodash-utils.html\",\"title\":\"Lodash 实用函数 Utils\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"Lodash 实用函数 Utils\",\"slug\":\"lodash-实用函数-utils\",\"link\":\"#lodash-实用函数-utils\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/javascript/lodash-utils.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
