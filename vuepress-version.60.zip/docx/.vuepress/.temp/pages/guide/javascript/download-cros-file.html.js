export const data = JSON.parse("{\"key\":\"v-7b50b952\",\"path\":\"/guide/javascript/download-cros-file.html\",\"title\":\"js跨域资源下载\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"js跨域资源下载\",\"slug\":\"js跨域资源下载\",\"link\":\"#js跨域资源下载\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/javascript/download-cros-file.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
