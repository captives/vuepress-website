export const data = JSON.parse("{\"key\":\"v-fd023f6c\",\"path\":\"/guide/javascript/javascript-array.html\",\"title\":\"数组 Array\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"数组 Array\",\"slug\":\"数组-array\",\"link\":\"#数组-array\",\"children\":[{\"level\":2,\"title\":\"基础\",\"slug\":\"基础\",\"link\":\"#基础\",\"children\":[{\"level\":3,\"title\":\"求最大/小值\",\"slug\":\"求最大-小值\",\"link\":\"#求最大-小值\",\"children\":[]},{\"level\":3,\"title\":\"map\",\"slug\":\"map\",\"link\":\"#map\",\"children\":[]},{\"level\":3,\"title\":\"reduce\",\"slug\":\"reduce\",\"link\":\"#reduce\",\"children\":[]},{\"level\":3,\"title\":\"filter\",\"slug\":\"filter\",\"link\":\"#filter\",\"children\":[]},{\"level\":3,\"title\":\"sort\",\"slug\":\"sort\",\"link\":\"#sort\",\"children\":[]}]},{\"level\":2,\"title\":\"数据交换\",\"slug\":\"数据交换\",\"link\":\"#数据交换\",\"children\":[{\"level\":3,\"title\":\"普通做法\",\"slug\":\"普通做法\",\"link\":\"#普通做法\",\"children\":[]},{\"level\":3,\"title\":\"算术运算\",\"slug\":\"算术运算\",\"link\":\"#算术运算\",\"children\":[]},{\"level\":3,\"title\":\"数组方式\",\"slug\":\"数组方式\",\"link\":\"#数组方式\",\"children\":[]},{\"level\":3,\"title\":\"对象方式\",\"slug\":\"对象方式\",\"link\":\"#对象方式\",\"children\":[]},{\"level\":3,\"title\":\"ES6解构\",\"slug\":\"es6解构\",\"link\":\"#es6解构\",\"children\":[]},{\"level\":3,\"title\":\"异或操作\",\"slug\":\"异或操作\",\"link\":\"#异或操作\",\"children\":[]}]},{\"level\":2,\"title\":\"排序\",\"slug\":\"排序\",\"link\":\"#排序\",\"children\":[]},{\"level\":2,\"title\":\"删除、去重\",\"slug\":\"删除、去重\",\"link\":\"#删除、去重\",\"children\":[{\"level\":3,\"title\":\"正序去重复\",\"slug\":\"正序去重复\",\"link\":\"#正序去重复\",\"children\":[]},{\"level\":3,\"title\":\"倒序去重复\",\"slug\":\"倒序去重复\",\"link\":\"#倒序去重复\",\"children\":[]}]},{\"level\":2,\"title\":\"排序\",\"slug\":\"排序-1\",\"link\":\"#排序-1\",\"children\":[{\"level\":3,\"title\":\"普通排序(Sort)\",\"slug\":\"普通排序-sort\",\"link\":\"#普通排序-sort\",\"children\":[]},{\"level\":3,\"title\":\"冒泡排序(Bubble Sort)\",\"slug\":\"冒泡排序-bubble-sort\",\"link\":\"#冒泡排序-bubble-sort\",\"children\":[]},{\"level\":3,\"title\":\"选择排序(Selection Sort)\",\"slug\":\"选择排序-selection-sort\",\"link\":\"#选择排序-selection-sort\",\"children\":[]},{\"level\":3,\"title\":\"插入排序(Insertion Sort)\",\"slug\":\"插入排序-insertion-sort\",\"link\":\"#插入排序-insertion-sort\",\"children\":[]}]}]}],\"git\":{},\"filePathRelative\":\"guide/javascript/javascript-array.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
