<template><div><h1 id="lodash-数学-math" tabindex="-1"><a class="header-anchor" href="#lodash-数学-math" aria-hidden="true">#</a> Lodash 数学 Math</h1>
<h2 id="逻辑运算" tabindex="-1"><a class="header-anchor" href="#逻辑运算" aria-hidden="true">#</a> 逻辑运算</h2>
<h3 id="add-augend-addend" tabindex="-1"><a class="header-anchor" href="#add-augend-addend" aria-hidden="true">#</a> _.add(augend, addend)</h3>
<p>两个数相加。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">add</span><span class="token punctuation">(</span><span class="token number">6</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 10</span>
</code></pre></div><h3 id="subtract-minuend-subtrahend" tabindex="-1"><a class="header-anchor" href="#subtract-minuend-subtrahend" aria-hidden="true">#</a> _.subtract(minuend, subtrahend)</h3>
<p>两个数相减。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">subtract</span><span class="token punctuation">(</span><span class="token number">6</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 2</span>
</code></pre></div><h3 id="multiply-multiplier-multiplicand" tabindex="-1"><a class="header-anchor" href="#multiply-multiplier-multiplicand" aria-hidden="true">#</a> _.multiply(multiplier, multiplicand)</h3>
<p>两个数相乘。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">multiply</span><span class="token punctuation">(</span><span class="token number">6</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 24</span>
</code></pre></div><h3 id="divide-dividend-divisor" tabindex="-1"><a class="header-anchor" href="#divide-dividend-divisor" aria-hidden="true">#</a> _.divide(dividend, divisor)</h3>
<p>两个数相除。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">divide</span><span class="token punctuation">(</span><span class="token number">6</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 1.5</span>
</code></pre></div><h3 id="sum-array" tabindex="-1"><a class="header-anchor" href="#sum-array" aria-hidden="true">#</a> _.sum(array)</h3>
<p>计算<code v-pre>array</code>中所有值的总和
_.sum([4, 2, 8, 6]);
// =&gt; 20</p>
<h3 id="sumby-array-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#sumby-array-iteratee-identity" aria-hidden="true">#</a> _.sumBy(array, [iteratee = _.identity])</h3>
<p>这个方法类似<a href="https://www.lodashjs.com/docs/lodash.summin" target="_blank" rel="noopener noreferrer">_.summin<ExternalLinkIcon/></a>除了它接受<code v-pre>iteratee(value)</code>来调用<code v-pre>array中</code>的每一个元素，来生成其值排序的标准。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> objects <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">8</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">6</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">sumBy</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">o</span><span class="token punctuation">)</span> <span class="token punctuation">{</span> <span class="token keyword">return</span> o<span class="token punctuation">.</span>n<span class="token punctuation">;</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 20</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">sumBy</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> <span class="token string">'n'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 20</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="mean-array" tabindex="-1"><a class="header-anchor" href="#mean-array" aria-hidden="true">#</a> _.mean(array)</h3>
<p>计算<code v-pre>array</code>的平均值。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">mean</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">8</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 5</span>
</code></pre></div><h3 id="meanby-array-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#meanby-array-iteratee-identity" aria-hidden="true">#</a> _.meanBy(array, [iteratee = _.identity])</h3>
<p>这个方法类似<code v-pre>_.mean</code>，除了它接受<code v-pre>iteratee(value) </code>来调用<code v-pre>array</code>中的每一个元素，来生成其值排序的标准。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> objects <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">8</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">6</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">meanBy</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">o</span><span class="token punctuation">)</span> <span class="token punctuation">{</span> <span class="token keyword">return</span> o<span class="token punctuation">.</span>n<span class="token punctuation">;</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 5</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">meanBy</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> <span class="token string">'n'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 5</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="格式化" tabindex="-1"><a class="header-anchor" href="#格式化" aria-hidden="true">#</a> 格式化</h2>
<h3 id="round-number-precision-0" tabindex="-1"><a class="header-anchor" href="#round-number-precision-0" aria-hidden="true">#</a> _.round(number, [precision=0])</h3>
<p>根据<code v-pre>precision</code>四舍五入 number。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">round</span><span class="token punctuation">(</span><span class="token number">4.006</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 4</span>
 
_<span class="token punctuation">.</span><span class="token function">round</span><span class="token punctuation">(</span><span class="token number">4.006</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 4.01</span>
 
_<span class="token punctuation">.</span><span class="token function">round</span><span class="token punctuation">(</span><span class="token number">4060</span><span class="token punctuation">,</span> <span class="token operator">-</span><span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 4100</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="ceil-number-precision-0" tabindex="-1"><a class="header-anchor" href="#ceil-number-precision-0" aria-hidden="true">#</a> _.ceil(number, [precision = 0])</h3>
<p>根据<code v-pre>precision</code>（精度）向上舍入<code v-pre>number</code>。（注：<code v-pre>precision</code>（精度）可以理解为保留几位小数。）</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">ceil</span><span class="token punctuation">(</span><span class="token number">4.006</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 5</span>
 
_<span class="token punctuation">.</span><span class="token function">ceil</span><span class="token punctuation">(</span><span class="token number">6.004</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 6.01</span>
 
_<span class="token punctuation">.</span><span class="token function">ceil</span><span class="token punctuation">(</span><span class="token number">6040</span><span class="token punctuation">,</span> <span class="token operator">-</span><span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 6100</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="floor-number-precision-0" tabindex="-1"><a class="header-anchor" href="#floor-number-precision-0" aria-hidden="true">#</a> _.floor(number, [precision=0])</h3>
<p>根据<code v-pre>precision</code>（精度）向下舍入<code v-pre>number</code>。（注：<code v-pre>precision</code>（精度）可以理解为保留几位小数。）</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">floor</span><span class="token punctuation">(</span><span class="token number">4.006</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 4</span>
 
_<span class="token punctuation">.</span><span class="token function">floor</span><span class="token punctuation">(</span><span class="token number">0.046</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 0.04</span>
 
_<span class="token punctuation">.</span><span class="token function">floor</span><span class="token punctuation">(</span><span class="token number">4060</span><span class="token punctuation">,</span> <span class="token operator">-</span><span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 4000</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="比较" tabindex="-1"><a class="header-anchor" href="#比较" aria-hidden="true">#</a> 比较</h2>
<h3 id="min-array" tabindex="-1"><a class="header-anchor" href="#min-array" aria-hidden="true">#</a> _.min(array)</h3>
<p>计算<code v-pre>array</code>中的最小值。 如果<code v-pre>array</code>是[]或者假值将会返回 undefined。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">min</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">8</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 2</span>
 
_<span class="token punctuation">.</span><span class="token function">min</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => undefined</span>
</code></pre></div><h3 id="minby-array-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#minby-array-iteratee-identity" aria-hidden="true">#</a> _.minBy(array, [iteratee = _.identity])</h3>
<p>这个方法类似<code v-pre>_.min</code>除了它接受<code v-pre>iteratee(value)</code>来调用<code v-pre>array</code>中的每一个元素，来生成其值排序的标准。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> objects <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">minBy</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">o</span><span class="token punctuation">)</span> <span class="token punctuation">{</span> <span class="token keyword">return</span> o<span class="token punctuation">.</span>n<span class="token punctuation">;</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { 'n': 1 }</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">minBy</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> <span class="token string">'n'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { 'n': 1 }</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="max-array" tabindex="-1"><a class="header-anchor" href="#max-array" aria-hidden="true">#</a> _.max(array)</h3>
<p>计算<code v-pre>array</code>中的最大值。 如果<code v-pre>array</code>是[]或者假值将会返回 undefined。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">max</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">8</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 8</span>
 
_<span class="token punctuation">.</span><span class="token function">max</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => undefined</span>
</code></pre></div><h3 id="maxby-array-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#maxby-array-iteratee-identity" aria-hidden="true">#</a> _.maxBy(array, [iteratee = _.identity])</h3>
<p>这个方法类似<code v-pre>_.max</code>除了它接受<code v-pre>iteratee(value)</code>来调用<code v-pre>array</code>中的每一个元素，来生成其值排序的标准。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> objects <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'n'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">maxBy</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">o</span><span class="token punctuation">)</span> <span class="token punctuation">{</span> <span class="token keyword">return</span> o<span class="token punctuation">.</span>n<span class="token punctuation">;</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { 'n': 2 }</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">maxBy</span><span class="token punctuation">(</span>objects<span class="token punctuation">,</span> <span class="token string">'n'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { 'n': 2 }</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr/>
</div></template>


