export const data = JSON.parse("{\"key\":\"v-3e3c917f\",\"path\":\"/guide/javascript/lodash-map.html\",\"title\":\"Lodash 对象 Map\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"Lodash 对象 Map\",\"slug\":\"lodash-对象-map\",\"link\":\"#lodash-对象-map\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/javascript/lodash-map.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
