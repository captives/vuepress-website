<template><div><h1 id="lodash-函数-function" tabindex="-1"><a class="header-anchor" href="#lodash-函数-function" aria-hidden="true">#</a> Lodash 函数 Function</h1>
<h3 id="before-n-func" tabindex="-1"><a class="header-anchor" href="#before-n-func" aria-hidden="true">#</a> _.before(n, func)</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>n (number): 超过多少次不再调用func（注：限制调用func 的次数）。</li>
<li>func (Function): 限制执行的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的限定函数。</li>
</ul>
</details>
<p>创建一个调用<code v-pre>func</code>的函数，通过<code v-pre>this</code>绑定和创建函数的参数调用<code v-pre>func</code>，调用次数不超过 n 次。
之后再调用这个函数，将返回最后一次调用<code v-pre>func</code>的结果。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token function">jQuery</span><span class="token punctuation">(</span>element<span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">on</span><span class="token punctuation">(</span><span class="token string">'click'</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span><span class="token function">before</span><span class="token punctuation">(</span><span class="token number">5</span><span class="token punctuation">,</span> addContactToList<span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 允许将最多4个联系人添加到列表中</span>
</code></pre></div><h3 id="after-n-func" tabindex="-1"><a class="header-anchor" href="#after-n-func" aria-hidden="true">#</a> _.after(n, func)</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>n (number): func 方法应该在调用多少次后才执行。</li>
<li>func (Function): 用来限定的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的限定函数。</li>
</ul>
</details>
<p><code v-pre>_.before</code>的反向函数;
此方法创建一个函数，当他被调用至少<code v-pre>n</code>次时才会触发<code v-pre>func</code>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> saves <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token string">'profile'</span><span class="token punctuation">,</span> <span class="token string">'settings'</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
<span class="token keyword">var</span> done <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">after</span><span class="token punctuation">(</span>saves<span class="token punctuation">.</span>length<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'done saving!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">forEach</span><span class="token punctuation">(</span>saves<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">type</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token function">asyncSave</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'type'</span><span class="token operator">:</span> type<span class="token punctuation">,</span> <span class="token string-property property">'complete'</span><span class="token operator">:</span> done <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 两次异步日志保存完成后才会输出：'done saving!'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="ary-func-n-func-length" tabindex="-1"><a class="header-anchor" href="#ary-func-n-func-length" aria-hidden="true">#</a> _.ary(func, [n = func.length])</h3>
<details class="tip-block details"><summary>参数：</summary><ul>
<li>func (Function): 需要被限制参数个数的函数。</li>
<li>[n=func.length] (number): 限制的参数数量。</li>
</ul>
<p>返回值：</p>
<ul>
<li>(Function): 返回新的覆盖函数。</li>
</ul>
</details>
<p>创建一个调用<code v-pre>func</code>的函数。调用<code v-pre>func</code>时最多接受<code v-pre>n</code>个参数，忽略多出的参数。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">map</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'6'</span><span class="token punctuation">,</span> <span class="token string">'8'</span><span class="token punctuation">,</span> <span class="token string">'10'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span><span class="token function">ary</span><span class="token punctuation">(</span>parseInt<span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [6, 8, 10]</span>
</code></pre></div><p>等价于</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">map</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'6'</span><span class="token punctuation">,</span> <span class="token string">'8'</span><span class="token punctuation">,</span> <span class="token string">'10'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span><span class="token function">ary</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token parameter">a<span class="token punctuation">,</span> b</span><span class="token punctuation">)</span> <span class="token operator">=></span> <span class="token punctuation">{</span>
    console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>a<span class="token punctuation">,</span> b<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token keyword">return</span> <span class="token function">parseInt</span><span class="token punctuation">(</span>a<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token doc-comment comment">/**
 6 undefined
 8 undefined
 10 undefined 
=> [6, 8, 10]
*/</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>扩展==n = 2==时，将输出：</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code> <span class="token number">6</span> <span class="token number">0</span>
 <span class="token number">8</span> <span class="token number">1</span>
 <span class="token number">10</span> <span class="token number">2</span>
<span class="token operator">=></span> <span class="token punctuation">[</span><span class="token number">6</span><span class="token punctuation">,</span> <span class="token number">8</span><span class="token punctuation">,</span> <span class="token number">10</span><span class="token punctuation">]</span>
</code></pre></div><h3 id="bind-func-thisarg-partials" tabindex="-1"><a class="header-anchor" href="#bind-func-thisarg-partials" aria-hidden="true">#</a> _.bind(func, thisArg, [partials])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 绑定的函数。</li>
<li>thisArg (*): func 绑定的this对象。</li>
<li>[partials] (...*): 附加的部分参数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的绑定函数。</li>
</ul>
</details>
<p>创建一个调用<code v-pre>func</code>的函数，<code v-pre>thisArg</code>绑定<code v-pre>func</code>函数中的<code v-pre>this</code>(注：this的上下文为thisArg)，并且<code v-pre>func</code>函数会接收<code v-pre>partials</code>附加参数。</p>
<p>_.bind.placeholder 值，默认是以<code v-pre>_</code>作为附加部分参数的占位符。</p>
<div class="tip-block warning"><p class="title">警告</p><p>不同于原生的 Function#bind，这个方法不会设置绑定函数的 <code v-pre>length</code> 属性。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> <span class="token function-variable function">greet</span> <span class="token operator">=</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">greeting<span class="token punctuation">,</span> punctuation</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> greeting <span class="token operator">+</span> <span class="token string">' '</span> <span class="token operator">+</span> <span class="token keyword">this</span><span class="token punctuation">.</span>user <span class="token operator">+</span> punctuation<span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">;</span>
 
<span class="token keyword">var</span> object <span class="token operator">=</span> <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span> <span class="token punctuation">}</span><span class="token punctuation">;</span>
 
<span class="token keyword">var</span> bound <span class="token operator">=</span> <span class="token function">_</span><span class="token punctuation">.</span><span class="token function">bind</span><span class="token punctuation">(</span>greet<span class="token punctuation">,</span> object<span class="token punctuation">,</span> <span class="token string">'hi'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">bound</span><span class="token punctuation">(</span><span class="token string">'!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hi fred!'</span>
 
<span class="token comment">// 占位符绑定</span>
<span class="token keyword">var</span> bound <span class="token operator">=</span> <span class="token function">_</span><span class="token punctuation">.</span><span class="token function">bind</span><span class="token punctuation">(</span>greet<span class="token punctuation">,</span> object<span class="token punctuation">,</span> _<span class="token punctuation">,</span> <span class="token string">'!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">bound</span><span class="token punctuation">(</span><span class="token string">'hi'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hi fred!'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="bindkey-object-key-partials" tabindex="-1"><a class="header-anchor" href="#bindkey-object-key-partials" aria-hidden="true">#</a> _.bindKey(object, key, [partials])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>object (Object): 需要绑定函数的对象。</li>
<li>key (string): 需要绑定函数对象的键。</li>
<li>[partials] (...*): 附加的部分参数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的绑定函数。</li>
</ul>
</details>
<p>创建一个函数,在<code v-pre>object[key]</code>上通过接收<code v-pre>partials</code>附加参数，调用这个方法。
这个方法与<code v-pre>_.bind</code>的不同之处在于允许重新定义绑定函数即使它还不存在。</p>
<p>_.bind.placeholder值，默认是以<code v-pre>_</code>作为附加部分参数的占位符。</p>
<p>:::info
浏览<a href="http://peter.michaux.ca/articles/lazy-function-definition-pattern" target="_blank" rel="noopener noreferrer">Peter Michaux's article<ExternalLinkIcon/></a>了解更多详情。
:::</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> object <span class="token operator">=</span> <span class="token punctuation">{</span>
  <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>
  <span class="token string-property property">'greet'</span><span class="token operator">:</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">greeting<span class="token punctuation">,</span> punctuation</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
    <span class="token keyword">return</span> greeting <span class="token operator">+</span> <span class="token string">' '</span> <span class="token operator">+</span> <span class="token keyword">this</span><span class="token punctuation">.</span>user <span class="token operator">+</span> punctuation<span class="token punctuation">;</span>
  <span class="token punctuation">}</span>
<span class="token punctuation">}</span><span class="token punctuation">;</span>
 
<span class="token keyword">var</span> bound <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">bindKey</span><span class="token punctuation">(</span>object<span class="token punctuation">,</span> <span class="token string">'greet'</span><span class="token punctuation">,</span> <span class="token string">'hi'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">bound</span><span class="token punctuation">(</span><span class="token string">'!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hi fred!'</span>
 
object<span class="token punctuation">.</span><span class="token function-variable function">greet</span> <span class="token operator">=</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">greeting<span class="token punctuation">,</span> punctuation</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> greeting <span class="token operator">+</span> <span class="token string">'ya '</span> <span class="token operator">+</span> <span class="token keyword">this</span><span class="token punctuation">.</span>user <span class="token operator">+</span> punctuation<span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">;</span>
 
<span class="token function">bound</span><span class="token punctuation">(</span><span class="token string">'!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hiya fred!'</span>
 
<span class="token comment">// 占位符绑定</span>
<span class="token keyword">var</span> bound <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">bindKey</span><span class="token punctuation">(</span>object<span class="token punctuation">,</span> <span class="token string">'greet'</span><span class="token punctuation">,</span> _<span class="token punctuation">,</span> <span class="token string">'!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">bound</span><span class="token punctuation">(</span><span class="token string">'hi'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hiya fred!'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="partial-func-partials" tabindex="-1"><a class="header-anchor" href="#partial-func-partials" aria-hidden="true">#</a> _.partial(func, [partials])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 需要预设的函数</li>
<li>[partials] (...*): 预设的参数</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回预设参数的函数。</li>
</ul>
</details>
<p>创建一个函数。 该函数调用<code v-pre>func</code>，并传入预设的<code v-pre>partials</code>参数。 这个方法类似<code v-pre>_.bind</code>，除了它不会绑定 <code v-pre>this</code>。</p>
<p>这个 _.partial.placeholder 的值，默认是以<code v-pre>_</code>作为附加部分参数的占位符。</p>
<div class="tip-block warning"><p class="title">警告</p><p>这个方法不会设置 &quot;length&quot; 到函数上。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> <span class="token function-variable function">greet</span> <span class="token operator">=</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">greeting<span class="token punctuation">,</span> name</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> greeting <span class="token operator">+</span> <span class="token string">' '</span> <span class="token operator">+</span> name<span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">;</span>
 
<span class="token keyword">var</span> sayHelloTo <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">partial</span><span class="token punctuation">(</span>greet<span class="token punctuation">,</span> <span class="token string">'hello'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">sayHelloTo</span><span class="token punctuation">(</span><span class="token string">'fred'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hello fred'</span>
 
<span class="token comment">// 使用了占位符。</span>
<span class="token keyword">var</span> greetFred <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">partial</span><span class="token punctuation">(</span>greet<span class="token punctuation">,</span> _<span class="token punctuation">,</span> <span class="token string">'fred'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">greetFred</span><span class="token punctuation">(</span><span class="token string">'hi'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hi fred'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="partialright-func-partials" tabindex="-1"><a class="header-anchor" href="#partialright-func-partials" aria-hidden="true">#</a> _.partialRight(func, [partials])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 需要预设的函数</li>
<li>[partials] (...*): 预设的参数</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回预设参数的函数。</li>
</ul>
</details>
<p>这个函数类似<code v-pre>_.partial</code>，除了预设参数被附加到接受参数的后面。</p>
<p>这个_.partialRight.placeholder 的值，默认是以<code v-pre>_</code>作为附加部分参数的占位符。</p>
<div class="tip-block warning"><p class="title">警告</p><p>这个方法不会设置 &quot;length&quot; 到函数上。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> <span class="token function-variable function">greet</span> <span class="token operator">=</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">greeting<span class="token punctuation">,</span> name</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> greeting <span class="token operator">+</span> <span class="token string">' '</span> <span class="token operator">+</span> name<span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">;</span>
 
<span class="token keyword">var</span> greetFred <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">partialRight</span><span class="token punctuation">(</span>greet<span class="token punctuation">,</span> <span class="token string">'fred'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">greetFred</span><span class="token punctuation">(</span><span class="token string">'hi'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hi fred'</span>
 
<span class="token comment">// 使用了占位符。</span>
<span class="token keyword">var</span> sayHelloTo <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">partialRight</span><span class="token punctuation">(</span>greet<span class="token punctuation">,</span> <span class="token string">'hello'</span><span class="token punctuation">,</span> _<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">sayHelloTo</span><span class="token punctuation">(</span><span class="token string">'fred'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hello fred'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="curry-func-arity-func-length" tabindex="-1"><a class="header-anchor" href="#curry-func-arity-func-length" aria-hidden="true">#</a> _.curry(func, [arity = func.length])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 用来柯里化（curry）的函数。</li>
<li>[arity=func.length] (number): 需要提供给 func 的参数数量。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的柯里化（curry）函数。</li>
</ul>
</details>
<p>创建一个函数，该函数接收<code v-pre>func</code>的参数，要么调用func返回的结果，如果 func 所需参数已经提供，则直接返回 func 所执行的结果。或返回一个函数，接受余下的func 参数的函数，可以使用 func.length 强制需要累积的参数个数。</p>
<p>_.curry.placeholder 值，默认是以<code v-pre>_</code>作为附加部分参数的占位符。</p>
<div class="tip-block warning"><p class="title">警告</p><p>这个方法不会设置<code v-pre>curried</code>函数的<code v-pre>length</code>属性。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> <span class="token function-variable function">abc</span> <span class="token operator">=</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">a<span class="token punctuation">,</span> b<span class="token punctuation">,</span> c</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> <span class="token punctuation">[</span>a<span class="token punctuation">,</span> b<span class="token punctuation">,</span> c<span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">;</span>
 
<span class="token keyword">var</span> curried <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">curry</span><span class="token punctuation">(</span>abc<span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token function">curried</span><span class="token punctuation">(</span><span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
 
<span class="token function">curried</span><span class="token punctuation">(</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
 
<span class="token function">curried</span><span class="token punctuation">(</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
 
<span class="token comment">// Curried with placeholders.</span>
<span class="token function">curried</span><span class="token punctuation">(</span><span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">(</span>_<span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="curryright-func-arity-func-length" tabindex="-1"><a class="header-anchor" href="#curryright-func-arity-func-length" aria-hidden="true">#</a> _.curryRight(func, [arity = func.length])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 用来柯里化（curry）的函数。</li>
<li>[arity=func.length] (number): 需要提供给 func 的参数数量。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的柯里化（curry）函数。</li>
</ul>
</details>
<p>这个方法类似<code v-pre>_.curry</code>。 除了它接受参数的方式用<code v-pre>_.partialRight</code>代替<code v-pre>_.partial</code>。</p>
<p>_.curryRight.placeholder值，默认是以<code v-pre>_</code>作为附加部分参数的占位符。</p>
<div class="tip-block warning"><p class="title">警告</p><p>这个方法不会设置 curried 函数的 &quot;length&quot; 属性。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> <span class="token function-variable function">abc</span> <span class="token operator">=</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">a<span class="token punctuation">,</span> b<span class="token punctuation">,</span> c</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> <span class="token punctuation">[</span>a<span class="token punctuation">,</span> b<span class="token punctuation">,</span> c<span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">;</span>
 
<span class="token keyword">var</span> curried <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">curryRight</span><span class="token punctuation">(</span>abc<span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token function">curried</span><span class="token punctuation">(</span><span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
 
<span class="token function">curried</span><span class="token punctuation">(</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
 
<span class="token function">curried</span><span class="token punctuation">(</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
 
<span class="token comment">// Curried with placeholders.</span>
<span class="token function">curried</span><span class="token punctuation">(</span><span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token number">1</span><span class="token punctuation">,</span> _<span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2, 3]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="rearg-func-indexes" tabindex="-1"><a class="header-anchor" href="#rearg-func-indexes" aria-hidden="true">#</a> _.rearg(func, indexes)</h3>
<details class="tip-block details"><summary>参数</summary><p>func (Function): 待调用的函数。
indexes (...(number|number[])): 排列参数的位置。
返回
(Function): 返回新的函数。</p>
</details>
<p>创建一个函数,调用<code v-pre>func</code>时，根据指定的<code v-pre>indexes</code>调整对应位置参数。其中第一个索引值是对应第一个参数，第二个索引值是作为第二个参数，依此类推。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> rearged <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">rearg</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">a<span class="token punctuation">,</span> b<span class="token punctuation">,</span> c</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> <span class="token punctuation">[</span>a<span class="token punctuation">,</span> b<span class="token punctuation">,</span> c<span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">0</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token function">rearged</span><span class="token punctuation">(</span><span class="token string">'b'</span><span class="token punctuation">,</span> <span class="token string">'c'</span><span class="token punctuation">,</span> <span class="token string">'a'</span><span class="token punctuation">)</span>
<span class="token comment">// => ['a', 'b', 'c']</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="rest-func-start-func-length-1" tabindex="-1"><a class="header-anchor" href="#rest-func-start-func-length-1" aria-hidden="true">#</a> _.rest(func, [start=func.length-1])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 要应用的函数。</li>
<li>[start=func.length-1] (number): rest 参数的开始位置。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的函数。</li>
</ul>
</details>
<p>创建一个函数，调用<code v-pre>func</code>时，<code v-pre>this</code>绑定到创建的新函数，并且<code v-pre>start</code>之后的参数作为数组传入。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> say <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">rest</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">what<span class="token punctuation">,</span> names</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> what <span class="token operator">+</span> <span class="token string">' '</span> <span class="token operator">+</span> _<span class="token punctuation">.</span><span class="token function">initial</span><span class="token punctuation">(</span>names<span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">join</span><span class="token punctuation">(</span><span class="token string">', '</span><span class="token punctuation">)</span> <span class="token operator">+</span>
    <span class="token punctuation">(</span>_<span class="token punctuation">.</span><span class="token function">size</span><span class="token punctuation">(</span>names<span class="token punctuation">)</span> <span class="token operator">></span> <span class="token number">1</span> <span class="token operator">?</span> <span class="token string">', &amp; '</span> <span class="token operator">:</span> <span class="token string">''</span><span class="token punctuation">)</span> <span class="token operator">+</span> _<span class="token punctuation">.</span><span class="token function">last</span><span class="token punctuation">(</span>names<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token function">say</span><span class="token punctuation">(</span><span class="token string">'hello'</span><span class="token punctuation">,</span> <span class="token string">'fred'</span><span class="token punctuation">,</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string">'pebbles'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hello fred, barney, &amp; pebbles'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="spread-func-start-0" tabindex="-1"><a class="header-anchor" href="#spread-func-start-0" aria-hidden="true">#</a> _.spread(func, [start=0])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 要应用传播参数的函数。</li>
<li>[start=0] (number): spread 参数的开始位置.</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的函数。</li>
</ul>
</details>
<p>创建一个函数，调用<code v-pre>func</code>时，<code v-pre>this</code>绑定到创建的新函数，把参数作为数组传入，类似于<a href="http://www.ecma-international.org/ecma-262/6.0/#sec-function.prototype.apply" target="_blank" rel="noopener noreferrer">Function#apply<ExternalLinkIcon/></a>.</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> say <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">spread</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">who<span class="token punctuation">,</span> what</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> who <span class="token operator">+</span> <span class="token string">' says '</span> <span class="token operator">+</span> what<span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token function">say</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'fred'</span><span class="token punctuation">,</span> <span class="token string">'hello'</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'fred says hello'</span>
 
<span class="token keyword">var</span> numbers <span class="token operator">=</span> Promise<span class="token punctuation">.</span><span class="token function">all</span><span class="token punctuation">(</span><span class="token punctuation">[</span>
  Promise<span class="token punctuation">.</span><span class="token function">resolve</span><span class="token punctuation">(</span><span class="token number">40</span><span class="token punctuation">)</span><span class="token punctuation">,</span>
  Promise<span class="token punctuation">.</span><span class="token function">resolve</span><span class="token punctuation">(</span><span class="token number">36</span><span class="token punctuation">)</span>
<span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
numbers<span class="token punctuation">.</span><span class="token function">then</span><span class="token punctuation">(</span>_<span class="token punctuation">.</span><span class="token function">spread</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">x<span class="token punctuation">,</span> y</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> x <span class="token operator">+</span> y<span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => a Promise of 76</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="throttle-func-wait-0-options" tabindex="-1"><a class="header-anchor" href="#throttle-func-wait-0-options" aria-hidden="true">#</a> _.throttle(func, [wait = 0], [options = ])</h3>
<details class="tip-block details"><summary>参数</summary><p>func (Function): 要节流的函数。
[wait=0] (number): 需要节流的毫秒。
[options=] (Object): 选项对象。
[options.leading=true] (boolean): 指定调用在节流开始前。
[options.trailing=true] (boolean): 指定调用在节流结束后。
返回
(Function): 返回节流的函数。</p>
</details>
<p>创建一个节流函数，在<code v-pre>wait</code>毫秒内最多执行<code v-pre>func</code>一次的函数。 该函数提供一个<code v-pre>cancel</code>方法取消延迟的函数调用以及 <code v-pre>flush</code>方法立即调用。 可以提供一个<code v-pre>options</code>对象决定如何调用<code v-pre>func</code>方法，<code v-pre>options.leading</code>与<code v-pre>|</code>或 <code v-pre>options.trailing</code>决定<code v-pre>wait</code>前后如何触发。<code v-pre>func</code>会传入最后一次传入的参数给这个函数。 随后调用的函数返回是最后一次<code v-pre>func</code>调用的结果。</p>
<div class="tip-block warning"><p class="title">注意:</p><p>如果<code v-pre>leading</code>和<code v-pre>trailing</code>都设定为==true==则<code v-pre>func</code>允许<code v-pre>trailing</code>方式调用的条件为: 在<code v-pre>wait</code>期间多次调用。</p>
</div>
<p>如果<code v-pre>wait</code>为==0==并且<code v-pre>leading</code>为==false==,<code v-pre>func</code>调用将被推迟到下一个点，类似<code v-pre>setTimeout</code>为==0==的超时。
:::info
查看 <a href="https://css-tricks.com/debouncing-throttling-explained-examples/" target="_blank" rel="noopener noreferrer">David Corbacho's article<ExternalLinkIcon/></a> 了解<a href="https://www.lodashjs.com/docs/lodash.debounce" target="_blank" rel="noopener noreferrer">_.throttle<ExternalLinkIcon/></a>与<a href="https://www.lodashjs.com/docs/lodash.throttle" target="_blank" rel="noopener noreferrer">_.debounce<ExternalLinkIcon/></a>的区别。
:::</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token comment">// 避免在滚动时过分的更新定位</span>
<span class="token function">jQuery</span><span class="token punctuation">(</span>window<span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">on</span><span class="token punctuation">(</span><span class="token string">'scroll'</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span><span class="token function">throttle</span><span class="token punctuation">(</span>updatePosition<span class="token punctuation">,</span> <span class="token number">100</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token comment">// 点击后就调用 `renewToken`，但5分钟内超过1次。</span>
<span class="token keyword">var</span> throttled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">throttle</span><span class="token punctuation">(</span>renewToken<span class="token punctuation">,</span> <span class="token number">300000</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'trailing'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">jQuery</span><span class="token punctuation">(</span>element<span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">on</span><span class="token punctuation">(</span><span class="token string">'click'</span><span class="token punctuation">,</span> throttled<span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token comment">// 取消一个 trailing 的节流调用。</span>
<span class="token function">jQuery</span><span class="token punctuation">(</span>window<span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">on</span><span class="token punctuation">(</span><span class="token string">'popstate'</span><span class="token punctuation">,</span> throttled<span class="token punctuation">.</span>cancel<span class="token punctuation">)</span><span class="token punctuation">;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="unary-func" tabindex="-1"><a class="header-anchor" href="#unary-func" aria-hidden="true">#</a> _.unary(func)</h3>
<p>创建一个最多接受一个参数的函数，忽略多余的参数。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">map</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'6'</span><span class="token punctuation">,</span> <span class="token string">'8'</span><span class="token punctuation">,</span> <span class="token string">'10'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span><span class="token function">unary</span><span class="token punctuation">(</span>parseInt<span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [6, 8, 10]</span>
</code></pre></div><h3 id="wrap-value-wrapper-identity" tabindex="-1"><a class="header-anchor" href="#wrap-value-wrapper-identity" aria-hidden="true">#</a> _.wrap(value, [wrapper=identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>value (*): 要包装的值。</li>
<li>[wrapper=identity] (Function): 包装函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的函数。</li>
</ul>
</details>
<p>创建一个函数。提供的<code v-pre>value</code>包装在<code v-pre>wrapper</code>函数的第一个参数里。 任何附加的参数都提供给<code v-pre>wrapper</code>函数。 被调用时<code v-pre>this</code>绑定在创建的函数上。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> p <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">wrap</span><span class="token punctuation">(</span>_<span class="token punctuation">.</span>escape<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">func<span class="token punctuation">,</span> text</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> <span class="token string">'&lt;p>'</span> <span class="token operator">+</span> <span class="token function">func</span><span class="token punctuation">(</span>text<span class="token punctuation">)</span> <span class="token operator">+</span> <span class="token string">'&lt;/p>'</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token function">p</span><span class="token punctuation">(</span><span class="token string">'fred, barney, &amp; pebbles'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '&lt;p>fred, barney, &amp; pebbles&lt;/p>'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="延迟" tabindex="-1"><a class="header-anchor" href="#延迟" aria-hidden="true">#</a> 延迟</h2>
<h3 id="debounce-func-wait-0-options" tabindex="-1"><a class="header-anchor" href="#debounce-func-wait-0-options" aria-hidden="true">#</a> _.debounce(func, [wait = 0], [options = ])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 要防抖动的函数。</li>
<li>[wait=0] (number): 需要延迟的毫秒数。</li>
<li>[options=] (Object): 选项对象。</li>
<li>[options.leading=false] (boolean): 指定在延迟开始前调用。</li>
<li>[options.maxWait] (number): 设置 func 允许被延迟的最大值。</li>
<li>[options.trailing=true] (boolean): 指定在延迟结束后调用。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的 debounced（防抖动）函数。</li>
</ul>
</details>
<p>创建一个<code v-pre>debounced</code>（防抖动）函数，该函数会从上一次被调用后，延迟<code v-pre>wait</code>毫秒后调用<code v-pre>func</code>方法。<code v-pre>debounced</code>（防抖动）函数提供一个<code v-pre>cancel</code>方法取消延迟的函数调用以及<code v-pre>flush</code>方法立即调用。 可以提供一个 <code v-pre>options</code>（选项）对象决定如何调用<code v-pre>func</code>方法，<code v-pre>options.leading</code> 与<code v-pre>|</code> 或<code v-pre>options.trailing</code>决定延迟前后如何触发（注：是 ==先调用后等待==还是 ==先等待后调用==）。 <code v-pre>func</code>调用时会传入最后一次提供给<code v-pre>debounced</code>（防抖动）函数的参数。 后续调用的<code v-pre>debounced</code>（防抖动）函数返回是最后一次<code v-pre>func</code>调用的结果。</p>
<div class="tip-block warning"><p class="title">注意:</p><p>如果<code v-pre>leading</code>和<code v-pre>trailing</code>选项为==true==, 则<code v-pre>func</code>允许<code v-pre>trailing</code>方式调用的条件为: 在<code v-pre>wait</code>期间多次调用防抖方法。</p>
<p>如果<code v-pre>wait</code>为==0== 并且<code v-pre>leading</code>为==false==, <code v-pre>func</code>调用将被推迟到下一个点，类似<code v-pre>setTimeout</code>为==0==的超时。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token comment">// 避免窗口在变动时出现昂贵的计算开销。</span>
<span class="token function">jQuery</span><span class="token punctuation">(</span>window<span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">on</span><span class="token punctuation">(</span><span class="token string">'resize'</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span><span class="token function">debounce</span><span class="token punctuation">(</span>calculateLayout<span class="token punctuation">,</span> <span class="token number">150</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token comment">// 当点击时 `sendMail` 随后就被调用。</span>
<span class="token function">jQuery</span><span class="token punctuation">(</span>element<span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">on</span><span class="token punctuation">(</span><span class="token string">'click'</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span><span class="token function">debounce</span><span class="token punctuation">(</span>sendMail<span class="token punctuation">,</span> <span class="token number">300</span><span class="token punctuation">,</span> <span class="token punctuation">{</span>
  <span class="token string-property property">'leading'</span><span class="token operator">:</span> <span class="token boolean">true</span><span class="token punctuation">,</span>
  <span class="token string-property property">'trailing'</span><span class="token operator">:</span> <span class="token boolean">false</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token comment">// 确保 `batchLog` 调用1次之后，1秒内会被触发。</span>
<span class="token keyword">var</span> debounced <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">debounce</span><span class="token punctuation">(</span>batchLog<span class="token punctuation">,</span> <span class="token number">250</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'maxWait'</span><span class="token operator">:</span> <span class="token number">1000</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token keyword">var</span> source <span class="token operator">=</span> <span class="token keyword">new</span> <span class="token class-name">EventSource</span><span class="token punctuation">(</span><span class="token string">'/stream'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">jQuery</span><span class="token punctuation">(</span>source<span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">on</span><span class="token punctuation">(</span><span class="token string">'message'</span><span class="token punctuation">,</span> debounced<span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token comment">// 取消一个 trailing 的防抖动调用</span>
<span class="token function">jQuery</span><span class="token punctuation">(</span>window<span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">on</span><span class="token punctuation">(</span><span class="token string">'popstate'</span><span class="token punctuation">,</span> debounced<span class="token punctuation">.</span>cancel<span class="token punctuation">)</span><span class="token punctuation">;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="defer-func-args" tabindex="-1"><a class="header-anchor" href="#defer-func-args" aria-hidden="true">#</a> _.defer(func, [args])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 要延迟的函数。</li>
<li>[args] (...*): 会在调用时传给 func 的参数。</li>
</ul>
<p>返回</p>
<ul>
<li>(number):返回计时器 id。</li>
</ul>
</details>
<p>推迟调用<code v-pre>func</code>，直到当前堆栈清理完毕。 调用时，任何附加的参数会传给<code v-pre>func</code>。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">defer</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">text</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>text<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token string">'deferred'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 一毫秒或更久一些输出 'deferred'。</span>
</code></pre></div><h3 id="delay-func-wait-args" tabindex="-1"><a class="header-anchor" href="#delay-func-wait-args" aria-hidden="true">#</a> _.delay(func, wait, [args])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 要延迟的函数。</li>
<li>wait (number): 要延迟的毫秒数。</li>
<li>[args] (...*): 会在调用时传入到 func 的参数。</li>
</ul>
<p>返回</p>
<ul>
<li>(number): 返回计时器 id</li>
</ul>
</details>
<p>延迟<code v-pre>wait</code>毫秒后调用<code v-pre>func</code>。 调用时，任何附加的参数会传给<code v-pre>func</code>。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">delay</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">text</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>text<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token number">1000</span><span class="token punctuation">,</span> <span class="token string">'later'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 一秒后输出 'later'。</span>
</code></pre></div><h2 id="转换" tabindex="-1"><a class="header-anchor" href="#转换" aria-hidden="true">#</a> 转换</h2>
<h3 id="flip-func" tabindex="-1"><a class="header-anchor" href="#flip-func" aria-hidden="true">#</a> _.flip(func)</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 要翻转参数的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的函数。</li>
</ul>
</details>
<p>创建一个函数，调用<code v-pre>func</code>时候接收翻转的参数。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> flipped <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">flip</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> _<span class="token punctuation">.</span><span class="token function">toArray</span><span class="token punctuation">(</span>arguments<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token function">flipped</span><span class="token punctuation">(</span><span class="token string">'a'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">,</span> <span class="token string">'c'</span><span class="token punctuation">,</span> <span class="token string">'d'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => ['d', 'c', 'b', 'a']</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="memoize-func-resolver" tabindex="-1"><a class="header-anchor" href="#memoize-func-resolver" aria-hidden="true">#</a> _.memoize(func, [resolver])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 需要缓存化的函数.</li>
<li>[resolver] (Function): 这个函数的返回值作为缓存的 key。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回缓存化后的函数。</li>
</ul>
</details>
<p>创建一个会缓存<code v-pre>func</code>结果的函数。 如果提供了<code v-pre>resolver</code>，就用<code v-pre>resolver</code>的返回值作为<code v-pre>key</code>缓存函数的结果。 默认情况下用第一个参数作为缓存的<code v-pre>key</code>。 <code v-pre>func</code>在调用时<code v-pre>this</code>会绑定在缓存函数上。</p>
<div class="tip-block warning"><p class="title">注意:</p><p>缓存会暴露在缓存函数的<code v-pre>cache</code>上。 它是可以定制的，只要替换了<code v-pre>_.memoize.Cache</code>构造函数，或实现了Map的 <code v-pre>delete</code>, <code v-pre>get</code>, <code v-pre>has</code>, 和<code v-pre>set</code>方法。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> object <span class="token operator">=</span> <span class="token punctuation">{</span> <span class="token string-property property">'a'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'b'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">;</span>
<span class="token keyword">var</span> other <span class="token operator">=</span> <span class="token punctuation">{</span> <span class="token string-property property">'c'</span><span class="token operator">:</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token string-property property">'d'</span><span class="token operator">:</span> <span class="token number">4</span> <span class="token punctuation">}</span><span class="token punctuation">;</span>
 
<span class="token keyword">var</span> values <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">memoize</span><span class="token punctuation">(</span>_<span class="token punctuation">.</span>values<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">values</span><span class="token punctuation">(</span>object<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2]</span>
 
<span class="token function">values</span><span class="token punctuation">(</span>other<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [3, 4]</span>
 
object<span class="token punctuation">.</span>a <span class="token operator">=</span> <span class="token number">2</span><span class="token punctuation">;</span>
<span class="token function">values</span><span class="token punctuation">(</span>object<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 2]</span>
 
<span class="token comment">// 修改结果缓存。</span>
values<span class="token punctuation">.</span>cache<span class="token punctuation">.</span><span class="token function">set</span><span class="token punctuation">(</span>object<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'a'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">values</span><span class="token punctuation">(</span>object<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => ['a', 'b']</span>
 
<span class="token comment">// 替换 `_.memoize.Cache`。</span>
_<span class="token punctuation">.</span>memoize<span class="token punctuation">.</span>Cache <span class="token operator">=</span> WeakMap<span class="token punctuation">;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="negate-predicate-function" tabindex="-1"><a class="header-anchor" href="#negate-predicate-function" aria-hidden="true">#</a> _.negate(predicate:Function)</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>predicate (Function): 需要对结果取反的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回一个新的取反函数。</li>
</ul>
</details>
<p>创建一个针对断言函数<code v-pre>func</code>结果取反的函数。 <code v-pre>func</code>断言函数被调用的时候, <code v-pre>this</code>绑定到创建的函数，并传入对应参数。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">function</span> <span class="token function">isEven</span><span class="token punctuation">(</span><span class="token parameter">n</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> n <span class="token operator">%</span> <span class="token number">2</span> <span class="token operator">==</span> <span class="token number">0</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
 
_<span class="token punctuation">.</span><span class="token function">filter</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">]</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span><span class="token function">negate</span><span class="token punctuation">(</span>isEven<span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 3, 5]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="once-func" tabindex="-1"><a class="header-anchor" href="#once-func" aria-hidden="true">#</a> _.once(func)</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function): 指定的触发的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新的受限函数。</li>
</ul>
</details>
<p>创建一个只能调用<code v-pre>func</code>一次的函数。重复调用返回第一次调用的结果。<code v-pre>func</code>调用时，<code v-pre>this</code>绑定到创建的函数，并传入对应参数。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> initialize <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">once</span><span class="token punctuation">(</span>createApplication<span class="token punctuation">)</span><span class="token punctuation">;</span>
initializ	<span class="token function">e</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">initialize</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// `initialize` 只能调用 `createApplication` 一次。</span>
</code></pre></div><h3 id="overargs-func-transforms-identity" tabindex="-1"><a class="header-anchor" href="#overargs-func-transforms-identity" aria-hidden="true">#</a> _.overArgs(func, [transforms = [ _.identity ]])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>func (Function):要包裹的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Function): 返回新函数。</li>
</ul>
</details>
<p>创建一个函数，调用func时参数为相对应的<code v-pre>transforms</code>的返回值。
:::info
执行func函数之前，需要通过<code v-pre>transforms</code> 处理参数；
:::</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">function</span> <span class="token function">doubled</span><span class="token punctuation">(</span><span class="token parameter">n</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> n <span class="token operator">*</span> <span class="token number">2</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
 
<span class="token keyword">function</span> <span class="token function">square</span><span class="token punctuation">(</span><span class="token parameter">n</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> n <span class="token operator">*</span> n<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
 
<span class="token keyword">var</span> func <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">overArgs</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">x<span class="token punctuation">,</span> y</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> <span class="token punctuation">[</span>x<span class="token punctuation">,</span> y<span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">[</span>square<span class="token punctuation">,</span> doubled<span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 
<span class="token function">func</span><span class="token punctuation">(</span><span class="token number">9</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [81, 6]</span>
 
<span class="token function">func</span><span class="token punctuation">(</span><span class="token number">10</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [100, 10]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>或</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> func <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">overArgs</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">x<span class="token punctuation">,</span> y</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> x <span class="token operator">+</span> y<span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">[</span>square<span class="token punctuation">,</span> doubled<span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>

<span class="token function">func</span><span class="token punctuation">(</span><span class="token number">9</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 87</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr/>
</div></template>


