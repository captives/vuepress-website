<template><div><h1 id="es6-学习笔记" tabindex="-1"><a class="header-anchor" href="#es6-学习笔记" aria-hidden="true">#</a> ES6 学习笔记</h1>
<h2 id="符号" tabindex="-1"><a class="header-anchor" href="#符号" aria-hidden="true">#</a> 符号</h2>
<ul>
<li><code v-pre>@</code>		at</li>
<li><code v-pre>|</code>		or</li>
<li><code v-pre>&amp;</code>		and</li>
<li><code v-pre>.</code>		dot</li>
<li><code v-pre>/</code>		divide, slash</li>
<li><code v-pre>\</code>		backslash</li>
<li><code v-pre>-</code>		dash, minus(减号/负号)</li>
<li><code v-pre>+</code>		plus</li>
<li><code v-pre>*</code>		multiply,asterisk</li>
<li><code v-pre>=</code>		equal</li>
<li><code v-pre>?</code> 		question mark</li>
<li><code v-pre>!</code> 		exclamation</li>
<li><code v-pre>:</code>		colon</li>
<li><code v-pre>...</code>		ellipsis</li>
<li><code v-pre>_</code>		underline</li>
<li><code v-pre>,</code>		comma</li>
<li><code v-pre>^</code>		caret</li>
<li><code v-pre>~</code>		tilde</li>
<li><code v-pre>()</code>		bracket</li>
<li><code v-pre>[]</code>		square bracket</li>
</ul>
<h2 id="运算符" tabindex="-1"><a class="header-anchor" href="#运算符" aria-hidden="true">#</a> 运算符</h2>
<h3 id="按位取反运算符" tabindex="-1"><a class="header-anchor" href="#按位取反运算符" aria-hidden="true">#</a> 按位取反运算符<code v-pre>~</code></h3>
<ul>
<li><code v-pre>~[string | number| null | undefined]</code></li>
</ul>
<p>示例：</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token operator">~</span><span class="token string">'a'</span>			<span class="token comment">//0</span>
<span class="token operator">~</span><span class="token keyword">null</span>			<span class="token comment">//0</span>
<span class="token operator">~</span><span class="token keyword">undefined</span>		<span class="token comment">//0</span>
<span class="token operator">~</span><span class="token number">0</span>				<span class="token comment">//-1</span>
<span class="token operator">~</span><span class="token operator">~</span><span class="token number">0</span>				<span class="token comment">//0</span>
<span class="token operator">~</span><span class="token number">1.555555</span> 		<span class="token comment">// -1</span>
<span class="token operator">~</span><span class="token operator">-</span><span class="token number">1.555555</span> 		<span class="token comment">// 1;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="求幂表达式" tabindex="-1"><a class="header-anchor" href="#求幂表达式" aria-hidden="true">#</a> 求幂表达式 <code v-pre>**</code></h3>
<p>返回基数<code v-pre>base</code>的指数<code v-pre>exponent</code>次幂,等价于<code v-pre>Math.pow(base, exponent)</code>：</p>
<ul>
<li><code v-pre>base**exponent	=== Math.pow(base, exponent)</code></li>
</ul>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token number">2</span><span class="token operator">**</span><span class="token number">2</span>		<span class="token comment">//4</span>
<span class="token number">2</span><span class="token operator">**</span><span class="token number">3</span>		<span class="token comment">//8</span>
<span class="token number">2</span><span class="token operator">**</span><span class="token number">10</span>		<span class="token comment">//1024</span>

<span class="token punctuation">(</span><span class="token operator">-</span><span class="token number">3</span><span class="token punctuation">)</span><span class="token operator">**</span><span class="token number">2</span>		<span class="token comment">// 9</span>
<span class="token punctuation">(</span><span class="token operator">-</span><span class="token number">3</span><span class="token punctuation">)</span><span class="token operator">**</span><span class="token number">3</span>		<span class="token comment">// -27</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="var-let-const" tabindex="-1"><a class="header-anchor" href="#var-let-const" aria-hidden="true">#</a> var/let/const</h2>
<p><code v-pre>var</code>命令会发生“变量提升”现象，即变量可以在声明之前使用，值为<code v-pre>undefined</code>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token comment">// var 的情况</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>foo<span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// 输出undefined</span>
<span class="token keyword">var</span> foo <span class="token operator">=</span> <span class="token number">2</span><span class="token punctuation">;</span>

<span class="token comment">// let 的情况</span>
console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>bar<span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// 报错ReferenceError</span>
<span class="token keyword">let</span> bar <span class="token operator">=</span> <span class="token number">2</span><span class="token punctuation">;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>如果使用<code v-pre>let</code>，声明的变量仅在块级作用域<code v-pre>{}</code>内有效, 且不允许在相同作用域内，重复声明同一个变量。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">for</span> <span class="token punctuation">(</span><span class="token keyword">var</span> i <span class="token operator">=</span> <span class="token number">0</span><span class="token punctuation">;</span> i <span class="token operator">&lt;</span> <span class="token number">10</span><span class="token punctuation">;</span> i<span class="token operator">++</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
    <span class="token function">setTimeout</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token operator">=></span><span class="token punctuation">{</span>
        console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'i = '</span><span class="token punctuation">,</span> i<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token comment">// 9, 9, 9, 9, 9, 9, 9, 9, 9, 9</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">for</span> <span class="token punctuation">(</span><span class="token keyword">let</span> i <span class="token operator">=</span> <span class="token number">0</span><span class="token punctuation">;</span> i <span class="token operator">&lt;</span> <span class="token number">10</span><span class="token punctuation">;</span> i<span class="token operator">++</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
    <span class="token function">setTimeout</span><span class="token punctuation">(</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token operator">=></span><span class="token punctuation">{</span>
        console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span><span class="token string">'i = '</span><span class="token punctuation">,</span> i<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
<span class="token comment">// 0, 1, 2, 3, 4, 5, 6, 7, 8, 9</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><code v-pre>const</code>是只读常量，一旦赋值，将不能更改；但对象可以更改对象的属性。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">const</span> a <span class="token operator">=</span> <span class="token number">5</span><span class="token punctuation">;</span>
a <span class="token operator">=</span> <span class="token number">6</span><span class="token punctuation">;</span> <span class="token comment">//error</span>

<span class="token keyword">const</span> a <span class="token operator">=</span> <span class="token punctuation">{</span> <span class="token literal-property property">a</span><span class="token operator">:</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token literal-property property">b</span><span class="token operator">:</span><span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">;</span>
a <span class="token operator">=</span> <span class="token punctuation">{</span> <span class="token literal-property property">c</span><span class="token operator">:</span><span class="token number">22</span> <span class="token punctuation">}</span><span class="token punctuation">;</span><span class="token comment">//error</span>
a<span class="token punctuation">.</span>a <span class="token operator">=</span> <span class="token number">3</span> <span class="token comment">//a = 3</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="对象解构" tabindex="-1"><a class="header-anchor" href="#对象解构" aria-hidden="true">#</a> 对象解构</h2>
</div></template>


