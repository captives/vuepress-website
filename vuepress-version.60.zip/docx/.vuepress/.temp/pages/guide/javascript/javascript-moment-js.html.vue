<template><div><h1 id="moment-js" tabindex="-1"><a class="header-anchor" href="#moment-js" aria-hidden="true">#</a> Moment.js</h1>
<div class="hero-circle">
    <div class="hero-face">
        <div id="hour" class="hero-hour"></div>
        <div id="minute" class="hero-minute"></div>
        <div id="second" class="hero-second"></div>
    </div>
</div>
<p><a href="http://momentjs.cn/" target="_blank" rel="noopener noreferrer">官网<ExternalLinkIcon/></a>、<a href="http://momentjs.cn/docs/" target="_blank" rel="noopener noreferrer">文档<ExternalLinkIcon/></a></p>
<h2 id="日期格式化" tabindex="-1"><a class="header-anchor" href="#日期格式化" aria-hidden="true">#</a> 日期格式化</h2>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'MMMM Do YYYY, h:mm:ss a'</span><span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// 四月 4日 2018, 1:35:14 下午</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'dddd'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>                    <span class="token comment">// 星期三</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">"MMM Do YY"</span><span class="token punctuation">)</span><span class="token punctuation">;</span>               <span class="token comment">// 4月 4日 18</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'YYYY [escaped] YYYY'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>     <span class="token comment">// 2018 escaped 2018</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>                          <span class="token comment">// 2018-04-04T13:35:14+08:00</span>
</code></pre></div><h2 id="相对时间" tabindex="-1"><a class="header-anchor" href="#相对时间" aria-hidden="true">#</a> 相对时间</h2>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token function">moment</span><span class="token punctuation">(</span><span class="token string">"20111031"</span><span class="token punctuation">,</span> <span class="token string">"YYYYMMDD"</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">fromNow</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// 6 年前</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token string">"20120620"</span><span class="token punctuation">,</span> <span class="token string">"YYYYMMDD"</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">fromNow</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// 6 年前</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">startOf</span><span class="token punctuation">(</span><span class="token string">'day'</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">fromNow</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>        <span class="token comment">// 14 小时前</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">endOf</span><span class="token punctuation">(</span><span class="token string">'day'</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">fromNow</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>          <span class="token comment">// 10 小时内</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">startOf</span><span class="token punctuation">(</span><span class="token string">'hour'</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">fromNow</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>       <span class="token comment">// 35 分钟前</span>
</code></pre></div><h2 id="日历时间" tabindex="-1"><a class="header-anchor" href="#日历时间" aria-hidden="true">#</a> 日历时间</h2>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">subtract</span><span class="token punctuation">(</span><span class="token number">10</span><span class="token punctuation">,</span> <span class="token string">'days'</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">calendar</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// 2018年3月25日</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">subtract</span><span class="token punctuation">(</span><span class="token number">6</span><span class="token punctuation">,</span> <span class="token string">'days'</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">calendar</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  <span class="token comment">// 上周四下午1点35</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">subtract</span><span class="token punctuation">(</span><span class="token number">3</span><span class="token punctuation">,</span> <span class="token string">'days'</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">calendar</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  <span class="token comment">// 上周日下午1点35</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">subtract</span><span class="token punctuation">(</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token string">'days'</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">calendar</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  <span class="token comment">// 昨天下午1点35分</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">calendar</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>                      <span class="token comment">// 今天下午1点35分</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">add</span><span class="token punctuation">(</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token string">'days'</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">calendar</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>       <span class="token comment">// 明天下午1点35分</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">add</span><span class="token punctuation">(</span><span class="token number">3</span><span class="token punctuation">,</span> <span class="token string">'days'</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">calendar</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>       <span class="token comment">// 本周六下午1点35</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">add</span><span class="token punctuation">(</span><span class="token number">10</span><span class="token punctuation">,</span> <span class="token string">'days'</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">calendar</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>      <span class="token comment">// 2018年4月14日</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="多语言支持" tabindex="-1"><a class="header-anchor" href="#多语言支持" aria-hidden="true">#</a> 多语言支持</h2>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'L'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>    <span class="token comment">// 2018-04-04</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'l'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>    <span class="token comment">// 2018-04-04</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'LL'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>   <span class="token comment">// 2018年4月4日</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'ll'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>   <span class="token comment">// 2018年4月4日</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'LLL'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  <span class="token comment">// 2018年4月4日下午1点36分</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'lll'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  <span class="token comment">// 2018年4月4日下午1点36分</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'LLLL'</span><span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// 2018年4月4日星期三下午1点36分</span>
<span class="token function">moment</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">format</span><span class="token punctuation">(</span><span class="token string">'llll'</span><span class="token punctuation">)</span><span class="token punctuation">;</span> <span class="token comment">// 2018年4月4日星期三下午1点36分</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div></div></template>

<script>
export default {
    name: "MonentClock",
    data () {
        return {
            title: "Hello VuePress ~"
        };
    },
    methods: {
        updateClock () {
            var now = moment(),
                second = now.seconds() * 6,
                minute = now.minutes() * 6 + second / 60,
                hour = ((now.hours() % 12) / 12) * 360 + 90 + minute / 12;
			if(document){
				document.getElementById('hour').style.transform = "rotate(" + hour + "deg)";
				document.getElementById('minute').style.transform = "rotate(" + minute + "deg)";
				document.getElementById('second').style.transform = "rotate(" + second + "deg)";
				setTimeout(this.updateClock.bind(this), 1000);
			}
        }
    },
    mounted () {
        this.loadScript("https://cdn.staticfile.org/moment.js/2.24.0/moment.min.js").then(this.updateClock.bind(this));
    }
}
</script>

<style>
.hero-circle {
    width: 180px;
    height: 180px;
    margin: 20px auto;
    position: relative;
    border: 8px solid #fff;
    border-radius: 50%;
    box-shadow: 0 1px 8px rgba(34,34,34,0.3),inset 0 1px 8px rgba(34,34,34,0.3);
    background: #61b2a7;
}

.hero-face {
    width: 100%;
    height: 100%
}

.hero-face:after {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 12px;
    height: 12px;
    margin: -6px 0 0 -6px;
    background: #fff;
    border-radius: 6px;
    content: "";
    display: block
}

.hero-hour {
    width: 0;
    height: 0;
    position: absolute;
    top: 50%;
    left: 50%;
    margin: -4px 0 -4px -25%;
    padding: 4px 0 4px 25%;
    background: #fff;
    -ms-transform-origin: 100% 50%;
    transform-origin: 100% 50%;
    border-radius: 4px 0 0 4px
}

.hero-minute {
    width: 0;
    height: 0;
    position: absolute;
    top: 50%;
    left: 50%;
    margin: -40% -3px 0;
    padding: 40% 3px 0;
    background: #fff;
    -ms-transform-origin: 50% 100%;
    transform-origin: 50% 100%;
    border-radius: 3px 3px 0 0
}

.hero-second {
    width: 0;
    height: 0;
    position: absolute;
    top: 50%;
    left: 50%;
    margin: -40% -1px 0 0;
    padding: 40% 1px 0;
    background: #fff;
    -ms-transform-origin: 50% 100%;
    transform-origin: 50% 100%
}
</style>