export const data = JSON.parse("{\"key\":\"v-4cbb61f8\",\"path\":\"/guide/javascript/date-by-week.html\",\"title\":\"日月周时间段处理\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"日月周时间段处理\",\"slug\":\"日月周时间段处理\",\"link\":\"#日月周时间段处理\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/javascript/date-by-week.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
