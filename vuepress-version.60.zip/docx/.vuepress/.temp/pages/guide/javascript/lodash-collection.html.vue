<template><div><h1 id="lodash-集合-collection" tabindex="-1"><a class="header-anchor" href="#lodash-集合-collection" aria-hidden="true">#</a> Lodash 集合 Collection</h1>
<h2 id="创建" tabindex="-1"><a class="header-anchor" href="#创建" aria-hidden="true">#</a> 创建</h2>
<h3 id="sample-collection" tabindex="-1"><a class="header-anchor" href="#sample-collection" aria-hidden="true">#</a> _.sample(collection)</h3>
<p>从<code v-pre>collection</code>（集合）中获得一个随机元素。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">sample</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 2</span>
</code></pre></div><h3 id="samplesize-collection-n-1" tabindex="-1"><a class="header-anchor" href="#samplesize-collection-n-1" aria-hidden="true">#</a> _.sampleSize(collection, [n = 1])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>
<p>collection (Array|Object): 要取样的集合。</p>
</li>
<li>
<p>[n=1] (number): 取样的元素个数。</p>
</li>
<li>
<p>返回</p>
<ul>
<li>(Array): 返回随机元素。</li>
</ul>
</li>
</ul>
</details>
<p>从<code v-pre>collection</code>中获得<code v-pre>n</code>个随机元素。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">sampleSize</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [3, 1]</span>
 
_<span class="token punctuation">.</span><span class="token function">sampleSize</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [2, 3, 1]</span>
</code></pre></div><h3 id="shuffle-collection" tabindex="-1"><a class="header-anchor" href="#shuffle-collection" aria-hidden="true">#</a> _.shuffle(collection)</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 要打乱的集合。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回打乱的新数组。</li>
</ul>
</details>
<p>创建一个被打乱值的集合。 使用<a href="https://en.wikipedia.org/wiki/Fisher-Yates_shuffle" target="_blank" rel="noopener noreferrer">Fisher-Yates shuffle<ExternalLinkIcon/></a>版本。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">shuffle</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [4, 1, 3, 2]</span>
</code></pre></div><h3 id="countby-collection-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#countby-collection-iteratee-identity" aria-hidden="true">#</a> _.countBy(collection, [iteratee = _.identity])</h3>
<p>创建一个组成对象；
key（键）是经过 iteratee（迭代函数）执行处理<code v-pre>collection</code>中每个元素后返回的结果；
每个key（键）对应的<code v-pre>value</code>值：是<code v-pre>iteratee(value)</code>（迭代函数）返回该key（键）的迭代次数。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">countBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">6.1</span><span class="token punctuation">,</span> <span class="token number">4.2</span><span class="token punctuation">,</span> <span class="token number">6.3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> Math<span class="token punctuation">.</span>floor<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { '4': 1, '6': 2 }</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">countBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'one'</span><span class="token punctuation">,</span> <span class="token string">'two'</span><span class="token punctuation">,</span> <span class="token string">'three'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'length'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { '3': 2, '5': 1 }</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="sortby-collection-iteratees-identity" tabindex="-1"><a class="header-anchor" href="#sortby-collection-iteratees-identity" aria-hidden="true">#</a> _.sortBy(collection, [iteratees = [ _.identity ] ])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 用来迭代的集合。</li>
<li>[iteratees=[_.identity]] (...(Array|Array[]|Function|Function[]|Object|Object[]|string|string[])): 这个函数决定排序。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回排序后的数组。</li>
</ul>
</details>
<p>创建一个元素数组。
以<code v-pre>iteratee(value)</code>处理的结果升序排序。 这个方法执行稳定排序，也就是说相同元素会保持原始排序。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>   <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">48</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">36</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>   <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">40</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">34</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">sortBy</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token parameter">item</span> <span class="token operator">=></span> item<span class="token punctuation">.</span>user<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for [['barney', 36], ['barney', 34], ['fred', 48], ['fred', 40]]</span>
 
_<span class="token punctuation">.</span><span class="token function">sortBy</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'user'</span><span class="token punctuation">,</span> <span class="token string">'age'</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for [['barney', 34], ['barney', 36], ['fred', 40], ['fred', 48]]</span>
 
_<span class="token punctuation">.</span><span class="token function">sortBy</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'user'</span><span class="token punctuation">,</span> <span class="token parameter">item</span> <span class="token operator">=></span> Math<span class="token punctuation">.</span><span class="token function">floor</span><span class="token punctuation">(</span>item<span class="token punctuation">.</span>age <span class="token operator">/</span> <span class="token number">10</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for [['barney', 36], ['barney', 34], ['fred', 48], ['fred', 40]]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="orderby-collection-iteratees-identity-orders" tabindex="-1"><a class="header-anchor" href="#orderby-collection-iteratees-identity-orders" aria-hidden="true">#</a> _.orderBy(collection, [iteratees=[ _.identity ] ], [ orders ])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>
<p>collection (Array|Object): 用来迭代的集合。</p>
</li>
<li>
<p>[iteratees=[_.identity]] (Array[]|Function[]|Object[]|string[]): 排序的迭代函数。</p>
</li>
<li>
<p>[orders] (string[]): iteratees迭代函数的排序顺序。</p>
</li>
<li>
<p>返回</p>
<ul>
<li>(Array): 排序排序后的新数组。</li>
</ul>
</li>
</ul>
</details>
<p>此方法类似于<code v-pre>_.sortBy</code>，除了它允许指定<code v-pre>iteratee</code>（迭代函数）结果如何排序。 如果没指定orders，以默认值&quot;asc&quot; 升序；否则为&quot;desc&quot; 降序排序对应值。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>   <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">48</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">34</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>   <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">40</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">36</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
<span class="token comment">// 以 `user` 升序排序 再  `age` 以降序排序。</span>
_<span class="token punctuation">.</span><span class="token function">orderBy</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'user'</span><span class="token punctuation">,</span> <span class="token string">'age'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'asc'</span><span class="token punctuation">,</span> <span class="token string">'desc'</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [{"user":"barney","age":36},{"user":"barney","age":34},{"user":"fred","age":48},{"user":"fred","age":40}]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="groupby-collection-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#groupby-collection-iteratee-identity" aria-hidden="true">#</a> _.groupBy(collection, [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>
<p>collection (Array|Object): 一个用来迭代的集合。</p>
</li>
<li>
<p>[iteratee=_.identity] (Array|Function|Object|string): 这个迭代函数用来转换key。</p>
</li>
<li>
<p>返回</p>
<ul>
<li>(Object): 返回一个组成聚合的对象。</li>
</ul>
</li>
</ul>
</details>
<p>创建一个对象;
<code v-pre>key</code>是<code v-pre>iteratee(value)</code>遍历<code v-pre>collectio</code>中的每个元素返回的结果。 分组值的顺序是由他们出现在<code v-pre>collection</code>中的顺序确定的。每个键对应的值负责生成<code v-pre>key</code>的元素组成的数组。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">groupBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">6.1</span><span class="token punctuation">,</span> <span class="token number">4.2</span><span class="token punctuation">,</span> <span class="token number">6.3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> Math<span class="token punctuation">.</span>floor<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { '4': [4.2], '6': [6.1, 6.3] }</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">groupBy</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'one'</span><span class="token punctuation">,</span> <span class="token string">'two'</span><span class="token punctuation">,</span> <span class="token string">'three'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'length'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { '3': ['one', 'two'], '5': ['three'] }</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="keyby-collection-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#keyby-collection-iteratee-identity" aria-hidden="true">#</a> _.keyBy(collection, [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 用来迭代的集合。</li>
<li>[iteratee=_.identity] (Array|Function|Object|string): 这个迭代函数用来转换key。</li>
</ul>
<p>返回</p>
<ul>
<li>(Object): 返回一个组成聚合的对象。</li>
</ul>
</details>
<p>创建一个对象; 组成<code v-pre>key</code>是<code v-pre>collection</code>中的每个元素经过<code v-pre>iteratee(value)</code>处理后返回的结果。 每个<code v-pre>key</code>对应的值是生成<code v-pre>key</code>的最后一个元素。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'dir'</span><span class="token operator">:</span> <span class="token string">'left'</span><span class="token punctuation">,</span> <span class="token string-property property">'code'</span><span class="token operator">:</span> <span class="token number">97</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'dir'</span><span class="token operator">:</span> <span class="token string">'right'</span><span class="token punctuation">,</span> <span class="token string-property property">'code'</span><span class="token operator">:</span> <span class="token number">100</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">keyBy</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">o</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> String<span class="token punctuation">.</span><span class="token function">fromCharCode</span><span class="token punctuation">(</span>o<span class="token punctuation">.</span>code<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { 'a': { 'dir': 'left', 'code': 97 }, 'd': { 'dir': 'right', 'code': 100 } }</span>
 
_<span class="token punctuation">.</span><span class="token function">keyBy</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token string">'dir'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { 'left': { 'dir': 'left', 'code': 97 }, 'right': { 'dir': 'right', 'code': 100 } }</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="遍历" tabindex="-1"><a class="header-anchor" href="#遍历" aria-hidden="true">#</a> 遍历</h2>
<h3 id="foreach-collection-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#foreach-collection-iteratee-identity" aria-hidden="true">#</a> _.forEach(collection, [iteratee = _.identity])</h3>
<blockquote>
<p>别名 _.each</p>
</blockquote>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 一个用来迭代的集合。</li>
<li>[iteratee=_.identity] (Function): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(*): 返回集合 collection。</li>
</ul>
</details>
<p>调用<code v-pre>iteratee</code>遍历<code v-pre>collection</code>(集合)中的每个元素，<code v-pre>iteratee</code>调用3个参数： <code v-pre>(value, index|key, collection)</code>。 如果迭代函数<code v-pre>iteratee</code>显式的返回false，迭代会提前退出。</p>
<div class="tip-block warning"><p class="title">注意:</p><p>与其他&quot;集合&quot;方法一样，类似于数组，对象的 &quot;length&quot; 属性也会被遍历。
想避免这种情况，可以用<a href="https://www.lodashjs.com/docs/lodash.forIn" target="_blank" rel="noopener noreferrer">_ .forIn<ExternalLinkIcon/></a>或者<a href="https://www.lodashjs.com/docs/lodash.forOwn" target="_blank" rel="noopener noreferrer">_ .forOwn<ExternalLinkIcon/></a>代替。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token function">_</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">forEach</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">value</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>value<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 顺序输出1、2.</span>
 
_<span class="token punctuation">.</span><span class="token function">forEach</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'a'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'b'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">value<span class="token punctuation">,</span> key</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>key<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 随机输出 a、b，不保证顺序</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="foreachright-collection-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#foreachright-collection-iteratee-identity" aria-hidden="true">#</a> _.forEachRight(collection, [iteratee = _.identity])</h3>
<blockquote>
<p>别名：_.eachRight</p>
</blockquote>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 一个用来迭代的集合。</li>
<li>[iteratee=_.identity] (Function): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(*): 返回集合 collection。</li>
</ul>
</details>
<p>这个方法类似<code v-pre>_.forEach</code>，不同之处在于<code v-pre>_.forEachRight</code>是从右到左遍历集合中每一个元素的。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">forEachRight</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">value</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  console<span class="token punctuation">.</span><span class="token function">log</span><span class="token punctuation">(</span>value<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 顺序输出1、2.</span>
</code></pre></div><h3 id="map-collection-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#map-collection-iteratee-identity" aria-hidden="true">#</a> _.map(collection, [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 用来迭代的集合。</li>
<li>[iteratee=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回新的映射后数组。</li>
</ul>
</details>
<p>创建一个数组，<code v-pre>value</code> 是<code v-pre>iteratee(value, index|key, collection)</code>遍历<code v-pre>collection</code>中的每个元素后返回的结果。</p>
<div class="tip-block warning"><p class="title">警告</p><p>lodash 中有许多方法是防止作为其他方法的迭代函数。
例如：
_.every, _.filter, _.map, _.mapValues, _.reject和 _.some</p>
<p>注：即不能作为iteratee参数传递给其他方法</p>
<p>受保护的方法有：
ary, chunk, curry, curryRight, drop, dropRight, every,fill, invert, parseInt, random, range, rangeRight, repeat,sampleSize, slice, some, sortBy, split, take, takeRight,template, trim, trimEnd, trimStart, and words</p>
<p>注：即这些方法不能使用 _.every, _.filter, _.map, _.mapValues, _.reject, 和 _.some作为iteratee迭代函数参数</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">function</span> <span class="token function">square</span><span class="token punctuation">(</span><span class="token parameter">n</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> n <span class="token operator">*</span> n<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
 
_<span class="token punctuation">.</span><span class="token function">map</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">8</span><span class="token punctuation">]</span><span class="token punctuation">,</span> square<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [16, 64]</span>
 
_<span class="token punctuation">.</span><span class="token function">map</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'a'</span><span class="token operator">:</span> <span class="token number">4</span><span class="token punctuation">,</span> <span class="token string-property property">'b'</span><span class="token operator">:</span> <span class="token number">8</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> square<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [16, 64] (iteration order is not guaranteed)</span>
 
<span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">map</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'user'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => ['barney', 'fred']</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="检索" tabindex="-1"><a class="header-anchor" href="#检索" aria-hidden="true">#</a> 检索</h2>
<h3 id="includes-collection-value-fromindex-0" tabindex="-1"><a class="header-anchor" href="#includes-collection-value-fromindex-0" aria-hidden="true">#</a> _.includes(collection, value, [fromIndex = 0])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object|string): 要检索的集合。</li>
<li>value (*): 要检索的值。</li>
<li>[fromIndex=0] (number): 要检索的 索引位置。</li>
</ul>
<p>返回</p>
<ul>
<li>(boolean): 如果找到 value 返回 true， 否则返回 false。</li>
</ul>
</details>
<p>检查<code v-pre>value</code>是否在<code v-pre>collection</code>中。如果<code v-pre>collection</code>是一个字符串，那么检查<code v-pre>value</code>(子字符串）是否在字符串中，否则使用<a href="http://ecma-international.org/ecma-262/6.0/#sec-samevaluezero" target="_blank" rel="noopener noreferrer">SameValueZero<ExternalLinkIcon/></a>做等值比较。 如果指定<code v-pre>fromIndex</code>是负数，那么从<code v-pre>collection</code>的结尾开始检索。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">includes</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
 
_<span class="token punctuation">.</span><span class="token function">includes</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => false</span>
 
_<span class="token punctuation">.</span><span class="token function">includes</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">40</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token string">'fred'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
 
_<span class="token punctuation">.</span><span class="token function">includes</span><span class="token punctuation">(</span><span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string">'eb'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="every-collection-predicate-identity" tabindex="-1"><a class="header-anchor" href="#every-collection-predicate-identity" aria-hidden="true">#</a> _.every(collection, [predicate = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 一个用来迭代的集合。</li>
<li>[predicate=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(boolean): 如果所有元素经 predicate（断言函数） 检查后都都返回真值，那么就返回true，否则返回 false 。</li>
</ul>
</details>
<p>通过<code v-pre>predicate</code>（断言函数）检查<code v-pre>collection</code>（集合）中的所有元素是否都返回true。一旦<code v-pre>predicate</code>（断言函数）返回false，迭代就马上停止。</p>
<p><code v-pre>predicate(value, index | key, collection)</code>。</p>
<div class="tip-block warning"><p class="title">注意:</p><p>这个方法对于对于<a href="https://en.wikipedia.org/wiki/Empty_set" target="_blank" rel="noopener noreferrer">空集合<ExternalLinkIcon/></a>返回 true，因为空集合的<a href="https://en.wikipedia.org/wiki/Vacuous_truth" target="_blank" rel="noopener noreferrer">任何元素都是true<ExternalLinkIcon/></a> 。</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">every</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token boolean">true</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token keyword">null</span><span class="token punctuation">,</span> <span class="token string">'yes'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> Boolean<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => false</span>
 
<span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">36</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>   <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">40</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">every</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => false</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">every</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">every</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => false</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="some-collection-predicate-identity" tabindex="-1"><a class="header-anchor" href="#some-collection-predicate-identity" aria-hidden="true">#</a> _.some(collection, [predicate = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 用来迭代的集合。</li>
<li>[predicate=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(boolean): 如果任意元素经 predicate 检查都为 truthy（真值），返回 true ，否则返回 false 。</li>
</ul>
</details>
<p>通过<code v-pre>predicate</code>（断言函数）检查<code v-pre>collection</code>（集合）中的元素是否存在<strong>任意</strong> truthy（真值）的元素，一旦<code v-pre>predicate</code>（断言函数）返回 truthy（真值），遍历就停止。</p>
<p><code v-pre>predicate(value, index | key, collection)</code>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">some</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token keyword">null</span><span class="token punctuation">,</span> <span class="token number">0</span><span class="token punctuation">,</span> <span class="token string">'yes'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">,</span> Boolean<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
 
<span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>   <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">some</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => false</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">some</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">some</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="find-collection-predicate-identity-fromindex-0" tabindex="-1"><a class="header-anchor" href="#find-collection-predicate-identity-fromindex-0" aria-hidden="true">#</a> _.find(collection, [predicate = _.identity], [fromIndex = 0])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 一个用来迭代的集合。</li>
<li>[predicate = _.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
<li>[fromIndex = 0] (number): 开始搜索的索引位置。</li>
</ul>
<p>返回</p>
<ul>
<li>(*): 返回匹配元素，否则返回 undefined。</li>
</ul>
</details>
<p>遍历<code v-pre>collection</code>（集合）元素，返回<code v-pre>predicate</code>（断言函数）第一个返回true的第一个元素。</p>
<p><code v-pre>predicate(value, index | key, collection)</code></p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span>  <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">36</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>    <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">40</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span>  <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">find</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token parameter">item</span> <span class="token operator">=></span> item<span class="token punctuation">.</span>age <span class="token operator">&lt;</span> <span class="token number">40</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => object for 'barney'</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">find</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => object for 'pebbles'</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">find</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => object for 'fred'</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">find</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => object for 'barney'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="findlast-collection-predicate-identity-fromindex-collection-length-1" tabindex="-1"><a class="header-anchor" href="#findlast-collection-predicate-identity-fromindex-collection-length-1" aria-hidden="true">#</a> _.findLast(collection, [predicate = _.identity], [fromIndex = collection.length - 1])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 一个用来迭代的集合。</li>
<li>[predicate=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
<li>[fromIndex=collection.length-1] (number): 开始搜索的索引位置。</li>
</ul>
<p>返回</p>
<ul>
<li>(*): 返回匹配元素，否则返回 undefined。</li>
</ul>
</details>
<p>这个方法类似<code v-pre>_.find</code>，不同之处在于，<code v-pre>_.findLast</code>是从右至左遍历<code v-pre>collection</code>元素的。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">findLast</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">4</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token parameter">n</span> <span class="token operator">=></span> n <span class="token operator">%</span> <span class="token number">2</span> <span class="token operator">==</span> <span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 3</span>
</code></pre></div><h2 id="过滤" tabindex="-1"><a class="header-anchor" href="#过滤" aria-hidden="true">#</a> 过滤</h2>
<h3 id="filter-collection-predicate-identity" tabindex="-1"><a class="header-anchor" href="#filter-collection-predicate-identity" aria-hidden="true">#</a> _.filter(collection, [predicate = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 一个用来迭代的集合。</li>
<li>[predicate=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回一个新的过滤后的数组。</li>
</ul>
</details>
<p>遍历<code v-pre>collection</code>（集合）元素，返回<code v-pre>predicate</code>（断言函数）返回true的所有元素的数组。</p>
<p><code v-pre>predicate(value, index | key, collection)</code></p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">36</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>   <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">40</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">filter</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">o</span><span class="token punctuation">)</span> <span class="token punctuation">{</span> <span class="token keyword">return</span> <span class="token operator">!</span>o<span class="token punctuation">.</span>active<span class="token punctuation">;</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['fred']</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">filter</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">36</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney']</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">filter</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['fred']</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">filter</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney']</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="reject-collection-predicate-identity" tabindex="-1"><a class="header-anchor" href="#reject-collection-predicate-identity" aria-hidden="true">#</a> _.reject(collection, [predicate = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 用来迭代的集合。</li>
<li>[predicate=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回过滤后的新数组</li>
</ul>
</details>
<p><code v-pre>_.filter</code>的反向方法;
此方法通过<code v-pre>predicate</code>（断言函数）不返回 <code v-pre>truthy</code>（真值）的<code v-pre>collection</code>元素（注释：非真）。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">36</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>   <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">40</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">reject</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token parameter">item</span> <span class="token operator">=></span> item<span class="token punctuation">.</span>active<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['fred']</span>
 
<span class="token comment">// `_.matches` 迭代简写</span>
_<span class="token punctuation">.</span><span class="token function">reject</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">40</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney']</span>
 
<span class="token comment">// `_.matchesProperty` 迭代简写</span>
_<span class="token punctuation">.</span><span class="token function">reject</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['fred']</span>
 
<span class="token comment">// `_.property` 迭代简写</span>
_<span class="token punctuation">.</span><span class="token function">reject</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for ['barney']</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="partition-collection-predicate-identity" tabindex="-1"><a class="header-anchor" href="#partition-collection-predicate-identity" aria-hidden="true">#</a> _.partition(collection, [predicate = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 用来迭代的集合。</li>
<li>[predicate=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回元素分组后的数组。</li>
</ul>
</details>
<p>创建一个分成两组的元素数组，第一组包含<code v-pre>predicate(value)</code>（断言函数）返回为 <code v-pre>truthy</code>（真值）的元素，第二组包含<code v-pre>predicate</code>返回为<code v-pre>falsey</code>的元素。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> users <span class="token operator">=</span> <span class="token punctuation">[</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span><span class="token punctuation">,</span>  <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">36</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span><span class="token punctuation">,</span>    <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">40</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">true</span> <span class="token punctuation">}</span><span class="token punctuation">,</span>
  <span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span><span class="token punctuation">,</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span>  <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span>
<span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">partition</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token parameter">item</span> <span class="token operator">=></span> item<span class="token punctuation">.</span>active<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for [['fred'], ['barney', 'pebbles']]</span>
 
<span class="token comment">// The `_.matches` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">partition</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'age'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'active'</span><span class="token operator">:</span> <span class="token boolean">false</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for [['pebbles'], ['barney', 'fred']]</span>
 
<span class="token comment">// The `_.matchesProperty` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">partition</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token string">'active'</span><span class="token punctuation">,</span> <span class="token boolean">false</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for [['barney', 'pebbles'], ['fred']]</span>
 
<span class="token comment">// The `_.property` iteratee shorthand.</span>
_<span class="token punctuation">.</span><span class="token function">partition</span><span class="token punctuation">(</span>users<span class="token punctuation">,</span> <span class="token string">'active'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => objects for [['fred'], ['barney', 'pebbles']]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="转换" tabindex="-1"><a class="header-anchor" href="#转换" aria-hidden="true">#</a> 转换</h2>
<h3 id="flatmap-collection-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#flatmap-collection-iteratee-identity" aria-hidden="true">#</a> _.flatMap(collection, [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 一个用来迭代遍历的集合。</li>
<li>[iteratee=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回新扁平化数组。</li>
</ul>
</details>
<p>创建一个<strong>扁平化</strong>（同阶数组）的数组，这个数组的值来自<code v-pre>collection</code>中每一个值经过<code v-pre>iteratee(value, index | key, collection)</code>处理后返回的结果，并且扁平化合并。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">function</span> <span class="token function">duplicate</span><span class="token punctuation">(</span><span class="token parameter">n</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> <span class="token punctuation">[</span>n<span class="token punctuation">,</span> n<span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
 
_<span class="token punctuation">.</span><span class="token function">flatMap</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> duplicate<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 1, 2, 2]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="flatmapdeep-collection-iteratee-identity" tabindex="-1"><a class="header-anchor" href="#flatmapdeep-collection-iteratee-identity" aria-hidden="true">#</a> _.flatMapDeep(collection, [iteratee = _.identity])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 一个用来迭代的集合。</li>
<li>[iteratee=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回新扁平化数组。</li>
</ul>
</details>
<p>这个方法类似<code v-pre>_.flatMap</code>不同之处在于，<code v-pre>_.flatMapDeep</code>会继续扁平化递归映射的结果。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">function</span> <span class="token function">duplicate</span><span class="token punctuation">(</span><span class="token parameter">n</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> <span class="token punctuation">[</span><span class="token punctuation">[</span><span class="token punctuation">[</span>n<span class="token punctuation">,</span> n<span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
 
_<span class="token punctuation">.</span><span class="token function">flatMapDeep</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> duplicate<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [1, 1, 2, 2]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="flatmapdepth-collection-iteratee-identity-depth-1" tabindex="-1"><a class="header-anchor" href="#flatmapdepth-collection-iteratee-identity-depth-1" aria-hidden="true">#</a> _.flatMapDepth(collection, [iteratee = _.identity], [depth = 1])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 一个用来迭代的集合。</li>
<li>[iteratee=_.identity] (Array|Function|Object|string): 每次迭代调用的函数。</li>
<li>[depth=1] (number): 最大递归深度。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回新扁平化数组。</li>
</ul>
</details>
<p>该方法类似<code v-pre>_.flatMap</code>，不同之处在于<code v-pre>_.flatMapDepth</code>会根据指定的 <code v-pre>depth</code>（递归深度）继续扁平化递归映射结果。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">function</span> <span class="token function">duplicate</span><span class="token punctuation">(</span><span class="token parameter">n</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> <span class="token punctuation">[</span><span class="token punctuation">[</span><span class="token punctuation">[</span>n<span class="token punctuation">,</span> n<span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
 
_<span class="token punctuation">.</span><span class="token function">flatMapDepth</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> duplicate<span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [[1, 1], [2, 2]]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="其它" tabindex="-1"><a class="header-anchor" href="#其它" aria-hidden="true">#</a> 其它</h2>
<h3 id="invokemap-collection-path-args" tabindex="-1"><a class="header-anchor" href="#invokemap-collection-path-args" aria-hidden="true">#</a> _.invokeMap(collection, path, [args])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 用来迭代的集合。</li>
<li>path (Array|Function|string): 用来调用方法的路径 或 者每次迭代调用的函数。</li>
<li>[args] (...*): 调用每个方法的参数。</li>
</ul>
<p>返回</p>
<ul>
<li>(Array): 返回的结果数组。</li>
</ul>
</details>
<p>调用<code v-pre>path</code>（路径）上的方法处理<code v-pre>collection</code>中的每个元素，返回一个数组, 包含每次调用方法得到的结果。
任何附加的参数提供给每个被调用的方法。如果<code v-pre>methodName</code>（方法名）是一个函数，每次调用函数时，内部的<code v-pre>this</code>指向集合中的每个元素。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">invokeMap</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token punctuation">[</span><span class="token number">5</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">7</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">3</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token string">'sort'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [[1, 5, 7], [1, 2, 3]]</span>
 
_<span class="token punctuation">.</span><span class="token function">invokeMap</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">123</span><span class="token punctuation">,</span> <span class="token number">456</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token class-name">String</span><span class="token punctuation">.</span>prototype<span class="token punctuation">.</span>split<span class="token punctuation">,</span> <span class="token string">''</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [['1', '2', '3'], ['4', '5', '6']]</span>
</code></pre></div><h3 id="reduce-collection-iteratee-identity-accumulator" tabindex="-1"><a class="header-anchor" href="#reduce-collection-iteratee-identity-accumulator" aria-hidden="true">#</a> _.reduce(collection, [iteratee = _.identity], [ accumulator ])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 用来迭代的集合。</li>
<li>[iteratee=_.identity] (Function): 每次迭代调用的函数。</li>
<li>[accumulator] (*): 初始值。</li>
</ul>
<p>返回</p>
<ul>
<li>(*): 返回累加后的值。</li>
</ul>
</details>
<p>压缩<code v-pre>collection</code>为一个值，通过<code v-pre>iteratee(accumulator, value, index|key, collection)</code>遍历<code v-pre>collection</code>中的每个元素，每次返回的值会作为下一次迭代使用(作为<code v-pre>iteratee</code>的第一个参数使用)。 如果没有提供<code v-pre>accumulator</code>，则<code v-pre>collection</code>中的第一个元素作为初始值。(<code v-pre>accumulator</code>参数在第一次迭代的时候作为<code v-pre>iteratee</code>第一个参数使用。)</p>
<div class="tip-block warning"><p class="title">警告</p><p>lodash 中有许多方法是防止作为其他方法的迭代函数，例如：
_.reduce, _.reduceRight 和 _.transform。
注：即不能作为iteratee参数传递给其他方法</p>
<p>受保护的方法有：
<code v-pre>assign</code>, <code v-pre>defaults</code>, <code v-pre>defaultsDeep</code>, <code v-pre>includes</code>, <code v-pre>merge</code>, <code v-pre>orderBy</code>和 <code v-pre>sortBy</code>
注：即这些方法不能使用 <code v-pre>_.reduce</code>, <code v-pre>_.reduceRight</code> 和 <code v-pre>_.transform</code>作为<code v-pre>iteratee</code>迭代函数参数</p>
</div>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">reduce</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">sum<span class="token punctuation">,</span> n</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> sum <span class="token operator">+</span> n<span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token number">0</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 3</span>
 
_<span class="token punctuation">.</span><span class="token function">reduce</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'a'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'b'</span><span class="token operator">:</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token string-property property">'c'</span><span class="token operator">:</span> <span class="token number">1</span> <span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">result<span class="token punctuation">,</span> value<span class="token punctuation">,</span> key</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token punctuation">(</span>result<span class="token punctuation">[</span>value<span class="token punctuation">]</span> <span class="token operator">||</span> <span class="token punctuation">(</span>result<span class="token punctuation">[</span>value<span class="token punctuation">]</span> <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">push</span><span class="token punctuation">(</span>key<span class="token punctuation">)</span><span class="token punctuation">;</span>
  <span class="token keyword">return</span> result<span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">{</span><span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => { '1': ['a', 'c'], '2': ['b'] } (无法保证遍历的顺序)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="reduceright-collection-iteratee-identity-accumulator" tabindex="-1"><a class="header-anchor" href="#reduceright-collection-iteratee-identity-accumulator" aria-hidden="true">#</a> _.reduceRight(collection, [iteratee = _.identity], [accumulator])</h3>
<details class="tip-block details"><summary>参数</summary><ul>
<li>collection (Array|Object): 用来迭代的集合。</li>
<li>[iteratee=_.identity] (Function): 每次迭代调用的函数。</li>
<li>[accumulator] (*): 初始值。</li>
</ul>
<p>返回</p>
<ul>
<li>(*): 返回累加后的值。</li>
</ul>
</details>
<p>这个方法类似<code v-pre>_.reduce</code>，除了它是从右到左遍历<code v-pre>collection</code>中的元素的。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token keyword">var</span> array <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token punctuation">[</span><span class="token number">0</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token number">4</span><span class="token punctuation">,</span> <span class="token number">5</span><span class="token punctuation">]</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
 
_<span class="token punctuation">.</span><span class="token function">reduceRight</span><span class="token punctuation">(</span>array<span class="token punctuation">,</span> <span class="token keyword">function</span><span class="token punctuation">(</span><span class="token parameter">flattened<span class="token punctuation">,</span> other</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
  <span class="token keyword">return</span> flattened<span class="token punctuation">.</span><span class="token function">concat</span><span class="token punctuation">(</span>other<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token punctuation">[</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [4, 5, 2, 3, 0, 1]</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="size-collection" tabindex="-1"><a class="header-anchor" href="#size-collection" aria-hidden="true">#</a> _.size(collection)</h3>
<p>返回<code v-pre>collection</code>的长度，如果集合是类数组或字符串，返回其<code v-pre>length</code>；如果集合是对象，返回其可枚举属性的个数。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">size</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token number">1</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 3</span>
 
_<span class="token punctuation">.</span><span class="token function">size</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'a'</span><span class="token operator">:</span> <span class="token number">1</span><span class="token punctuation">,</span> <span class="token string-property property">'b'</span><span class="token operator">:</span> <span class="token number">2</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 2</span>
 
_<span class="token punctuation">.</span><span class="token function">size</span><span class="token punctuation">(</span><span class="token string">'pebbles'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 7</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr/>
</div></template>


