<template><div><h1 id="lodash-字符串处理-string" tabindex="-1"><a class="header-anchor" href="#lodash-字符串处理-string" aria-hidden="true">#</a> Lodash 字符串处理 String</h1>
<h2 id="转换" tabindex="-1"><a class="header-anchor" href="#转换" aria-hidden="true">#</a> 转换</h2>
<h3 id="tolower-string" tabindex="-1"><a class="header-anchor" href="#tolower-string" aria-hidden="true">#</a> _.toLower([string=''])</h3>
<p>转换整个string字符串的字符为小写，类似<a href="https://mdn.io/toLowerCase" target="_blank" rel="noopener noreferrer">String#toLowerCase<ExternalLinkIcon/></a>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">toLower</span><span class="token punctuation">(</span><span class="token string">'--Foo-Bar--'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '--foo-bar--'</span>
 
_<span class="token punctuation">.</span><span class="token function">toLower</span><span class="token punctuation">(</span><span class="token string">'fooBar'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'foobar'</span>
 
_<span class="token punctuation">.</span><span class="token function">toLower</span><span class="token punctuation">(</span><span class="token string">'__FOO_BAR__'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '__foo_bar__'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="toupper-string" tabindex="-1"><a class="header-anchor" href="#toupper-string" aria-hidden="true">#</a> _.toUpper([string=''])</h3>
<p>转换整个string字符串的字符为大写，类似<a href="https://mdn.io/toUpperCase" target="_blank" rel="noopener noreferrer">String#toUpperCase<ExternalLinkIcon/></a>。</p>
<h3 id="lowercase-string" tabindex="-1"><a class="header-anchor" href="#lowercase-string" aria-hidden="true">#</a> _.lowerCase([string=''])</h3>
<p>转换字符串string以空格分开单词，并转换为小写。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">lowerCase</span><span class="token punctuation">(</span><span class="token string">'--Foo-Bar--'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'foo bar'</span>
 
_<span class="token punctuation">.</span><span class="token function">lowerCase</span><span class="token punctuation">(</span><span class="token string">'fooBar'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'foo bar'</span>
 
_<span class="token punctuation">.</span><span class="token function">lowerCase</span><span class="token punctuation">(</span><span class="token string">'__FOO_BAR__'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'foo bar'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="lowerfirst-string" tabindex="-1"><a class="header-anchor" href="#lowerfirst-string" aria-hidden="true">#</a> _.lowerFirst([string=''])</h3>
<p>转换字符串string的首字母为小写, 其余不变。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">lowerFirst</span><span class="token punctuation">(</span><span class="token string">'Fred'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'fred'</span>
 
_<span class="token punctuation">.</span><span class="token function">lowerFirst</span><span class="token punctuation">(</span><span class="token string">'FRED'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'fRED'</span>
</code></pre></div><h3 id="uppercase-string" tabindex="-1"><a class="header-anchor" href="#uppercase-string" aria-hidden="true">#</a> _.upperCase([string=''])</h3>
<p>转换字符串string为 空格 分隔的大写单词。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">upperCase</span><span class="token punctuation">(</span><span class="token string">'--foo-bar'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'FOO BAR'</span>
 
_<span class="token punctuation">.</span><span class="token function">upperCase</span><span class="token punctuation">(</span><span class="token string">'fooBar'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'FOO BAR'</span>
 
_<span class="token punctuation">.</span><span class="token function">upperCase</span><span class="token punctuation">(</span><span class="token string">'__foo_bar__'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'FOO BAR'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="upperfirst-string" tabindex="-1"><a class="header-anchor" href="#upperfirst-string" aria-hidden="true">#</a> _.upperFirst([string=''])</h3>
<p>转换字符串string的首字母为大写，其余不变。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">upperFirst</span><span class="token punctuation">(</span><span class="token string">'fred'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'Fred'</span>
 
_<span class="token punctuation">.</span><span class="token function">upperFirst</span><span class="token punctuation">(</span><span class="token string">'FRED'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'FRED'</span>
</code></pre></div><h3 id="capitalize-string" tabindex="-1"><a class="header-anchor" href="#capitalize-string" aria-hidden="true">#</a> _.capitalize([string=''])</h3>
<p>字符串首字符大写，其余小写</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">capitalize</span><span class="token punctuation">(</span><span class="token string">'FRED'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'Fred'</span>
</code></pre></div><h3 id="camelcase-string" tabindex="-1"><a class="header-anchor" href="#camelcase-string" aria-hidden="true">#</a> _.camelCase([string=''])</h3>
<p>转换字符串string为驼峰写法。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">camelCase</span><span class="token punctuation">(</span><span class="token string">'Foo Bar'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'fooBar'</span>
 
_<span class="token punctuation">.</span><span class="token function">camelCase</span><span class="token punctuation">(</span><span class="token string">'--foo-bar--'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'fooBar'</span>
 
_<span class="token punctuation">.</span><span class="token function">camelCase</span><span class="token punctuation">(</span><span class="token string">'__FOO_BAR__'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'fooBar'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="kebabcase-string" tabindex="-1"><a class="header-anchor" href="#kebabcase-string" aria-hidden="true">#</a> _.kebabCase([string=''])</h3>
<p>转换字符串string为<a href="https://en.wikipedia.org/wiki/Letter_case#Special_case_styles" target="_blank" rel="noopener noreferrer">kebab case<ExternalLinkIcon/></a>.</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">kebabCase</span><span class="token punctuation">(</span><span class="token string">'Foo Bar'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'foo-bar'</span>
 
_<span class="token punctuation">.</span><span class="token function">kebabCase</span><span class="token punctuation">(</span><span class="token string">'fooBar'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'foo-bar'</span>
 
_<span class="token punctuation">.</span><span class="token function">kebabCase</span><span class="token punctuation">(</span><span class="token string">'__FOO_BAR__'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'foo-bar'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="snakecase-string" tabindex="-1"><a class="header-anchor" href="#snakecase-string" aria-hidden="true">#</a> _.snakeCase([string=''])</h3>
<p>转换字符串string为<a href="https://en.wikipedia.org/wiki/Snake_case" target="_blank" rel="noopener noreferrer">snake case<ExternalLinkIcon/></a>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">snakeCase</span><span class="token punctuation">(</span><span class="token string">'Foo Bar'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'foo_bar'</span>
 
_<span class="token punctuation">.</span><span class="token function">snakeCase</span><span class="token punctuation">(</span><span class="token string">'fooBar'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'foo_bar'</span>
 
_<span class="token punctuation">.</span><span class="token function">snakeCase</span><span class="token punctuation">(</span><span class="token string">'--FOO-BAR--'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'foo_bar'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="startcase-string" tabindex="-1"><a class="header-anchor" href="#startcase-string" aria-hidden="true">#</a> _.startCase([string=''])</h3>
<p>转换string字符串为<a href="https://en.wikipedia.org/wiki/Letter_case#Stylistic_or_specialised_usage" target="_blank" rel="noopener noreferrer">start case<ExternalLinkIcon/></a>。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">startCase</span><span class="token punctuation">(</span><span class="token string">'--foo-bar--'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'Foo Bar'</span>
 
_<span class="token punctuation">.</span><span class="token function">startCase</span><span class="token punctuation">(</span><span class="token string">'fooBar'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'Foo Bar'</span>
 
_<span class="token punctuation">.</span><span class="token function">startCase</span><span class="token punctuation">(</span><span class="token string">'__FOO_BAR__'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'FOO BAR'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="转义" tabindex="-1"><a class="header-anchor" href="#转义" aria-hidden="true">#</a> 转义</h2>
<h3 id="escape-string" tabindex="-1"><a class="header-anchor" href="#escape-string" aria-hidden="true">#</a> _.escape([string=''])</h3>
<p>转义string中的 &quot;&amp;&quot;, &quot;&lt;&quot;, &quot;&gt;&quot;, '&quot;', &quot;'&quot;, 和 &quot;`&quot; 字符为HTML实体字符。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>不会转义其他字符。如果需要，可以使用第三方库，例如he。</p>
</div>
<p>虽然 &quot;&gt;&quot; 是对称转义的，字符如 &quot;&gt;&quot; 和 &quot;/&quot; 没有特殊的意义，所以不需要在 HTML 转义。 除非它们是标签的一部分，或者是不带引号的属性值。</p>
<p>当解析 HTML 时，总应该在<a href="http://wonko.com/post/html-escaping" target="_blank" rel="noopener noreferrer">属性值上使用引号<ExternalLinkIcon/></a> 以减少 XSS 的可能性。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">escape</span><span class="token punctuation">(</span><span class="token string">'fred, barney, &amp; pebbles'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'fred, barney, &amp; pebbles'</span>
</code></pre></div><h3 id="escaperegexp-string" tabindex="-1"><a class="header-anchor" href="#escaperegexp-string" aria-hidden="true">#</a> _.escapeRegExp([string=''])</h3>
<p>转义 RegExp 字符串中特殊的字符 &quot;^&quot;, &quot;$&quot;, &quot;&quot;, &quot;.&quot;, &quot;*&quot;, &quot;+&quot;, &quot;?&quot;, &quot;(&quot;, &quot;)&quot;, &quot;[&quot;, &quot;]&quot;, &quot;, &quot;, 和 &quot;|&quot; in .</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">escapeRegExp</span><span class="token punctuation">(</span><span class="token string">'[lodash](https://lodash.com/)'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '\[lodash\]\(https://lodash\.com/\)'</span>
</code></pre></div><h3 id="unescape-string" tabindex="-1"><a class="header-anchor" href="#unescape-string" aria-hidden="true">#</a> _.unescape([string=''])</h3>
<p><code v-pre>_.escape</code>的反向版。 这个方法转换string字符串中的 HTML 实体 &amp;, &lt;, &gt;, &quot;, ', 和 ` 为对应的字符。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>不会转义其他字符。如果需要，可以使用第三方库，例如he。</p>
</div>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">unescape</span><span class="token punctuation">(</span><span class="token string">'fred, barney, &amp; pebbles'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'fred, barney, &amp; pebbles'</span>
</code></pre></div><h2 id="分割" tabindex="-1"><a class="header-anchor" href="#分割" aria-hidden="true">#</a> 分割</h2>
<h3 id="split-string-separator-limit" tabindex="-1"><a class="header-anchor" href="#split-string-separator-limit" aria-hidden="true">#</a> _.split([string=''], separator, [limit])</h3>
<p>根据<code v-pre>separator</code>拆分字符串<code v-pre>string</code>。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>这个方法基于<a href="https://mdn.io/String/split" target="_blank" rel="noopener noreferrer">String#split<ExternalLinkIcon/></a>。</p>
</div>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">split</span><span class="token punctuation">(</span><span class="token string">'a-b-c'</span><span class="token punctuation">,</span> <span class="token string">'-'</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => ['a', 'b']</span>
</code></pre></div><h3 id="words-string-pattern" tabindex="-1"><a class="header-anchor" href="#words-string-pattern" aria-hidden="true">#</a> _.words([string=''], [pattern])</h3>
<p>拆分字符串string中的词为数组 。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">words</span><span class="token punctuation">(</span><span class="token string">'fred, barney, &amp; pebbles'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => ['fred', 'barney', 'pebbles']</span>
 
_<span class="token punctuation">.</span><span class="token function">words</span><span class="token punctuation">(</span><span class="token string">'fred, barney, &amp; pebbles'</span><span class="token punctuation">,</span> <span class="token regex"><span class="token regex-delimiter">/</span><span class="token regex-source language-regex">[^, ]+</span><span class="token regex-delimiter">/</span><span class="token regex-flags">g</span></span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => ['fred', 'barney', '&amp;', 'pebbles']</span>
</code></pre></div><h2 id="检索" tabindex="-1"><a class="header-anchor" href="#检索" aria-hidden="true">#</a> 检索</h2>
<h3 id="startswith-string-target-position-0" tabindex="-1"><a class="header-anchor" href="#startswith-string-target-position-0" aria-hidden="true">#</a> _.startsWith([string=''], [target], [position=0])</h3>
<p>检查字符串string是否以<code v-pre>target</code>开头。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">startsWith</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token string">'a'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
 
_<span class="token punctuation">.</span><span class="token function">startsWith</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => false</span>
 
_<span class="token punctuation">.</span><span class="token function">startsWith</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">,</span> <span class="token number">1</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="endswith-string-target-position-string-length" tabindex="-1"><a class="header-anchor" href="#endswith-string-target-position-string-length" aria-hidden="true">#</a> _.endsWith([string=''], [target], [position=string.length])</h3>
<p>检查字符串string是否以给定的target字符串结尾;如果字符串string以target字符串结尾，那么返回 true，否则返回 false</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">endsWith</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token string">'c'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
 
_<span class="token punctuation">.</span><span class="token function">endsWith</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => false</span>
 
_<span class="token punctuation">.</span><span class="token function">endsWith</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token string">'b'</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => true</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="替换" tabindex="-1"><a class="header-anchor" href="#替换" aria-hidden="true">#</a> 替换</h2>
<h3 id="replace-string-pattern-replacement" tabindex="-1"><a class="header-anchor" href="#replace-string-pattern-replacement" aria-hidden="true">#</a> _.replace([string=''], pattern, replacement)</h3>
<p>替换string字符串中匹配的<code v-pre>pattern</code>为给定的<code v-pre>replacement</code></p>
<div class="tip-block warning"><p class="title">注意：</p><p>这个方法基于<a href="https://mdn.io/String/replace" target="_blank" rel="noopener noreferrer">String#replace<ExternalLinkIcon/></a>.</p>
</div>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">replace</span><span class="token punctuation">(</span><span class="token string">'Hi Fred'</span><span class="token punctuation">,</span> <span class="token string">'Fred'</span><span class="token punctuation">,</span> <span class="token string">'Barney'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'Hi Barney'</span>
</code></pre></div><h3 id="trim-string-chars-whitespace" tabindex="-1"><a class="header-anchor" href="#trim-string-chars-whitespace" aria-hidden="true">#</a> _.trim([string=''], [chars=whitespace])</h3>
<p>从string字符串中移除前面和后面的 空格 或 指定的字符。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">trim</span><span class="token punctuation">(</span><span class="token string">'  abc  '</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'abc'</span>
 
_<span class="token punctuation">.</span><span class="token function">trim</span><span class="token punctuation">(</span><span class="token string">'-_-abc-_-'</span><span class="token punctuation">,</span> <span class="token string">'_-'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'abc'</span>
 
_<span class="token punctuation">.</span><span class="token function">map</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'  foo  '</span><span class="token punctuation">,</span> <span class="token string">'  bar  '</span><span class="token punctuation">]</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span>trim<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => ['foo', 'bar']</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="trimstart-string-chars-whitespace" tabindex="-1"><a class="header-anchor" href="#trimstart-string-chars-whitespace" aria-hidden="true">#</a> _.trimStart([string=''], [chars=whitespace])</h3>
<p>从string字符串中移除前面的 空格 或 指定的字符。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">trimStart</span><span class="token punctuation">(</span><span class="token string">'  abc  '</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'abc  '</span>
 
_<span class="token punctuation">.</span><span class="token function">trimStart</span><span class="token punctuation">(</span><span class="token string">'-_-abc-_-'</span><span class="token punctuation">,</span> <span class="token string">'_-'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'abc-_-'</span>
</code></pre></div><h3 id="trimend-string-chars-whitespace" tabindex="-1"><a class="header-anchor" href="#trimend-string-chars-whitespace" aria-hidden="true">#</a> _.trimEnd([string=''], [chars=whitespace])</h3>
<p>从string字符串中移除后面的 空格 或 指定的字符。</p>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">trimEnd</span><span class="token punctuation">(</span><span class="token string">'  abc  '</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '  abc'</span>
 
_<span class="token punctuation">.</span><span class="token function">trimEnd</span><span class="token punctuation">(</span><span class="token string">'-_-abc-_-'</span><span class="token punctuation">,</span> <span class="token string">'_-'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '-_-abc'</span>
</code></pre></div><h3 id="pad-string-length-0-chars" tabindex="-1"><a class="header-anchor" href="#pad-string-length-0-chars" aria-hidden="true">#</a> _.pad([string=''], [length=0], [chars=' '])</h3>
<p>如果string字符串长度小于 length 则从左侧和右侧填充字符。 如果没法平均分配，则截断超出的长度。</p>
<details class="tip-block details"><summary>参数：</summary><ul>
<li>[string=''] (string): 要填充的字符串。</li>
<li>[length=0] (number): 填充的长度。</li>
<li>[chars=' '] (string): 填充字符。</li>
</ul>
</details>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">pad</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">8</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '  abc   '</span>
 
_<span class="token punctuation">.</span><span class="token function">pad</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">8</span><span class="token punctuation">,</span> <span class="token string">'_-'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '_-abc_-_'</span>
 
_<span class="token punctuation">.</span><span class="token function">pad</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'abc'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="padstart-string-length-0-chars" tabindex="-1"><a class="header-anchor" href="#padstart-string-length-0-chars" aria-hidden="true">#</a> _.padStart([string=''], [length=0], [chars=' '])</h3>
<p>如果string字符串长度小于 length 则在左侧填充字符。 如果超出length长度则截断超出的部分。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">padStart</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '   abc'</span>
 
_<span class="token punctuation">.</span><span class="token function">padStart</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">,</span> <span class="token string">'_-'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '_-_abc'</span>
 
_<span class="token punctuation">.</span><span class="token function">padStart</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'abc'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="padend-string-length-0-chars" tabindex="-1"><a class="header-anchor" href="#padend-string-length-0-chars" aria-hidden="true">#</a> _.padEnd([string=''], [length=0], [chars=' '])</h3>
<p>如果string字符串长度小于 length 则在右侧填充字符。 如果超出length长度则截断超出的部分。</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">padEnd</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'abc   '</span>
 
_<span class="token punctuation">.</span><span class="token function">padEnd</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">6</span><span class="token punctuation">,</span> <span class="token string">'_-'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'abc_-_'</span>
 
_<span class="token punctuation">.</span><span class="token function">padEnd</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'abc'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="其它" tabindex="-1"><a class="header-anchor" href="#其它" aria-hidden="true">#</a> 其它</h2>
<h3 id="parseint-string-radix-10" tabindex="-1"><a class="header-anchor" href="#parseint-string-radix-10" aria-hidden="true">#</a> _.parseInt(string, [radix=10])</h3>
<p>转换string字符串为指定基数的整数。 如果基数是 <code v-pre>undefined</code> 或者 <code v-pre>0</code>，则<code v-pre>radix</code>基数默认是10，如果<code v-pre>string</code>字符串是16进制，则<code v-pre>radix</code>基数为 16。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>注意: 这个方法与ES5 implementation 的 parseInt是一样的。</p>
</div>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">parseInt</span><span class="token punctuation">(</span><span class="token string">'08'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 8</span>
 
_<span class="token punctuation">.</span><span class="token function">map</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">'6'</span><span class="token punctuation">,</span> <span class="token string">'08'</span><span class="token punctuation">,</span> <span class="token string">'10'</span><span class="token punctuation">]</span><span class="token punctuation">,</span> _<span class="token punctuation">.</span>parseInt<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => [6, 8, 10]</span>
</code></pre></div><h3 id="repeat-string-n-1" tabindex="-1"><a class="header-anchor" href="#repeat-string-n-1" aria-hidden="true">#</a> _.repeat([string=''], [n=1])</h3>
<p>重复 N 次给定字符串</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">repeat</span><span class="token punctuation">(</span><span class="token string">'*'</span><span class="token punctuation">,</span> <span class="token number">3</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '***'</span>
 
_<span class="token punctuation">.</span><span class="token function">repeat</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">2</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'abcabc'</span>
 
_<span class="token punctuation">.</span><span class="token function">repeat</span><span class="token punctuation">(</span><span class="token string">'abc'</span><span class="token punctuation">,</span> <span class="token number">0</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => ''</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="truncate-string-options" tabindex="-1"><a class="header-anchor" href="#truncate-string-options" aria-hidden="true">#</a> _.truncate([string=''], [options=])</h3>
<p>截断string字符串，如果字符串超出了限定的最大值。 被截断的字符串后面会以<code v-pre>omission</code>代替，<code v-pre>omission</code>默认是 &quot;...&quot;。</p>
<details class="tip-block details"><summary>参数</summary><p>[string=''] (string): 要截断的字符串。
[options=] (Object): 选项对象。
[options.length=30] (number): 允许的最大长度。
[options.omission='...'] (string): 超出后的代替字符。
[options.separator] (RegExp|string): 截断点。</p>
</details>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>_<span class="token punctuation">.</span><span class="token function">truncate</span><span class="token punctuation">(</span><span class="token string">'hi-diddly-ho there, neighborino'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hi-diddly-ho there, neighbo...'</span>
 
_<span class="token punctuation">.</span><span class="token function">truncate</span><span class="token punctuation">(</span><span class="token string">'hi-diddly-ho there, neighborino'</span><span class="token punctuation">,</span> <span class="token punctuation">{</span>
  <span class="token string-property property">'length'</span><span class="token operator">:</span> <span class="token number">24</span><span class="token punctuation">,</span>
  <span class="token string-property property">'separator'</span><span class="token operator">:</span> <span class="token string">' '</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hi-diddly-ho there,...'</span>
 
_<span class="token punctuation">.</span><span class="token function">truncate</span><span class="token punctuation">(</span><span class="token string">'hi-diddly-ho there, neighborino'</span><span class="token punctuation">,</span> <span class="token punctuation">{</span>
  <span class="token string-property property">'length'</span><span class="token operator">:</span> <span class="token number">24</span><span class="token punctuation">,</span>
  <span class="token string-property property">'separator'</span><span class="token operator">:</span> <span class="token regex"><span class="token regex-delimiter">/</span><span class="token regex-source language-regex">,? +</span><span class="token regex-delimiter">/</span></span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hi-diddly-ho there...'</span>
 
_<span class="token punctuation">.</span><span class="token function">truncate</span><span class="token punctuation">(</span><span class="token string">'hi-diddly-ho there, neighborino'</span><span class="token punctuation">,</span> <span class="token punctuation">{</span>
  <span class="token string-property property">'omission'</span><span class="token operator">:</span> <span class="token string">' [...]'</span>
<span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hi-diddly-ho there, neig [...]'</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="template-string-options" tabindex="-1"><a class="header-anchor" href="#template-string-options" aria-hidden="true">#</a> _.template([string=''], [options=])</h3>
<p>创建一个预编译模板方法，可以插入数据到模板中<code v-pre>&quot;interpolate&quot;</code>分隔符相应的位置。 HTML会在<code v-pre>&quot;escape&quot;</code>分隔符中转换为相应实体。 在<code v-pre>&quot;evaluate&quot;</code>分隔符中允许执行JavaScript代码。 在模板中可以自由访问变量。 如果设置了选项对象，则会优先覆盖<a href="https://www.lodashjs.com/docs/lodash.template#templateSettings" target="_blank" rel="noopener noreferrer">_.templateSettings<ExternalLinkIcon/></a>的值。</p>
<div class="tip-block warning"><p class="title">注意：</p><p>在开发过程中，构建<a href="https://www.lodashjs.com/docs/lodash.template#template" target="_blank" rel="noopener noreferrer">_.template<ExternalLinkIcon/></a>可以使用<a href="http://www.html5rocks.com/en/tutorials/developertools/sourcemaps/#toc-sourceurl" target="_blank" rel="noopener noreferrer">sourceURLs<ExternalLinkIcon/></a>， 便于调试。
了解更多预编译模板的信息查看<a href="https://lodash.com/custom-builds" target="_blank" rel="noopener noreferrer">lodash的自定义构建文档<ExternalLinkIcon/></a>。
了解更多 Chrome 沙箱扩展的信息查看<a href="https://developer.chrome.com/extensions/sandboxingEval" target="_blank" rel="noopener noreferrer">Chrome的扩展文档<ExternalLinkIcon/></a>。</p>
</div>
<details class="tip-block details"><summary>参数：</summary><ul>
<li>[string=''] (string): 模板字符串.</li>
<li>[options=] (Object): 选项对象.</li>
<li>[options.escape=_.templateSettings.escape] (RegExp): &quot;escape&quot; 分隔符.</li>
<li>[options.evaluate=_.templateSettings.evaluate] (RegExp): &quot;evaluate&quot; 分隔符.</li>
<li>[options.imports=_.templateSettings.imports] (Object): 导入对象到模板中作为自由变量。</li>
<li>[options.interpolate=_.templateSettings.interpolate] (RegExp): &quot;interpolate&quot; 分隔符。</li>
<li>[options.sourceURL='lodash.templateSources[n]'] (string): 模板编译的来源URL。</li>
<li>[options.variable='obj'] (string): 数据对象的变量名。</li>
</ul>
</details>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token comment">// 使用 "interpolate" 分隔符创建编译模板</span>
<span class="token keyword">var</span> compiled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span><span class="token string">'hello &lt;%= user %>!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">compiled</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'fred'</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hello fred!'</span>
 
<span class="token comment">// 使用 HTML "escape" 转义数据的值</span>
<span class="token keyword">var</span> compiled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span><span class="token string">'&lt;b>&lt;%- value %>&lt;/b>'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">compiled</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'value'</span><span class="token operator">:</span> <span class="token string">'&lt;script>'</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '&lt;b>&lt;script>&lt;/b>'</span>
 
<span class="token comment">// 使用 "evaluate" 分隔符执行 JavaScript 和 生成HTML代码</span>
<span class="token keyword">var</span> compiled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span><span class="token string">'&lt;% _.forEach(users, function(user) { %>&lt;li>&lt;%- user %>&lt;/li>&lt;% }); %>'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">compiled</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'users'</span><span class="token operator">:</span> <span class="token punctuation">[</span><span class="token string">'fred'</span><span class="token punctuation">,</span> <span class="token string">'barney'</span><span class="token punctuation">]</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '&lt;li>fred&lt;/li>&lt;li>barney&lt;/li>'</span>
 
<span class="token comment">// 在 "evaluate" 分隔符中使用内部的 `print` 函数</span>
<span class="token keyword">var</span> compiled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span><span class="token string">'&lt;% print("hello " + user); %>!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">compiled</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'barney'</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hello barney!'</span>
 
<span class="token comment">// 使用 ES 分隔符代替默认的 "interpolate" 分隔符</span>
<span class="token keyword">var</span> compiled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span><span class="token string">'hello ${ user }!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">compiled</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'pebbles'</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hello pebbles!'</span>
 
<span class="token comment">// 使用自定义的模板分隔符</span>
_<span class="token punctuation">.</span>templateSettings<span class="token punctuation">.</span>interpolate <span class="token operator">=</span> <span class="token regex"><span class="token regex-delimiter">/</span><span class="token regex-source language-regex">{ {([\s\S]+?)} }</span><span class="token regex-delimiter">/</span><span class="token regex-flags">g</span></span><span class="token punctuation">;</span>
<span class="token keyword">var</span> compiled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span><span class="token string">'hello {{ user }}!'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">compiled</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'user'</span><span class="token operator">:</span> <span class="token string">'mustache'</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 'hello mustache!'</span>
 
<span class="token comment">// 使用反斜杠符号作为纯文本处理</span>
<span class="token keyword">var</span> compiled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span><span class="token string">'&lt;%= "\\&lt;%- value %\\>" %>'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">compiled</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'value'</span><span class="token operator">:</span> <span class="token string">'ignored'</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '&lt;%- value %>'</span>
 
<span class="token comment">// 使用 `imports` 选项导入 `jq` 作为 `jQuery` 的别名</span>
<span class="token keyword">var</span> text <span class="token operator">=</span> <span class="token string">'&lt;% jq.each(users, function(user) { %>&lt;li>&lt;%- user %>&lt;/li>&lt;% }); %>'</span><span class="token punctuation">;</span>
<span class="token keyword">var</span> compiled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span>text<span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'imports'</span><span class="token operator">:</span> <span class="token punctuation">{</span> <span class="token string-property property">'jq'</span><span class="token operator">:</span> jQuery <span class="token punctuation">}</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">compiled</span><span class="token punctuation">(</span><span class="token punctuation">{</span> <span class="token string-property property">'users'</span><span class="token operator">:</span> <span class="token punctuation">[</span><span class="token string">'fred'</span><span class="token punctuation">,</span> <span class="token string">'barney'</span><span class="token punctuation">]</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => '&lt;li>fred&lt;/li>&lt;li>barney&lt;/li>'</span>
 
<span class="token comment">// 使用 `sourceURL` 选项指定模板的来源URL</span>
<span class="token keyword">var</span> compiled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span><span class="token string">'hello &lt;%= user %>!'</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'sourceURL'</span><span class="token operator">:</span> <span class="token string">'/basic/greeting.jst'</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token function">compiled</span><span class="token punctuation">(</span>data<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token comment">// => 在开发工具的 Sources 选项卡 或 Resources 面板中找到 "greeting.jst"</span>
 
<span class="token comment">// 使用 `variable` 选项确保在编译模板中不声明变量</span>
<span class="token keyword">var</span> compiled <span class="token operator">=</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span><span class="token string">'hi &lt;%= data.user %>!'</span><span class="token punctuation">,</span> <span class="token punctuation">{</span> <span class="token string-property property">'variable'</span><span class="token operator">:</span> <span class="token string">'data'</span> <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
compiled<span class="token punctuation">.</span>source<span class="token punctuation">;</span>
<span class="token comment">// => function(data) {</span>
<span class="token comment">//   var __t, __p = '';</span>
<span class="token comment">//   __p += 'hi ' + ((__t = ( data.user )) == null ? '' : __t) + '!';</span>
<span class="token comment">//   return __p;</span>
<span class="token comment">// }</span>
 
<span class="token comment">// 使用 `source` 特性内联编译模板</span>
<span class="token comment">// 便以查看行号、错误信息、堆栈</span>
fs<span class="token punctuation">.</span><span class="token function">writeFileSync</span><span class="token punctuation">(</span>path<span class="token punctuation">.</span><span class="token function">join</span><span class="token punctuation">(</span>cwd<span class="token punctuation">,</span> <span class="token string">'jst.js'</span><span class="token punctuation">)</span><span class="token punctuation">,</span> <span class="token string">'\
  var JST = {\
    "main": '</span> <span class="token operator">+</span> _<span class="token punctuation">.</span><span class="token function">template</span><span class="token punctuation">(</span>mainText<span class="token punctuation">)</span><span class="token punctuation">.</span>source <span class="token operator">+</span> <span class="token string">'\
  };\
'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr/>
</div></template>


