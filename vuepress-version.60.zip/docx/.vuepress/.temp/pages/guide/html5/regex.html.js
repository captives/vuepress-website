export const data = JSON.parse("{\"key\":\"v-d41799ba\",\"path\":\"/guide/html5/regex.html\",\"title\":\"常用正则表达语句\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"常用正则表达语句\",\"slug\":\"常用正则表达语句\",\"link\":\"#常用正则表达语句\",\"children\":[{\"level\":2,\"title\":\"高亮段落内关键字\",\"slug\":\"高亮段落内关键字\",\"link\":\"#高亮段落内关键字\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/html5/regex.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
