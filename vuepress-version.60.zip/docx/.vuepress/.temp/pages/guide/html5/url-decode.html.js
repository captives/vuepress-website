export const data = JSON.parse("{\"key\":\"v-665b7688\",\"path\":\"/guide/html5/url-decode.html\",\"title\":\"url 编解码\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"url 编解码\",\"slug\":\"url-编解码\",\"link\":\"#url-编解码\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/html5/url-decode.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
