export const data = JSON.parse("{\"key\":\"v-310216c0\",\"path\":\"/guide/html5/linefeed-br-transform.html\",\"title\":\"\\\\n 和 <br/> 互转\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"\\\\n 和 <br/> 互转\",\"slug\":\"n-和-br-互转\",\"link\":\"#n-和-br-互转\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/html5/linefeed-br-transform.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
