export const data = JSON.parse("{\"key\":\"v-4c3bff06\",\"path\":\"/guide/html5/print.html\",\"title\":\"Web打印处理\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"Web打印处理\",\"slug\":\"web打印处理\",\"link\":\"#web打印处理\",\"children\":[{\"level\":2,\"title\":\"打印\",\"slug\":\"打印\",\"link\":\"#打印\",\"children\":[]},{\"level\":2,\"title\":\"监听事件\",\"slug\":\"监听事件\",\"link\":\"#监听事件\",\"children\":[]},{\"level\":2,\"title\":\"样式\",\"slug\":\"样式\",\"link\":\"#样式\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/html5/print.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
