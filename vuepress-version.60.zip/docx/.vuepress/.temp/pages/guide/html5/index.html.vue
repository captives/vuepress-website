<template><div><h2 id="web-api" tabindex="-1"><a class="header-anchor" href="#web-api" aria-hidden="true">#</a> Web API</h2>
<ol>
<li>
<p><a href="https://developer.mozilla.org/zh-CN/docs/Web/API/Intersection_Observer_API" target="_blank" rel="noopener noreferrer">Intersection Observer API<ExternalLinkIcon/></a>
提供了一种异步检测目标元素与祖先元素或 viewport 相交情况变化的方法。
过去，要检测一个元素是否可见或者两个元素是否相交并不容易，很多解决办法不可靠或性能很差。然而，随着互联网的发展，这种需求却与日俱增，比如，下面这些情况都需要用到相交检测：</p>
</li>
<li>
<p><a href="https://developer.mozilla.org/zh-CN/docs/Web/API/Fetch_API" target="_blank" rel="noopener noreferrer">Fetch API<ExternalLinkIcon/></a>
提供了一个获取资源的接口（包括跨域请求）。任何使用过 XMLHttpRequest 的人都能轻松上手，而且新的 API 提供了更强大和灵活的功能集。</p>
</li>
</ol>
<blockquote>
<p>获取随机颜色</p>
</blockquote>
<div class="language-javascript" data-ext="js"><pre v-pre class="language-javascript"><code> <span class="token string">"#"</span> <span class="token operator">+</span> Math<span class="token punctuation">.</span><span class="token function">floor</span><span class="token punctuation">(</span><span class="token number">0xFFFFFF</span> <span class="token operator">*</span> Math<span class="token punctuation">.</span><span class="token function">random</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">.</span><span class="token function">toString</span><span class="token punctuation">(</span><span class="token number">16</span><span class="token punctuation">)</span>
</code></pre></div></div></template>



<style lang="scss">
    header.hero{
        min-height: 100vh;
    }
</style>