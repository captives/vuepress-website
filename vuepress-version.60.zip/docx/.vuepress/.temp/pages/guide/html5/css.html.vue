<template><div><h1 id="css-使用笔记" tabindex="-1"><a class="header-anchor" href="#css-使用笔记" aria-hidden="true">#</a> CSS 使用笔记</h1>
<h2 id="css-语法" tabindex="-1"><a class="header-anchor" href="#css-语法" aria-hidden="true">#</a> CSS 语法</h2>
<h3 id="语法" tabindex="-1"><a class="header-anchor" href="#语法" aria-hidden="true">#</a> 语法</h3>
<p>CSS 规则由两个主要的部分构成：选择器，以及一条或多条声明。</p>
<blockquote>
<p>selector { declaration1; declaration2; ... declarationN }</p>
</blockquote>
<p>属性<code v-pre>property</code>是您希望设置的样式属性<code v-pre>style attribute</code>。每个属性有一个值。属性和值被冒号分开。</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">selector</span> <span class="token punctuation">{</span> 
    <span class="token property">property</span><span class="token punctuation">:</span> value
<span class="token punctuation">}</span>
</code></pre></div><h3 id="分组" tabindex="-1"><a class="header-anchor" href="#分组" aria-hidden="true">#</a> 分组</h3>
<p>你可以使用<code v-pre>(,)</code>对选择器进行分组。这样，被分组的选择器就可以使用相同的声明。</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h1, h2, h3, h4, h5, h6</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> green<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><h2 id="css-选择器" tabindex="-1"><a class="header-anchor" href="#css-选择器" aria-hidden="true">#</a> CSS 选择器</h2>
<h3 id="全局选择器" tabindex="-1"><a class="header-anchor" href="#全局选择器" aria-hidden="true">#</a> 全局选择器</h3>
<p>匹配所有元素，使用<code v-pre>(*)</code>表示；</p>
<p>移除所有属性的内外边距：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">*</span> <span class="token punctuation">{</span> <span class="token property">padding</span><span class="token punctuation">:</span>0<span class="token punctuation">;</span> <span class="token property">margin</span><span class="token punctuation">:</span>0<span class="token punctuation">;</span> <span class="token punctuation">}</span><span class="token punctuation">;</span>
</code></pre></div><h3 id="元素选择器" tabindex="-1"><a class="header-anchor" href="#元素选择器" aria-hidden="true">#</a> 元素选择器</h3>
<p>以html标签名定义的css样式，如<code v-pre>ul</code>、<code v-pre>li</code>、<code v-pre>p</code>、 <code v-pre>h1</code>、<code v-pre>div</code>;</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h1,h2,h3, p</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span>#eee<span class="token punctuation">;</span> <span class="token punctuation">}</span><span class="token punctuation">;</span>
</code></pre></div><h3 id="派生选择器" tabindex="-1"><a class="header-anchor" href="#派生选择器" aria-hidden="true">#</a> 派生选择器</h3>
<p>通过依据元素在其位置的上下文关系来定义样式，你可以使标记更加简洁。</p>
<p>比方说，你希望列表中的 <strong>strong</strong> 元素变为斜体字，而不是通常的粗体字，可以这样定义一个派生选择器：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">li strong</span> <span class="token punctuation">{</span>
    <span class="token property">font-style</span><span class="token punctuation">:</span> italic<span class="token punctuation">;</span>
    <span class="token property">font-weight</span><span class="token punctuation">:</span> normal<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><p>只有<code v-pre>li</code>元素中的 <strong>strong</strong> 元素的样式为斜体字，无需为 <strong>strong</strong> 元素定义特别的<code v-pre>class</code>或<code v-pre>id</code>，代码更加简洁。</p>
<div class="language-html line-numbers-mode" data-ext="html"><pre v-pre class="language-html"><code><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>p</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>strong</span><span class="token punctuation">></span></span>我是粗体字，不是斜体字，因为我不在列表当中，所以这个规则对我不起作用<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>strong</span><span class="token punctuation">></span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>p</span><span class="token punctuation">></span></span>

<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>ol</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>strong</span><span class="token punctuation">></span></span>我是斜体字。这是因为 strong 元素位于 li 元素内。<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>strong</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>我是正常的字体。<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>ol</span><span class="token punctuation">></span></span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="id选择器" tabindex="-1"><a class="header-anchor" href="#id选择器" aria-hidden="true">#</a> id选择器</h3>
<p>id 选择器可以为标有特定 id 的 HTML 元素指定特定的样式。
id 选择器以 &quot;#&quot; 来定义。</p>
<p>下面的两个 id 选择器，第一个可以定义元素的颜色为红色，第二个定义元素的颜色为绿色：</p>
<div class="language-html" data-ext="html"><pre v-pre class="language-html"><code><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>p</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>red<span class="token punctuation">"</span></span><span class="token punctuation">></span></span>这个段落是红色。<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>p</span><span class="token punctuation">></span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>p</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>green<span class="token punctuation">"</span></span><span class="token punctuation">></span></span>这个段落是绿色。<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>p</span><span class="token punctuation">></span></span>
</code></pre></div><div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">#red</span> <span class="token punctuation">{</span><span class="token property">color</span><span class="token punctuation">:</span>red<span class="token punctuation">;</span><span class="token punctuation">}</span>
<span class="token selector">#green</span> <span class="token punctuation">{</span><span class="token property">color</span><span class="token punctuation">:</span>green<span class="token punctuation">;</span><span class="token punctuation">}</span>
</code></pre></div><div class="tip-block warning"><p class="title">警告</p><p>注意：id 属性只能在每个 HTML 文档中出现一次。想知道原因吗，请参阅<a href="https://www.w3school.com.cn/xhtml/xhtml_structural_01.asp" target="_blank" rel="noopener noreferrer">XHTML:网站重构<ExternalLinkIcon/></a>。</p>
</div>
<h3 id="类选择器" tabindex="-1"><a class="header-anchor" href="#类选择器" aria-hidden="true">#</a> 类选择器</h3>
<p>在 CSS 中，类选择器以一个点号<code v-pre>(.)</code>开头显示：</p>
<p>所有拥有<code v-pre>center</code>类的<code v-pre>HTML</code>元素内容均居中。</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.center</span> <span class="token punctuation">{</span> <span class="token property">text-align</span><span class="token punctuation">:</span> center<span class="token punctuation">;</span> <span class="token punctuation">}</span>
</code></pre></div><div class="tip-block warning"><p class="title">警告</p><p>注意：类名的第一个字符不能使用数字！它无法在 Mozilla 或 Firefox 中起作用。</p>
</div>
<h3 id="属性选择器" tabindex="-1"><a class="header-anchor" href="#属性选择器" aria-hidden="true">#</a> 属性选择器</h3>
<p>CSS2支持的属性选择器用一个表达式</p>
<blockquote>
<p>[{属性 | 属性 {= | |= | ~=} 值}]</p>
</blockquote>
<ul>
<li><code v-pre>[class=&quot;a&quot;]</code>只能匹配<code v-pre>class=&quot;a&quot;</code>的所有元素。</li>
<li><code v-pre>[class^='a']</code> 只能匹配<code v-pre>class</code>以<code v-pre>a</code>开头的所有元素。</li>
<li><code v-pre>[class$='a']</code> 只能匹配<code v-pre>class</code>以<code v-pre>a</code>结尾的所有元素。</li>
<li><code v-pre>[class*='a']</code> 匹配<code v-pre>class</code>包含字符串<code v-pre>a</code>的所有元素。</li>
<li><code v-pre>[class~=&quot;a&quot;]</code>则可以匹配<code v-pre>class=&quot;a&quot;、class=&quot;a b&quot;</code>的所有元素。</li>
<li><code v-pre>[lang|=en]</code>则可以匹配<code v-pre>en</code>或以<code v-pre>en-</code>开头的所有元素。</li>
</ul>
<p>假设一个 HTML 文档中有一系列图片，其中每个图片的文件名都形如<code v-pre>figure-1.jpg</code>和<code v-pre>figure-2.jpg</code>。
就可以使用以下选择器匹配所有这些图像：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">img[src|="figure"]</span> <span class="token punctuation">{</span><span class="token property">border</span><span class="token punctuation">:</span> 1px solid gray<span class="token punctuation">;</span><span class="token punctuation">}</span>
</code></pre></div><p><strong>例子1:</strong>
所有<code v-pre>a</code>元素，带有<code v-pre>href</code>的链接，设置为红色：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">a[href]</span> <span class="token punctuation">{</span>
   <span class="token property">color</span><span class="token punctuation">:</span>red<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><p>还可以根据多个属性进行选择，只需将属性选择器链接在一起即可。
<strong>例子2:</strong>
同时将有 href 和 title 属性的 HTML 超链接的文本设置为红色，可以这样写</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">a[href][title]</span> <span class="token punctuation">{</span>
   <span class="token property">color</span><span class="token punctuation">:</span>red<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><p>根据具体属性值选择</p>
<p>除了选择拥有某些属性的元素，还可以进一步缩小选择范围，只选择有特定属性值的元素。</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">a[href="http://www.w3school.com.cn/about_us.asp"]</span> <span class="token punctuation">{</span><span class="token property">color</span><span class="token punctuation">:</span> red<span class="token punctuation">;</span><span class="token punctuation">}</span>
</code></pre></div><p>CSS3支持的属性选择器用一个表达式:</p>
<blockquote>
<p>[{属性 | 属性 {*= | ^= | $=} 值}]</p>
</blockquote>
<ul>
<li><code v-pre>*=</code>表示模糊匹配
<code v-pre>[href=&quot;163&quot;]</code>可以匹配<code v-pre>href=&quot;163.com&quot;、href=&quot;mail.163.com&quot;</code>等元素；</li>
<li><code v-pre>^=</code>表示以指定字符开头。
<code v-pre>[href^=&quot;/&quot;]</code>则匹配<code v-pre>href=&quot;/a/a.htm&quot;、href=&quot;/b&quot;</code>的元素。</li>
<li><code v-pre>=</code>表示以指定字符结尾;
[scr=&quot;.png&quot;]<code v-pre>则匹配所有png图片，如</code>src=&quot;logo.png&quot;`。</li>
</ul>
<h3 id="后代选择器" tabindex="-1"><a class="header-anchor" href="#后代选择器" aria-hidden="true">#</a> 后代选择器</h3>
<p>后代选择器（descendant selector）又称为包含选择器。</p>
<p>因此，h1 em 选择器可以解释为 “作为 h1 元素后代的任何 em 元素”。如果要从左向右读选择器，可以换成以下说法：“包含 em 的所有 h1 会把以下样式应用到该 em”。</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h1 em</span> <span class="token punctuation">{</span><span class="token property">color</span><span class="token punctuation">:</span>red<span class="token punctuation">;</span><span class="token punctuation">}</span>
</code></pre></div><p>只有<code v-pre>h1</code>下的所有<code v-pre>em</code> 设置为红色，其余元素无影响；
:::info
在后代选择器中，规则左边的选择器一端包括两个或多个用空格分隔的选择器。选择器之间的空格是一种结合符（combinator）。每个空格结合符可以解释为“... 在 ... 找到”、“... 作为 ... 的一部分”、“... 作为 ... 的后代”，但是要求必须从右向左读选择器。
:::</p>
<h3 id="子元素选择器" tabindex="-1"><a class="header-anchor" href="#子元素选择器" aria-hidden="true">#</a> 子元素选择器 <code v-pre>&gt;</code></h3>
<p>子元素选择器（Child selectors）只能选择作为某元素子元素的元素。</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h1 > strong</span> <span class="token punctuation">{</span> 
   <span class="token property">color</span><span class="token punctuation">:</span>red<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><h3 id="相邻兄弟选择器" tabindex="-1"><a class="header-anchor" href="#相邻兄弟选择器" aria-hidden="true">#</a> 相邻兄弟选择器 <code v-pre>+</code></h3>
<p>相邻兄弟选择器（Adjacent sibling selector）可选择紧接在另一元素后的元素，且二者有相同父元素：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h1 + p</span> <span class="token punctuation">{</span> <span class="token property">margin-top</span><span class="token punctuation">:</span>50px<span class="token punctuation">;</span> <span class="token punctuation">}</span>

</code></pre></div><p>可以匹配</p>
<div class="language-html" data-ext="html"><pre v-pre class="language-html"><code><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h1</span><span class="token punctuation">></span></span>这是标题<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h1</span><span class="token punctuation">></span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>p</span><span class="token punctuation">></span></span>这是段落<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>p</span><span class="token punctuation">></span></span>
</code></pre></div><p><strong>例子：</strong></p>
<div class="language-html line-numbers-mode" data-ext="html"><pre v-pre class="language-html"><code>  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>ul</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 1<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 2<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 3<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>ul</span><span class="token punctuation">></span></span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>ol</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 1<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 2<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 3<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>ol</span><span class="token punctuation">></span></span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">li + li</span> <span class="token punctuation">{</span> <span class="token property">font-weight</span><span class="token punctuation">:</span>bold<span class="token punctuation">;</span> <span class="token punctuation">}</span>
</code></pre></div><p>只会把列表中的第二个和第三个列表项变为粗体。第一个列表项不受影响</p>
<h3 id="同层全体组合选择器" tabindex="-1"><a class="header-anchor" href="#同层全体组合选择器" aria-hidden="true">#</a> 同层全体组合选择器<code v-pre>~</code></h3>
<p>选择所有跟在<code v-pre>article</code>后的同层<code v-pre>article</code>元素，不管它们之间隔了多少其他元素：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">article ~ article</span> <span class="token punctuation">{</span> 
   <span class="token property">border-top</span><span class="token punctuation">:</span> 1px dashed #ccc 
<span class="token punctuation">}</span>
</code></pre></div><h3 id="伪类选择器" tabindex="-1"><a class="header-anchor" href="#伪类选择器" aria-hidden="true">#</a> 伪类选择器</h3>
<blockquote>
<p>selector:pseudo-class { property: value; }</p>
</blockquote>
<p>伪类用于定义元素的特殊状态。</p>
<p><strong>例子1</strong>
链接能够以不同的方式显示：</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token comment">/* 未访问的链接 */</span>
<span class="token selector">a:link</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> #FF0000<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token comment">/* 已访问的链接 */</span>
<span class="token selector">a:visited</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> #00FF00<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token comment">/* 鼠标悬停链接 */</span>
<span class="token selector">a:hover</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> #FF00FF<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token comment">/* 已选择的链接 */</span>
<span class="token selector">a:active</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> #0000FF<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><div class="tip-block warning"><p class="title">注意：</p><ol>
<li><code v-pre>a:hover</code>必须在CSS定义中的<code v-pre>a:link</code>和<code v-pre>a:visited</code>之后，才能生效！</li>
<li><code v-pre>a:active</code>必须在CSS定义中的<code v-pre>a:hover</code>之后才能生效！</li>
<li>伪类名称对大小写不敏感。</li>
</ol>
</div>
<p>css1支持<code v-pre>:link</code>、<code v-pre>:visited</code>、<code v-pre>:active</code>只提供给<code v-pre>a</code>标签使用，元素之间互斥；
css2新增：<code v-pre>:hover</code>、<code v-pre>:focus</code>，还支持：<code v-pre>:first-child</code>、<code v-pre>:lang</code></p>
<div class="tip-block warning"><p class="title">警告</p><p><code v-pre>:link</code>、<code v-pre>:visited</code>、<code v-pre>:active</code>只提供给<code v-pre>a</code>标签使用，元素之间互斥；
<code v-pre>:first-child</code>、<code v-pre>:last-child</code>是对元素本身状态的描述，而非其它元素；</p>
</div>
<h3 id="伪元素选择器" tabindex="-1"><a class="header-anchor" href="#伪元素选择器" aria-hidden="true">#</a> 伪元素选择器</h3>
<blockquote>
<p>selector::pseudo-element { property: value; }</p>
</blockquote>
<p>CSS 伪元素用于设置元素指定部分的样式。
例如，它可用于：</p>
<ul>
<li>设置元素的首字母、首行的样式</li>
<li>在元素的内容之前或之后插入内容</li>
</ul>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">p::first-line</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> #ff0000<span class="token punctuation">;</span>
  <span class="token property">font-variant</span><span class="token punctuation">:</span> small-caps<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><div class="tip-block warning"><p class="title">警告</p><p>请注意双冒号表示法 - <code v-pre>::first-line</code>对比<code v-pre>:first-line</code>
在 CSS3 中，双冒号取代了伪元素的单冒号表示法。这是 W3C 试图区分伪类和伪元素的尝试。
在 CSS2 和 CSS1 中，伪类和伪元素都使用了单冒号语法。
为了向后兼容，CSS2 和 CSS1 伪元素可接受单冒号语法。</p>
</div>
<h2 id="伪类和伪元素的区别" tabindex="-1"><a class="header-anchor" href="#伪类和伪元素的区别" aria-hidden="true">#</a> 伪类和伪元素的区别</h2>
<p>最根本区别在于：<strong>它们是否创造了新的元素。</strong>（伪元素会创建新元素）</p>
<p><strong>所有CSS伪类:</strong></p>
<table>
<thead>
<tr>
<th>选择器</th>
<th>例子</th>
<th>例子描述</th>
</tr>
</thead>
<tbody>
<tr>
<td>:active</td>
<td>a:active</td>
<td>选择活动的链接。</td>
</tr>
<tr>
<td>:checked</td>
<td>input:checked</td>
<td>选择每个被选中的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:disabled</td>
<td>input:disabled</td>
<td>选择每个被禁用的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:empty</td>
<td>p:empty</td>
<td>选择没有子元素的每个<code v-pre>&lt;p&gt;</code>元素。</td>
</tr>
<tr>
<td>:enabled</td>
<td>input:enabled</td>
<td>选择每个已启用的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:first-child</td>
<td>p:first-child</td>
<td>选择作为其父的首个子元素的每个<code v-pre>&lt;p&gt;</code>元素。</td>
</tr>
<tr>
<td>:first-of-type</td>
<td>p:first-of-type</td>
<td>选择作为其父的首个<code v-pre>&lt;p&gt;</code>元素的每个<code v-pre>&lt;p&gt;</code>元素。</td>
</tr>
<tr>
<td>:focus</td>
<td>input:focus</td>
<td>选择获得焦点的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:hover</td>
<td>a:hover</td>
<td>选择鼠标悬停其上的链接。</td>
</tr>
<tr>
<td>:in-range</td>
<td>input:in-range</td>
<td>选择具有指定范围内的值的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:invalid</td>
<td>input:invalid</td>
<td>选择所有具有无效值的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:lang(language)</td>
<td>p:lang(it)</td>
<td>选择每个 lang 属性值以 &quot;it&quot; 开头的<code v-pre>&lt;p&gt;</code>元素。</td>
</tr>
<tr>
<td>:last-child</td>
<td>p:last-child</td>
<td>选择作为其父的最后一个子元素的每个<code v-pre>&lt;p&gt;</code>元素。</td>
</tr>
<tr>
<td>:last-of-type</td>
<td>p:last-of-type</td>
<td>选择作为其父的最后一个<code v-pre>&lt;p&gt;</code>元素的每个<code v-pre>&lt;p&gt;</code>元素。</td>
</tr>
<tr>
<td>:link</td>
<td>a:link</td>
<td>选择所有未被访问的链接。</td>
</tr>
<tr>
<td>:not(selector)</td>
<td>:not(p)</td>
<td>选择每个非<code v-pre>&lt;p&gt;</code>元素的元素。</td>
</tr>
<tr>
<td>:nth-child(n)</td>
<td>p:nth-child(2)</td>
<td>选择作为其父的第二个子元素的每个<code v-pre>&lt;p&gt;</code>元素。</td>
</tr>
<tr>
<td>:nth-last-child(n)</td>
<td>p:nth-last-child(2)</td>
<td>选择作为父的第二个子元素的每个<code v-pre>&lt;p&gt;</code>元素，从最后一个子元素计数。</td>
</tr>
<tr>
<td>:nth-last-of-type(n)</td>
<td>p:nth-last-of-type(2)</td>
<td>选择作为父的第二个<code v-pre>&lt;p&gt;</code>元素的每个<code v-pre>&lt;p&gt;</code>元素，从最后一个子元素计数</td>
</tr>
<tr>
<td>:nth-of-type(n)</td>
<td>p:nth-of-type(2)</td>
<td>选择作为其父的第二个<code v-pre>&lt;p&gt;</code>元素的每个<code v-pre>&lt;p&gt;</code>元素。</td>
</tr>
<tr>
<td>:only-of-type</td>
<td>p:only-of-type</td>
<td>选择作为其父的唯一<code v-pre>&lt;p&gt;</code>元素的每个<code v-pre>&lt;p&gt;</code>元素。</td>
</tr>
<tr>
<td>:only-child</td>
<td>p:only-child</td>
<td>选择作为其父的唯一子元素的<code v-pre>&lt;p&gt;</code>元素。</td>
</tr>
<tr>
<td>:optional</td>
<td>input:optional</td>
<td>选择不带 &quot;required&quot; 属性的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:out-of-range</td>
<td>input:out-of-range</td>
<td>选择值在指定范围之外的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:read-only</td>
<td>input:read-only</td>
<td>选择指定了 &quot;readonly&quot; 属性的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:read-write</td>
<td>input:read-write</td>
<td>选择不带 &quot;readonly&quot; 属性的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:required</td>
<td>input:required</td>
<td>选择指定了 &quot;required&quot; 属性的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:root</td>
<td>root</td>
<td>选择元素的根元素。</td>
</tr>
<tr>
<td>:target</td>
<td>#news:target</td>
<td>选择当前活动的 #news 元素（单击包含该锚名称的 URL）。</td>
</tr>
<tr>
<td>:valid</td>
<td>input:valid</td>
<td>选择所有具有有效值的<code v-pre>&lt;input&gt;</code>元素。</td>
</tr>
<tr>
<td>:visited</td>
<td>a:visited</td>
<td>选择所有已访问的链接。</td>
</tr>
</tbody>
</table>
<p><strong>所有 CSS 伪元素:</strong></p>
<table>
<thead>
<tr>
<th>选择器</th>
<th>例子</th>
<th>例子描述</th>
</tr>
</thead>
<tbody>
<tr>
<td>::after</td>
<td>p::after</td>
<td>在每个<code v-pre>&lt;p&gt;</code>元素之后插入内容。</td>
</tr>
<tr>
<td>::before</td>
<td>p::before</td>
<td>在每个<code v-pre>&lt;p&gt;</code>元素之前插入内容。</td>
</tr>
<tr>
<td>::first-letter</td>
<td>p::first-letter</td>
<td>选择每个<code v-pre>&lt;p&gt;</code>元素的首字母。</td>
</tr>
<tr>
<td>::first-line</td>
<td>p::first-line</td>
<td>选择每个<code v-pre>&lt;p&gt;</code>元素的首行，只能应用于块级元素。</td>
</tr>
<tr>
<td>::selection</td>
<td>p::selection</td>
<td>选择用户选择的元素部分。</td>
</tr>
</tbody>
</table>
<p>:::info
实际上<code v-pre>css3</code>为了区分两者，已经明确规定了<strong>伪类</strong>用一个冒号来表示，而<strong>伪元素</strong>则用两个冒号来表示。
:::</p>
<h2 id="文本样式" tabindex="-1"><a class="header-anchor" href="#文本样式" aria-hidden="true">#</a> 文本样式</h2>
<h3 id="文本颜色" tabindex="-1"><a class="header-anchor" href="#文本颜色" aria-hidden="true">#</a> 文本颜色</h3>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h1</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> white<span class="token punctuation">;</span>			//文本颜色
  <span class="token property">background-color</span><span class="token punctuation">:</span> black<span class="token punctuation">;</span>	//文本背景色
<span class="token punctuation">}</span>
</code></pre></div><h3 id="文本阴影" tabindex="-1"><a class="header-anchor" href="#文本阴影" aria-hidden="true">#</a> 文本阴影</h3>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h1</span> <span class="token punctuation">{</span>
  <span class="token property">text-shadow</span><span class="token punctuation">:</span> 2px 2px<span class="token punctuation">;</span>		 //水平阴影（2px）和垂直阴影（2px）
  <span class="token property">text-shadow</span><span class="token punctuation">:</span> 2px 2px red<span class="token punctuation">;</span>	 //水平阴影（2px）和垂直阴影（2px）颜色（红色）
  <span class="token property">text-shadow</span><span class="token punctuation">:</span> 2px 2px 5px red<span class="token punctuation">;</span>  //水平阴影（2px）和垂直阴影（2px）模糊效果（5px）颜色（红色）
<span class="token punctuation">}</span>
</code></pre></div><hr/>
</div></template>


