export const data = JSON.parse("{\"key\":\"v-6076b11e\",\"path\":\"/guide/html5/\",\"title\":\"\",\"lang\":\"guide\",\"frontmatter\":{\"home\":true,\"heroText\":\"Web\",\"heroImage\":\"/assets/images/browser_960_720.png\"},\"headers\":[{\"level\":2,\"title\":\"Web API\",\"slug\":\"web-api\",\"link\":\"#web-api\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/html5/README.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
