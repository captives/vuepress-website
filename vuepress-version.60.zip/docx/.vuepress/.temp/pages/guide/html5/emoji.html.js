export const data = JSON.parse("{\"key\":\"v-03666af8\",\"path\":\"/guide/html5/emoji.html\",\"title\":\"\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":2,\"title\":\"Emoji\",\"slug\":\"emoji\",\"link\":\"#emoji\",\"children\":[]},{\"level\":2,\"title\":\"常用\",\"slug\":\"常用\",\"link\":\"#常用\",\"children\":[]},{\"level\":2,\"title\":\"表情\",\"slug\":\"表情\",\"link\":\"#表情\",\"children\":[]},{\"level\":2,\"title\":\"人类和身体\",\"slug\":\"人类和身体\",\"link\":\"#人类和身体\",\"children\":[]},{\"level\":2,\"title\":\"动物和自然\",\"slug\":\"动物和自然\",\"link\":\"#动物和自然\",\"children\":[]},{\"level\":2,\"title\":\"食物和饮料\",\"slug\":\"食物和饮料\",\"link\":\"#食物和饮料\",\"children\":[]},{\"level\":2,\"title\":\"旅行和地点\",\"slug\":\"旅行和地点\",\"link\":\"#旅行和地点\",\"children\":[]},{\"level\":2,\"title\":\"活动\",\"slug\":\"活动\",\"link\":\"#活动\",\"children\":[]},{\"level\":2,\"title\":\"物品\",\"slug\":\"物品\",\"link\":\"#物品\",\"children\":[]},{\"level\":2,\"title\":\"符号\",\"slug\":\"符号\",\"link\":\"#符号\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/html5/emoji.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
