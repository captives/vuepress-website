export const data = JSON.parse("{\"key\":\"v-1f4e1b24\",\"path\":\"/guide/html5/mobile-adapter.html\",\"title\":\"移动端适配处理\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"移动端适配处理\",\"slug\":\"移动端适配处理\",\"link\":\"#移动端适配处理\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/html5/mobile-adapter.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
