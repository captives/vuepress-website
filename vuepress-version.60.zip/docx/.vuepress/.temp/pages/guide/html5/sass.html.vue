<template><div><h1 id="sass-使用笔记" tabindex="-1"><a class="header-anchor" href="#sass-使用笔记" aria-hidden="true">#</a> Sass 使用笔记</h1>
<p>Sass 是世界上最成熟、稳定、强大的专业级 CSS 扩展语言。
<img src="https://sass.bootcss.com/assets/img/illustrations/glasses-2087d741.svg" alt="sass"></p>
<h2 id="快速开始" tabindex="-1"><a class="header-anchor" href="#快速开始" aria-hidden="true">#</a> 快速开始</h2>
<p>Sass 是一种 CSS 的预编译语言。Sass还提供了CSS中还不存在的特性：变量(Variables)、嵌套(Nesting)、片段(Partials)、 混合(Mixins)、 扩展(Extend)、函数（functions）等功能，并且完全兼容 CSS 语法，让编写CSS 代码变得再次有趣。</p>
<p>Sass 能够帮助复杂的样式表更有条理， 并且易于在项目内部或跨项目共享设计。</p>
<p><a href="https://sass.bootcss.com/" target="_blank" rel="noopener noreferrer">sass 官网<ExternalLinkIcon/></a> | <a href="https://www.sass.hk/" target="_blank" rel="noopener noreferrer">sass 中文网<ExternalLinkIcon/></a> | <a href="https://ninghao.net/video/2096" target="_blank" rel="noopener noreferrer">视频学习<ExternalLinkIcon/></a></p>
<h3 id="安装-install" tabindex="-1"><a class="header-anchor" href="#安装-install" aria-hidden="true">#</a> 安装(Install)</h3>
<p>node环境安装</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">npm</span> <span class="token function">install</span> <span class="token parameter variable">-g</span> sass
</code></pre></div><div class="tip-block warning"><p class="title">警告</p><p>这种方式安装的 Sass 是纯 JavaScript 实现的，运行的速度比这里列出的其它安装方式安装的Sass要稍微慢一些。
但是接口是完全一致的，所以，如果你需要 更快的执行速度，请使用其他方式重新安装Sass ！</p>
</div>
<p>Mac OS X（通过Homebrew安装）
可以按照如下命令安装 Dart Sass：</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code>brew <span class="token function">install</span> sass/sass/sass
</code></pre></div><h3 id="预处理-preprocessing" tabindex="-1"><a class="header-anchor" href="#预处理-preprocessing" aria-hidden="true">#</a> 预处理(Preprocessing)</h3>
<p>最直接的方式就是在命令行中调用<code v-pre>sass</code>命令。安装Sass之后，你就可以用<code v-pre>sass</code>命令将Sass编译为CSS了。
首先你需要告诉Sass从哪个文件开始构建，以及将生成的 CSS 输出到哪里。</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code>sass input.scss output.css
</code></pre></div><p><code v-pre>--watch</code>参数来监视单个文件或目录;并在每次保存Sass文件时重新编译为CSS。</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code>sass <span class="token parameter variable">--watch</span> input.scss output.css
</code></pre></div><p>监视整个文件夹, 并使用冒号分隔它们，来监听文件并输出到目录。</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code>sass <span class="token parameter variable">--watch</span> app/sass:public/css
</code></pre></div><p><code v-pre>--style</code> 参数提供输出风格：</p>
<ul>
<li><code v-pre>expanded</code>：默认格式，没有缩进、扩展的css代码。</li>
<li><code v-pre>compressed</code>：压缩后的css代码,移除所有注释(强制注释除外)。</li>
</ul>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code>sass <span class="token parameter variable">--watch</span> sass/index.scss:css/index.css <span class="token parameter variable">--style</span> compressed
</code></pre></div><h3 id="注释-annotation" tabindex="-1"><a class="header-anchor" href="#注释-annotation" aria-hidden="true">#</a> 注释(Annotation)</h3>
<p>正常编译后，多行注释会保留；压缩编译<code v-pre>--style compressed</code>，所有注释都会移除</p>
<div class="language-scss line-numbers-mode" data-ext="scss"><pre v-pre class="language-scss"><code><span class="token comment">//这是单行注释</span>

<span class="token comment">/*
 * 这是多行块注释 
 */</span>

<span class="token comment">/*!
 * 重要注释！版权声明
 */</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>多行注释后增加<code v-pre>!</code>为重要注视，即使压缩编译也会被保留；</p>
<h3 id="调试" tabindex="-1"><a class="header-anchor" href="#调试" aria-hidden="true">#</a> 调试</h3>
<h4 id="debug" tabindex="-1"><a class="header-anchor" href="#debug" aria-hidden="true">#</a> @debug</h4>
<p><code v-pre>@debug</code>将<code v-pre>SassScript</code>表达式的值打印到标准输出流。它对于调试具有复杂<code v-pre>SassScript</code>的<code v-pre>Sass</code>文件很有用。</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@function</span> <span class="token function">double</span><span class="token punctuation">(</span>$n<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
    <span class="token atrule"><span class="token rule">@debug</span> <span class="token string">'输出 ====> '</span>$n<span class="token punctuation">;</span></span>
    <span class="token atrule"><span class="token rule">@return</span> $n * 2<span class="token punctuation">;</span></span>
<span class="token punctuation">}</span>

<span class="token selector">#sidebar</span> <span class="token punctuation">{</span>
    <span class="token property">width</span><span class="token punctuation">:</span> <span class="token function">double</span><span class="token punctuation">(</span>25px<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译器输出</p>
<div class="language-console" data-ext="console"><pre v-pre class="language-console"><code>sass/style.scss:2 Debug: &quot;输出 ====&gt; &quot; 25px
Compiled sass/style.scss to css/style.css.
</code></pre></div><h4 id="warn" tabindex="-1"><a class="header-anchor" href="#warn" aria-hidden="true">#</a> @warn</h4>
<p><code v-pre>@warn</code>指令将<code v-pre>SassScript</code>表达式的值打印到标准错误输出流。
这对于需要警告用户弃用或从轻微的<code v-pre>mixin</code>使用错误中恢复的库很有用。<code v-pre>@warn</code>和<code v-pre>@debug</code>之间有两个主要区别：</p>
<ul>
<li>您可以使用<code v-pre>--quiet</code>命令行选项或 <code v-pre>:quiet Sass</code>选项关闭警告。</li>
<li>样式表跟踪将与消息一起打印出来，以便被警告的用户可以看到他们的样式导致警告的位置。</li>
</ul>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@function</span> <span class="token function">double</span><span class="token punctuation">(</span>$n<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
    <span class="token atrule"><span class="token rule">@warn</span> <span class="token string">'输出 ====> '</span>$n<span class="token punctuation">;</span></span>
    <span class="token atrule"><span class="token rule">@return</span> $n * 2<span class="token punctuation">;</span></span>
<span class="token punctuation">}</span>

<span class="token selector">#sidebar</span> <span class="token punctuation">{</span>
    <span class="token property">width</span><span class="token punctuation">:</span> <span class="token function">double</span><span class="token punctuation">(</span>25px<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译器输出</p>
<div class="language-console" data-ext="console"><pre v-pre class="language-console"><code>Warning: &quot;输出 ====&gt; &quot; 25px
    sass/style.scss 1:5   double()
    sass/style.scss 7:12  root stylesheet

Compiled sass/style.scss to css/style.css.
</code></pre></div><h4 id="error" tabindex="-1"><a class="header-anchor" href="#error" aria-hidden="true">#</a> @error</h4>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@function</span> <span class="token function">double</span><span class="token punctuation">(</span>$n<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
    <span class="token atrule"><span class="token rule">@error</span> <span class="token string">'输出 ====> '</span>$n<span class="token punctuation">;</span></span>
    <span class="token atrule"><span class="token rule">@return</span> $n * 2<span class="token punctuation">;</span></span>
<span class="token punctuation">}</span>

<span class="token selector">#sidebar</span> <span class="token punctuation">{</span>
    <span class="token property">width</span><span class="token punctuation">:</span> <span class="token function">double</span><span class="token punctuation">(</span>25px<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译器输出</p>
<div class="language-console line-numbers-mode" data-ext="console"><pre v-pre class="language-console"><code>Error: &quot;输出 ====&gt; &quot; 25px
   ╷
2  │     width: double(25px);
   │            ^^^^^^^^^^^^
   ╵
  sass/style.scss 7:12  root stylesheet

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="数据类型-data-types" tabindex="-1"><a class="header-anchor" href="#数据类型-data-types" aria-hidden="true">#</a> 数据类型 (Data Types</h3>
<p>SassScript 支持 6 种主要的数据类型：</p>
<ul>
<li>数字。<code v-pre>1</code>, <code v-pre>2</code>, <code v-pre>13</code>, <code v-pre>10px</code></li>
<li>字符串，有引号字符串与无引号字符串。<code v-pre>&quot;foo&quot;, 'bar', baz</code></li>
<li>颜色。<code v-pre>blue, #04a3f9, rgba(255,0,0,0.5)</code></li>
<li>布尔型。<code v-pre>true, false</code></li>
<li>空值。<code v-pre>null</code></li>
<li>数组 (list)，用空格或逗号作分隔符。<code v-pre>1.5em 1em 0 2em</code>,<code v-pre>Helvetica, Arial, sans-serif</code></li>
<li>maps, 相当于<code v-pre>JavaScript</code>的<code v-pre>object</code>。<code v-pre>(key1: value1, key2: value2)</code></li>
</ul>
<h3 id="变量-variables" tabindex="-1"><a class="header-anchor" href="#变量-variables" aria-hidden="true">#</a> 变量(Variables)<code v-pre>$</code></h3>
<p>Sass 使用<code v-pre>$</code>符号作为变量的标志。
变量是存储信息并在将来重复利用的一种方式，在整个样式表中都可访问。</p>
<blockquote>
<p>变量支持块级作用域：在样式表顶层声明的变量是全局的（全局变量）,在块中声明的变量，只能在它们声明的块内访问（局部变量）；</p>
</blockquote>
<p>你可以在变量中存储颜色、字体 或任何 CSS 值，并在将来重复利用。例如：</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code>$<span class="token property">font-size</span><span class="token punctuation">:</span>22px<span class="token punctuation">;</span>
$<span class="token property">font-color</span><span class="token punctuation">:</span>#FFF<span class="token punctuation">;</span>
$<span class="token property">primary-color</span><span class="token punctuation">:</span>teal<span class="token punctuation">;</span>
<span class="token selector">body</span> <span class="token punctuation">{</span>
    $<span class="token property">font-color</span><span class="token punctuation">:</span>red<span class="token punctuation">;</span>

    <span class="token property">width</span><span class="token punctuation">:</span> 100%<span class="token punctuation">;</span>
    <span class="token property">color</span><span class="token punctuation">:</span> $font-color<span class="token punctuation">;</span>
    <span class="token property">font-size</span><span class="token punctuation">:</span> $font-size<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译后：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">body</span> <span class="token punctuation">{</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 100%<span class="token punctuation">;</span>
  <span class="token property">color</span><span class="token punctuation">:</span> red<span class="token punctuation">;</span>
  <span class="token property">font-size</span><span class="token punctuation">:</span> 22px<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><p>将局部变量转换为全局变量可以添加 !global 声明：
scss</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code>$<span class="token property">variable</span><span class="token punctuation">:</span> first global value<span class="token punctuation">;</span>

<span class="token selector">.content</span> <span class="token punctuation">{</span>
  $<span class="token property">variable</span><span class="token punctuation">:</span> second global value !global<span class="token punctuation">;</span>
  <span class="token property">value</span><span class="token punctuation">:</span> $variable<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.sidebar</span> <span class="token punctuation">{</span>
  <span class="token property">value</span><span class="token punctuation">:</span> $variable<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>css</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.content</span> <span class="token punctuation">{</span>
  <span class="token property">value</span><span class="token punctuation">:</span> second global value<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.sidebar</span> <span class="token punctuation">{</span>
  <span class="token property">value</span><span class="token punctuation">:</span> second global value<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>Sass核心库提供了一组用于处理变量的高级函数：</p>
<ul>
<li><code v-pre>meta.variable-exists</code> 该函数返回具有给定名称的变量是否存在于当前作用域中；</li>
<li><code v-pre>meta.global-variable-exists</code> 该函数执行相同的操作但仅针对全局作用域。</li>
</ul>
<h4 id="变量定义-default" tabindex="-1"><a class="header-anchor" href="#变量定义-default" aria-hidden="true">#</a> 变量定义<code v-pre>!default</code></h4>
<p>在变量的结尾添加<code v-pre>!default</code>给一个未通过<code v-pre>!default</code>声明赋值的变量赋值；此时，如果变量已经被赋值，不会再被重新赋值，但是如果变量还没有被赋值，则会被赋予新的值。</p>
<p>变量是 null 空值时将视为未被 !default 赋值。</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code>$<span class="token property">content</span><span class="token punctuation">:</span> <span class="token string">"First content"</span><span class="token punctuation">;</span>
$<span class="token property">content</span><span class="token punctuation">:</span> <span class="token string">"Second content?"</span> !default<span class="token punctuation">;</span>

$<span class="token property">new_content</span><span class="token punctuation">:</span> null<span class="token punctuation">;</span>
$<span class="token property">new_content</span><span class="token punctuation">:</span> <span class="token string">"First time reference"</span> !default<span class="token punctuation">;</span>

<span class="token selector">#main</span> <span class="token punctuation">{</span>
    <span class="token property">content</span><span class="token punctuation">:</span> $content<span class="token punctuation">;</span>
    <span class="token property">new-content</span><span class="token punctuation">:</span> $new_content<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译为：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">#main</span> <span class="token punctuation">{</span>
  <span class="token property">content</span><span class="token punctuation">:</span> <span class="token string">"First content"</span><span class="token punctuation">;</span>
  <span class="token property">new-content</span><span class="token punctuation">:</span> <span class="token string">"First time reference"</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><h3 id="选择器" tabindex="-1"><a class="header-anchor" href="#选择器" aria-hidden="true">#</a> 选择器</h3>
<p>css基本选择器，查看 <strong>CSS 使用笔记</strong></p>
<h4 id="父选择器" tabindex="-1"><a class="header-anchor" href="#父选择器" aria-hidden="true">#</a> 父选择器<code v-pre>&amp;</code></h4>
<p>在嵌套 CSS 规则时，有时也需要直接使用嵌套外层的父选择器，例如，当给某个元素设定<code v-pre>hover</code>样式时，或者当<code v-pre>body</code>元素有某个<code v-pre>classname</code>时，可以用<code v-pre>&amp;</code>代表嵌套规则外层的父选择器。</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">a</span> <span class="token punctuation">{</span>
    <span class="token property">font-weight</span><span class="token punctuation">:</span> bold<span class="token punctuation">;</span>
    <span class="token property">text-decoration</span><span class="token punctuation">:</span> none<span class="token punctuation">;</span>
    <span class="token selector">&amp;:hover</span> <span class="token punctuation">{</span>
        <span class="token property">text-decoration</span><span class="token punctuation">:</span> underline<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
    <span class="token selector">body.firefox &amp;</span> <span class="token punctuation">{</span>
        <span class="token property">font-weight</span><span class="token punctuation">:</span> normal<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译后</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">a</span> <span class="token punctuation">{</span>
  <span class="token property">font-weight</span><span class="token punctuation">:</span> bold<span class="token punctuation">;</span>
  <span class="token property">text-decoration</span><span class="token punctuation">:</span> none<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
<span class="token selector">a:hover</span> <span class="token punctuation">{</span>
  <span class="token property">text-decoration</span><span class="token punctuation">:</span> underline<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
<span class="token selector">body.firefox a</span> <span class="token punctuation">{</span>
  <span class="token property">font-weight</span><span class="token punctuation">:</span> normal<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><code v-pre>&amp;</code>必须作为选择器的第一个字符，其后可以跟随后缀生成复合的选择器，例如:</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">#main</span> <span class="token punctuation">{</span>
    <span class="token property">color</span><span class="token punctuation">:</span> black<span class="token punctuation">;</span>
    <span class="token selector">&amp;-sidebar</span> <span class="token punctuation">{</span>
        <span class="token property">border</span><span class="token punctuation">:</span> 1px solid<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译后</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">#main</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> black<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
<span class="token selector">#main-sidebar</span> <span class="token punctuation">{</span>
  <span class="token property">border</span><span class="token punctuation">:</span> 1px solid<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h4 id="占位符选择器" tabindex="-1"><a class="header-anchor" href="#占位符选择器" aria-hidden="true">#</a> 占位符选择器<code v-pre>%-</code></h4>
<p>占位符选择器 (placeholder selector)。与常用的<code v-pre>id</code>与<code v-pre>class</code>选择器写法相似，只是<code v-pre>#</code>或<code v-pre>.</code>替换成了<code v-pre>%</code>。必须通过 <code v-pre>@extend</code>指令调用，</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">%message-info,
.message.info</span> <span class="token punctuation">{</span>
    <span class="token property">border</span><span class="token punctuation">:</span> 1px solid black<span class="token punctuation">;</span>
    <span class="token property">font-size</span><span class="token punctuation">:</span> 1.5rem<span class="token punctuation">;</span>
    <span class="token selector">&amp;-title</span> <span class="token punctuation">{</span>
        <span class="token property">color</span><span class="token punctuation">:</span> yellow<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token selector">.heads-up</span> <span class="token punctuation">{</span>
    // Instead of `.message.info`.
    <span class="token atrule"><span class="token rule">@extend</span> %message-info<span class="token punctuation">;</span></span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译后：</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.heads-up,
.message.info</span> <span class="token punctuation">{</span>
  <span class="token property">border</span><span class="token punctuation">:</span> 1px solid black<span class="token punctuation">;</span>
  <span class="token property">font-size</span><span class="token punctuation">:</span> 1.5rem<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.message.info-title</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> yellow<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h4 id="子元素选择器" tabindex="-1"><a class="header-anchor" href="#子元素选择器" aria-hidden="true">#</a> 子元素选择器 <code v-pre>&gt;</code></h4>
<p>子元素选择器（Child selectors）只能选择作为某元素子元素的元素。</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h1 > strong</span> <span class="token punctuation">{</span> 
   <span class="token property">color</span><span class="token punctuation">:</span>red<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><h4 id="相邻兄弟选择器" tabindex="-1"><a class="header-anchor" href="#相邻兄弟选择器" aria-hidden="true">#</a> 相邻兄弟选择器 <code v-pre>+</code></h4>
<p>相邻兄弟选择器（Adjacent sibling selector）可选择紧接在另一元素后的元素，且二者有相同父元素：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h1 + p</span> <span class="token punctuation">{</span> <span class="token property">margin-top</span><span class="token punctuation">:</span>50px<span class="token punctuation">;</span> <span class="token punctuation">}</span>

</code></pre></div><p>可以匹配</p>
<div class="language-html" data-ext="html"><pre v-pre class="language-html"><code><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h1</span><span class="token punctuation">></span></span>这是标题<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h1</span><span class="token punctuation">></span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>p</span><span class="token punctuation">></span></span>这是段落<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>p</span><span class="token punctuation">></span></span>
</code></pre></div><p><strong>例子：</strong></p>
<div class="language-html line-numbers-mode" data-ext="html"><pre v-pre class="language-html"><code>  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>ul</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 1<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 2<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 3<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>ul</span><span class="token punctuation">></span></span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>ol</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 1<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 2<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>li</span><span class="token punctuation">></span></span>List item 3<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>li</span><span class="token punctuation">></span></span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>ol</span><span class="token punctuation">></span></span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">li + li</span> <span class="token punctuation">{</span> <span class="token property">font-weight</span><span class="token punctuation">:</span>bold<span class="token punctuation">;</span> <span class="token punctuation">}</span>
</code></pre></div><p>只会把列表中的第二个和第三个列表项变为粗体。第一个列表项不受影响</p>
<h4 id="同层全体组合选择器" tabindex="-1"><a class="header-anchor" href="#同层全体组合选择器" aria-hidden="true">#</a> 同层全体组合选择器<code v-pre>~</code></h4>
<p>选择所有跟在<code v-pre>article</code>后的同层<code v-pre>article</code>元素，不管它们之间隔了多少其他元素：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">article ~ article</span> <span class="token punctuation">{</span> 
   <span class="token property">border-top</span><span class="token punctuation">:</span> 1px dashed #ccc 
<span class="token punctuation">}</span>
</code></pre></div><p>这些组合选择器(<code v-pre>&amp;</code>、<code v-pre>&gt;</code>、<code v-pre>+</code>、<code v-pre>~</code>)可以毫不费力地应用到<code v-pre>sass</code>的规则嵌套中。可以把它们放在外层选择器后边，或里层选择器前边：</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">article</span> <span class="token punctuation">{</span>
  <span class="token selector">&amp;</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span> red <span class="token punctuation">}</span>
  <span class="token selector">~ article</span> <span class="token punctuation">{</span> <span class="token property">border-top</span><span class="token punctuation">:</span> 1px dashed #ccc <span class="token punctuation">}</span>
  <span class="token selector">> section</span> <span class="token punctuation">{</span> <span class="token property">background</span><span class="token punctuation">:</span> #eee <span class="token punctuation">}</span>
  <span class="token selector">dl ></span> <span class="token punctuation">{</span>
    <span class="token selector">dt</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span> #333 <span class="token punctuation">}</span>
    <span class="token selector">dd</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span> #555 <span class="token punctuation">}</span>
  <span class="token punctuation">}</span>
  <span class="token selector">nav + &amp;</span> <span class="token punctuation">{</span> <span class="token property">margin-top</span><span class="token punctuation">:</span> 0 <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><code v-pre>sass</code>会如你所愿地将这些嵌套规则一一解开组合在一起：</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">article</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span> red <span class="token punctuation">}</span>
<span class="token selector">article ~ article</span> <span class="token punctuation">{</span> <span class="token property">border-top</span><span class="token punctuation">:</span> 1px dashed #ccc <span class="token punctuation">}</span>
<span class="token selector">article > footer</span> <span class="token punctuation">{</span> <span class="token property">background</span><span class="token punctuation">:</span> #eee <span class="token punctuation">}</span>
<span class="token selector">article dl > dt</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span> #333 <span class="token punctuation">}</span>
<span class="token selector">article dl > dd</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span> #555 <span class="token punctuation">}</span>
<span class="token selector">nav + article</span> <span class="token punctuation">{</span> <span class="token property">margin-top</span><span class="token punctuation">:</span> 0 <span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="嵌套-nesting" tabindex="-1"><a class="header-anchor" href="#嵌套-nesting" aria-hidden="true">#</a> 嵌套(Nesting)</h3>
<p>有些 CSS 属性遵循相同的命名空间 (namespace)，比如 <code v-pre>font-family</code>,<code v-pre>font-size</code>,<code v-pre>font-weight</code>都以<code v-pre>font</code>作为属性的命名空间。
为了便于管理这样的属性，同时也为了避免了重复输入，Sass 允许将属性嵌套在命名空间中；命名空间也可以包含自己的属性值，例如：</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.funky</span> <span class="token punctuation">{</span>
    <span class="token selector">font: 20px/24px</span> <span class="token punctuation">{</span>
        <span class="token property">family</span><span class="token punctuation">:</span> fantasy<span class="token punctuation">;</span>
        <span class="token property">size</span><span class="token punctuation">:</span> 30em<span class="token punctuation">;</span>
        <span class="token property">weight</span><span class="token punctuation">:</span> bold<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译后：</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.funky</span> <span class="token punctuation">{</span>
  <span class="token property">font</span><span class="token punctuation">:</span> 20px/24px<span class="token punctuation">;</span>
  <span class="token property">font-family</span><span class="token punctuation">:</span> fantasy<span class="token punctuation">;</span>
  <span class="token property">font-size</span><span class="token punctuation">:</span> 30em<span class="token punctuation">;</span>
  <span class="token property">font-weight</span><span class="token punctuation">:</span> bold<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>在编写HTML时，您可能已经注意到它有一个清晰的嵌套和可视化层次结构，而CSS则没有。
Sass 允许您嵌套 CSS 选择器，嵌套方式 与 HTML 的视觉层次结构相同。</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">nav</span> <span class="token punctuation">{</span>
  <span class="token selector">ul</span> <span class="token punctuation">{</span>
    <span class="token property">margin</span><span class="token punctuation">:</span> 0<span class="token punctuation">;</span>
    <span class="token property">padding</span><span class="token punctuation">:</span> 0<span class="token punctuation">;</span>
    <span class="token property">list-style</span><span class="token punctuation">:</span> none<span class="token punctuation">;</span>
  <span class="token punctuation">}</span>

  <span class="token selector">li</span> <span class="token punctuation">{</span> <span class="token property">display</span><span class="token punctuation">:</span> inline-block<span class="token punctuation">;</span> <span class="token punctuation">}</span>

  <span class="token selector">a</span> <span class="token punctuation">{</span>
    <span class="token property">display</span><span class="token punctuation">:</span> block<span class="token punctuation">;</span>
    <span class="token property">padding</span><span class="token punctuation">:</span> 6px 12px<span class="token punctuation">;</span>
    <span class="token property">text-decoration</span><span class="token punctuation">:</span> none<span class="token punctuation">;</span>
  <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译后：</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">nav ul</span> <span class="token punctuation">{</span>
  <span class="token property">margin</span><span class="token punctuation">:</span> 0<span class="token punctuation">;</span>
  <span class="token property">padding</span><span class="token punctuation">:</span> 0<span class="token punctuation">;</span>
  <span class="token property">list-style</span><span class="token punctuation">:</span> none<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
<span class="token selector">nav li</span> <span class="token punctuation">{</span>
  <span class="token property">display</span><span class="token punctuation">:</span> inline-block<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
<span class="token selector">nav a</span> <span class="token punctuation">{</span>
  <span class="token property">display</span><span class="token punctuation">:</span> block<span class="token punctuation">;</span>
  <span class="token property">padding</span><span class="token punctuation">:</span> 6px 12px<span class="token punctuation">;</span>
  <span class="token property">text-decoration</span><span class="token punctuation">:</span> none<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><div class="tip-block warning"><p class="title">注意</p><p>过度嵌套的规则 将导致过度限定的CSS，这些CSS可能很难维护，并且通常被认为是不好的做法。</p>
</div>
<p>属性也可以嵌套，比如<code v-pre>border-color</code>属性，可以写成：</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">p</span> <span class="token punctuation">{</span>
    <span class="token selector">border:</span> <span class="token punctuation">{</span>
        <span class="token property">color</span><span class="token punctuation">:</span> red<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
    <span class="token selector">&amp;:hover</span> <span class="token punctuation">{</span>
        <span class="token property">background</span><span class="token punctuation">:</span> blue<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译后：</p>
<div class="language-text line-numbers-mode" data-ext="text"><pre v-pre class="language-text"><code>p {
  border-color: red;
}

p:hover {
  background: blue;
}
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><div class="tip-block warning"><p class="title">注意</p><p>border后面必须加上冒号;
在嵌套的代码块内，可以使用<code v-pre>&amp;</code>引用父元素。</p>
</div>
<h4 id="at-root" tabindex="-1"><a class="header-anchor" href="#at-root" aria-hidden="true">#</a> @at-root</h4>
<p>Sass 3.3.0中新增的功能，用来跳出选择器嵌套, 摆脱样式规则。
默认所有的嵌套，继承所有上级选择器，但有了这个就可以跳出所有上级选择器。</p>
<details class="tip-block details"><summary>示例</summary><p>scss</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">//没有跳出
.parent-1</span> <span class="token punctuation">{</span>
    <span class="token property">color</span><span class="token punctuation">:</span>#f00<span class="token punctuation">;</span>
    <span class="token selector">.child</span> <span class="token punctuation">{</span>
        <span class="token property">width</span><span class="token punctuation">:</span>100px<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token selector">//单个选择器跳出
.parent-2</span> <span class="token punctuation">{</span>
    <span class="token property">color</span><span class="token punctuation">:</span>#f00<span class="token punctuation">;</span>
    <span class="token atrule"><span class="token rule">@at-root</span> .child</span> <span class="token punctuation">{</span>
        <span class="token property">width</span><span class="token punctuation">:</span>200px<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token selector">//多个选择器跳出
.parent-3</span> <span class="token punctuation">{</span>
    <span class="token property">background</span><span class="token punctuation">:</span>#f00<span class="token punctuation">;</span>
    <span class="token atrule"><span class="token rule">@at-root</span></span> <span class="token punctuation">{</span>
        <span class="token selector">.child1</span> <span class="token punctuation">{</span>
            <span class="token property">width</span><span class="token punctuation">:</span>300px<span class="token punctuation">;</span>
        <span class="token punctuation">}</span>
        <span class="token selector">.child2</span> <span class="token punctuation">{</span>
            <span class="token property">width</span><span class="token punctuation">:</span>400px<span class="token punctuation">;</span>
        <span class="token punctuation">}</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>css</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.parent-1</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> #f00<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.parent-1 .child</span> <span class="token punctuation">{</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 100px<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.parent-2</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> #f00<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.child</span> <span class="token punctuation">{</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 200px<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.parent-3</span> <span class="token punctuation">{</span>
  <span class="token property">background</span><span class="token punctuation">:</span> #f00<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.child1</span> <span class="token punctuation">{</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 300px<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.child2</span> <span class="token punctuation">{</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 400px<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div></details>
<h4 id="at-root-without-和-at-root-with" tabindex="-1"><a class="header-anchor" href="#at-root-without-和-at-root-with" aria-hidden="true">#</a> @at-root(without:…)和@at-root(with:…)</h4>
<p>默认<code v-pre>@at-root</code>只会跳出选择器嵌套，而不能跳出<code v-pre>@media</code>或<code v-pre>@support</code>，如果要跳出这两种，则需使用<code v-pre>@at-root(without:media)</code>，<code v-pre>@at-root(without:support)</code>。这个语法的关键词有四个：</p>
<ul>
<li>1、all（表示所有）</li>
<li>2、rule（默认值，表示常规css）</li>
<li>3、media（表示media）</li>
<li>4、support（表示support，因为@support目前还无法广泛使用，所以在此不表）。</li>
</ul>
<details class="tip-block details"><summary>示例</summary><p>scss</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token comment">/*跳出父级元素嵌套*/</span>
<span class="token atrule"><span class="token rule">@media</span> print</span> <span class="token punctuation">{</span>
    <span class="token selector">.parent1</span><span class="token punctuation">{</span>
        <span class="token property">color</span><span class="token punctuation">:</span>#f00<span class="token punctuation">;</span>
        <span class="token atrule"><span class="token rule">@at-root</span> .child1</span> <span class="token punctuation">{</span>
            <span class="token property">width</span><span class="token punctuation">:</span>200px<span class="token punctuation">;</span>
        <span class="token punctuation">}</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token comment">/*跳出media嵌套，父级有效*/</span>
<span class="token atrule"><span class="token rule">@media</span> print</span> <span class="token punctuation">{</span>
    <span class="token selector">.parent2</span><span class="token punctuation">{</span>
        <span class="token property">color</span><span class="token punctuation">:</span>#f00<span class="token punctuation">;</span>
        <span class="token atrule"><span class="token rule">@at-root</span> <span class="token punctuation">(</span><span class="token property">without</span><span class="token punctuation">:</span> media<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
            <span class="token selector">.child2</span> <span class="token punctuation">{</span>
                <span class="token property">width</span><span class="token punctuation">:</span>200px<span class="token punctuation">;</span>
            <span class="token punctuation">}</span>
        <span class="token punctuation">}</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token comment">/*跳出media和父级*/</span>
<span class="token atrule"><span class="token rule">@media</span> print</span> <span class="token punctuation">{</span>
    <span class="token selector">.parent3</span><span class="token punctuation">{</span>
        <span class="token property">color</span><span class="token punctuation">:</span>#f00<span class="token punctuation">;</span>
        <span class="token atrule"><span class="token rule">@at-root</span> <span class="token punctuation">(</span><span class="token property">without</span><span class="token punctuation">:</span> all<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
            <span class="token selector">.child3</span> <span class="token punctuation">{</span>
                <span class="token property">width</span><span class="token punctuation">:</span>200px<span class="token punctuation">;</span>
            <span class="token punctuation">}</span>
        <span class="token punctuation">}</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>css</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@charset</span> <span class="token string">"UTF-8"</span><span class="token punctuation">;</span></span>
<span class="token comment">/*跳出父级元素嵌套*/</span>
<span class="token atrule"><span class="token rule">@media</span> print</span> <span class="token punctuation">{</span>
  <span class="token selector">.parent1</span> <span class="token punctuation">{</span>
    <span class="token property">color</span><span class="token punctuation">:</span> #f00<span class="token punctuation">;</span>
  <span class="token punctuation">}</span>
  <span class="token selector">.child1</span> <span class="token punctuation">{</span>
    <span class="token property">width</span><span class="token punctuation">:</span> 200px<span class="token punctuation">;</span>
  <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token comment">/*跳出media嵌套，父级有效*/</span>
<span class="token atrule"><span class="token rule">@media</span> print</span> <span class="token punctuation">{</span>
  <span class="token selector">.parent2</span> <span class="token punctuation">{</span>
    <span class="token property">color</span><span class="token punctuation">:</span> #f00<span class="token punctuation">;</span>
  <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token selector">.child2</span> <span class="token punctuation">{</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 200px<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token comment">/*跳出media和父级*/</span>
<span class="token atrule"><span class="token rule">@media</span> print</span> <span class="token punctuation">{</span>
  <span class="token selector">.parent3</span> <span class="token punctuation">{</span>
    <span class="token property">color</span><span class="token punctuation">:</span> #f00<span class="token punctuation">;</span>
  <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token selector">.child3</span> <span class="token punctuation">{</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 200px<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div></details>
<h4 id="at-root与" tabindex="-1"><a class="header-anchor" href="#at-root与" aria-hidden="true">#</a> @at-root与&amp;</h4>
<p>scss</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.child</span><span class="token punctuation">{</span>
    <span class="token atrule"><span class="token rule">@at-root</span> .parent &amp;</span><span class="token punctuation">{</span>
        <span class="token property">color</span><span class="token punctuation">:</span>#f00<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre></div><p>css</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.parent .child</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> #f00<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><h3 id="片段-partials" tabindex="-1"><a class="header-anchor" href="#片段-partials" aria-hidden="true">#</a> 片段(Partials)</h3>
<p>你可以创建部分Sass文件，其中可以包含在其他Sass文件中的CSS片段，这是一个很好的方法来帮助你模块化CSS， 并保持css更容易维护。片段代码需要<code v-pre>_</code>开头命名文件名，sass会认为这是片段，不会生成对应的css文件；</p>
<h3 id="模块-modules" tabindex="-1"><a class="header-anchor" href="#模块-modules" aria-hidden="true">#</a> 模块(Modules)</h3>
<p>你不必把所有的Sass都写在一个文件中。你可以用<code v-pre>@use</code>规则任意分割。此规则将另一个Sass文件作为模块加载，这意味着可以使用基于文件名的命名空间在Sass文件中引用其变量、mixin和函数。</p>
<p>该<code v-pre>@use</code>规则是主要代替<code v-pre>@import</code>, 它使 CSS、变量、mixin 和来自另一个样式表的函数可在当前样式表中访问。默认情况下，变量、mixin 和函数在基于URL基本名称的命名空间中可用 。</p>
<p>除了命名空间之外，<code v-pre>@use</code>和 之间还有一些重要的区别<code v-pre>@import</code>：</p>
<ul>
<li><code v-pre>@use</code>只执行一个样式表并包含它的CSS一次，无论该样式表被使用多少次。</li>
<li><code v-pre>@use</code>仅使名称在当前样式表中可用，而不是全局可用。</li>
<li>名称以<code v-pre>-</code>or<code v-pre>_</code>开头的成员对于带有<code v-pre>@use</code>的当前样式表是私有的</li>
<li>如果样式表包含<code v-pre>@extend</code>，则该扩展只应用于它导入的样式表，而不应用于导入它的样式表。</li>
</ul>
<p>请注意，占位符选择器没有命名空间，但它们确实认为是私有的。参考：<a href="https://sass.bootcss.com/blog/the-module-system-is-launched" target="_blank" rel="noopener noreferrer">The Module System is Launched<ExternalLinkIcon/></a></p>
<p>_footer.scss</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code>$<span class="token property">font-size</span><span class="token punctuation">:</span>30px<span class="token punctuation">;</span>
<span class="token selector">.footer</span> <span class="token punctuation">{</span>
    <span class="token property">font-size</span><span class="token punctuation">:</span> 20px<span class="token punctuation">;</span>
    <span class="token property">color</span><span class="token punctuation">:</span> $primary-color<span class="token punctuation">;</span> //错误，$primary-color访问不到
<span class="token punctuation">}</span>
</code></pre></div><p>scss</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code>$<span class="token property">font-size</span><span class="token punctuation">:</span>22px<span class="token punctuation">;</span>
$<span class="token property">font-color</span><span class="token punctuation">:</span>#FFF<span class="token punctuation">;</span>
$<span class="token property">primary-color</span><span class="token punctuation">:</span>teal<span class="token punctuation">;</span>
<span class="token atrule"><span class="token rule">@use</span> <span class="token string">'base'</span><span class="token punctuation">;</span></span>
<span class="token atrule"><span class="token rule">@use</span> <span class="token string">'_footer'</span> as footer<span class="token punctuation">;</span></span>
<span class="token selector">body</span> <span class="token punctuation">{</span>
    <span class="token property">width</span><span class="token punctuation">:</span> base.$width<span class="token punctuation">;</span>
    <span class="token property">color</span><span class="token punctuation">:</span> $font-color<span class="token punctuation">;</span>
    <span class="token property">font-size</span><span class="token punctuation">:</span> footer.$font-size<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><div class="tip-block warning"><p class="title">注意</p><p>在<code v-pre>@use 'base';</code>中没有扩展名，这是不需要的，sass很聪明，它会帮我们解决</p>
</div>
<h3 id="混合-mixins" tabindex="-1"><a class="header-anchor" href="#混合-mixins" aria-hidden="true">#</a> 混合(Mixins)</h3>
<p>Mixins是Sass中的一个强大的功能。使用<code v-pre>@mixin</code>根据功能定义一个模块，然后在需要使用的地方通过<code v-pre>@include</code>来调用声明的mixins。</p>
<p>scss</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@mixin</span> <span class="token function">css3</span><span class="token punctuation">(</span>$property<span class="token punctuation">,</span> $value<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
    <span class="token atrule"><span class="token rule">@each</span> $prefix in -webkit-<span class="token punctuation">,</span> -moz-<span class="token punctuation">,</span> -ms-<span class="token punctuation">,</span> -o-<span class="token punctuation">,</span> <span class="token string">''</span></span> <span class="token punctuation">{</span>
        <span class="token selector">#</span><span class="token punctuation">{</span>$prefix<span class="token punctuation">}</span><span class="token selector">#</span><span class="token punctuation">{</span>$property<span class="token punctuation">}</span><span class="token punctuation">:</span> $value<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token selector">.border_radius</span> <span class="token punctuation">{</span>
    <span class="token atrule"><span class="token rule">@include</span> <span class="token function">css3</span><span class="token punctuation">(</span>transition<span class="token punctuation">,</span> 0.5s<span class="token punctuation">)</span><span class="token punctuation">;</span></span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>css</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.border_radius</span> <span class="token punctuation">{</span>
    <span class="token property">-webkit-transition</span><span class="token punctuation">:</span> 0.5s<span class="token punctuation">;</span>
    <span class="token property">-moz-transition</span><span class="token punctuation">:</span> 0.5s<span class="token punctuation">;</span>
    <span class="token property">-ms-transition</span><span class="token punctuation">:</span> 0.5s<span class="token punctuation">;</span>
    <span class="token property">-o-transition</span><span class="token punctuation">:</span> 0.5s<span class="token punctuation">;</span>
    <span class="token property">transition</span><span class="token punctuation">:</span> 0.5s<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>要创建mixin，请使用<code v-pre>@mixin</code>指令为其命名。我们还在括号内使用变量<code v-pre>$property</code>，这样我们就可以传递任何我们想要的转换。创建mixin之后，可以将其用作CSS声明，以<code v-pre>@include</code>开头，后跟mixin的名称。</p>
<blockquote>
<p><a href="http://compass-style.org/" target="_blank" rel="noopener noreferrer">Compass<ExternalLinkIcon/></a>是一个Sass的<code v-pre>mixins</code>库，里面包括了很多有用的功能模块，比如说<code v-pre>border-radius</code>和<code v-pre>box-shadow</code>等;
参考：SASS基础 <a href="https://www.w3cplus.com/preprocessor/ten-best-common-mixins.html" target="_blank" rel="noopener noreferrer">10个常见的Mixins<ExternalLinkIcon/></a>、<a href="https://www.w3cplus.com/preprocessor/css-shapes-reference-boxes.html" target="_blank" rel="noopener noreferrer">10个有用的Sass Mixins<ExternalLinkIcon/></a></p>
</blockquote>
<h3 id="扩展-extend-和继承-inheritance" tabindex="-1"><a class="header-anchor" href="#扩展-extend-和继承-inheritance" aria-hidden="true">#</a> 扩展(Extend)和继承(Inheritance)</h3>
<p><code v-pre>@extend</code>是Sass的一项功能，它允许类彼此共享一组属性。 在Sass中<code v-pre>@extend</code>类的选择器将在其扩展的类旁边添加选择器，从而产生一个逗号分隔的列表。
scss</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.block</span> <span class="token punctuation">{</span>
    <span class="token property">color</span><span class="token punctuation">:</span> black<span class="token punctuation">;</span>
    <span class="token property">border</span><span class="token punctuation">:</span> 1px solid black<span class="token punctuation">;</span>
    <span class="token selector">a</span> <span class="token punctuation">{</span>
        <span class="token property">font-weight</span><span class="token punctuation">:</span> bold<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token selector">.card</span> <span class="token punctuation">{</span>
    <span class="token atrule"><span class="token rule">@extend</span> .block<span class="token punctuation">;</span></span>
    <span class="token property">background-color</span><span class="token punctuation">:</span> red<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>css</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">.block, .card</span> <span class="token punctuation">{</span>
  <span class="token property">color</span><span class="token punctuation">:</span> black<span class="token punctuation">;</span>
  <span class="token property">border</span><span class="token punctuation">:</span> 1px solid black<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.block a, .card a</span> <span class="token punctuation">{</span>
  <span class="token property">font-weight</span><span class="token punctuation">:</span> bold<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">.card</span> <span class="token punctuation">{</span>
  <span class="token property">background-color</span><span class="token punctuation">:</span> red<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><code v-pre>@extend</code>优点:</p>
<ul>
<li>更干净HTML类</li>
<li>减少CSS重复</li>
<li>节省时间和精力
:::error 注意：
<code v-pre>@extend</code>会大大增加CSS文件的大小，并且在不加保护的情况下影响CSS的性能。
:::
多重继承可以使用逗号分隔选择器名，比如 <code v-pre>@extend .error, .attention;</code> 与 <code v-pre>@extend .error;</code> 、<code v-pre>@extend.attention;</code> 有相同的效果。</li>
</ul>
<h3 id="运算-operators" tabindex="-1"><a class="header-anchor" href="#运算-operators" aria-hidden="true">#</a> 运算(Operators)</h3>
<p>所有数据类型均支持相等运算<code v-pre>==</code>或<code v-pre>!=</code>，此外，每种数据类型也有其各自支持的运算方式。</p>
<blockquote>
<p>关系运算<code v-pre>&lt;</code>, <code v-pre>&gt;</code>, <code v-pre>&lt;=</code>, <code v-pre>&gt;=</code>可用于数字运算，相等运算<code v-pre>==</code>,<code v-pre>!=</code>可用于所有数据类型。</p>
</blockquote>
<h4 id="基本运算" tabindex="-1"><a class="header-anchor" href="#基本运算" aria-hidden="true">#</a> 基本运算</h4>
<p>在CSS中经常需要做数学计算。Sass 支持一些标准的<strong>数学运算符</strong>，例如<code v-pre>+</code>、<code v-pre>-</code>、<code v-pre>*</code>、<code v-pre>/</code>和<code v-pre>%</code>。</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code>//除法
<span class="token atrule"><span class="token rule">@debug</span> math.<span class="token function">div</span><span class="token punctuation">(</span>600px<span class="token punctuation">,</span> 60px<span class="token punctuation">)</span><span class="token punctuation">;</span></span>  // 10
<span class="token atrule"><span class="token rule">@debug</span> math.<span class="token function">div</span><span class="token punctuation">(</span>600px<span class="token punctuation">,</span> 60<span class="token punctuation">)</span><span class="token punctuation">;</span></span>  // 10px  
<span class="token atrule"><span class="token rule">@debug</span> math.<span class="token function">div</span><span class="token punctuation">(</span>100px<span class="token punctuation">,</span> 5s<span class="token punctuation">)</span><span class="token punctuation">;</span></span> // 20px/s <span class="token punctuation">(</span>每秒20px<span class="token punctuation">)</span>

//字符串
$<span class="token property">i</span><span class="token punctuation">:</span>5<span class="token punctuation">;</span> 
<span class="token atrule"><span class="token rule">@debug</span> #</span><span class="token punctuation">{</span>$i<span class="token punctuation">}</span>px<span class="token punctuation">;</span>      //5px
@ e + -resize<span class="token punctuation">;</span>	     //e-resize 连接符使用
$<span class="token property">prefix</span><span class="token punctuation">:</span> ms<span class="token punctuation">;</span>
<span class="token atrule"><span class="token rule">@debug</span> -#</span><span class="token punctuation">{</span>$prefix<span class="token punctuation">}</span>-flex<span class="token punctuation">;</span> // -ms-flex

//乘法
<span class="token atrule"><span class="token rule">@debug</span> 20px * 2<span class="token punctuation">;</span></span> // 40px <span class="token punctuation">(</span>向量<span class="token punctuation">)</span>
<span class="token atrule"><span class="token rule">@debug</span> 20px * 2px<span class="token punctuation">;</span></span> // 40px*px <span class="token punctuation">(</span>平方像素数｜面积<span class="token punctuation">)</span>

//加法
<span class="token atrule"><span class="token rule">@debug</span> 20px + 2<span class="token punctuation">;</span></span> //22px
<span class="token atrule"><span class="token rule">@debug</span> 20px + 2px<span class="token punctuation">;</span></span> //22px
// CSS将1英寸定义为96像素。
<span class="token atrule"><span class="token rule">@debug</span> 1in + 6px<span class="token punctuation">;</span></span> // 102px or 1.0625in

//减法
<span class="token atrule"><span class="token rule">@debug</span> 20px - 2<span class="token punctuation">;</span></span>//18px
<span class="token atrule"><span class="token rule">@debug</span> 20px - 2px<span class="token punctuation">;</span></span> //18px
<span class="token atrule"><span class="token rule">@debug</span> 20px - 22px<span class="token punctuation">;</span></span> //-2px

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>更多内容详见 <a href="https://sass-lang.com/documentation/values" target="_blank" rel="noopener noreferrer">sass:Value<ExternalLinkIcon/></a></p>
<p>在下面的例子中，我们将做一些简单的数学运算来计算出<code v-pre>aside</code>&amp;<code v-pre>article</code>的宽度。
scss</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@use</span> <span class="token string">'sass:math'</span><span class="token punctuation">;</span></span>
<span class="token selector">article[role="main"]</span> <span class="token punctuation">{</span>
    <span class="token property">float</span><span class="token punctuation">:</span> left<span class="token punctuation">;</span>
    <span class="token property">width</span><span class="token punctuation">:</span> math.<span class="token function">div</span><span class="token punctuation">(</span>600rpx<span class="token punctuation">,</span> 960rpx<span class="token punctuation">)</span> * 100%<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">aside[role="complementary"]</span> <span class="token punctuation">{</span>
    <span class="token property">float</span><span class="token punctuation">:</span> right<span class="token punctuation">;</span>
    <span class="token property">width</span><span class="token punctuation">:</span> math.<span class="token function">div</span><span class="token punctuation">(</span>330px<span class="token punctuation">,</span> 960px<span class="token punctuation">)</span> * 100%<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>css</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">article[role=main]</span> <span class="token punctuation">{</span>
  <span class="token property">float</span><span class="token punctuation">:</span> left<span class="token punctuation">;</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 62.5%<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token selector">aside[role=complementary]</span> <span class="token punctuation">{</span>
  <span class="token property">float</span><span class="token punctuation">:</span> right<span class="token punctuation">;</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 34.375%<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>上述代码创建了一个非常简单的流式网格，以<strong>960px</strong>作为基准。Sass中的内置模块和操作符让我们可以做一些比如将像素值转换为百分比的操作，并且使用起来非常简单。</p>
<p>在有引号的文本字符串中使用<code v-pre>#{}</code>插值语句可以添加动态的值：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">p:before</span> <span class="token punctuation">{</span>
  <span class="token property">content</span><span class="token punctuation">:</span> <span class="token selector">"I ate #</span><span class="token punctuation">{</span>5 + 10<span class="token punctuation">}</span> pies!"<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><p>编译后：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">p:before</span> <span class="token punctuation">{</span>
  <span class="token property">content</span><span class="token punctuation">:</span> <span class="token string">"I ate 15 pies!"</span><span class="token punctuation">;</span> 
<span class="token punctuation">}</span>
</code></pre></div><h4 id="字符串运算-string-operations" tabindex="-1"><a class="header-anchor" href="#字符串运算-string-operations" aria-hidden="true">#</a> 字符串运算 (String Operations)</h4>
<p><code v-pre>+</code>可用于连接字符串</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">p</span> <span class="token punctuation">{</span>
  <span class="token property">cursor</span><span class="token punctuation">:</span> e + -resize<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><p>编译为：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">p</span> <span class="token punctuation">{</span>
  <span class="token property">cursor</span><span class="token punctuation">:</span> e-resize<span class="token punctuation">;</span> 
<span class="token punctuation">}</span>
</code></pre></div><h4 id="布尔运算-boolean-operations" tabindex="-1"><a class="header-anchor" href="#布尔运算-boolean-operations" aria-hidden="true">#</a> 布尔运算 (Boolean Operations)</h4>
<p>支持布尔型的 <code v-pre>and</code>、<code v-pre>or</code>以及<code v-pre>not</code>运算。</p>
<h4 id="数组运算-list-operations" tabindex="-1"><a class="header-anchor" href="#数组运算-list-operations" aria-hidden="true">#</a> 数组运算 (List Operations)</h4>
<p>数组不支持任何运算方式，只能使用 <a href="https://sass-lang.com/documentation/modules#list-functions" target="_blank" rel="noopener noreferrer">list functions<ExternalLinkIcon/></a> 控制。</p>
<h4 id="圆括号-parentheses" tabindex="-1"><a class="header-anchor" href="#圆括号-parentheses" aria-hidden="true">#</a> 圆括号 (Parentheses)</h4>
<p>圆括号可以用来影响运算的顺序：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">p</span> <span class="token punctuation">{</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 1em + <span class="token punctuation">(</span>2em * 3<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><p>编译为：</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">p</span> <span class="token punctuation">{</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 7em<span class="token punctuation">;</span> 
<span class="token punctuation">}</span>
</code></pre></div><h2 id="控制指令-control-directives" tabindex="-1"><a class="header-anchor" href="#控制指令-control-directives" aria-hidden="true">#</a> 控制指令(Control Directives)</h2>
<h3 id="条件语句-if、-else-if、-else" tabindex="-1"><a class="header-anchor" href="#条件语句-if、-else-if、-else" aria-hidden="true">#</a> 条件语句<code v-pre>@if</code>、<code v-pre>@else if</code>、<code v-pre>@else</code></h3>
<p>当<code v-pre>@if</code>的表达式返回值不是<code v-pre>false</code>、<code v-pre>null</code>时条件成立，输出 <code v-pre>{}</code>内的代码：</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@function</span> <span class="token function">double</span><span class="token punctuation">(</span>$n<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
    <span class="token atrule"><span class="token rule">@debug</span> <span class="token string">'输出'</span>$n<span class="token punctuation">;</span></span> //编译输出
    <span class="token atrule"><span class="token rule">@if</span> $n &lt; 10</span> <span class="token punctuation">{</span>
        <span class="token atrule"><span class="token rule">@return</span> $n * 2<span class="token punctuation">;</span></span>
    <span class="token punctuation">}</span>
    <span class="token atrule"><span class="token rule">@else</span></span> <span class="token punctuation">{</span>
        <span class="token atrule"><span class="token rule">@return</span> $n<span class="token punctuation">;</span></span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token selector">#sidebar</span> <span class="token punctuation">{</span>
    <span class="token property">width</span><span class="token punctuation">:</span> <span class="token function">double</span><span class="token punctuation">(</span>5px<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token property">font-size</span><span class="token punctuation">:</span> <span class="token function">double</span><span class="token punctuation">(</span>25px<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译后输出</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">#sidebar</span> <span class="token punctuation">{</span>
  <span class="token property">width</span><span class="token punctuation">:</span> 10px<span class="token punctuation">;</span>
  <span class="token property">font-size</span><span class="token punctuation">:</span> 25px<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div><h3 id="循环语句-for、while、each" tabindex="-1"><a class="header-anchor" href="#循环语句-for、while、each" aria-hidden="true">#</a> 循环语句 <code v-pre>for</code>、<code v-pre>while</code>、<code v-pre>each</code></h3>
<h4 id="for" tabindex="-1"><a class="header-anchor" href="#for" aria-hidden="true">#</a> @for</h4>
<p><code v-pre>@for</code>指令可以在限制的范围内重复输出格式，每次按要求（变量的值）对输出结果做出变动。这个指令包含两种格式：</p>
<ul>
<li>@for $var from &lt;start&gt; through &lt;end&gt;  包含<code v-pre>start</code>、<code v-pre>end</code></li>
<li>@for $var from &lt;start&gt; to &lt;end&gt; 包含<code v-pre>start</code>、不包含<code v-pre>end</code></li>
</ul>
<p>另外，<code v-pre>$var</code>可以是任何变量，比如 $i；<code v-pre>start</code>和<code v-pre>end</code>必须是整数值。
:::info
区别在于<code v-pre>through</code>与<code v-pre>to</code>的含义：
使用<code v-pre>through</code>时，条件范围包含 &lt;start&gt; 与 &lt;end&gt; 的值;
使用<code v-pre>to</code>时条件范围只包含&lt;start&gt;的值，不包含&lt;end&gt;<code v-pre>的值。 ::: 输出</code>h1-h6`标题样式:</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@use</span> <span class="token string">'sass:math'</span><span class="token punctuation">;</span></span>
<span class="token atrule"><span class="token rule">@for</span> $i from 1 through 6</span> <span class="token punctuation">{</span>
    <span class="token selector">h#</span><span class="token punctuation">{</span>$i<span class="token punctuation">}</span> <span class="token punctuation">{</span>
        <span class="token property">font-size</span><span class="token punctuation">:</span> 10px + math.<span class="token function">div</span><span class="token punctuation">(</span>25px<span class="token punctuation">,</span> $i<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
//or
<span class="token atrule"><span class="token rule">@for</span> $i from 1 to 7</span> <span class="token punctuation">{</span>
    <span class="token selector">h#</span><span class="token punctuation">{</span>$i<span class="token punctuation">}</span> <span class="token punctuation">{</span>
        <span class="token property">font-size</span><span class="token punctuation">:</span> 10px + math.<span class="token function">div</span><span class="token punctuation">(</span>25px<span class="token punctuation">,</span> $i<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h4 id="each" tabindex="-1"><a class="header-anchor" href="#each" aria-hidden="true">#</a> @each</h4>
<p><code v-pre>@each</code>指令的格式是</p>
<ul>
<li>@each $var in &lt;list&gt;</li>
</ul>
<p><code v-pre>$var</code>可以是任何变量名，比如<code v-pre>$length</code>或者<code v-pre>$name</code>，而<code v-pre>&lt;list&gt;</code>是一连串的值，也就是值列表。</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code>//批量添加浏览器前缀
<span class="token atrule"><span class="token rule">@mixin</span> <span class="token function">css3</span><span class="token punctuation">(</span>$property<span class="token punctuation">,</span> $value<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
    <span class="token atrule"><span class="token rule">@each</span> $prefix in -webkit-<span class="token punctuation">,</span> -moz-<span class="token punctuation">,</span> -ms-<span class="token punctuation">,</span> -o-<span class="token punctuation">,</span> <span class="token string">''</span></span> <span class="token punctuation">{</span>
        <span class="token selector">#</span><span class="token punctuation">{</span>$prefix<span class="token punctuation">}</span><span class="token selector">#</span><span class="token punctuation">{</span>$property<span class="token punctuation">}</span><span class="token punctuation">:</span> $value<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>

<span class="token selector">#sidebar</span> <span class="token punctuation">{</span>
    @include <span class="token function">css3</span><span class="token punctuation">(</span>font-smoothing<span class="token punctuation">,</span> auto<span class="token punctuation">)</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译后:</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">#sidebar</span> <span class="token punctuation">{</span>
  <span class="token property">-webkit-font-smoothing</span><span class="token punctuation">:</span> auto<span class="token punctuation">;</span>
  <span class="token property">-moz-font-smoothing</span><span class="token punctuation">:</span> auto<span class="token punctuation">;</span>
  <span class="token property">-ms-font-smoothing</span><span class="token punctuation">:</span> auto<span class="token punctuation">;</span>
  <span class="token property">-o-font-smoothing</span><span class="token punctuation">:</span> auto<span class="token punctuation">;</span>
  <span class="token property">font-smoothing</span><span class="token punctuation">:</span> auto<span class="token punctuation">;</span>
<span class="token punctuation">}</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>多重赋值</strong>
<code v-pre>@each</code>指令也可以使用多个变量，如@each $var1, $var2, ... in。
如果是一个列表的列表集合，子列表的每个元素都分配给相应的变量。</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@each</span> $h<span class="token punctuation">,</span> $color<span class="token punctuation">,</span> $size in <span class="token punctuation">(</span>h1<span class="token punctuation">,</span> red<span class="token punctuation">,</span> 20px<span class="token punctuation">)</span><span class="token punctuation">,</span>
	 		   <span class="token punctuation">(</span>h2<span class="token punctuation">,</span> blue<span class="token punctuation">,</span> 15px<span class="token punctuation">)</span><span class="token punctuation">,</span>
	 		   <span class="token punctuation">(</span>h3<span class="token punctuation">,</span> yellow<span class="token punctuation">,</span> 10px<span class="token punctuation">)</span><span class="token punctuation">,</span>
	 		   <span class="token punctuation">(</span>h4<span class="token punctuation">,</span> orange<span class="token punctuation">,</span> 7px<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
    <span class="token selector">#</span><span class="token punctuation">{</span>$h<span class="token punctuation">}</span> <span class="token punctuation">{</span>
        <span class="token property">color</span><span class="token punctuation">:</span> $color<span class="token punctuation">;</span>
        <span class="token property">font-size</span><span class="token punctuation">:</span> $size<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>由于映射被视为成对的列表，因此多重赋值也可以与它们一起使用</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@each</span> $h<span class="token punctuation">,</span> $color in <span class="token punctuation">(</span><span class="token property">h1</span><span class="token punctuation">:</span> red<span class="token punctuation">,</span> <span class="token property">h2</span><span class="token punctuation">:</span> blue<span class="token punctuation">,</span> <span class="token property">h3</span><span class="token punctuation">:</span> yellow<span class="token punctuation">,</span> <span class="token property">h4</span><span class="token punctuation">:</span> orange<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
    <span class="token selector">#</span><span class="token punctuation">{</span>$h<span class="token punctuation">}</span> <span class="token punctuation">{</span>
        <span class="token property">color</span><span class="token punctuation">:</span> $color<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
<span class="token punctuation">}</span>
</code></pre></div><p>编译后</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h1</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span> red<span class="token punctuation">;</span> <span class="token punctuation">}</span>
<span class="token selector">h2</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span> blue<span class="token punctuation">;</span> <span class="token punctuation">}</span>
<span class="token selector">h3</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span> yellow<span class="token punctuation">;</span> <span class="token punctuation">}</span>
<span class="token selector">h4</span> <span class="token punctuation">{</span> <span class="token property">color</span><span class="token punctuation">:</span> orange<span class="token punctuation">;</span> <span class="token punctuation">}</span>
</code></pre></div><h4 id="while" tabindex="-1"><a class="header-anchor" href="#while" aria-hidden="true">#</a> @while</h4>
<p><code v-pre>@while</code>指令重复输出格式，直到表达式返回结果为<code v-pre>false</code>。这样可以比<code v-pre>@for</code>实现更复杂的循环，只是很少会用到。</p>
<p>示例输出h1-h6标题字体大小:</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code>$<span class="token property">i</span><span class="token punctuation">:</span>6<span class="token punctuation">;</span>
<span class="token atrule"><span class="token rule">@while</span><span class="token punctuation">(</span>$i > 0<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
    <span class="token selector">h#</span><span class="token punctuation">{</span>$i<span class="token punctuation">}</span> <span class="token punctuation">{</span>
        <span class="token property">font-size</span><span class="token punctuation">:</span> 10px + math.<span class="token function">div</span><span class="token punctuation">(</span>25px<span class="token punctuation">,</span> $i<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token punctuation">}</span>
    $<span class="token property">i</span><span class="token punctuation">:</span> $i - 1<span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译后输出</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">h6</span><span class="token punctuation">{</span><span class="token property">font-size</span><span class="token punctuation">:</span>14.1666666667px<span class="token punctuation">}</span>
<span class="token selector">h5</span><span class="token punctuation">{</span><span class="token property">font-size</span><span class="token punctuation">:</span>15px<span class="token punctuation">}</span>
<span class="token selector">h4</span><span class="token punctuation">{</span><span class="token property">font-size</span><span class="token punctuation">:</span>16.25px<span class="token punctuation">}</span>
<span class="token selector">h3</span><span class="token punctuation">{</span><span class="token property">font-size</span><span class="token punctuation">:</span>18.3333333333px<span class="token punctuation">}</span>
<span class="token selector">h2</span><span class="token punctuation">{</span><span class="token property">font-size</span><span class="token punctuation">:</span>22.5px<span class="token punctuation">}</span>
<span class="token selector">h1</span><span class="token punctuation">{</span><span class="token property">font-size</span><span class="token punctuation">:</span>35px<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="自定义函数function" tabindex="-1"><a class="header-anchor" href="#自定义函数function" aria-hidden="true">#</a> 自定义函数<code v-pre>function</code></h3>
<p>SASS允许用户编写自己的函数:</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token atrule"><span class="token rule">@function</span> <span class="token function">double</span><span class="token punctuation">(</span>$n<span class="token punctuation">)</span></span> <span class="token punctuation">{</span>
    <span class="token atrule"><span class="token rule">@return</span> $n * 2<span class="token punctuation">;</span></span>
<span class="token punctuation">}</span>

<span class="token selector">#sidebar</span> <span class="token punctuation">{</span>
    <span class="token property">width</span><span class="token punctuation">:</span> <span class="token function">double</span><span class="token punctuation">(</span>5px<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="内置" tabindex="-1"><a class="header-anchor" href="#内置" aria-hidden="true">#</a> 内置</h2>
<h3 id="模块-modules-1" tabindex="-1"><a class="header-anchor" href="#模块-modules-1" aria-hidden="true">#</a> 模块(Modules)</h3>
<ul>
<li><code v-pre>sass:math</code>模块提供对<a href="https://sass.bootcss.com/documentation/values/numbers" target="_blank" rel="noopener noreferrer">数字<ExternalLinkIcon/></a>进行操作的函数。</li>
<li><code v-pre>sass:string</code> 模块提供对<a href="https://sass.bootcss.com/documentation/values/strings" target="_blank" rel="noopener noreferrer">字符串<ExternalLinkIcon/></a>进行操作的函数。</li>
<li><code v-pre>sass:color</code>模块基于现有<a href="https://sass.bootcss.com/documentation/values/colors" target="_blank" rel="noopener noreferrer">颜色<ExternalLinkIcon/></a>生成新颜色，从而轻松构建颜色主题。</li>
<li><code v-pre>sass:list</code>模块允许您访问和修改<a href="https://sass.bootcss.com/documentation/values/lists" target="_blank" rel="noopener noreferrer">列表<ExternalLinkIcon/></a>中的值。</li>
<li><code v-pre>sass:map</code>模块可以在<a href="https://sass.bootcss.com/documentation/values/maps" target="_blank" rel="noopener noreferrer">map<ExternalLinkIcon/></a>中查找与键关联的值，等等。</li>
<li><code v-pre>sass:selector</code>模块提供对Sass强大的<a href="https://sass.bootcss.com/documentation/modules/selector" target="_blank" rel="noopener noreferrer">选择器引擎<ExternalLinkIcon/></a>的访问。</li>
<li><code v-pre>sass:meta</code>模块公开了 Sass<a href="https://sass.bootcss.com/documentation/modules/meta" target="_blank" rel="noopener noreferrer">内部工作<ExternalLinkIcon/></a>的细节。</li>
</ul>
<h3 id="全局函数-function" tabindex="-1"><a class="header-anchor" href="#全局函数-function" aria-hidden="true">#</a> 全局函数(Function)</h3>
<h3 id="hsl-hsla" tabindex="-1"><a class="header-anchor" href="#hsl-hsla" aria-hidden="true">#</a> HSL/HSLA</h3>
<p>色相Hue、饱和度Saturation、亮度Lightness、透明度Alpha；</p>
<ul>
<li>hsl($hue $saturation $lightness)</li>
<li>hsl($hue $saturation $lightness / $alpha)</li>
<li>hsl($hue, $saturation, $lightness, $alpha: 1)</li>
<li>hsla($hue $saturation $lightness)</li>
<li>hsla($hue $saturation $lightness / $alpha)</li>
<li>hsla($hue, $saturation, $lightness, $alpha: 1) //alpha (0-1/0%-100%)</li>
</ul>
<p>色相(H)是色彩的基本属性，就是平常所说的颜色名称，如红色、黄色等。</p>
<p>色环上的0度、120度、240度位置，分别对应了RGB模型的红、绿、蓝三原色。原色两两混合形成了二次色。比如黄色（60度）就是由红色和绿色混合而成；蓝色和绿色则相加形成青色（180度）；品红（300度）则由红蓝两色组成。</p>
<p>饱和度(S)是指色彩的纯度，饱和度越高色彩越纯越浓，饱和度越低则色彩变灰变淡，取0-100%的数值。
<strong>图略</strong></p>
<p>亮度（Lightness）指的是色彩的明暗程度，亮度值越高，色彩越白，亮度越低，色彩越黑,取0-100%的数值。
<strong>图略</strong></p>
<p>把色相（Hue）、饱和度（Saturation）和亮度（Lightness）三个属性整合到一个圆柱中，就形成了HSL色彩空间模型:</p>
<p><strong>图略</strong></p>
<p>HSL圆柱中的任意一个点，都对应了一种颜色。圆环上的度数代表了颜色的色相，离中轴的距离代表了颜色的饱和度，点的高度则对应了颜色的亮度。</p>
<p>示例：
scss</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">div</span> <span class="token punctuation">{</span>
    <span class="token property">border-top</span><span class="token punctuation">:</span> 5px solid <span class="token function">hsl</span><span class="token punctuation">(</span>210deg 100% 20%<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token property">border-right</span><span class="token punctuation">:</span> 5px solid <span class="token function">hsl</span><span class="token punctuation">(</span>210 100% 20%<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token property">border-bottom</span><span class="token punctuation">:</span> 5px solid <span class="token function">hsla</span><span class="token punctuation">(</span>210deg 100% 20% / 60%<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token property">border-left</span><span class="token punctuation">:</span> 5px solid <span class="token function">hsla</span><span class="token punctuation">(</span>210deg<span class="token punctuation">,</span> 100%<span class="token punctuation">,</span> 20%<span class="token punctuation">,</span> 60%<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>css</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">div</span> <span class="token punctuation">{</span>
  <span class="token property">border-top</span><span class="token punctuation">:</span> 5px solid #003366<span class="token punctuation">;</span>
  <span class="token property">border-right</span><span class="token punctuation">:</span> 5px solid #003366<span class="token punctuation">;</span>
  <span class="token property">border-bottom</span><span class="token punctuation">:</span> 5px solid <span class="token function">rgba</span><span class="token punctuation">(</span>0<span class="token punctuation">,</span> 51<span class="token punctuation">,</span> 102<span class="token punctuation">,</span> 0.6<span class="token punctuation">)</span><span class="token punctuation">;</span>
  <span class="token property">border-left</span><span class="token punctuation">:</span> 5px solid <span class="token function">rgba</span><span class="token punctuation">(</span>0<span class="token punctuation">,</span> 51<span class="token punctuation">,</span> 102<span class="token punctuation">,</span> 0.6<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="rgb-rgba" tabindex="-1"><a class="header-anchor" href="#rgb-rgba" aria-hidden="true">#</a> RGB/RGBA</h3>
<ul>
<li>rgb($red $green $blue)</li>
<li>rgb($red $green $blue / $alpha)</li>
<li>rgb($red, $green, $blue, $alpha: 1)</li>
<li>rgb($color, $alpha)</li>
<li>rgba($red $green $blue)</li>
<li>rgba($red $green $blue / $alpha)</li>
<li>rgba($red, $green, $blue, $alpha: 1)</li>
<li>rgba($color, $alpha) //=&gt; color</li>
</ul>
<p>scss</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">div</span> <span class="token punctuation">{</span>
    <span class="token property">border-top</span><span class="token punctuation">:</span> 5px solid <span class="token function">rgb</span><span class="token punctuation">(</span>210 21 210<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token property">border-right</span><span class="token punctuation">:</span> 5px solid <span class="token function">rgb</span><span class="token punctuation">(</span>210 21 210<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token property">border-bottom</span><span class="token punctuation">:</span> 5px solid <span class="token function">rgba</span><span class="token punctuation">(</span>210 21 210 / 60%<span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token property">border-left</span><span class="token punctuation">:</span> 5px solid <span class="token function">rgba</span><span class="token punctuation">(</span>210<span class="token punctuation">,</span> 21<span class="token punctuation">,</span> 210<span class="token punctuation">,</span> 60%<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>css</p>
<div class="language-css line-numbers-mode" data-ext="css"><pre v-pre class="language-css"><code><span class="token selector">div</span> <span class="token punctuation">{</span>
  <span class="token property">border-top</span><span class="token punctuation">:</span> 5px solid #d215d2<span class="token punctuation">;</span>
  <span class="token property">border-right</span><span class="token punctuation">:</span> 5px solid #d215d2<span class="token punctuation">;</span>
  <span class="token property">border-bottom</span><span class="token punctuation">:</span> 5px solid <span class="token function">rgba</span><span class="token punctuation">(</span>210<span class="token punctuation">,</span> 21<span class="token punctuation">,</span> 210<span class="token punctuation">,</span> 0.6<span class="token punctuation">)</span><span class="token punctuation">;</span>
  <span class="token property">border-left</span><span class="token punctuation">:</span> 5px solid <span class="token function">rgba</span><span class="token punctuation">(</span>210<span class="token punctuation">,</span> 21<span class="token punctuation">,</span> 210<span class="token punctuation">,</span> 0.6<span class="token punctuation">)</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="内置颜色函数" tabindex="-1"><a class="header-anchor" href="#内置颜色函数" aria-hidden="true">#</a> 内置颜色函数</h3>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code>　　<span class="token function">lighten</span><span class="token punctuation">(</span>#cc3<span class="token punctuation">,</span> 10%<span class="token punctuation">)</span> // #d6d65c
　　<span class="token function">darken</span><span class="token punctuation">(</span>#cc3<span class="token punctuation">,</span> 10%<span class="token punctuation">)</span> // #a3a329
　　<span class="token function">grayscale</span><span class="token punctuation">(</span>#cc3<span class="token punctuation">)</span> // #808080
　　<span class="token function">complement</span><span class="token punctuation">(</span>#cc3<span class="token punctuation">)</span> // #33c
</code></pre></div><h3 id="if" tabindex="-1"><a class="header-anchor" href="#if" aria-hidden="true">#</a> IF</h3>
<ul>
<li>if($condition, $if-true, $if-false)</li>
</ul>
<p>如果<code v-pre>$condition</code>为==truthy==，则返回<code v-pre>$if(true)</code>，否则返回<code v-pre>$if(false)</code>。
此函数的特殊之处在于它甚至不计算未返回的参数，因此即使未使用的参数会引发错误，也可以安全地调用。
scss</p>
<div class="language-css" data-ext="css"><pre v-pre class="language-css"><code><span class="token property">font-size</span><span class="token punctuation">:</span> <span class="token function">if</span><span class="token punctuation">(</span>true<span class="token punctuation">,</span> 20px<span class="token punctuation">,</span> 30px<span class="token punctuation">)</span><span class="token punctuation">;</span>	//20px
<span class="token property">font-size</span><span class="token punctuation">:</span> <span class="token function">if</span><span class="token punctuation">(</span>false<span class="token punctuation">,</span> 20px<span class="token punctuation">,</span> 30px<span class="token punctuation">)</span><span class="token punctuation">;</span>	//30px
<span class="token property">font-size</span><span class="token punctuation">:</span> <span class="token function">if</span><span class="token punctuation">(</span>null<span class="token punctuation">,</span> 20px<span class="token punctuation">,</span> 30px<span class="token punctuation">)</span><span class="token punctuation">;</span>	//30px
<span class="token property">font-size</span><span class="token punctuation">:</span> <span class="token function">if</span><span class="token punctuation">(</span>2<span class="token punctuation">,</span> 20px<span class="token punctuation">,</span> 30px<span class="token punctuation">)</span><span class="token punctuation">;</span>		//20px
</code></pre></div><hr/>
</div></template>


