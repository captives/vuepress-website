export const data = JSON.parse("{\"key\":\"v-ce4ba1b2\",\"path\":\"/guide/html5/css.html\",\"title\":\"CSS 使用笔记\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"CSS 使用笔记\",\"slug\":\"css-使用笔记\",\"link\":\"#css-使用笔记\",\"children\":[{\"level\":2,\"title\":\"CSS 语法\",\"slug\":\"css-语法\",\"link\":\"#css-语法\",\"children\":[{\"level\":3,\"title\":\"语法\",\"slug\":\"语法\",\"link\":\"#语法\",\"children\":[]},{\"level\":3,\"title\":\"分组\",\"slug\":\"分组\",\"link\":\"#分组\",\"children\":[]}]},{\"level\":2,\"title\":\"CSS 选择器\",\"slug\":\"css-选择器\",\"link\":\"#css-选择器\",\"children\":[{\"level\":3,\"title\":\"全局选择器\",\"slug\":\"全局选择器\",\"link\":\"#全局选择器\",\"children\":[]},{\"level\":3,\"title\":\"元素选择器\",\"slug\":\"元素选择器\",\"link\":\"#元素选择器\",\"children\":[]},{\"level\":3,\"title\":\"派生选择器\",\"slug\":\"派生选择器\",\"link\":\"#派生选择器\",\"children\":[]},{\"level\":3,\"title\":\"id选择器\",\"slug\":\"id选择器\",\"link\":\"#id选择器\",\"children\":[]},{\"level\":3,\"title\":\"类选择器\",\"slug\":\"类选择器\",\"link\":\"#类选择器\",\"children\":[]},{\"level\":3,\"title\":\"属性选择器\",\"slug\":\"属性选择器\",\"link\":\"#属性选择器\",\"children\":[]},{\"level\":3,\"title\":\"后代选择器\",\"slug\":\"后代选择器\",\"link\":\"#后代选择器\",\"children\":[]},{\"level\":3,\"title\":\"子元素选择器 >\",\"slug\":\"子元素选择器\",\"link\":\"#子元素选择器\",\"children\":[]},{\"level\":3,\"title\":\"相邻兄弟选择器 +\",\"slug\":\"相邻兄弟选择器\",\"link\":\"#相邻兄弟选择器\",\"children\":[]},{\"level\":3,\"title\":\"同层全体组合选择器~\",\"slug\":\"同层全体组合选择器\",\"link\":\"#同层全体组合选择器\",\"children\":[]},{\"level\":3,\"title\":\"伪类选择器\",\"slug\":\"伪类选择器\",\"link\":\"#伪类选择器\",\"children\":[]},{\"level\":3,\"title\":\"伪元素选择器\",\"slug\":\"伪元素选择器\",\"link\":\"#伪元素选择器\",\"children\":[]}]},{\"level\":2,\"title\":\"伪类和伪元素的区别\",\"slug\":\"伪类和伪元素的区别\",\"link\":\"#伪类和伪元素的区别\",\"children\":[]},{\"level\":2,\"title\":\"文本样式\",\"slug\":\"文本样式\",\"link\":\"#文本样式\",\"children\":[{\"level\":3,\"title\":\"文本颜色\",\"slug\":\"文本颜色\",\"link\":\"#文本颜色\",\"children\":[]},{\"level\":3,\"title\":\"文本阴影\",\"slug\":\"文本阴影\",\"link\":\"#文本阴影\",\"children\":[]}]}]}],\"git\":{},\"filePathRelative\":\"guide/html5/css.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
