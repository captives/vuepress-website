<template><div><h1 id="webrtc-媒体服务" tabindex="-1"><a class="header-anchor" href="#webrtc-媒体服务" aria-hidden="true">#</a> WebRTC 媒体服务</h1>
<h1 id="获取设备列表" tabindex="-1"><a class="header-anchor" href="#获取设备列表" aria-hidden="true">#</a> 获取设备列表</h1>
<p>使用以下代码获取设备列表</p>
</div></template>


