export const data = JSON.parse("{\"key\":\"v-281db8d6\",\"path\":\"/guide/webrtc/\",\"title\":\"WebRTC 媒体服务\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"WebRTC 媒体服务\",\"slug\":\"webrtc-媒体服务\",\"link\":\"#webrtc-媒体服务\",\"children\":[]},{\"level\":1,\"title\":\"获取设备列表\",\"slug\":\"获取设备列表\",\"link\":\"#获取设备列表\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/webrtc/readme.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
