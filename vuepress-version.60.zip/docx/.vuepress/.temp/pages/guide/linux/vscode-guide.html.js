export const data = JSON.parse("{\"key\":\"v-190bb819\",\"path\":\"/guide/linux/vscode-guide.html\",\"title\":\"vscode 前端常用配置\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"vscode 前端常用配置\",\"slug\":\"vscode-前端常用配置\",\"link\":\"#vscode-前端常用配置\",\"children\":[{\"level\":2,\"title\":\"配置\",\"slug\":\"配置\",\"link\":\"#配置\",\"children\":[]},{\"level\":2,\"title\":\"常用插件\",\"slug\":\"常用插件\",\"link\":\"#常用插件\",\"children\":[{\"level\":3,\"title\":\"Vue 3 Snippets\",\"slug\":\"vue-3-snippets\",\"link\":\"#vue-3-snippets\",\"children\":[]},{\"level\":3,\"title\":\"vscode-vue-peek\",\"slug\":\"vscode-vue-peek\",\"link\":\"#vscode-vue-peek\",\"children\":[]},{\"level\":3,\"title\":\"Vetur\",\"slug\":\"vetur\",\"link\":\"#vetur\",\"children\":[]},{\"level\":3,\"title\":\"EsLint\",\"slug\":\"eslint\",\"link\":\"#eslint\",\"children\":[]},{\"level\":3,\"title\":\"Path Intellisense\",\"slug\":\"path-intellisense\",\"link\":\"#path-intellisense\",\"children\":[]},{\"level\":3,\"title\":\"HTML CSS Support\",\"slug\":\"html-css-support\",\"link\":\"#html-css-support\",\"children\":[]},{\"level\":3,\"title\":\"Git History\",\"slug\":\"git-history\",\"link\":\"#git-history\",\"children\":[]}]}]}],\"git\":{},\"filePathRelative\":\"guide/linux/vscode-guide.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
