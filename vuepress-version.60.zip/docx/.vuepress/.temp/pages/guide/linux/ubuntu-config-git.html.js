export const data = JSON.parse("{\"key\":\"v-12734c1a\",\"path\":\"/guide/linux/ubuntu-config-git.html\",\"title\":\"Ubuntu 配置 git\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"Ubuntu 配置 git\",\"slug\":\"ubuntu-配置-git\",\"link\":\"#ubuntu-配置-git\",\"children\":[{\"level\":2,\"title\":\"常用命令\",\"slug\":\"常用命令\",\"link\":\"#常用命令\",\"children\":[]},{\"level\":2,\"title\":\"重命名分支\",\"slug\":\"重命名分支\",\"link\":\"#重命名分支\",\"children\":[]},{\"level\":2,\"title\":\"配置SSH\",\"slug\":\"配置ssh\",\"link\":\"#配置ssh\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/linux/ubuntu-config-git.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
