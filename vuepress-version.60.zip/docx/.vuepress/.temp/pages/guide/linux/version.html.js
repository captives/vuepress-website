export const data = JSON.parse("{\"key\":\"v-775863b0\",\"path\":\"/guide/linux/version.html\",\"title\":\"版本发布命名\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"版本发布命名\",\"slug\":\"版本发布命名\",\"link\":\"#版本发布命名\",\"children\":[{\"level\":2,\"title\":\"常见版本的具体含义\",\"slug\":\"常见版本的具体含义\",\"link\":\"#常见版本的具体含义\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/linux/version.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
