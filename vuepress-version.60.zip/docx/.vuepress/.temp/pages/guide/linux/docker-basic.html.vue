<template><div><h1 id="docker-基本入门" tabindex="-1"><a class="header-anchor" href="#docker-基本入门" aria-hidden="true">#</a> Docker 基本入门</h1>
<h2 id="安装" tabindex="-1"><a class="header-anchor" href="#安装" aria-hidden="true">#</a> 安装</h2>
<h2 id="名词解释" tabindex="-1"><a class="header-anchor" href="#名词解释" aria-hidden="true">#</a> 名词解释</h2>
<ul>
<li>host				宿主机</li>
<li>image				镜像</li>
<li>container			容器</li>
<li>register			仓库</li>
<li>daemon			守护程序</li>
<li>client			客户端</li>
</ul>
<h2 id="启动" tabindex="-1"><a class="header-anchor" href="#启动" aria-hidden="true">#</a> 启动</h2>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> <span class="token function">service</span> <span class="token function">docker</span> start
</code></pre></div><h2 id="权限" tabindex="-1"><a class="header-anchor" href="#权限" aria-hidden="true">#</a> 权限</h2>
<h3 id="查看用户组与用户" tabindex="-1"><a class="header-anchor" href="#查看用户组与用户" aria-hidden="true">#</a> 查看用户组与用户</h3>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">vim</span> /etc/group
</code></pre></div><p><code v-pre>/etc/group</code>的内容包括用户组（Group）、用户组口令、GID及该用户组所包含的用户（User），每个用户组一条记录；格式如下：</p>
<blockquote>
<p>group_name:passwd:GID:user_list</p>
</blockquote>
<p>其中每条记录分四个字段：</p>
<ol>
<li>第一字段：用户组名称；</li>
<li>第二字段：用户组密码；</li>
<li>第三字段：GID</li>
<li>第四字段：用户列表，每个用户之间用,号分割；本字段可以为空；如果字段为空表示用户组为GID的用户名；</li>
</ol>
<h3 id="加入用户组" tabindex="-1"><a class="header-anchor" href="#加入用户组" aria-hidden="true">#</a> 加入用户组</h3>
<p>1.将登陆用户(seven) 加入到docker用户组中</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code>gpasswd <span class="token parameter variable">-a</span> seven <span class="token function">docker</span> 
</code></pre></div><p>2.添加当前用户到docker组</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code>newgrp <span class="token function">docker</span> 
</code></pre></div><h2 id="常用命令" tabindex="-1"><a class="header-anchor" href="#常用命令" aria-hidden="true">#</a> 常用命令</h2>
<ul>
<li><code v-pre>docker search</code>				查找镜像</li>
<li><code v-pre>docker pull</code>					获取image镜像</li>
<li><code v-pre>docker build</code>				创建image镜像</li>
<li><code v-pre>docker images</code>				列出image镜像</li>
<li><code v-pre>docker rmi</code>					删除image镜像</li>
<li><code v-pre>docker run</code>					运行container</li>
<li><code v-pre>docker ps</code>					列出container</li>
<li><code v-pre>docker rm</code>					删除container</li>
<li><code v-pre>docker cp</code>					在host和container之间拷贝文件</li>
<li><code v-pre>docker commit</code>				保存改动为新的image</li>
<li><code v-pre>docker logs</code>					日志查询</li>
</ul>
<p>1.查看docker信息</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> info
</code></pre></div><p>2.查看启动日志</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> logs <span class="token operator">&lt;</span><span class="token punctuation">{</span>CONTAINER<span class="token punctuation">}</span> <span class="token operator">|</span> <span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span><span class="token operator">></span>
</code></pre></div><p>3.查看正在运行的docker容器</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> <span class="token function">ps</span> -<span class="token operator">&lt;</span> l <span class="token operator">|</span> a <span class="token operator">></span>
</code></pre></div><p>4.停止正在运行的docker容器</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> stop  <span class="token operator">&lt;</span><span class="token punctuation">{</span>CONTAINER<span class="token punctuation">}</span> <span class="token operator">|</span> <span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span><span class="token operator">></span>
</code></pre></div><p>5.重启停止的docker容器</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> start  <span class="token operator">&lt;</span><span class="token punctuation">{</span>CONTAINER<span class="token punctuation">}</span> <span class="token operator">|</span> <span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span><span class="token operator">></span>
</code></pre></div><p>6.创建容器并映射端口</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> run -d<span class="token punctuation">(</span>后台运行<span class="token punctuation">)</span> -p<span class="token punctuation">(</span>指定开放端口，默认briage模式<span class="token punctuation">)</span> <span class="token number">8080</span><span class="token punctuation">(</span>主机端口<span class="token punctuation">)</span>:80<span class="token punctuation">(</span>容器端口<span class="token punctuation">)</span> nginx
</code></pre></div><div class="tip-block warning"><p class="title">注意：</p><p>[-p] 指定端口、[-P] 自动分配端口</p>
</div>
<p>7.检查端口是否开放</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">netstat</span> <span class="token parameter variable">-na</span> <span class="token operator">|</span> <span class="token function">grep</span> <span class="token number">8080</span>
</code></pre></div><p>8.映射磁盘目录</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> run <span class="token parameter variable">-v</span> /disk<span class="token punctuation">(</span>宿主目录<span class="token punctuation">)</span>:/sharedisk<span class="token punctuation">(</span>挂载目录<span class="token punctuation">)</span> seven/docker_demo<span class="token punctuation">(</span>镜像名<span class="token punctuation">)</span>
</code></pre></div><p>9.进入容器</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> <span class="token builtin class-name">exec</span> <span class="token parameter variable">-it</span> <span class="token operator">&lt;</span><span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span> <span class="token operator">|</span> <span class="token punctuation">{</span>NAMES<span class="token punctuation">}</span><span class="token operator">></span> <span class="token function">bash</span>
<span class="token function">docker</span> <span class="token builtin class-name">exec</span> <span class="token parameter variable">-it</span> <span class="token operator">&lt;</span><span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span> <span class="token operator">|</span> <span class="token punctuation">{</span>NAMES<span class="token punctuation">}</span><span class="token operator">></span> /bin/bash
<span class="token function">docker</span> <span class="token builtin class-name">exec</span> <span class="token parameter variable">-it</span> <span class="token operator">&lt;</span><span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span> <span class="token operator">|</span> <span class="token punctuation">{</span>NAMES<span class="token punctuation">}</span><span class="token operator">></span> <span class="token function">sh</span>
<span class="token function">docker</span> <span class="token builtin class-name">exec</span> <span class="token parameter variable">-it</span> <span class="token operator">&lt;</span><span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span> <span class="token operator">|</span> <span class="token punctuation">{</span>NAMES<span class="token punctuation">}</span><span class="token operator">></span> /bin/sh

</code></pre></div><p>10.获取容器/镜像的元数据</p>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> inspect <span class="token operator">&lt;</span><span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span><span class="token operator">></span>
</code></pre></div><ol start="11">
<li>查看移除容器</li>
</ol>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> <span class="token function">ps</span> <span class="token parameter variable">-a</span>
<span class="token function">docker</span> <span class="token function">rm</span> <span class="token operator">&lt;</span><span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span><span class="token operator">></span>
</code></pre></div><ol start="12">
<li>查看并移除镜像</li>
</ol>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> images
<span class="token function">docker</span> rmi <span class="token operator">&lt;</span><span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span><span class="token operator">></span>
</code></pre></div><ol start="13">
<li>从容器内拷贝文件到主机上</li>
</ol>
<div class="language-bash" data-ext="sh"><pre v-pre class="language-bash"><code><span class="token function">docker</span> <span class="token function">cp</span> <span class="token punctuation">{</span>CONTAINER ID<span class="token punctuation">}</span>:/var/www/html/index.html /disk/nodejs/webrtc 
</code></pre></div><h2 id="dockerfile-语法" tabindex="-1"><a class="header-anchor" href="#dockerfile-语法" aria-hidden="true">#</a> Dockerfile 语法</h2>
<ul>
<li><code v-pre>FROM</code>					base image</li>
<li><code v-pre>RUN</code>						执行命令</li>
<li><code v-pre>ADD</code>						添加文件（本地或者远程文件）</li>
<li><code v-pre>COPY</code>					拷贝文件（文件或者目录）</li>
<li><code v-pre>CMD</code>						执行命令</li>
<li><code v-pre>EXPOSE</code>					暴露端口</li>
<li><code v-pre>WORKDIR</code>					指定路径</li>
<li><code v-pre>MAINTAINER</code>					维护者</li>
<li><code v-pre>ENV</code>						设定环境变量</li>
<li><code v-pre>ENTRYPOINT</code>					容器入口</li>
<li><code v-pre>USER</code>					指定用户</li>
<li><code v-pre>VOLUME</code>					挂载点(mount point)</li>
</ul>
<h3 id="dockerfile-示例" tabindex="-1"><a class="header-anchor" href="#dockerfile-示例" aria-hidden="true">#</a> Dockerfile 示例</h3>
<p>1.创建nginx服务</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code><span class="token constant">FROM</span> ubuntu
<span class="token constant">MAINTAINER</span> docker_seven
<span class="token constant">RUN</span> sed <span class="token operator">-</span>i <span class="token string">'s/archive.ubuntu.com/mirrors.ustc.edu.cn/g'</span> <span class="token operator">/</span>etc<span class="token operator">/</span>apt<span class="token operator">/</span>sources<span class="token punctuation">.</span>list
<span class="token constant">RUN</span> apt<span class="token operator">-</span><span class="token keyword">get</span> update
<span class="token constant">RUN</span> apt<span class="token operator">-</span><span class="token keyword">get</span> install <span class="token operator">-</span>y nginx
<span class="token constant">COPY</span> index<span class="token punctuation">.</span>html <span class="token operator">/</span><span class="token keyword">var</span><span class="token operator">/</span>www<span class="token operator">/</span>html
#<span class="token constant">RUN</span> service nginx start
<span class="token constant">ENTRYPOINT</span> <span class="token punctuation">[</span><span class="token string">"/usr/sbin/nginx"</span><span class="token punctuation">,</span> <span class="token string">"-g"</span><span class="token punctuation">,</span> <span class="token string">"daemon off;"</span><span class="token punctuation">]</span>
<span class="token constant">EXPOSE</span> <span class="token number">80</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>1.pm2部署node项目</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code># 基于最新版的<span class="token constant">NODE</span>容器创建
<span class="token constant">FROM</span> keymetrics<span class="token operator">/</span>pm2<span class="token operator">:</span><span class="token number">14</span><span class="token operator">-</span>alpine
<span class="token constant">MAINTAINER</span> <span class="token string">"author"</span><span class="token operator">=</span><span class="token string">"seven@kaibo.ai"</span>
<span class="token constant">MAINTAINER</span> <span class="token string">"vendor"</span><span class="token operator">=</span><span class="token string">"kaibo"</span>

# 复制容器的执行脚本
<span class="token constant">WORKDIR</span> <span class="token operator">/</span>opt
<span class="token constant">COPY</span> <span class="token keyword">package</span><span class="token punctuation">.</span>json <span class="token keyword">package</span><span class="token operator">-</span>lock<span class="token punctuation">.</span>json <span class="token punctuation">.</span><span class="token operator">/</span>
<span class="token constant">RUN</span> npm i <span class="token operator">--</span>registry https<span class="token operator">:</span><span class="token operator">/</span><span class="token operator">/</span>registry<span class="token punctuation">.</span>npm<span class="token punctuation">.</span>taobao<span class="token punctuation">.</span>org
<span class="token constant">COPY</span> <span class="token punctuation">.</span> <span class="token punctuation">.</span><span class="token operator">/</span>

# 容器的执行命令
<span class="token constant">CMD</span> <span class="token punctuation">[</span><span class="token string">"pm2-runtime"</span><span class="token punctuation">,</span> <span class="token string">"start"</span><span class="token punctuation">,</span> <span class="token string">"index.js"</span><span class="token punctuation">]</span>

# 暴露端口映射
<span class="token constant">EXPOSE</span> <span class="token number">3000</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>编译并运行</p>
<div class="language-javascript line-numbers-mode" data-ext="js"><pre v-pre class="language-javascript"><code>echo <span class="token string">'build images ....'</span>
docker build <span class="token operator">-</span>t kaibo<span class="token operator">-</span>record<span class="token operator">:</span>v1<span class="token punctuation">.</span><span class="token number">1</span> <span class="token punctuation">.</span>

echo <span class="token string">'run images ....'</span>
docker run <span class="token operator">-</span>d <span class="token operator">-</span>p <span class="token number">3000</span><span class="token operator">:</span><span class="token number">3000</span> <span class="token operator">--</span>name<span class="token operator">=</span>kaibo<span class="token operator">-</span>record kaibo<span class="token operator">-</span>record<span class="token operator">:</span>v1<span class="token punctuation">.</span><span class="token number">1</span>

echo <span class="token string">'run complete!'</span>
docker ps <span class="token operator">-</span>a
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h1 id="docker-compose" tabindex="-1"><a class="header-anchor" href="#docker-compose" aria-hidden="true">#</a> Docker Compose</h1>
<p>Compose 是用于定义和运行多容器 Docker 应用程序的工具。通过 Compose，您可以使用 YML 文件来配置应用程序需要的所有服务。然后，使用一个命令，就可以从 YML 文件配置中创建并启动所有服务。</p>
<h2 id="安装-1" tabindex="-1"><a class="header-anchor" href="#安装-1" aria-hidden="true">#</a> 安装</h2>
<p><a href="https://docs.docker.com/compose/install/" target="_blank" rel="noopener noreferrer">Install Docker Compose<ExternalLinkIcon/></a></p>
<ul>
<li><a href="https://docs.docker.com/desktop/mac/install/" target="_blank" rel="noopener noreferrer">on macOS<ExternalLinkIcon/></a></li>
<li><a href="https://docs.docker.com/desktop/windows/install/" target="_blank" rel="noopener noreferrer">on Window<ExternalLinkIcon/></a></li>
<li><a href="">on Linux</a></li>
</ul>
<h2 id="常用命令-1" tabindex="-1"><a class="header-anchor" href="#常用命令-1" aria-hidden="true">#</a> 常用命令</h2>
<ul>
<li><code v-pre>build</code>					本地创建镜像</li>
<li><code v-pre>command</code>				覆盖缺省命令</li>
<li><code v-pre>depends_on</code>			连接容器</li>
<li><code v-pre>volumes</code>				卷</li>
<li><code v-pre>image</code>					pull镜像</li>
<li><code v-pre>up</code>						启动服务</li>
<li><code v-pre>stop</code>					停止服务</li>
<li><code v-pre>rm</code>						删除服务中的各个容器</li>
<li><code v-pre>logs</code>					观察各个容器的日志</li>
<li><code v-pre>ps</code>						列出服务相关的容器</li>
</ul>
<hr/>
</div></template>


