export const data = JSON.parse("{\"key\":\"v-0b009929\",\"path\":\"/guide/linux/go-basic.html\",\"title\":\"Go 基本入门\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"Go 基本入门\",\"slug\":\"go-基本入门\",\"link\":\"#go-基本入门\",\"children\":[{\"level\":2,\"title\":\"环境安装\",\"slug\":\"环境安装\",\"link\":\"#环境安装\",\"children\":[{\"level\":3,\"title\":\"下载\",\"slug\":\"下载\",\"link\":\"#下载\",\"children\":[]},{\"level\":3,\"title\":\"配置Go Proxy\",\"slug\":\"配置go-proxy\",\"link\":\"#配置go-proxy\",\"children\":[]},{\"level\":3,\"title\":\"VS Code 安装Go插件\",\"slug\":\"vs-code-安装go插件\",\"link\":\"#vs-code-安装go插件\",\"children\":[]},{\"level\":3,\"title\":\"测试\",\"slug\":\"测试\",\"link\":\"#测试\",\"children\":[]}]},{\"level\":2,\"title\":\"语言基础\",\"slug\":\"语言基础\",\"link\":\"#语言基础\",\"children\":[{\"level\":3,\"title\":\"import\",\"slug\":\"import\",\"link\":\"#import\",\"children\":[]}]}]},{\"level\":1,\"title\":\"学习资料\",\"slug\":\"学习资料\",\"link\":\"#学习资料\",\"children\":[]}],\"git\":{},\"filePathRelative\":\"guide/linux/go-basic.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
