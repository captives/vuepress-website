export const data = JSON.parse("{\"key\":\"v-6afd4071\",\"path\":\"/guide/linux/docker-basic.html\",\"title\":\"Docker 基本入门\",\"lang\":\"guide\",\"frontmatter\":{},\"headers\":[{\"level\":1,\"title\":\"Docker 基本入门\",\"slug\":\"docker-基本入门\",\"link\":\"#docker-基本入门\",\"children\":[{\"level\":2,\"title\":\"安装\",\"slug\":\"安装\",\"link\":\"#安装\",\"children\":[]},{\"level\":2,\"title\":\"名词解释\",\"slug\":\"名词解释\",\"link\":\"#名词解释\",\"children\":[]},{\"level\":2,\"title\":\"启动\",\"slug\":\"启动\",\"link\":\"#启动\",\"children\":[]},{\"level\":2,\"title\":\"权限\",\"slug\":\"权限\",\"link\":\"#权限\",\"children\":[{\"level\":3,\"title\":\"查看用户组与用户\",\"slug\":\"查看用户组与用户\",\"link\":\"#查看用户组与用户\",\"children\":[]},{\"level\":3,\"title\":\"加入用户组\",\"slug\":\"加入用户组\",\"link\":\"#加入用户组\",\"children\":[]}]},{\"level\":2,\"title\":\"常用命令\",\"slug\":\"常用命令\",\"link\":\"#常用命令\",\"children\":[]},{\"level\":2,\"title\":\"Dockerfile 语法\",\"slug\":\"dockerfile-语法\",\"link\":\"#dockerfile-语法\",\"children\":[{\"level\":3,\"title\":\"Dockerfile 示例\",\"slug\":\"dockerfile-示例\",\"link\":\"#dockerfile-示例\",\"children\":[]}]}]},{\"level\":1,\"title\":\"Docker Compose\",\"slug\":\"docker-compose\",\"link\":\"#docker-compose\",\"children\":[{\"level\":2,\"title\":\"安装\",\"slug\":\"安装-1\",\"link\":\"#安装-1\",\"children\":[]},{\"level\":2,\"title\":\"常用命令\",\"slug\":\"常用命令-1\",\"link\":\"#常用命令-1\",\"children\":[]}]}],\"git\":{},\"filePathRelative\":\"guide/linux/docker-basic.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
