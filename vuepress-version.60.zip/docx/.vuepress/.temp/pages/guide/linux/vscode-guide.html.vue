<template><div><h1 id="vscode-前端常用配置" tabindex="-1"><a class="header-anchor" href="#vscode-前端常用配置" aria-hidden="true">#</a> vscode 前端常用配置</h1>
<h2 id="配置" tabindex="-1"><a class="header-anchor" href="#配置" aria-hidden="true">#</a> 配置</h2>
<h2 id="常用插件" tabindex="-1"><a class="header-anchor" href="#常用插件" aria-hidden="true">#</a> 常用插件</h2>
<h3 id="vue-3-snippets" tabindex="-1"><a class="header-anchor" href="#vue-3-snippets" aria-hidden="true">#</a> Vue 3 Snippets</h3>
<blockquote>
<p>这个插件基于最新的 Vue 2 及 Vue 3 的 API 添加了代码片段。</p>
</blockquote>
<details class="tip-block details"><summary>查看 Vue 2、Vue 3 代码片段</summary><h4 id="vue-3-代码片段" tabindex="-1"><a class="header-anchor" href="#vue-3-代码片段" aria-hidden="true">#</a> Vue 3 代码片段</h4>
<p>包含常用 Vue3 代码片段，比如你输入 <code v-pre>reactive</code>，选择 <code v-pre>reactive</code> 的代码片段，则编辑器会自动帮你生成 <code v-pre>const data = reactive({...})</code> 代码，提高你的开发效率。</p>
<table>
<thead>
<tr>
<th>关键字</th>
<th>JavaScript 代码片段</th>
</tr>
</thead>
<tbody>
<tr>
<td><code v-pre>import</code></td>
<td><code v-pre>import {...} from &quot;@vue/composition-api&quot;</code></td>
</tr>
<tr>
<td><code v-pre>import</code></td>
<td><code v-pre>import {...} from 'vue'</code></td>
</tr>
<tr>
<td><code v-pre>newVue</code></td>
<td><code v-pre>newVue({...})</code></td>
</tr>
<tr>
<td><code v-pre>defineComponent</code></td>
<td><code v-pre>defineComponent({...})</code></td>
</tr>
<tr>
<td><code v-pre>export</code></td>
<td><code v-pre>export default { ... }</code></td>
</tr>
<tr>
<td><code v-pre>setup</code></td>
<td><code v-pre>setup(${...}) {...}</code></td>
</tr>
<tr>
<td><code v-pre>reactive</code></td>
<td><code v-pre>const data = reactive({...})</code></td>
</tr>
<tr>
<td><code v-pre>watch</code></td>
<td><code v-pre>watch(..., ...)</code></td>
</tr>
<tr>
<td><code v-pre>watchFn</code></td>
<td><code v-pre>watch(() =&gt; {...})</code></td>
</tr>
<tr>
<td><code v-pre>watchArray</code></td>
<td><code v-pre>watch([...]) =&gt; {...}</code></td>
</tr>
<tr>
<td><code v-pre>watchEffect</code></td>
<td><code v-pre>watchEffect(() =&gt; {...})</code></td>
</tr>
<tr>
<td><code v-pre>computed</code></td>
<td><code v-pre>computed(() =&gt; { get: () =&gt; {...}, set: () =&gt; {...}})</code></td>
</tr>
<tr>
<td><code v-pre>toRefs</code></td>
<td><code v-pre>toRefs(...)</code></td>
</tr>
<tr>
<td><code v-pre>ref</code></td>
<td><code v-pre>ref(...)</code></td>
</tr>
<tr>
<td><code v-pre>props</code></td>
<td><code v-pre>props(...)</code></td>
</tr>
<tr>
<td><code v-pre>onBeforeMount</code></td>
<td><code v-pre>onBeforeMount(...)</code></td>
</tr>
<tr>
<td><code v-pre>onMounted</code></td>
<td><code v-pre>onMounted(...)</code></td>
</tr>
<tr>
<td><code v-pre>onBeforeUpdate</code></td>
<td><code v-pre>onBeforeUpdate(...)</code></td>
</tr>
<tr>
<td><code v-pre>onUpdated</code></td>
<td><code v-pre>onUpdated(...)</code></td>
</tr>
<tr>
<td><code v-pre>onBeforeUnmount</code></td>
<td><code v-pre>onBeforeUnmount(...)</code></td>
</tr>
<tr>
<td><code v-pre>onUnmounted</code></td>
<td><code v-pre>onUnmounted(...)</code></td>
</tr>
<tr>
<td><code v-pre>onErrorCaptured</code></td>
<td><code v-pre>onErrorCaptured(...)</code></td>
</tr>
</tbody>
</table>
<h4 id="vue-2-代码片段" tabindex="-1"><a class="header-anchor" href="#vue-2-代码片段" aria-hidden="true">#</a> Vue 2 代码片段</h4>
<p>兼容所有常用 Vue 2 代码片段，如下：</p>
<table>
<thead>
<tr>
<th>关键字</th>
<th>JavaScript 代码片段</th>
</tr>
</thead>
<tbody>
<tr>
<td><code v-pre>import</code></td>
<td><code v-pre>import ... from ...</code></td>
</tr>
<tr>
<td><code v-pre>newVue</code></td>
<td><code v-pre>new Vue({...})</code></td>
</tr>
<tr>
<td><code v-pre>VueConfigSilent</code></td>
<td><code v-pre>Vue.config.silent = true</code></td>
</tr>
<tr>
<td><code v-pre>VueConfigOptionMergeStrategies</code></td>
<td><code v-pre>Vue.config.optionMergeStrategies</code></td>
</tr>
<tr>
<td><code v-pre>VueConfigDevtools</code></td>
<td><code v-pre>Vue.config.devtools = true</code></td>
</tr>
<tr>
<td><code v-pre>VueConfigErrorHandler</code></td>
<td><code v-pre>Vue.config.errorHandler = function (err, vm, info) {...}</code></td>
</tr>
<tr>
<td><code v-pre>VueConfigWarnHandler</code></td>
<td><code v-pre>Vue.config.warnHandler = function (msg, vm, trace) {...}</code></td>
</tr>
<tr>
<td><code v-pre>VueConfigIgnoredElements</code></td>
<td><code v-pre>Vue.config.ignoredElements = ['']</code> \</td>
</tr>
<tr>
<td><code v-pre>VueConfigKeyCodes</code></td>
<td><code v-pre>Vue.config.keyCodes</code></td>
</tr>
<tr>
<td><code v-pre>VueConfigPerformance</code></td>
<td><code v-pre>Vue.config.performance = true</code></td>
</tr>
<tr>
<td><code v-pre>VueConfigProductionTip</code></td>
<td><code v-pre>Vue.config.productionTip = false</code></td>
</tr>
<tr>
<td><code v-pre>vueExtend</code></td>
<td><code v-pre>Vue.extend( options )</code></td>
</tr>
<tr>
<td><code v-pre>VueNextTick</code></td>
<td><code v-pre>Vue.nextTick( callback, [context] )</code></td>
</tr>
<tr>
<td><code v-pre>VueNextTickThen</code></td>
<td><code v-pre>Vue.nextTick( callback, [context] ).then(function(){ })</code></td>
</tr>
<tr>
<td><code v-pre>VueSet</code></td>
<td><code v-pre>Vue.set( target, key, value )</code></td>
</tr>
<tr>
<td><code v-pre>VueDelete</code></td>
<td><code v-pre>Vue.delete( target, key )</code></td>
</tr>
<tr>
<td><code v-pre>VueDirective</code></td>
<td><code v-pre>Vue.directive( id, [definition] )</code></td>
</tr>
<tr>
<td><code v-pre>VueFilter</code></td>
<td><code v-pre>Vue.filter( id, [definition] )</code></td>
</tr>
<tr>
<td><code v-pre>VueComponent</code></td>
<td><code v-pre>Vue.component( id, [definition] )</code></td>
</tr>
<tr>
<td><code v-pre>VueUse</code></td>
<td><code v-pre>Vue.use( plugin )</code></td>
</tr>
<tr>
<td><code v-pre>VueMixin</code></td>
<td><code v-pre>Vue.mixin({ mixin })</code></td>
</tr>
<tr>
<td><code v-pre>VueCompile</code></td>
<td><code v-pre>Vue.compile( template )</code></td>
</tr>
<tr>
<td><code v-pre>VueVersion</code></td>
<td><code v-pre>Vue.version</code></td>
</tr>
<tr>
<td><code v-pre>data</code></td>
<td><code v-pre>data() { return {} }</code></td>
</tr>
<tr>
<td><code v-pre>watchWithOptions</code></td>
<td><code v-pre>key: { deep: true, immediate: true, handler: function () { } }</code></td>
</tr>
<tr>
<td><code v-pre>vmData</code></td>
<td><code v-pre>${this, vm}.$data</code></td>
</tr>
<tr>
<td><code v-pre>vmProps</code></td>
<td><code v-pre>${this, vm}.$props</code></td>
</tr>
<tr>
<td><code v-pre>vmEl</code></td>
<td><code v-pre>${this, vm}.$el</code></td>
</tr>
<tr>
<td><code v-pre>vmOptions</code></td>
<td><code v-pre>${this, vm}.$options</code></td>
</tr>
<tr>
<td><code v-pre>vmParent</code></td>
<td><code v-pre>${this, vm}.$parent</code></td>
</tr>
<tr>
<td><code v-pre>vmRoot</code></td>
<td><code v-pre>${this, vm}.$root</code></td>
</tr>
<tr>
<td><code v-pre>vmChildren</code></td>
<td><code v-pre>${this, vm}.$children</code></td>
</tr>
<tr>
<td><code v-pre>vmSlots</code></td>
<td><code v-pre>${this, vm}.$slots</code></td>
</tr>
<tr>
<td><code v-pre>vmScopedSlots</code></td>
<td><code v-pre>${this, vm}.$scopedSlots.default({})</code></td>
</tr>
<tr>
<td><code v-pre>vmRefs</code></td>
<td><code v-pre>${this, vm}.$refs</code></td>
</tr>
<tr>
<td><code v-pre>vmIsServer</code></td>
<td><code v-pre>${this, vm}.$isServer</code></td>
</tr>
<tr>
<td><code v-pre>vmAttrs</code></td>
<td><code v-pre>${this, vm}.$attrs</code></td>
</tr>
<tr>
<td><code v-pre>vmListeners</code></td>
<td><code v-pre>${this, vm}.listeners</code></td>
</tr>
<tr>
<td><code v-pre>vmWatch</code></td>
<td><code v-pre>${this, vm}.$watch( expOrFn, callback, [options] )</code></td>
</tr>
<tr>
<td><code v-pre>vmSet</code></td>
<td><code v-pre>${this, vm}.$set( object, key, value )</code></td>
</tr>
<tr>
<td><code v-pre>vmDelete</code></td>
<td><code v-pre>${this, vm}.$delete( object, key )</code></td>
</tr>
<tr>
<td><code v-pre>vmOn</code></td>
<td><code v-pre>${this, vm}.$on( event, callback )</code></td>
</tr>
<tr>
<td><code v-pre>vmOnce</code></td>
<td><code v-pre>${this, vm}.$once( event, callback )</code></td>
</tr>
<tr>
<td><code v-pre>vmOff</code></td>
<td><code v-pre>${this, vm}.$off( [event, callback] )</code></td>
</tr>
<tr>
<td><code v-pre>vmEmit</code></td>
<td><code v-pre>${this, vm}.$emit( event, […args] )</code></td>
</tr>
<tr>
<td><code v-pre>vmMount</code></td>
<td><code v-pre>${this, vm}.$mount( [elementOrSelector] )</code></td>
</tr>
<tr>
<td><code v-pre>vmForceUpdate</code></td>
<td><code v-pre>${this, vm}.$forceUpdate()</code></td>
</tr>
<tr>
<td><code v-pre>vmNextTick</code></td>
<td><code v-pre>${this, vm}.$nextTick( callback )</code></td>
</tr>
<tr>
<td><code v-pre>vmDestroy</code></td>
<td><code v-pre>${this, vm}.$destroy()</code></td>
</tr>
<tr>
<td><code v-pre>renderer</code></td>
<td><code v-pre>const renderer = require('vue-server-renderer').createRenderer()</code></td>
</tr>
<tr>
<td><code v-pre>createRenderer</code></td>
<td><code v-pre>createRenderer({ })</code></td>
</tr>
<tr>
<td><code v-pre>preventDefault</code></td>
<td><code v-pre>preventDefault();</code></td>
</tr>
<tr>
<td><code v-pre>stopPropagation</code></td>
<td><code v-pre>stopPropagation();</code></td>
</tr>
</tbody>
</table>
<br />
<table>
<thead>
<tr>
<th>关键字</th>
<th>HTML 代码片段</th>
</tr>
</thead>
<tbody>
<tr>
<td><code v-pre>template</code></td>
<td><code v-pre>&lt;template&gt;&lt;/template&gt;</code></td>
</tr>
<tr>
<td><code v-pre>script</code></td>
<td><code v-pre>&lt;script&gt;&lt;/script&gt;</code></td>
</tr>
<tr>
<td><code v-pre>style</code></td>
<td><code v-pre>&lt;style&gt;&lt;/style&gt;</code></td>
</tr>
<tr>
<td><code v-pre>vText</code></td>
<td><code v-pre>v-text=msg</code></td>
</tr>
<tr>
<td><code v-pre>vHtml</code></td>
<td><code v-pre>v-html=html</code></td>
</tr>
<tr>
<td><code v-pre>vShow</code></td>
<td><code v-pre>v-show</code></td>
</tr>
<tr>
<td><code v-pre>vIf</code></td>
<td><code v-pre>v-if</code></td>
</tr>
<tr>
<td><code v-pre>vElse</code></td>
<td><code v-pre>v-else</code></td>
</tr>
<tr>
<td><code v-pre>vElseIf</code></td>
<td><code v-pre>v-else-if</code></td>
</tr>
<tr>
<td><code v-pre>vForWithoutKey</code></td>
<td><code v-pre>v-for</code></td>
</tr>
<tr>
<td><code v-pre>vFor</code></td>
<td><code v-pre>v-for=&quot;&quot; :key=&quot;&quot;</code></td>
</tr>
<tr>
<td><code v-pre>vOn</code></td>
<td><code v-pre>v-on</code></td>
</tr>
<tr>
<td><code v-pre>vBind</code></td>
<td><code v-pre>v-bind</code></td>
</tr>
<tr>
<td><code v-pre>vModel</code></td>
<td><code v-pre>v-model</code></td>
</tr>
<tr>
<td><code v-pre>vPre</code></td>
<td><code v-pre>v-pre</code></td>
</tr>
<tr>
<td><code v-pre>vCloak</code></td>
<td><code v-pre>v-cloak</code></td>
</tr>
<tr>
<td><code v-pre>vOnce</code></td>
<td><code v-pre>v-once</code></td>
</tr>
<tr>
<td><code v-pre>key</code></td>
<td><code v-pre>:key</code></td>
</tr>
<tr>
<td><code v-pre>ref</code></td>
<td><code v-pre>ref</code></td>
</tr>
<tr>
<td><code v-pre>slotA</code></td>
<td><code v-pre>slot=&quot;&quot;</code></td>
</tr>
<tr>
<td><code v-pre>slotE</code></td>
<td><code v-pre>&lt;slot&gt;&lt;/slot&gt;</code></td>
</tr>
<tr>
<td><code v-pre>slotScope</code></td>
<td><code v-pre>slot-scope=&quot;&quot;</code></td>
</tr>
<tr>
<td><code v-pre>component</code></td>
<td><code v-pre>&lt;component :is=''&gt;&lt;/component&gt;</code></td>
</tr>
<tr>
<td><code v-pre>keepAlive</code></td>
<td><code v-pre>&lt;keep-alive&gt;&lt;/keep-alive&gt;</code></td>
</tr>
<tr>
<td><code v-pre>transition</code></td>
<td><code v-pre>&lt;transition&gt;&lt;/transition&gt;</code></td>
</tr>
<tr>
<td><code v-pre>transitionGroup</code></td>
<td><code v-pre>&lt;transition-group&gt;&lt;/transition-group&gt;</code></td>
</tr>
<tr>
<td><code v-pre>enterClass</code></td>
<td><code v-pre>enter-class=''</code></td>
</tr>
<tr>
<td><code v-pre>leaveClass</code></td>
<td><code v-pre>leave-class=''</code></td>
</tr>
<tr>
<td><code v-pre>appearClass</code></td>
<td><code v-pre>appear-class=''</code></td>
</tr>
<tr>
<td><code v-pre>enterToClass</code></td>
<td><code v-pre>enter-to-class=''</code></td>
</tr>
<tr>
<td><code v-pre>leaveToClass</code></td>
<td><code v-pre>leave-to-class=''</code></td>
</tr>
<tr>
<td><code v-pre>appearToClass</code></td>
<td><code v-pre>appear-to-class=''</code></td>
</tr>
<tr>
<td><code v-pre>enterActiveClass</code></td>
<td><code v-pre>enter-active-class=''</code></td>
</tr>
<tr>
<td><code v-pre>leaveActiveClass</code></td>
<td><code v-pre>leave-active-class=''</code></td>
</tr>
<tr>
<td><code v-pre>appearActiveClass</code></td>
<td><code v-pre>appear-active-class=''</code></td>
</tr>
<tr>
<td><code v-pre>beforeEnterEvent</code></td>
<td><code v-pre>@before-enter=''</code></td>
</tr>
<tr>
<td><code v-pre>beforeLeaveEvent</code></td>
<td><code v-pre>@before-leave=''</code></td>
</tr>
<tr>
<td><code v-pre>beforeAppearEvent</code></td>
<td><code v-pre>@before-appear=''</code></td>
</tr>
<tr>
<td><code v-pre>enterEvent</code></td>
<td><code v-pre>@enter=''</code></td>
</tr>
<tr>
<td><code v-pre>leaveEvent</code></td>
<td><code v-pre>@leave=''</code></td>
</tr>
<tr>
<td><code v-pre>appearEvent</code></td>
<td><code v-pre>@appear=''</code></td>
</tr>
<tr>
<td><code v-pre>afterEnterEvent</code></td>
<td><code v-pre>@after-enter=''</code></td>
</tr>
<tr>
<td><code v-pre>afterLeaveEvent</code></td>
<td><code v-pre>@after-leave=''</code></td>
</tr>
<tr>
<td><code v-pre>afterAppearEvent</code></td>
<td><code v-pre>@after-appear=''</code></td>
</tr>
<tr>
<td><code v-pre>enterCancelledEvent</code></td>
<td><code v-pre>@enter-cancelled=''</code></td>
</tr>
<tr>
<td><code v-pre>leaveCancelledEvent</code></td>
<td><code v-pre>@leave-cancelled=''</code></td>
</tr>
<tr>
<td><code v-pre>appearCancelledEvent</code></td>
<td><code v-pre>@appear-cancelled=''</code></td>
</tr>
</tbody>
</table>
<br />
<table>
<thead>
<tr>
<th>关键字</th>
<th>Vue Router 代码片段</th>
</tr>
</thead>
<tbody>
<tr>
<td><code v-pre>routerLink</code></td>
<td><code v-pre>&lt;router-link&gt;&lt;/router-link&gt;</code></td>
</tr>
<tr>
<td><code v-pre>routerView</code></td>
<td><code v-pre>&lt;router-view&gt;&lt;/router-view&gt;</code></td>
</tr>
<tr>
<td><code v-pre>to</code></td>
<td><code v-pre>to=&quot;&quot;</code></td>
</tr>
<tr>
<td><code v-pre>tag</code></td>
<td><code v-pre>tag=&quot;&quot;</code></td>
</tr>
<tr>
<td><code v-pre>newVueRouter</code></td>
<td><code v-pre>const router = newVueRouter({ })</code></td>
</tr>
<tr>
<td><code v-pre>routerBeforeEach</code></td>
<td><code v-pre>router.beforeEach((to, from, next) =&gt; { }</code></td>
</tr>
<tr>
<td><code v-pre>routerBeforeResolve</code></td>
<td><code v-pre>router.beforeResolve((to, from, next) =&gt; { }</code></td>
</tr>
<tr>
<td><code v-pre>routerAfterEach</code></td>
<td><code v-pre>router.afterEach((to, from) =&gt; { }</code></td>
</tr>
<tr>
<td><code v-pre>routerPush</code></td>
<td><code v-pre>router.push()</code></td>
</tr>
<tr>
<td><code v-pre>routerReplace</code></td>
<td><code v-pre>router.replace()</code></td>
</tr>
<tr>
<td><code v-pre>routerGo</code></td>
<td><code v-pre>router.back()</code></td>
</tr>
<tr>
<td><code v-pre>routerBack</code></td>
<td><code v-pre>router.push()</code></td>
</tr>
<tr>
<td><code v-pre>routerForward</code></td>
<td><code v-pre>router.forward()</code></td>
</tr>
<tr>
<td><code v-pre>routerGetMatchedComponents</code></td>
<td><code v-pre>router.getMatchedComponents()</code></td>
</tr>
<tr>
<td><code v-pre>routerResolve</code></td>
<td><code v-pre>router.resolve()</code></td>
</tr>
<tr>
<td><code v-pre>routerAddRoutes</code></td>
<td><code v-pre>router.addRoutes()</code></td>
</tr>
<tr>
<td><code v-pre>routerOnReady</code></td>
<td><code v-pre>router.onReady()</code></td>
</tr>
<tr>
<td><code v-pre>routerOnError</code></td>
<td><code v-pre>router.onError()</code></td>
</tr>
<tr>
<td><code v-pre>routes</code></td>
<td><code v-pre>routes: []</code></td>
</tr>
<tr>
<td><code v-pre>beforeEnter</code></td>
<td><code v-pre>beforeEnter: (to, from, next) =&gt; { }</code></td>
</tr>
<tr>
<td><code v-pre>beforeRouteEnter</code></td>
<td><code v-pre>beforeRouteEnter (to, from, next) { }</code></td>
</tr>
<tr>
<td><code v-pre>beforeRouteLeave</code></td>
<td><code v-pre>beforeRouteLeave (to, from, next) { }</code></td>
</tr>
<tr>
<td><code v-pre>scrollBehavior</code></td>
<td><code v-pre>scrollBehavior (to, from, savedPosition) { }</code></td>
</tr>
</tbody>
</table>
<br />
<table>
<thead>
<tr>
<th>关键字</th>
<th>Vuex 代码片段</th>
</tr>
</thead>
<tbody>
<tr>
<td><code v-pre>newVuexStore</code></td>
<td><code v-pre>const store = new Vuex.Store({})</code></td>
</tr>
<tr>
<td><code v-pre>mapGetters</code></td>
<td><code v-pre>import { mapGetters } from 'vuex'</code></td>
</tr>
<tr>
<td><code v-pre>mapMutations</code></td>
<td><code v-pre>import { mapMutations } from 'vuex'</code></td>
</tr>
<tr>
<td><code v-pre>mapActions</code></td>
<td><code v-pre>import { mapActions } from 'vuex'</code></td>
</tr>
<tr>
<td><code v-pre>state</code></td>
<td><code v-pre>state</code></td>
</tr>
<tr>
<td><code v-pre>mutations</code></td>
<td><code v-pre>mutations</code></td>
</tr>
<tr>
<td><code v-pre>actions</code></td>
<td><code v-pre>actions</code></td>
</tr>
<tr>
<td><code v-pre>modules</code></td>
<td><code v-pre>modules</code></td>
</tr>
<tr>
<td><code v-pre>plugins</code></td>
<td><code v-pre>plugins</code></td>
</tr>
<tr>
<td><code v-pre>dispatch</code></td>
<td><code v-pre>dispatch</code></td>
</tr>
<tr>
<td><code v-pre>subscribe</code></td>
<td><code v-pre>subscribe</code></td>
</tr>
<tr>
<td><code v-pre>registerModule</code></td>
<td><code v-pre>registerModule</code></td>
</tr>
<tr>
<td><code v-pre>unregisterModule</code></td>
<td><code v-pre>unregisterModule</code></td>
</tr>
<tr>
<td><code v-pre>hotUpdate</code></td>
<td><code v-pre>hotUpdate</code></td>
</tr>
</tbody>
</table>
<br />
<table>
<thead>
<tr>
<th>关键字</th>
<th>Nuxt.js 代码片段</th>
</tr>
</thead>
<tbody>
<tr>
<td><code v-pre>nuxt</code></td>
<td><code v-pre>&lt;nuxt/&gt;</code></td>
</tr>
<tr>
<td><code v-pre>nuxtChild</code></td>
<td><code v-pre>&lt;nuxt-child/&gt;</code></td>
</tr>
<tr>
<td><code v-pre>nuxtLink</code></td>
<td><code v-pre>&lt;nuxt-link to=&quot;&quot;/&gt;</code></td>
</tr>
<tr>
<td><code v-pre>asyncData</code></td>
<td><code v-pre>asyncData() {}</code></td>
</tr>
</tbody>
</table>
<h4 id="插件设置" tabindex="-1"><a class="header-anchor" href="#插件设置" aria-hidden="true">#</a> 插件设置</h4>
<p>你可以在插件的选项中自定义代码格式化的格式，便于定制你的 <code v-pre>vue</code> 代码格式，配置参数如下：</p>
<div class="language-json line-numbers-mode" data-ext="json"><pre v-pre class="language-json"><code>vue3snippets.arrowParens
vue3snippets.bracketSpacing
vue3snippets.endOfLine
vue3snippets.htmlWhitespaceSensitivity
vue3snippets.insertPragma
vue3snippets.jsxBracketSameLine
vue3snippets.jsxSingleQuote
vue3snippets.printWidth
vue3snippets.proseWrap
vue3snippets.quoteProps
vue3snippets.requirePragma
vue3snippets.semi
vue3snippets.singleQuote
vue3snippets.tabWidth
vue3snippets.trailingComma
vue3snippets.useTabs
vue3snippets.vueIndentScriptAndStyle
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><table>
<thead>
<tr>
<th>键值</th>
<th>例子</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td>vue3snippets.printWidth</td>
<td>10/20/30/40/n</td>
<td>80</td>
</tr>
<tr>
<td>vue3snippets.tabWidth</td>
<td>1/2/3/4/n</td>
<td>2</td>
</tr>
<tr>
<td>vue3snippets.singleQuote</td>
<td>false/true</td>
<td>false</td>
</tr>
<tr>
<td>vue3snippets.trailingComma</td>
<td>none/es5/all</td>
<td>es5</td>
</tr>
<tr>
<td>vue3snippets.bracketSpacing</td>
<td>true</td>
<td>true</td>
</tr>
<tr>
<td>vue3snippets.jsxBracketSameLine</td>
<td>false/true</td>
<td>false</td>
</tr>
<tr>
<td>vue3snippets.semi</td>
<td>false/true</td>
<td>true</td>
</tr>
<tr>
<td>vue3snippets.requirePragma</td>
<td>false/true</td>
<td>false</td>
</tr>
<tr>
<td>vue3snippets.insertPragma</td>
<td>false/true</td>
<td>false</td>
</tr>
<tr>
<td>vue3snippets.useTabs</td>
<td>false/true</td>
<td>false</td>
</tr>
<tr>
<td>vue3snippets.proseWrap</td>
<td>preserve/always/never</td>
<td>preserve</td>
</tr>
<tr>
<td>vue3snippets.arrowParens</td>
<td>avoid/always</td>
<td>always</td>
</tr>
<tr>
<td>vue3snippets.jsxSingleQuote</td>
<td>false/true</td>
<td>false</td>
</tr>
<tr>
<td>vue3snippets.htmlWhitespaceSensitivity</td>
<td>css/strict/ignore</td>
<td>css</td>
</tr>
<tr>
<td>vue3snippets.vueIndentScriptAndStyle</td>
<td>false/true</td>
<td>false</td>
</tr>
<tr>
<td>vue3snippets.endOfLine</td>
<td>auto/lf/crlf/cr</td>
<td>lf</td>
</tr>
<tr>
<td>vue3snippets.quoteProps</td>
<td>as-needed/consistent/preserve</td>
<td>as-needed</td>
</tr>
</tbody>
</table>
<h4 id="vue-2-3-详细教程" tabindex="-1"><a class="header-anchor" href="#vue-2-3-详细教程" aria-hidden="true">#</a> Vue 2/3 详细教程</h4>
<p>附赠一些 Vue 中文教程，希望能帮助你快速上手：</p>
<ul>
<li><a href="https://github.com/Wscats/vue-cli" target="_blank" rel="noopener noreferrer">《Vue 3.0 教程》<ExternalLinkIcon/></a></li>
<li><a href="https://github.com/Wscats/vue-tutorial" target="_blank" rel="noopener noreferrer">《Vue 2.0 教程》<ExternalLinkIcon/></a></li>
</ul>
</details>
<h3 id="vscode-vue-peek" tabindex="-1"><a class="header-anchor" href="#vscode-vue-peek" aria-hidden="true">#</a> vscode-vue-peek</h3>
<blockquote>
<p>为.Vue的单文件组件中的组件和文件名提供了Go To Definition和Peek Definition支持。它允许快速跳转到或浏览作为组件（来自模板）或模块导入（来自脚本）引用的文件。</p>
</blockquote>
<h3 id="vetur" tabindex="-1"><a class="header-anchor" href="#vetur" aria-hidden="true">#</a> Vetur</h3>
<blockquote>
<p><a href="https://vuejs.github.io/vetur/" target="_blank" rel="noopener noreferrer">Vetur<ExternalLinkIcon/></a>支持.vue文件的语法高亮显示，除了支持template模板以外，还支持大多数主流的前端开发脚本和插件，比如Sass和TypeScript。</p>
</blockquote>
<h3 id="eslint" tabindex="-1"><a class="header-anchor" href="#eslint" aria-hidden="true">#</a> EsLint</h3>
<blockquote>
<p>语法纠错</p>
</blockquote>
<h3 id="path-intellisense" tabindex="-1"><a class="header-anchor" href="#path-intellisense" aria-hidden="true">#</a> Path Intellisense</h3>
<blockquote>
<p>自动路径补全</p>
</blockquote>
<h3 id="html-css-support" tabindex="-1"><a class="header-anchor" href="#html-css-support" aria-hidden="true">#</a> HTML CSS Support</h3>
<blockquote>
<p>让 html 标签上写class 智能提示当前项目所支持的样式, <a href="https://marketplace.visualstudio.com/items?itemName=ecmel.vscode-html-css" target="_blank" rel="noopener noreferrer">查看详细信息 &gt;&gt;<ExternalLinkIcon/></a></p>
</blockquote>
<h3 id="git-history" tabindex="-1"><a class="header-anchor" href="#git-history" aria-hidden="true">#</a> Git History</h3>
<blockquote>
<p>Git History 是一个可以轻松快速浏览 GitHub 文件操作历史记录的工具，该工具的功能和使用方法简洁明了，只要将任何文件的 URL 中的“github.com”替换成“github.githistory.xyz”即可以动画的方式快速查看该文件的修改历史记录。 <a href="https://marketplace.visualstudio.com/items?itemName=donjayamanne.githistory" target="_blank" rel="noopener noreferrer">查看详细信息 &gt;&gt;<ExternalLinkIcon/></a></p>
</blockquote>
<hr/>
</div></template>


