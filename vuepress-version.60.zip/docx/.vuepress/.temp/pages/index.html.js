export const data = JSON.parse("{\"key\":\"v-8daa1a0e\",\"path\":\"/\",\"title\":\"Home\",\"lang\":\"/\",\"frontmatter\":{\"home\":true,\"title\":\"Home\",\"heroImage\":\"./assets/images/logo.svg\",\"actions\":[{\"text\":\"Get Started\",\"link\":\"/guide\",\"type\":\"primary\"},{\"text\":\"GitHub →\",\"link\":\"https://www.github.com/captives\",\"type\":\"secondary\"}],\"features\":[{\"title\":\"Guide\",\"details\":\"代码片段\"},{\"title\":\"Poetry\",\"details\":\"古诗词系列\"},{\"title\":\"Tutorial\",\"details\":\"教程系列\"}],\"footer\":\"MIT Licensed | Copyright © 2018-present Evan You\"},\"headers\":[],\"git\":{},\"filePathRelative\":\"README.md\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
