<template><div><!-- <h2>{{title}}</h2> -->
<!-- <NpmBadge></NpmBadge> -->
<p>注释： 全局组件</p>
<!-- <VueSite>{{title}}</VueSite> --></div></template>


