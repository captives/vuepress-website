import {
  Options,
  Vue,
  createDecorator,
  mixins
} from "./chunk-UHG5UZPX.js";
import {
  computed2 as computed,
  inject
} from "./chunk-S7PK7LHJ.js";
import "./chunk-SB46YUIN.js";

// node_modules/_vue-property-decorator@10.0.0-rc.3@vue-property-decorator/lib/decorators/Emit.js
var hyphenateRE = /\B([A-Z])/g;
var hyphenate = (str) => str.replace(hyphenateRE, "-$1").toLowerCase();
function Emit(event) {
  return createDecorator((componentOptions, propertyKey) => {
    const emitName = event || hyphenate(propertyKey);
    componentOptions.emits || (componentOptions.emits = []);
    componentOptions.emits.push(emitName);
    const original = componentOptions.methods[propertyKey];
    componentOptions.methods[propertyKey] = function emitter(...args) {
      const emit = (returnValue2) => {
        if (returnValue2 === void 0) {
          if (args.length === 0) {
            this.$emit(emitName);
          } else if (args.length === 1) {
            this.$emit(emitName, args[0]);
          } else {
            this.$emit(emitName, ...args);
          }
        } else {
          args.unshift(returnValue2);
          this.$emit(emitName, ...args);
        }
      };
      const returnValue = original.apply(this, args);
      if (isPromise(returnValue)) {
        returnValue.then(emit);
      } else {
        emit(returnValue);
      }
      return returnValue;
    };
  });
}
function isPromise(obj) {
  return obj instanceof Promise || obj && typeof obj.then === "function";
}

// node_modules/_vue-property-decorator@10.0.0-rc.3@vue-property-decorator/lib/decorators/Inject.js
function Inject(options = /* @__PURE__ */ Object.create(null)) {
  return createDecorator((componentOptions, key) => {
    const originalSetup = componentOptions.setup;
    componentOptions.setup = (props, ctx) => {
      const result = originalSetup === null || originalSetup === void 0 ? void 0 : originalSetup(props, ctx);
      const injectedValue = inject(options.from || key, options.default);
      return Object.assign(Object.assign({}, result), { [key]: injectedValue });
    };
  });
}

// node_modules/_vue-property-decorator@10.0.0-rc.3@vue-property-decorator/lib/decorators/Model.js
function Model(propName, propOptions) {
  return createDecorator((componentOptions, key) => {
    const eventName = `update:${propName}`;
    componentOptions.props || (componentOptions.props = /* @__PURE__ */ Object.create(null));
    componentOptions.props[propName] = propOptions;
    componentOptions.emits || (componentOptions.emits = []);
    componentOptions.emits.push(eventName);
    componentOptions.computed || (componentOptions.computed = /* @__PURE__ */ Object.create(null));
    componentOptions.computed[key] = {
      get() {
        return this[propName];
      },
      set(newValue) {
        this.$emit(eventName, newValue);
      }
    };
  });
}

// node_modules/_vue-property-decorator@10.0.0-rc.3@vue-property-decorator/lib/decorators/Prop.js
function Prop(propOptions) {
  return createDecorator((componentOptions, key) => {
    componentOptions.props || (componentOptions.props = /* @__PURE__ */ Object.create(null));
    componentOptions.props[key] = propOptions;
  });
}

// node_modules/_vue-property-decorator@10.0.0-rc.3@vue-property-decorator/lib/decorators/Provide.js
function Provide(options) {
  return createDecorator((componentOptions, key) => {
    const originalProvide = componentOptions.provide;
    componentOptions.provide = function() {
      const providedValue = typeof originalProvide === "function" ? originalProvide.call(this) : originalProvide;
      return Object.assign(Object.assign({}, providedValue), { [(options === null || options === void 0 ? void 0 : options.to) || key]: (options === null || options === void 0 ? void 0 : options.reactive) ? computed(() => this[key]) : this[key] });
    };
  });
}

// node_modules/_vue-property-decorator@10.0.0-rc.3@vue-property-decorator/lib/decorators/Ref.js
function Ref(refKey) {
  return createDecorator((componentOptions, key) => {
    componentOptions.computed || (componentOptions.computed = /* @__PURE__ */ Object.create(null));
    componentOptions.computed[key] = {
      cache: false,
      get() {
        return this.$refs[refKey || key];
      }
    };
  });
}

// node_modules/_vue-property-decorator@10.0.0-rc.3@vue-property-decorator/lib/decorators/Watch.js
function Watch(path, watchOptions) {
  return createDecorator((componentOptions, handler) => {
    componentOptions.watch || (componentOptions.watch = /* @__PURE__ */ Object.create(null));
    const watch = componentOptions.watch;
    if (typeof watch[path] === "object" && !Array.isArray(watch[path])) {
      watch[path] = [watch[path]];
    } else if (typeof watch[path] === "undefined") {
      watch[path] = [];
    }
    watch[path].push(Object.assign({ handler }, watchOptions));
  });
}
export {
  Emit,
  Inject,
  Model,
  Options,
  Prop,
  Provide,
  Ref,
  Vue,
  Watch,
  mixins
};
//# sourceMappingURL=vue-property-decorator.js.map
