import {
  Options,
  Vue,
  createDecorator,
  mixins,
  prop,
  setup
} from "./chunk-UHG5UZPX.js";
import "./chunk-S7PK7LHJ.js";
import "./chunk-SB46YUIN.js";
export {
  Options,
  Vue,
  createDecorator,
  mixins,
  prop,
  setup
};
//# sourceMappingURL=vue-class-component.js.map
