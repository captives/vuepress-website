/**
 * 语言选择，排除首页
 */
export default {
    '/guide/': {
        lang: 'guide',
        title: '学习指南',
        description: 'captives.github.io',
    },
    '/poetry/': {
        lang: 'poetry',
        title: '古诗词',
        description: 'captives.github.io',
    }
}