// 导航菜单区域
export default [{
    text: '帮助',
    children: [
        { text: 'markdown语法', link: '/markdown' },
        { text: 'markdown语法', link: '/markdown' },
        { text: 'markdown语法', link: '/markdown' },
    ]
}]