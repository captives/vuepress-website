# Vue props 对象

```js
props: {
    // 基础的类型检查 (`null` 匹配任何类型)
    propA: Number,
    // 多个可能的类型
    propB: [String, Number],
    // 必填的字符串
    propC: {
      type: String,
      required: true
    },
    // 带有默认值的数字
    propD: {
      type: Number,
      default: 100
    },
    // 带有默认值的对象
    propE: {
      type: Object,
      // 对象或数组且一定会从一个工厂函数返回默认值
      default: function () {
        return { message: 'hello' };
      }
    },
    // 自定义验证函数
    propF: {
      type: String,
      validator: function (t) {
        // 这个值必须匹配下列字符串中的一个
        return t === 'fade' || t === 'slide';
      },
      defalut:'slide'
    }
```

