# Vue 学习资源收藏

## Vue 2 生态相关

## Vue 3 生态相关


::: details Vite介绍
[Vite](https://cn.vitejs.dev/guide/why.html)（法语意思是 “快”，发音为 /vit/，类似 veet）是一种全新的前端构建工具。你可以把它理解为一个开箱即用的开发服务器 + 打包工具的组合，但是更轻更快。Vite 利用浏览器原生的 ES 模块支持和用编译到原生的语言开发的工具（如 esbuild）来提供一个快速且现代的开发体验。

Vite 有多快？在 Repl.it 上从零启动一个基于 Vite 的 React 应用，浏览器页面加载完毕的时候，CRA（create-react-app）甚至还没有装完依赖。

如果你还没听说过 Vite 到底是什么，可以到这里了解一下项目的设计初衷。如果你想要了解 Vite 跟其它一些类似的工具有什么区别，可以参考这里的对比。
:::


## PPT模板下载站点
[www.1ppt.com](http://www.1ppt.com/)
[www.51pptmoban.com](http://www.51pptmoban.com/)

<hr/>
