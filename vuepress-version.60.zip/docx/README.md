---
home: true
title: Home
heroImage: ./assets/images/logo.svg
actions:
  - text: Get Started
    link: /guide
    type: primary
  - text: GitHub →
    link: https://www.github.com/captives
    type: secondary
features:
- title: Guide
  details: 代码片段
- title: Poetry
  details: 古诗词系列
- title: Tutorial
  details: 教程系列
footer: MIT Licensed | Copyright © 2018-present Evan You
---

<!-- <h2>{{title}}</h2> -->
<!-- <NpmBadge></NpmBadge> -->
注释： 全局组件
<!-- <VueSite>{{title}}</VueSite> -->